// -----// IR Dump After AppendUsePrintDebugData (append-use-print-debug-data) //----- //
module attributes {dlti.target_system_spec = #dlti.target_system_spec<"NPU" : #hacc.target_device_spec<#dlti.dl_entry<"AI_CORE_COUNT", 28 : i32>, #dlti.dl_entry<"CUBE_CORE_COUNT", 28 : i32>, #dlti.dl_entry<"VECTOR_CORE_COUNT", 56 : i32>, #dlti.dl_entry<"UB_SIZE", 2031616 : i32>, #dlti.dl_entry<"L1_SIZE", 4194304 : i32>, #dlti.dl_entry<"L0A_SIZE", 524288 : i32>, #dlti.dl_entry<"L0B_SIZE", 524288 : i32>, #dlti.dl_entry<"L0C_SIZE", 2097152 : i32>, #dlti.dl_entry<"UB_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L1_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L0C_ALIGN_SIZE", 4096 : i32>, #dlti.dl_entry<"MINIMAL_D_CACHE_SIZE", 262144 : i32>, #dlti.dl_entry<"MAXIMUM_D_CACHE_SIZE", 983040 : i32>, #dlti.dl_entry<"ARCH", "dav-c310">>>, hacc.target = #hacc.target<"Ascend950PR_957b">, hivm.aic_bitcode = #hivm.aic_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.aic.c310.bc">, hivm.aiv_bitcode = #hivm.aiv_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.aiv.c310.bc">, hivm.host_bitcode = #hivm.host_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/host-a5.bc">, hivm.mix_aic_bitcode = #hivm.mix_aic_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.mix.aic.c310.bc">, hivm.mix_aiv_bitcode = #hivm.mix_aiv_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.mix.aiv.c310.bc">, hivm.module_core_type = #hivm.module_core_type<MIX>} {
  llvm.func @paged_prefill_small_q_grouped_kernel_outlined_merged_vf_0(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(16 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(6 : i32) : i32
    %4 = llvm.mlir.constant(2 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(1114112 : i32) : i32
    %7 = llvm.mlir.constant(64 : index) : i64
    %8 = llvm.mlir.constant(16 : index) : i64
    %9 = llvm.mlir.constant(272 : index) : i64
    %10 = llvm.mlir.constant(0 : index) : i64
    %11 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %2) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %12 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %13 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %14 = "hivm_regbaseintrins.intr.hivm.vsub.s.x"(%12, %13, %11) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%14, %arg2, %2, %4, %2, %11) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.br ^bb1(%2 : i32)
  ^bb1(%15: i32):  // 2 preds: ^bb0, ^bb2
    %16 = llvm.icmp "slt" %15, %1 : i32
    llvm.cond_br %16, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %17 = llvm.sext %15 : i32 to i64
    %18 = llvm.mul %17, %7 : i64
    %19 = llvm.getelementptr %arg3[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %20 = llvm.mul %10, %7 : i64
    %21 = llvm.add %20, %10 : i64
    %22 = llvm.getelementptr %19[%21] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %23 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%22, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %24 = llvm.mul %17, %8 : i64
    %25 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%5, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %26 = llvm.getelementptr %arg4[%24] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %27 = llvm.mul %10, %9 : i64
    %28 = llvm.add %27, %10 : i64
    %29 = llvm.getelementptr %26[%28] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vsstb.v128bf16"(%23, %29, %6, %2, %25) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, vector<256xi1>) -> ()
    %30 = llvm.add %15, %0 overflow<nsw> : i32
    llvm.br ^bb1(%30 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_small_q_grouped_kernel_outlined_vf_0(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: f32, %arg5: i32, %arg6: f32, %arg7: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(16 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(1 : i8) : i8
    %4 = llvm.mlir.constant(0 : i8) : i8
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(256 : i32) : i32
    %7 = llvm.mlir.constant(1.000000e+00 : f16) : f16
    %8 = llvm.mlir.constant(0.000000e+00 : f16) : f16
    %9 = llvm.mlir.constant(-1.000000e+00 : f16) : f16
    %10 = llvm.mlir.constant(-1.000000e+06 : f32) : f32
    %11 = llvm.mlir.constant(8 : index) : i64
    %12 = llvm.mlir.constant(2 : i32) : i32
    %13 = llvm.mlir.constant(1 : index) : i64
    %14 = llvm.mlir.constant(64 : index) : i64
    %15 = llvm.mlir.constant(0 : index) : i64
    %16 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %17 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%10, %16, %0) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %18 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %19 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%9, %18, %0) : (f16, vector<256xi1>, i32) -> vector<128xf16>
    %20 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %21 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%8, %20, %0) : (f16, vector<256xi1>, i32) -> vector<128xf16>
    %22 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %23 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%8, %22, %0) : (f16, vector<256xi1>, i32) -> vector<128xf16>
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%7, %24, %0) : (f16, vector<256xi1>, i32) -> vector<128xf16>
    llvm.br ^bb1(%2 : i32)
  ^bb1(%26: i32):  // 2 preds: ^bb0, ^bb2
    %27 = llvm.icmp "slt" %26, %1 : i32
    llvm.cond_br %27, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %28 = llvm.sext %26 : i32 to i64
    %29 = llvm.trunc %28 : i64 to i32
    %30 = llvm.sdiv %29, %6  : i32
    %31 = llvm.mul %30, %6 : i32
    %32 = llvm.sub %29, %31 : i32
    %33 = llvm.sdiv %31, %5  : i32
    %34 = llvm.sext %33 : i32 to i64
    %35 = llvm.sext %32 : i32 to i64
    %36 = llvm.udiv %15, %11  : i64
    %37 = llvm.getelementptr %arg0[%36] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %38 = llvm.getelementptr %37[%34] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %39 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%38, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %40 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) {mask_bit_width = 8 : i32} : (i32, i32) -> vector<256xi1>
    %41 = "hivm_regbaseintrins.intr.hivm.vbr"(%4) : (i8) -> vector<256xi8>
    %42 = "hivm_regbaseintrins.intr.hivm.vbr"(%3) : (i8) -> vector<256xi8>
    %43 = "hivm_regbaseintrins.intr.hivm.vsel"(%42, %41, %39) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %44 = llvm.add %35, %13 : i64
    %45 = llvm.trunc %44 : i64 to i32
    %46 = "hivm_regbaseintrins.intr.hivm.plt.b8.v300"(%45) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %47 = llvm.extractvalue %46[0] {mask_bit_width = 8 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %48 = llvm.trunc %35 : i64 to i32
    %49 = "hivm_regbaseintrins.intr.hivm.plt.b8.v300"(%48) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %50 = llvm.extractvalue %49[0] {mask_bit_width = 8 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %51 = "hivm_regbaseintrins.intr.hivm.pxor.z"(%47, %50, %40) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %52 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) {mask_bit_width = 8 : i32} : (i32, i32) -> vector<256xi1>
    %53 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%4, %52, %0) : (i8, vector<256xi1>, i32) -> vector<256xi8>
    %54 = "hivm_regbaseintrins.intr.hivm.vor.x"(%43, %53, %51) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %55 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) {mask_bit_width = 8 : i32} : (i32, i32) -> vector<256xi1>
    %56 = "hivm_regbaseintrins.intr.hivm.vintlv"(%54, %53) : (vector<256xi8>, vector<256xi8>) -> !llvm.struct<(vector<256xi8>, vector<256xi8>)>
    %57 = llvm.extractvalue %56[0] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %58 = llvm.extractvalue %56[1] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %59 = "hivm_regbaseintrins.intr.hivm.vxor.x"(%57, %58, %55) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %60 = "hivm_regbaseintrins.intr.hivm.vintlv"(%59, %53) : (vector<256xi8>, vector<256xi8>) -> !llvm.struct<(vector<256xi8>, vector<256xi8>)>
    %61 = llvm.extractvalue %60[0] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %62 = llvm.extractvalue %60[1] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %63 = "hivm_regbaseintrins.intr.hivm.vxor.x"(%61, %62, %55) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %64 = "hivm_regbaseintrins.intr.hivm.vintlv"(%63, %53) : (vector<256xi8>, vector<256xi8>) -> !llvm.struct<(vector<256xi8>, vector<256xi8>)>
    %65 = llvm.extractvalue %64[0] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %66 = llvm.extractvalue %64[1] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %67 = "hivm_regbaseintrins.intr.hivm.vxor.x"(%65, %66, %55) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %68 = "hivm_regbaseintrins.intr.hivm.vintlv"(%67, %53) : (vector<256xi8>, vector<256xi8>) -> !llvm.struct<(vector<256xi8>, vector<256xi8>)>
    %69 = llvm.extractvalue %68[0] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %70 = llvm.extractvalue %68[1] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %71 = "hivm_regbaseintrins.intr.hivm.vxor.x"(%69, %70, %55) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %72 = "hivm_regbaseintrins.intr.hivm.vintlv"(%71, %53) : (vector<256xi8>, vector<256xi8>) -> !llvm.struct<(vector<256xi8>, vector<256xi8>)>
    %73 = llvm.extractvalue %72[0] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %74 = llvm.extractvalue %72[1] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %75 = "hivm_regbaseintrins.intr.hivm.vxor.x"(%73, %74, %55) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %76 = "hivm_regbaseintrins.intr.hivm.vintlv"(%75, %53) : (vector<256xi8>, vector<256xi8>) -> !llvm.struct<(vector<256xi8>, vector<256xi8>)>
    %77 = llvm.extractvalue %76[0] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %78 = llvm.extractvalue %76[1] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %79 = "hivm_regbaseintrins.intr.hivm.vxor.x"(%77, %78, %55) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %80 = "hivm_regbaseintrins.intr.hivm.vintlv"(%79, %53) : (vector<256xi8>, vector<256xi8>) -> !llvm.struct<(vector<256xi8>, vector<256xi8>)>
    %81 = llvm.extractvalue %80[0] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %82 = llvm.extractvalue %80[1] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %83 = "hivm_regbaseintrins.intr.hivm.vxor.x"(%81, %82, %55) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %84 = "hivm_regbaseintrins.intr.hivm.vintlv"(%83, %53) : (vector<256xi8>, vector<256xi8>) -> !llvm.struct<(vector<256xi8>, vector<256xi8>)>
    %85 = llvm.extractvalue %84[0] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %86 = llvm.extractvalue %84[1] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %87 = "hivm_regbaseintrins.intr.hivm.vxor.x"(%85, %86, %55) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %88 = "hivm_regbaseintrins.intr.hivm.vdup.z"(%87, %40, %0) : (vector<256xi8>, vector<256xi1>, i32) -> vector<256xi8>
    %89 = "hivm_regbaseintrins.intr.hivm.vcmp.ne.s.z"(%88, %41, %40) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi1>
    %90 = "hivm_regbaseintrins.intr.hivm.punpack"(%89, %2) : (vector<256xi1>, i32) -> vector<256xi1>
    %91 = "hivm_regbaseintrins.intr.hivm.punpack"(%90, %2) : (vector<256xi1>, i32) -> vector<256xi1>
    %92 = "hivm_regbaseintrins.intr.hivm.vsel"(%25, %23, %91) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    %93 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %94 = "hivm_regbaseintrins.intr.hivm.vdup.z"(%92, %93, %0) : (vector<128xf16>, vector<256xi1>, i32) -> vector<128xf16>
    %95 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %96 = "hivm_regbaseintrins.intr.hivm.vcmp.ne.s.z"(%94, %21, %95) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<256xi1>
    %97 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64s32"(%arg3, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xi32>
    %98 = llvm.mul %28, %14 : i64
    %99 = llvm.getelementptr %arg1[%98] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %100 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%99, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %101 = llvm.mul %28, %14 : i64
    %102 = llvm.getelementptr %arg2[%101] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %103 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%102, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %104 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %105 = "hivm_regbaseintrins.intr.hivm.vmuls.s.x"(%103, %arg4, %104) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %106 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg5) : (i32) -> vector<64xi32>
    %107 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %108 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%106, %97, %107) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    %109 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %110 = "hivm_regbaseintrins.intr.hivm.vcvtif.s322f32.x"(%108, %109, %2) : (vector<64xi32>, vector<256xi1>, i32) -> vector<64xf32>
    %111 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %112 = "hivm_regbaseintrins.intr.hivm.vcmp.le.s.z"(%110, %100, %111) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %113 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg6) : (f32) -> vector<64xf32>
    %114 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %115 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%110, %113, %114) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %116 = "hivm_regbaseintrins.intr.hivm.vsel"(%19, %21, %115) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    %117 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %118 = "hivm_regbaseintrins.intr.hivm.vcmp.ne.s.z"(%116, %21, %117) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<256xi1>
    %119 = "hivm_regbaseintrins.intr.hivm.vsel"(%19, %21, %96) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    %120 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %121 = "hivm_regbaseintrins.intr.hivm.vcmp.ne.s.z"(%119, %21, %120) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<256xi1>
    %122 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %123 = "hivm_regbaseintrins.intr.hivm.pand.z"(%121, %118, %122) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %124 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %125 = "hivm_regbaseintrins.intr.hivm.pand.z"(%123, %112, %124) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %126 = "hivm_regbaseintrins.intr.hivm.vsel"(%105, %17, %125) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %127 = llvm.mul %28, %14 : i64
    %128 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %129 = llvm.getelementptr %arg7[%127] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%126, %129, %2, %12, %2, %128) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %130 = llvm.add %26, %0 overflow<nsw> : i32
    llvm.br ^bb1(%130 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_small_q_grouped_kernel_outlined_vf_1(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(0 : i32) : i32
    %1 = llvm.mlir.constant(16 : i32) : i32
    %2 = llvm.mlir.constant(1 : i32) : i32
    %3 = llvm.mlir.constant(8 : i32) : i32
    %4 = llvm.mlir.constant(4 : i32) : i32
    %5 = llvm.mlir.constant(6 : i32) : i32
    %6 = llvm.mlir.constant(2 : i32) : i32
    %7 = llvm.mlir.undef : !llvm.ptr<6>
    %8 = llvm.mlir.constant(64 : index) : i64
    %9 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%0, %9, %7 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%10: i32, %11: vector<32xi8>, %12: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %13 = llvm.icmp "slt" %10, %1 : i32
    llvm.cond_br %13, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %14 = llvm.sext %10 : i32 to i64
    %15 = llvm.mul %14, %8 : i64
    %16 = llvm.getelementptr %arg0[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %17 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%16, %0, %0, %0) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %18 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %19 = "hivm_regbaseintrins.intr.hivm.vcmax.s.x"(%17, %18) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %20 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %21 = llvm.getelementptr %arg1[%14] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %22 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%19, %21, %4, %11) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %23 = llvm.extractvalue %22[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %24 = llvm.extractvalue %22[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %25 = llvm.add %10, %2 overflow<nsw> : i32
    llvm.br ^bb1(%25, %23, %24 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%11, %12, %0, %0) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %0) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %27 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg2, %0, %0, %0) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %28 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %0, %0, %0) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %29 = "hivm_regbaseintrins.intr.hivm.vmax.s.x"(%27, %28, %26) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%29, %arg3, %0, %6, %0, %26) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_small_q_grouped_kernel_outlined_vf_2(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(16 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %4 = llvm.mlir.constant(3 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(7 : i32) : i32
    %7 = llvm.mlir.constant(4 : i32) : i32
    %8 = llvm.mlir.undef : !llvm.ptr<6>
    %9 = llvm.mlir.constant(64 : index) : i64
    %10 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %10, %8 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%11: i32, %12: vector<32xi8>, %13: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %14 = llvm.icmp "slt" %11, %1 : i32
    llvm.cond_br %14, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %15 = llvm.sext %11 : i32 to i64
    %16 = llvm.mul %15, %9 : i64
    %17 = llvm.getelementptr %arg0[%16] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %18 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%17, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %19 = llvm.getelementptr %arg1[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %20 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%19, %2, %4, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%18, %20, %21, %2) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %23 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %24 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%22, %23, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %25 = llvm.mul %15, %9 : i64
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %27 = llvm.getelementptr %arg2[%25] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%24, %27, %2, %6, %2, %26) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%22, %3, %28) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %30 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %31 = "hivm_regbaseintrins.intr.hivm.vcadd.s.x"(%29, %30) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %32 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %33 = llvm.getelementptr %arg3[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %34 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%31, %33, %7, %12) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %35 = llvm.extractvalue %34[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %36 = llvm.extractvalue %34[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %37 = llvm.add %11, %0 overflow<nsw> : i32
    llvm.br ^bb1(%37, %35, %36 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%12, %13, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_small_q_grouped_kernel_outlined_vf_5(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %1) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %4 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %5 = "hivm_regbaseintrins.intr.hivm.vexp.x"(%4, %3) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%5, %arg1, %1, %2, %1, %3) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_small_q_grouped_kernel_outlined_vf_6(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(64 : i32) : i32
    %1 = llvm.mlir.constant(256 : i32) : i32
    %2 = llvm.mlir.constant(1 : i32) : i32
    %3 = llvm.mlir.constant(16 : i32) : i32
    %4 = llvm.mlir.constant(0 : i32) : i32
    %5 = llvm.mlir.constant(6 : i32) : i32
    %6 = llvm.mlir.constant(2 : i32) : i32
    %7 = llvm.mlir.constant(3 : i32) : i32
    %8 = llvm.mlir.constant(8 : i32) : i32
    %9 = llvm.mlir.constant(256 : index) : i64
    %10 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %4) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %11 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %12 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %13 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg2, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %14 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%11, %12, %10) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %15 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%14, %13, %10) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%15, %arg3, %4, %6, %4, %10) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.br ^bb1(%4 : i32)
  ^bb1(%16: i32):  // 2 preds: ^bb0, ^bb5
    %17 = llvm.icmp "slt" %16, %3 : i32
    llvm.cond_br %17, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %16 : i32 to i64
    llvm.br ^bb3(%4 : i32)
  ^bb3(%19: i32):  // 2 preds: ^bb2, ^bb4
    %20 = llvm.icmp "slt" %19, %1 : i32
    llvm.cond_br %20, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %21 = llvm.sext %19 : i32 to i64
    %22 = llvm.mul %18, %9 : i64
    %23 = llvm.add %22, %21 : i64
    %24 = llvm.getelementptr %arg4[%23] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %25 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%24, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %26 = llvm.mul %18, %9 : i64
    %27 = llvm.add %26, %21 : i64
    %28 = llvm.getelementptr %arg5[%27] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %29 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%28, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %30 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %31 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%30, %4, %7, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %32 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %33 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%29, %31, %32) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %34 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %35 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%25, %33, %34) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %36 = llvm.mul %18, %9 : i64
    %37 = llvm.add %36, %21 : i64
    %38 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %39 = llvm.getelementptr %arg6[%37] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%35, %39, %4, %6, %4, %38) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %40 = llvm.add %19, %0 overflow<nsw> : i32
    llvm.br ^bb3(%40 : i32)
  ^bb5:  // pred: ^bb3
    %41 = llvm.add %16, %2 overflow<nsw> : i32
    llvm.br ^bb1(%41 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_small_q_grouped_kernel_outlined_vf_7(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(8 : i32) : i32
    %3 = llvm.mlir.constant(1 : i32) : i32
    %4 = llvm.mlir.constant(2 : i32) : i32
    %5 = "hivm_regbaseintrins.intr.hivm.vci"(%1, %1) : (i32, i32) -> vector<64xi32>
    %6 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %1) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %7 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%1, %6, %3) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %8 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %1) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %9 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%0, %8, %3) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %10 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %1) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %11 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%7, %5, %10) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64s32"(%11, %arg0, %1, %4, %1, %10) : (vector<64xi32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %12 = llvm.call @_mlir_ciface_vdiv_int32_t(%11, %9, %10) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64s32"(%12, %arg1, %1, %4, %1, %10) : (vector<64xi32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_small_q_grouped_kernel_outlined_vf_8(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: f32, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(12 : i32) : i32
    %1 = llvm.mlir.constant(8 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(1 : i32) : i32
    %4 = llvm.mlir.constant(6 : i32) : i32
    %5 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %6 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%0, %5, %3) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %7 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%4, %2) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %8 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64s32"(%arg0, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xi32>
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64s32"(%arg1, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xi32>
    %10 = "hivm_regbaseintrins.intr.hivm.vcvtif.s322f32.x"(%9, %7, %2) : (vector<64xi32>, vector<256xi1>, i32) -> vector<64xf32>
    %11 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg2) : (f32) -> vector<64xf32>
    %12 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%10, %11, %7) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %13 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%8, %6, %7) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<256xi1>
    %14 = "hivm_regbaseintrins.intr.hivm.pand.z"(%13, %12, %7) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %15 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %16 = "hivm_regbaseintrins.intr.hivm.pstu.b32"(%14, %arg3, %15) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %17 = llvm.extractvalue %16[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %18 = llvm.extractvalue %16[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%17, %18, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_small_q_grouped_kernel_outlined_vf_9(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: f32, %arg4: f32, %arg5: f32, %arg6: f32, %arg7: f32, %arg8: f32, %arg9: !llvm.ptr<6>, %arg10: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(5 : i32) : i32
    %2 = llvm.mlir.constant(4 : i32) : i32
    %3 = llvm.mlir.constant(3 : i32) : i32
    %4 = llvm.mlir.constant(2 : i32) : i32
    %5 = llvm.mlir.constant(1 : i32) : i32
    %6 = llvm.mlir.constant(0xFF800000 : f32) : f32
    %7 = llvm.mlir.constant(1.000000e+00 : f32) : f32
    %8 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %9 = llvm.mlir.constant(8 : i32) : i32
    %10 = llvm.mlir.constant(0 : i32) : i32
    %11 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%9, %10) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %12 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%8, %11, %5) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %13 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%9, %10) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %14 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%7, %13, %5) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %15 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%9, %10) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %16 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%6, %15, %5) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %17 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%9, %10) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %18 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%5, %17, %5) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %19 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%9, %10) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %20 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%4, %19, %5) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%9, %10) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%3, %21, %5) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %23 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%9, %10) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %24 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%2, %23, %5) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %25 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%9, %10) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %26 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%1, %25, %5) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %27 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %10) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %28 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%arg0, %10, %10, %10) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %29 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%10, %10) : (i32, i32) -> vector<256xi1>
    %30 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%28, %29) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %31 = llvm.extractvalue %30[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %32 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%31, %29) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %33 = llvm.extractvalue %32[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %34 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64s32"(%arg1, %10, %10, %10) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xi32>
    %35 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64s32"(%arg2, %10, %10, %10) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xi32>
    %36 = "hivm_regbaseintrins.intr.hivm.vmuls.s.x"(%35, %0, %27) : (vector<64xi32>, i32, vector<256xi1>) -> vector<64xi32>
    %37 = "hivm_regbaseintrins.intr.hivm.vsub.s.x"(%34, %36, %27) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    %38 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%37, %26, %27) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<256xi1>
    %39 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg3) : (f32) -> vector<64xf32>
    %40 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg4) : (f32) -> vector<64xf32>
    %41 = "hivm_regbaseintrins.intr.hivm.vsel"(%39, %40, %38) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %42 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%37, %24, %27) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<256xi1>
    %43 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg5) : (f32) -> vector<64xf32>
    %44 = "hivm_regbaseintrins.intr.hivm.vsel"(%43, %41, %42) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %45 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%37, %22, %27) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<256xi1>
    %46 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg6) : (f32) -> vector<64xf32>
    %47 = "hivm_regbaseintrins.intr.hivm.vsel"(%46, %44, %45) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %48 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%37, %20, %27) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<256xi1>
    %49 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg7) : (f32) -> vector<64xf32>
    %50 = "hivm_regbaseintrins.intr.hivm.vsel"(%49, %47, %48) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %51 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%37, %18, %27) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<256xi1>
    %52 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg8) : (f32) -> vector<64xf32>
    %53 = "hivm_regbaseintrins.intr.hivm.vsel"(%52, %50, %51) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %54 = "hivm_regbaseintrins.intr.hivm.vsel"(%53, %16, %33) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%54, %arg9, %10, %4, %10, %27) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %55 = "hivm_regbaseintrins.intr.hivm.vsel"(%14, %12, %33) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%55, %arg10, %10, %4, %10, %27) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_small_q_grouped_kernel_outlined_vf_10(%arg0: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(0 : i32) : i32
    %1 = llvm.mlir.constant(8 : i32) : i32
    %2 = llvm.mlir.constant(1 : i32) : i32
    %3 = llvm.mlir.constant(2 : i32) : i32
    %4 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %5 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%0, %4, %2) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %6 = "hivm_regbaseintrins.intr.hivm.vci"(%0, %0) : (i32, i32) -> vector<64xi32>
    %7 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %8 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%5, %6, %7) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    %9 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64s32"(%8, %arg0, %0, %3, %0, %9) : (vector<64xi32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_small_q_grouped_kernel_outlined_vf_11(%arg0: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(64 : index) : i64
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(1 : i64) : i64
    %3 = llvm.mlir.constant(0 : i64) : i64
    %4 = llvm.mlir.constant(16 : i32) : i32
    %5 = llvm.mlir.constant(1 : i32) : i32
    %6 = llvm.mlir.constant(256 : i32) : i32
    %7 = llvm.mlir.constant(64 : i32) : i32
    %8 = llvm.mlir.constant(8 : i32) : i32
    %9 = llvm.mlir.constant(1 : index) : i64
    %10 = llvm.mlir.constant(256 : index) : i64
    %11 = "hivm_regbaseintrins.intr.hivm.vci"(%1, %1) : (i32, i32) -> vector<64xi32>
    llvm.br ^bb1(%1 : i32)
  ^bb1(%12: i32):  // 2 preds: ^bb0, ^bb5
    %13 = llvm.icmp "slt" %12, %4 : i32
    llvm.cond_br %13, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %14 = llvm.sext %12 : i32 to i64
    llvm.br ^bb3(%1 : i32)
  ^bb3(%15: i32):  // 2 preds: ^bb2, ^bb4
    %16 = llvm.icmp "slt" %15, %6 : i32
    llvm.cond_br %16, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %17 = llvm.sext %15 : i32 to i64
    %18 = llvm.trunc %17 : i64 to i32
    %19 = "hivm_regbaseintrins.intr.hivm.vbr"(%18) : (i32) -> vector<64xi32>
    %20 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %1) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %21 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%19, %11, %20) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    %22 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %1) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %23 = llvm.alloca %2 x !llvm.struct<"vector_2xvl_s64", (array<2 x vector<64xi32>>)> : (i64) -> !llvm.ptr
    llvm.call @_mlir_ciface_cast_int32_t_to_int64_t(%23, %21, %22) : (!llvm.ptr, vector<64xi32>, vector<256xi1>) -> ()
    %24 = llvm.mul %14, %10 : i64
    %25 = llvm.add %24, %17 : i64
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %1) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    llvm.call @masked_store_NORM_B64_int64_t_rank1(%arg0, %arg0, %25, %0, %9, %3, %26, %23) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, vector<256xi1>, !llvm.ptr) -> ()
    %27 = llvm.add %15, %7 overflow<nsw> : i32
    llvm.br ^bb3(%27 : i32)
  ^bb5:  // pred: ^bb3
    %28 = llvm.add %12, %5 overflow<nsw> : i32
    llvm.br ^bb1(%28 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_small_q_grouped_kernel_outlined_vf_12(%arg0: !llvm.ptr<6>, %arg1: i32, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: i32, %arg6: i64, %arg7: !llvm.ptr<6>, %arg8: !llvm.ptr<6>, %arg9: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(256 : i32) : i32
    %1 = llvm.mlir.constant(8 : i32) : i32
    %2 = llvm.mlir.constant(0 : i8) : i8
    %3 = llvm.mlir.constant(1 : i8) : i8
    %4 = llvm.mlir.constant(1 : i64) : i64
    %5 = llvm.mlir.constant(0 : i64) : i64
    %6 = llvm.mlir.constant(16 : i32) : i32
    %7 = llvm.mlir.constant(64 : i32) : i32
    %8 = llvm.mlir.constant(1.000000e+00 : f16) : f16
    %9 = llvm.mlir.constant(0.000000e+00 : f16) : f16
    %10 = llvm.mlir.constant(1 : i32) : i32
    %11 = llvm.mlir.constant(0 : i32) : i32
    %12 = llvm.mlir.constant(3 : i32) : i32
    %13 = llvm.mlir.constant(2 : i32) : i32
    %14 = llvm.mlir.constant(8 : index) : i64
    %15 = llvm.mlir.constant(12 : i32) : i32
    %16 = llvm.mlir.constant(64 : index) : i64
    %17 = llvm.mlir.constant(1 : index) : i64
    %18 = llvm.mlir.constant(256 : index) : i64
    %19 = llvm.mlir.constant(0 : index) : i64
    %20 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %11) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %21 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%11, %20, %10) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %22 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %11) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %23 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%10, %22, %10) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %11) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%9, %24, %10) : (f16, vector<256xi1>, i32) -> vector<128xf16>
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%10, %11) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %27 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%9, %26, %10) : (f16, vector<256xi1>, i32) -> vector<128xf16>
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%10, %11) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%8, %28, %10) : (f16, vector<256xi1>, i32) -> vector<128xf16>
    llvm.br ^bb1(%11 : i32)
  ^bb1(%30: i32):  // 2 preds: ^bb0, ^bb5
    %31 = llvm.icmp "slt" %30, %6 : i32
    llvm.cond_br %31, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %32 = llvm.sext %30 : i32 to i64
    %33 = llvm.getelementptr %arg0[%32] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i32
    %34 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64s32"(%33, %11, %12, %11) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xi32>
    %35 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg1) : (i32) -> vector<64xi32>
    %36 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %11) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %37 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%35, %34, %36) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    %38 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %11) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %39 = "hivm_regbaseintrins.intr.hivm.vcvtif.s322f32.x"(%37, %38, %11) : (vector<64xi32>, vector<256xi1>, i32) -> vector<64xf32>
    %40 = llvm.mul %32, %16 : i64
    %41 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %11) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %42 = llvm.getelementptr %arg7[%40] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%39, %42, %11, %13, %11, %41) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.br ^bb3(%11 : i32)
  ^bb3(%43: i32):  // 2 preds: ^bb2, ^bb4
    %44 = llvm.icmp "slt" %43, %0 : i32
    llvm.cond_br %44, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %45 = llvm.sext %43 : i32 to i64
    %46 = llvm.getelementptr %arg2[%32] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i32
    %47 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64s32"(%46, %11, %12, %11) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xi32>
    %48 = llvm.mul %32, %18 : i64
    %49 = llvm.add %48, %45 : i64
    %50 = llvm.alloca %4 x !llvm.struct<"vector_2xvl_s64", (array<2 x vector<64xi32>>)> : (i64) -> !llvm.ptr
    llvm.call @vload_NORM_int64_t_rank1(%50, %arg4, %arg4, %49, %16, %17, %5) : (!llvm.ptr, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64) -> ()
    %51 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %11) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %52 = "hivm_regbaseintrins.intr.hivm.vmuls.s.x"(%47, %arg5, %51) : (vector<64xi32>, i32, vector<256xi1>) -> vector<64xi32>
    %53 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %11) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %54 = llvm.alloca %4 x !llvm.struct<"vector_2xvl_s64", (array<2 x vector<64xi32>>)> : (i64) -> !llvm.ptr
    llvm.call @_mlir_ciface_cast_int32_t_to_int64_t(%54, %52, %53) : (!llvm.ptr, vector<64xi32>, vector<256xi1>) -> ()
    %55 = llvm.alloca %4 x !llvm.struct<"vector_2xvl_s64", (array<2 x vector<64xi32>>)> : (i64) -> !llvm.ptr
    llvm.call @_mlir_ciface_vbr_int64_t(%55, %arg6) : (!llvm.ptr, i64) -> ()
    %56 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %11) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %57 = llvm.alloca %4 x !llvm.struct<"vector_2xvl_s64", (array<2 x vector<64xi32>>)> : (i64) -> !llvm.ptr
    llvm.call @_mlir_ciface_vadd_int64_t(%57, %55, %54, %56) : (!llvm.ptr, !llvm.ptr, !llvm.ptr, vector<256xi1>) -> ()
    %58 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %11) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %59 = llvm.alloca %4 x !llvm.struct<"vector_2xvl_s64", (array<2 x vector<64xi32>>)> : (i64) -> !llvm.ptr
    llvm.call @_mlir_ciface_vadd_int64_t(%59, %57, %50, %58) : (!llvm.ptr, !llvm.ptr, !llvm.ptr, vector<256xi1>) -> ()
    %60 = llvm.mul %32, %18 : i64
    %61 = llvm.add %60, %45 : i64
    %62 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %11) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    llvm.call @masked_store_NORM_B64_int64_t_rank1(%arg8, %arg8, %61, %16, %17, %5, %62, %59) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, vector<256xi1>, !llvm.ptr) -> ()
    %63 = llvm.trunc %32 : i64 to i32
    %64 = llvm.sdiv %63, %0  : i32
    %65 = llvm.mul %64, %0 : i32
    %66 = llvm.sub %63, %65 : i32
    %67 = llvm.sdiv %65, %1  : i32
    %68 = llvm.sext %67 : i32 to i64
    %69 = llvm.sext %66 : i32 to i64
    %70 = llvm.udiv %19, %14  : i64
    %71 = llvm.getelementptr %arg3[%70] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %72 = llvm.getelementptr %71[%68] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %73 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%72, %11, %11, %11) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %74 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%11, %11) {mask_bit_width = 8 : i32} : (i32, i32) -> vector<256xi1>
    %75 = "hivm_regbaseintrins.intr.hivm.vbr"(%2) : (i8) -> vector<256xi8>
    %76 = "hivm_regbaseintrins.intr.hivm.vbr"(%3) : (i8) -> vector<256xi8>
    %77 = "hivm_regbaseintrins.intr.hivm.vsel"(%76, %75, %73) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %78 = llvm.add %69, %17 : i64
    %79 = llvm.trunc %78 : i64 to i32
    %80 = "hivm_regbaseintrins.intr.hivm.plt.b8.v300"(%79) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %81 = llvm.extractvalue %80[0] {mask_bit_width = 8 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %82 = llvm.trunc %69 : i64 to i32
    %83 = "hivm_regbaseintrins.intr.hivm.plt.b8.v300"(%82) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %84 = llvm.extractvalue %83[0] {mask_bit_width = 8 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %85 = "hivm_regbaseintrins.intr.hivm.pxor.z"(%81, %84, %74) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %86 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%11, %11) {mask_bit_width = 8 : i32} : (i32, i32) -> vector<256xi1>
    %87 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%2, %86, %10) : (i8, vector<256xi1>, i32) -> vector<256xi8>
    %88 = "hivm_regbaseintrins.intr.hivm.vor.x"(%77, %87, %85) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %89 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%11, %11) {mask_bit_width = 8 : i32} : (i32, i32) -> vector<256xi1>
    %90 = "hivm_regbaseintrins.intr.hivm.vintlv"(%88, %87) : (vector<256xi8>, vector<256xi8>) -> !llvm.struct<(vector<256xi8>, vector<256xi8>)>
    %91 = llvm.extractvalue %90[0] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %92 = llvm.extractvalue %90[1] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %93 = "hivm_regbaseintrins.intr.hivm.vxor.x"(%91, %92, %89) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %94 = "hivm_regbaseintrins.intr.hivm.vintlv"(%93, %87) : (vector<256xi8>, vector<256xi8>) -> !llvm.struct<(vector<256xi8>, vector<256xi8>)>
    %95 = llvm.extractvalue %94[0] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %96 = llvm.extractvalue %94[1] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %97 = "hivm_regbaseintrins.intr.hivm.vxor.x"(%95, %96, %89) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %98 = "hivm_regbaseintrins.intr.hivm.vintlv"(%97, %87) : (vector<256xi8>, vector<256xi8>) -> !llvm.struct<(vector<256xi8>, vector<256xi8>)>
    %99 = llvm.extractvalue %98[0] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %100 = llvm.extractvalue %98[1] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %101 = "hivm_regbaseintrins.intr.hivm.vxor.x"(%99, %100, %89) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %102 = "hivm_regbaseintrins.intr.hivm.vintlv"(%101, %87) : (vector<256xi8>, vector<256xi8>) -> !llvm.struct<(vector<256xi8>, vector<256xi8>)>
    %103 = llvm.extractvalue %102[0] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %104 = llvm.extractvalue %102[1] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %105 = "hivm_regbaseintrins.intr.hivm.vxor.x"(%103, %104, %89) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %106 = "hivm_regbaseintrins.intr.hivm.vintlv"(%105, %87) : (vector<256xi8>, vector<256xi8>) -> !llvm.struct<(vector<256xi8>, vector<256xi8>)>
    %107 = llvm.extractvalue %106[0] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %108 = llvm.extractvalue %106[1] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %109 = "hivm_regbaseintrins.intr.hivm.vxor.x"(%107, %108, %89) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %110 = "hivm_regbaseintrins.intr.hivm.vintlv"(%109, %87) : (vector<256xi8>, vector<256xi8>) -> !llvm.struct<(vector<256xi8>, vector<256xi8>)>
    %111 = llvm.extractvalue %110[0] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %112 = llvm.extractvalue %110[1] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %113 = "hivm_regbaseintrins.intr.hivm.vxor.x"(%111, %112, %89) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %114 = "hivm_regbaseintrins.intr.hivm.vintlv"(%113, %87) : (vector<256xi8>, vector<256xi8>) -> !llvm.struct<(vector<256xi8>, vector<256xi8>)>
    %115 = llvm.extractvalue %114[0] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %116 = llvm.extractvalue %114[1] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %117 = "hivm_regbaseintrins.intr.hivm.vxor.x"(%115, %116, %89) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %118 = "hivm_regbaseintrins.intr.hivm.vintlv"(%117, %87) : (vector<256xi8>, vector<256xi8>) -> !llvm.struct<(vector<256xi8>, vector<256xi8>)>
    %119 = llvm.extractvalue %118[0] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %120 = llvm.extractvalue %118[1] : !llvm.struct<(vector<256xi8>, vector<256xi8>)> 
    %121 = "hivm_regbaseintrins.intr.hivm.vxor.x"(%119, %120, %89) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %122 = "hivm_regbaseintrins.intr.hivm.vdup.z"(%121, %74, %10) : (vector<256xi8>, vector<256xi1>, i32) -> vector<256xi8>
    %123 = "hivm_regbaseintrins.intr.hivm.vcmp.ne.s.z"(%122, %75, %74) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi1>
    %124 = "hivm_regbaseintrins.intr.hivm.punpack"(%123, %11) : (vector<256xi1>, i32) -> vector<256xi1>
    %125 = "hivm_regbaseintrins.intr.hivm.punpack"(%124, %11) : (vector<256xi1>, i32) -> vector<256xi1>
    %126 = "hivm_regbaseintrins.intr.hivm.vsel"(%29, %27, %125) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    %127 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %11) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %128 = "hivm_regbaseintrins.intr.hivm.vdup.z"(%126, %127, %10) : (vector<128xf16>, vector<256xi1>, i32) -> vector<128xf16>
    %129 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %11) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %130 = "hivm_regbaseintrins.intr.hivm.vcmp.ne.s.z"(%128, %25, %129) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<256xi1>
    %131 = "hivm_regbaseintrins.intr.hivm.vsel"(%23, %21, %130) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    %132 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %11) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %133 = "hivm_regbaseintrins.intr.hivm.vcvtii.s322u8.x"(%131, %132, %11, %11) : (vector<64xi32>, vector<256xi1>, i32, i32) -> vector<256xi8>
    %134 = llvm.mul %32, %18 : i64
    %135 = llvm.add %134, %45 : i64
    %136 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %11) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %137 = llvm.getelementptr %arg9[%135] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i8
    "hivm_regbaseintrins.intr.hivm.vstsx1.v256s8"(%133, %137, %11, %15, %11, %136) : (vector<256xi8>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %138 = llvm.add %43, %7 overflow<nsw> : i32
    llvm.br ^bb3(%138 : i32)
  ^bb5:  // pred: ^bb3
    %139 = llvm.add %30, %10 overflow<nsw> : i32
    llvm.br ^bb1(%139 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_small_q_grouped_kernel_outlined_vf_13(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(16 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(8 : i32) : i32
    %4 = llvm.mlir.constant(9 : i32) : i32
    %5 = llvm.mlir.constant(1114112 : i32) : i32
    %6 = llvm.mlir.constant(256 : index) : i64
    %7 = llvm.mlir.constant(272 : index) : i64
    %8 = llvm.mlir.constant(16 : index) : i64
    %9 = llvm.mlir.constant(0 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%10: i32):  // 2 preds: ^bb0, ^bb5
    %11 = llvm.icmp "slt" %10, %1 : i32
    llvm.cond_br %11, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %12 = llvm.sext %10 : i32 to i64
    llvm.br ^bb3(%2 : i32)
  ^bb3(%13: i32):  // 2 preds: ^bb2, ^bb4
    %14 = llvm.icmp "slt" %13, %1 : i32
    llvm.cond_br %14, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %15 = llvm.sext %13 : i32 to i64
    %16 = llvm.mul %15, %8 : i64
    %17 = llvm.mul %12, %6 : i64
    %18 = llvm.add %16, %17 : i64
    %19 = llvm.getelementptr %arg0[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %20 = "hivm_regbaseintrins.intr.hivm.vldas"(%19) : (!llvm.ptr<6>) -> vector<32xi8>
    %21 = "hivm_regbaseintrins.intr.hivm.vldus.post.bf16"(%19, %20, %2) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<128xbf16>, vector<32xi8>, ptr<6>)>
    %22 = llvm.extractvalue %21[0] : !llvm.struct<(vector<128xbf16>, vector<32xi8>, ptr<6>)> 
    %23 = llvm.mul %15, %7 : i64
    %24 = llvm.mul %12, %8 : i64
    %25 = llvm.add %23, %24 : i64
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%4, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %27 = llvm.getelementptr %arg1[%25] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %28 = llvm.mul %9, %7 : i64
    %29 = llvm.add %28, %9 : i64
    %30 = llvm.getelementptr %27[%29] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vsstb.v128bf16"(%22, %30, %5, %2, %26) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, vector<256xi1>) -> ()
    %31 = llvm.add %13, %3 overflow<nsw> : i32
    llvm.br ^bb3(%31 : i32)
  ^bb5:  // pred: ^bb3
    %32 = llvm.add %10, %0 overflow<nsw> : i32
    llvm.br ^bb1(%32 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_small_q_grouped_kernel_outlined_vf_14(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i32, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(64 : index) : i64
    %1 = llvm.mlir.constant(1 : i32) : i32
    %2 = llvm.mlir.constant(16 : i32) : i32
    %3 = llvm.mlir.constant(0 : i32) : i32
    %4 = llvm.mlir.constant(1 : i64) : i64
    %5 = llvm.mlir.constant(0 : i64) : i64
    %6 = llvm.mlir.constant(256 : i32) : i32
    %7 = llvm.mlir.constant(64 : i32) : i32
    %8 = llvm.mlir.constant(3 : i32) : i32
    %9 = llvm.mlir.constant(8 : i32) : i32
    %10 = llvm.mlir.constant(7 : i32) : i32
    %11 = llvm.mlir.constant(1 : index) : i64
    %12 = llvm.mlir.constant(256 : index) : i64
    llvm.br ^bb1(%3 : i32)
  ^bb1(%13: i32):  // 2 preds: ^bb0, ^bb5
    %14 = llvm.icmp "slt" %13, %2 : i32
    llvm.cond_br %14, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %15 = llvm.sext %13 : i32 to i64
    llvm.br ^bb3(%3 : i32)
  ^bb3(%16: i32):  // 2 preds: ^bb2, ^bb4
    %17 = llvm.icmp "slt" %16, %6 : i32
    llvm.cond_br %17, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %18 = llvm.sext %16 : i32 to i64
    %19 = llvm.getelementptr %arg0[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i32
    %20 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64s32"(%19, %3, %8, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xi32>
    %21 = llvm.mul %15, %12 : i64
    %22 = llvm.add %21, %18 : i64
    %23 = llvm.alloca %4 x !llvm.struct<"vector_2xvl_s64", (array<2 x vector<64xi32>>)> : (i64) -> !llvm.ptr
    llvm.call @vload_NORM_int64_t_rank1(%23, %arg2, %arg2, %22, %0, %11, %5) : (!llvm.ptr, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64) -> ()
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%9, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = "hivm_regbaseintrins.intr.hivm.vmuls.s.x"(%20, %arg3, %24) : (vector<64xi32>, i32, vector<256xi1>) -> vector<64xi32>
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%9, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %27 = llvm.alloca %4 x !llvm.struct<"vector_2xvl_s64", (array<2 x vector<64xi32>>)> : (i64) -> !llvm.ptr
    llvm.call @_mlir_ciface_cast_int32_t_to_int64_t(%27, %25, %26) : (!llvm.ptr, vector<64xi32>, vector<256xi1>) -> ()
    %28 = llvm.alloca %4 x !llvm.struct<"vector_2xvl_s64", (array<2 x vector<64xi32>>)> : (i64) -> !llvm.ptr
    llvm.call @_mlir_ciface_vbr_int64_t(%28, %arg4) : (!llvm.ptr, i64) -> ()
    %29 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%9, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %30 = llvm.alloca %4 x !llvm.struct<"vector_2xvl_s64", (array<2 x vector<64xi32>>)> : (i64) -> !llvm.ptr
    llvm.call @_mlir_ciface_vadd_int64_t(%30, %28, %27, %29) : (!llvm.ptr, !llvm.ptr, !llvm.ptr, vector<256xi1>) -> ()
    %31 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%9, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %32 = llvm.alloca %4 x !llvm.struct<"vector_2xvl_s64", (array<2 x vector<64xi32>>)> : (i64) -> !llvm.ptr
    llvm.call @_mlir_ciface_vadd_int64_t(%32, %30, %23, %31) : (!llvm.ptr, !llvm.ptr, !llvm.ptr, vector<256xi1>) -> ()
    %33 = llvm.mul %15, %12 : i64
    %34 = llvm.add %33, %18 : i64
    %35 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%9, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    llvm.call @masked_store_NORM_B64_int64_t_rank1(%arg6, %arg6, %34, %0, %11, %5, %35, %32) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, vector<256xi1>, !llvm.ptr) -> ()
    %36 = llvm.mul %15, %12 : i64
    %37 = llvm.add %36, %18 : i64
    %38 = llvm.getelementptr %arg5[%37] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %39 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%38, %3, %3, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %40 = llvm.getelementptr %arg1[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %41 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%40, %3, %8, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %42 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%9, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %43 = "hivm_regbaseintrins.intr.hivm.vdiv.s.x"(%39, %41, %42) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %44 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%9, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %45 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%43, %44, %3, %3, %3) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %46 = llvm.mul %15, %12 : i64
    %47 = llvm.add %46, %18 : i64
    %48 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%9, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %49 = llvm.getelementptr %arg7[%47] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%45, %49, %3, %10, %3, %48) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %50 = llvm.add %16, %7 overflow<nsw> : i32
    llvm.br ^bb3(%50 : i32)
  ^bb5:  // pred: ^bb3
    %51 = llvm.add %13, %1 overflow<nsw> : i32
    llvm.br ^bb1(%51 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_small_q_grouped_kernel_outlined_vf_15(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(8 : i32) : i32
    %1 = llvm.mlir.constant(0.000000e+00 : bf16) : bf16
    %2 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %3 = llvm.mlir.constant(0 : i32) : i32
    %4 = llvm.mlir.constant(16 : i32) : i32
    %5 = llvm.mlir.constant(1 : i32) : i32
    %6 = llvm.mlir.constant(256 : i32) : i32
    %7 = llvm.mlir.constant(64 : i32) : i32
    %8 = llvm.mlir.constant(2 : i32) : i32
    %9 = llvm.mlir.constant(256 : index) : i64
    %10 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%0, %3) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %11 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%1, %10, %5) : (bf16, vector<256xi1>, i32) -> vector<128xbf16>
    %12 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %13 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%2, %12, %5) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    llvm.br ^bb1(%3 : i32)
  ^bb1(%14: i32):  // 2 preds: ^bb0, ^bb5
    %15 = llvm.icmp "slt" %14, %4 : i32
    llvm.cond_br %15, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %16 = llvm.sext %14 : i32 to i64
    llvm.br ^bb3(%3 : i32)
  ^bb3(%17: i32):  // 2 preds: ^bb2, ^bb4
    %18 = llvm.icmp "slt" %17, %6 : i32
    llvm.cond_br %18, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %19 = llvm.sext %17 : i32 to i64
    %20 = llvm.mul %16, %9 : i64
    %21 = llvm.add %20, %19 : i64
    %22 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %23 = llvm.getelementptr %arg0[%21] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%13, %23, %3, %8, %3, %22) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %24 = llvm.mul %16, %9 : i64
    %25 = llvm.add %24, %19 : i64
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%0, %3) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %27 = llvm.getelementptr %arg1[%25] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%11, %27, %3, %5, %3, %26) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %28 = llvm.add %17, %7 overflow<nsw> : i32
    llvm.br ^bb3(%28 : i32)
  ^bb5:  // pred: ^bb3
    %29 = llvm.add %14, %5 overflow<nsw> : i32
    llvm.br ^bb1(%29 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_small_q_grouped_kernel_mix_aic(%arg0: i64, %arg1: !llvm.ptr<1>, %arg2: !llvm.ptr<1>, %arg3: !llvm.ptr<1>, %arg4: !llvm.ptr<1>, %arg5: !llvm.ptr<1>, %arg6: !llvm.ptr<1>, %arg7: !llvm.ptr<1>, %arg8: !llvm.ptr<1>, %arg9: !llvm.ptr<1>, %arg10: !llvm.ptr<1>, %arg11: i32, %arg12: i32, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32, %arg17: i32, %arg18: i32, %arg19: i32, %arg20: i32, %arg21: f32, %arg22: i32, %arg23: i32, %arg24: i32) attributes {DirectlyUsedGMArgIdxList = [5, 2], SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, hivm.vf_mode = #hivm.vf_mode<MIX>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, mix_mode = "mix", parallel_mode = "mix_simd_simt"} {
    %0 = llvm.mlir.constant(15 : index) : i64
    %1 = llvm.mlir.constant(-1 : index) : i64
    %2 = llvm.mlir.constant(48 : i64) : i64
    %3 = llvm.mlir.constant(60 : i64) : i64
    %4 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %5 = llvm.mlir.constant(16384 : index) : i64
    %6 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %7 = llvm.mlir.constant(1024 : index) : i64
    %8 = llvm.mlir.constant(1 : index) : i64
    %9 = llvm.mlir.constant(4 : index) : i64
    %10 = llvm.mlir.constant(0 : index) : i64
    %11 = llvm.mlir.constant(0 : i8) : i8
    %12 = llvm.mlir.constant(false) : i1
    %13 = llvm.mlir.constant(1.000000e+00 : f32) : f32
    %14 = llvm.mlir.constant(119712 : i64) : i64
    %15 = llvm.mlir.constant(115616 : i64) : i64
    %16 = llvm.mlir.constant(8192 : i64) : i64
    %17 = llvm.mlir.constant(16 : index) : i64
    %18 = llvm.mlir.constant(256 : index) : i64
    %19 = llvm.mlir.constant(64 : index) : i64
    %20 = llvm.mlir.constant(4 : i64) : i64
    %21 = llvm.mlir.constant(1028 : i64) : i64
    %22 = llvm.mlir.constant(8 : i64) : i64
    %23 = llvm.mlir.constant(1032 : i64) : i64
    %24 = llvm.mlir.constant(0.000000e+00 : bf16) : bf16
    %25 = llvm.mlir.constant(3 : i32) : i32
    %26 = llvm.mlir.constant(64 : i32) : i32
    %27 = llvm.mlir.constant(63 : i32) : i32
    %28 = llvm.mlir.constant(0 : i32) : i32
    %29 = llvm.mlir.constant(0 : i64) : i64
    %30 = llvm.mlir.constant(1024 : i64) : i64
    %31 = llvm.mlir.constant(1 : i32) : i32
    %32 = llvm.mlir.constant(true) : i1
    %33 = llvm.mlir.constant(2 : i64) : i64
    %34 = llvm.mlir.constant(3 : i64) : i64
    %35 = llvm.mlir.constant(1 : i64) : i64
    %36 = llvm.mlir.constant(-1 : i64) : i64
    %37 = llvm.mlir.constant(75776 : i64) : i64
    %38 = llvm.mlir.constant(10240 : i64) : i64
    %39 = llvm.mlir.constant(108544 : i64) : i64
    %40 = llvm.mlir.constant(43008 : i64) : i64
    %41 = llvm.mlir.constant(24576 : i64) : i64
    %42 = llvm.mlir.constant(4096 : i64) : i64
    %43 = llvm.mlir.constant(20480 : i64) : i64
    %44 = llvm.inttoptr %29 : i64 to !llvm.ptr<5>
    %45 = llvm.insertvalue %44, %6[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %46 = llvm.insertvalue %44, %45[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %47 = llvm.insertvalue %10, %46[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %48 = llvm.insertvalue %9, %47[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %49 = llvm.insertvalue %8, %48[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %50 = llvm.insertvalue %17, %49[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %51 = llvm.insertvalue %17, %50[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %52 = llvm.insertvalue %18, %51[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %53 = llvm.insertvalue %18, %52[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %54 = llvm.insertvalue %17, %53[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %55 = llvm.insertvalue %8, %54[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %56 = llvm.inttoptr %43 : i64 to !llvm.ptr<5>
    %57 = llvm.insertvalue %56, %6[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %58 = llvm.insertvalue %56, %57[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %59 = llvm.insertvalue %10, %58[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %60 = llvm.insertvalue %9, %59[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %61 = llvm.insertvalue %8, %60[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %62 = llvm.insertvalue %17, %61[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %63 = llvm.insertvalue %17, %62[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %64 = llvm.insertvalue %18, %63[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %65 = llvm.insertvalue %18, %64[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %66 = llvm.insertvalue %17, %65[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %67 = llvm.insertvalue %8, %66[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %68 = llvm.inttoptr %42 : i64 to !llvm.ptr<5>
    %69 = llvm.insertvalue %68, %6[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %70 = llvm.insertvalue %68, %69[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %71 = llvm.insertvalue %10, %70[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %72 = llvm.insertvalue %17, %71[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %73 = llvm.insertvalue %8, %72[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %74 = llvm.insertvalue %17, %73[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %75 = llvm.insertvalue %17, %74[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %76 = llvm.insertvalue %18, %75[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %77 = llvm.insertvalue %18, %76[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %78 = llvm.insertvalue %17, %77[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %79 = llvm.insertvalue %8, %78[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %80 = llvm.inttoptr %41 : i64 to !llvm.ptr<5>
    %81 = llvm.insertvalue %80, %6[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %82 = llvm.insertvalue %80, %81[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %83 = llvm.insertvalue %10, %82[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %84 = llvm.insertvalue %17, %83[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %85 = llvm.insertvalue %8, %84[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %86 = llvm.insertvalue %17, %85[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %87 = llvm.insertvalue %17, %86[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %88 = llvm.insertvalue %18, %87[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %89 = llvm.insertvalue %18, %88[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %90 = llvm.insertvalue %17, %89[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %91 = llvm.insertvalue %8, %90[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %92 = llvm.inttoptr %40 : i64 to !llvm.ptr<2>
    %93 = llvm.insertvalue %92, %4[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %94 = llvm.insertvalue %92, %93[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %95 = llvm.insertvalue %10, %94[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %96 = llvm.insertvalue %17, %95[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %97 = llvm.insertvalue %9, %96[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %98 = llvm.insertvalue %17, %97[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %99 = llvm.insertvalue %17, %98[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %100 = llvm.insertvalue %7, %99[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %101 = llvm.insertvalue %18, %100[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %102 = llvm.insertvalue %17, %101[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %103 = llvm.insertvalue %8, %102[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %104 = llvm.inttoptr %39 : i64 to !llvm.ptr<2>
    %105 = llvm.insertvalue %104, %4[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %106 = llvm.insertvalue %104, %105[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %107 = llvm.insertvalue %10, %106[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %108 = llvm.insertvalue %17, %107[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %109 = llvm.insertvalue %9, %108[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %110 = llvm.insertvalue %17, %109[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %111 = llvm.insertvalue %17, %110[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %112 = llvm.insertvalue %7, %111[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %113 = llvm.insertvalue %18, %112[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %114 = llvm.insertvalue %17, %113[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %115 = llvm.insertvalue %8, %114[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %116 = llvm.inttoptr %38 : i64 to !llvm.ptr<2>
    %117 = llvm.insertvalue %116, %4[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %118 = llvm.insertvalue %116, %117[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %119 = llvm.insertvalue %10, %118[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %120 = llvm.insertvalue %17, %119[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %121 = llvm.insertvalue %9, %120[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %122 = llvm.insertvalue %17, %121[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %123 = llvm.insertvalue %17, %122[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %124 = llvm.insertvalue %7, %123[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %125 = llvm.insertvalue %18, %124[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %126 = llvm.insertvalue %17, %125[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %127 = llvm.insertvalue %8, %126[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %128 = llvm.inttoptr %37 : i64 to !llvm.ptr<2>
    %129 = llvm.insertvalue %128, %4[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %130 = llvm.insertvalue %128, %129[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %131 = llvm.insertvalue %10, %130[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %132 = llvm.insertvalue %17, %131[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %133 = llvm.insertvalue %9, %132[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %134 = llvm.insertvalue %17, %133[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %135 = llvm.insertvalue %17, %134[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %136 = llvm.insertvalue %7, %135[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %137 = llvm.insertvalue %18, %136[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %138 = llvm.insertvalue %17, %137[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %139 = llvm.insertvalue %8, %138[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %140 = llvm.alloca %8 x i64 : (i64) -> !llvm.ptr
    llvm.store %29, %140 : i64, !llvm.ptr
    %141 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %142 = "hivm.intr.hivm.SBITSET0"(%141, %3) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%142) : (i64) -> ()
    %143 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %144 = "hivm.intr.hivm.SBITSET1"(%143, %2) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%144) : (i64) -> ()
    %145 = "hivm.intr.hivm.GET.BLOCK.IDX"() : () -> i64
    %146 = llvm.trunc %145 : i64 to i32
    %147 = llvm.srem %146, %arg22  : i32
    %148 = llvm.inttoptr %29 : i64 to !llvm.ptr<11>
    %149 = llvm.inttoptr %30 : i64 to !llvm.ptr<11>
    llvm.store volatile %28, %148 : i32, !llvm.ptr<11>
    llvm.store volatile %28, %149 : i32, !llvm.ptr<11>
    %150 = llvm.inttoptr %20 : i64 to !llvm.ptr<11>
    %151 = llvm.inttoptr %21 : i64 to !llvm.ptr<11>
    llvm.store volatile %28, %150 : i32, !llvm.ptr<11>
    llvm.store volatile %28, %151 : i32, !llvm.ptr<11>
    %152 = llvm.inttoptr %22 : i64 to !llvm.ptr<11>
    %153 = llvm.inttoptr %23 : i64 to !llvm.ptr<11>
    llvm.store volatile %28, %152 : i32, !llvm.ptr<11>
    llvm.store volatile %28, %153 : i32, !llvm.ptr<11>
    %154 = llvm.mul %147, %arg11 : i32
    %155 = llvm.sdiv %154, %arg22  : i32
    %156 = llvm.add %147, %31 : i32
    %157 = llvm.mul %156, %arg11 : i32
    %158 = llvm.sdiv %157, %arg22  : i32
    %159 = llvm.inttoptr %29 : i64 to !llvm.ptr<2>
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 17 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 16 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 0 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    llvm.br ^bb1(%155 : i32)
  ^bb1(%160: i32):  // 2 preds: ^bb0, ^bb23
    %161 = llvm.icmp "slt" %160, %158 : i32
    llvm.cond_br %161, ^bb2, ^bb24
  ^bb2:  // pred: ^bb1
    %162 = llvm.sext %160 : i32 to i64
    %163 = llvm.getelementptr %arg7[%162] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %164 = llvm.load %163 : !llvm.ptr<1> -> i32
    %165 = llvm.add %162, %8 : i64
    %166 = llvm.getelementptr %arg7[%165] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %167 = llvm.load %166 : !llvm.ptr<1> -> i32
    %168 = llvm.sub %167, %164 : i32
    %169 = llvm.icmp "sgt" %168, %28 : i32
    llvm.cond_br %169, ^bb3, ^bb23
  ^bb3:  // pred: ^bb2
    %170 = llvm.getelementptr %arg8[%162] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %171 = llvm.load %170 : !llvm.ptr<1> -> i32
    %172 = llvm.add %171, %27 : i32
    %173 = llvm.sdiv %172, %26  : i32
    %174 = llvm.sub %arg20, %31 : i32
    %175 = llvm.mul %160, %arg20 : i32
    %176 = llvm.inttoptr %16 : i64 to !llvm.ptr<2>
    %177 = llvm.inttoptr %15 : i64 to !llvm.ptr<6>
    %178 = llvm.inttoptr %14 : i64 to !llvm.ptr<6>
    %179 = llvm.add %173, %25 : i32
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 4 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    llvm.br ^bb4(%28, %28, %28, %28 : i32, i32, i32, i32)
  ^bb4(%180: i32, %181: i32, %182: i32, %183: i32):  // 2 preds: ^bb3, ^bb21
    %184 = llvm.icmp "slt" %180, %179 : i32
    llvm.cond_br %184, ^bb5, ^bb22
  ^bb5:  // pred: ^bb4
    %185 = llvm.load %140 : !llvm.ptr -> i64
    %186 = llvm.urem %185, %33  : i64
    %187 = llvm.icmp "eq" %186, %35 : i64
    %188 = llvm.select %187, %67, %55 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %189 = llvm.select %187, %91, %79 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %190 = llvm.select %187, %115, %103 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %191 = llvm.select %187, %139, %127 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %192 = llvm.trunc %186 : i64 to i1
    %193 = llvm.select %192, %33, %34 : i1, i64
    %194 = llvm.select %192, %34, %20 : i1, i64
    %195 = llvm.xor %192, %32  : i1
    %196 = llvm.zext %195 : i1 to i64
    %197 = llvm.select %192, %35, %33 : i1, i64
    %198 = llvm.icmp "slt" %181, %173 : i32
    llvm.cond_br %198, ^bb6, ^bb7
  ^bb6:  // pred: ^bb5
    %199 = llvm.add %181, %31 : i32
    llvm.br ^bb8(%199 : i32)
  ^bb7:  // pred: ^bb5
    llvm.br ^bb8(%181 : i32)
  ^bb8(%200: i32):  // 2 preds: ^bb6, ^bb7
    llvm.br ^bb9
  ^bb9:  // pred: ^bb8
    %201 = llvm.load volatile %148 : !llvm.ptr<11> -> i32
    %202 = llvm.load volatile %149 : !llvm.ptr<11> -> i32
    %203 = llvm.icmp "slt" %201, %31 : i32
    %204 = llvm.icmp "slt" %202, %31 : i32
    %205 = llvm.and %203, %204  : i1
    %206 = llvm.icmp "slt" %182, %173 : i32
    %207 = llvm.and %205, %206  : i1
    llvm.cond_br %207, ^bb10, ^bb13
  ^bb10:  // pred: ^bb9
    %208 = llvm.mul %182, %26 : i32
    %209 = llvm.add %208, %26 : i32
    %210 = llvm.intr.smin(%209, %171)  : (i32, i32) -> i32
    %211 = llvm.sub %210, %208 : i32
    %212 = llvm.sext %211 : i32 to i64
    %213 = llvm.sext %arg15 : i32 to i64
    %214 = llvm.intr.smax(%212, %10)  : (i64, i64) -> i64
    %215 = llvm.intr.smin(%214, %19)  : (i64, i64) -> i64
    %216 = llvm.intr.smin(%215, %10)  : (i64, i64) -> i64
    %217 = llvm.mul %216, %1 : i64
    %218 = llvm.add %215, %217 : i64
    %219 = llvm.icmp "slt" %218, %19 : i64
    %220 = llvm.sdiv %208, %26  : i32
    %221 = llvm.intr.smin(%220, %174)  : (i32, i32) -> i32
    %222 = llvm.sext %175 : i32 to i64
    %223 = llvm.sext %221 : i32 to i64
    %224 = llvm.add %222, %223 : i64
    %225 = llvm.getelementptr %arg9[%224] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %226 = llvm.load %225 : !llvm.ptr<1> -> i32
    %227 = llvm.mul %226, %arg14 : i32
    %228 = llvm.sext %227 : i32 to i64
    %229 = llvm.mul %216, %1 : i64
    %230 = llvm.add %215, %229 : i64
    %231 = llvm.add %230, %0 : i64
    %232 = llvm.icmp "slt" %231, %10 : i64
    %233 = llvm.sub %1, %231 : i64
    %234 = llvm.select %232, %233, %231 : i1, i64
    %235 = llvm.sdiv %234, %17  : i64
    %236 = llvm.sub %1, %235 : i64
    %237 = llvm.select %232, %236, %235 : i1, i64
    %238 = llvm.extractvalue %191[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %239 = llvm.extractvalue %191[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %240 = llvm.mul %216, %17 : i64
    llvm.cond_br %219, ^bb11, ^bb12
  ^bb11:  // pred: ^bb10
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %241 = llvm.extractvalue %191[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %242 = llvm.extractvalue %191[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%24, %241, %242, %10, %5, %8) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb12
  ^bb12:  // 2 preds: ^bb10, ^bb11
    "hivm.intr.hivm.WAIT.FLAG.REG"(%197) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.call @nd2nz_bfloat16_t(%arg4, %arg4, %228, %218, %18, %213, %8, %238, %239, %240, %17, %237, %17, %17, %7, %18, %17, %8) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%196) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %243 = llvm.extractvalue %191[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %244 = llvm.extractvalue %191[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %245 = llvm.extractvalue %191[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %246 = llvm.extractvalue %191[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %247 = llvm.extractvalue %191[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %248 = llvm.extractvalue %191[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %249 = llvm.extractvalue %191[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %250 = llvm.extractvalue %191[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %251 = llvm.extractvalue %191[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %252 = llvm.extractvalue %191[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %253 = llvm.extractvalue %191[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %254 = llvm.extractvalue %188[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %255 = llvm.extractvalue %188[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %256 = llvm.extractvalue %188[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %257 = llvm.extractvalue %188[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %258 = llvm.extractvalue %188[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %259 = llvm.extractvalue %188[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %260 = llvm.extractvalue %188[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %261 = llvm.extractvalue %188[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %262 = llvm.extractvalue %188[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %263 = llvm.extractvalue %188[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %264 = llvm.extractvalue %188[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float_tb(%159, %159, %10, %17, %8, %17, %17, %18, %18, %17, %8, %243, %244, %245, %246, %247, %248, %249, %250, %251, %252, %253, %32, %17, %18, %19, %254, %255, %256, %257, %258, %259, %260, %261, %262, %263, %264, %36, %29, %36, %197, %36, %36, %36, %11) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 10 : i64}> : () -> ()
    %265 = llvm.extractvalue %188[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %266 = llvm.extractvalue %188[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %267 = llvm.extractvalue %188[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %268 = llvm.extractvalue %188[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %269 = llvm.extractvalue %188[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %270 = llvm.extractvalue %188[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %271 = llvm.extractvalue %188[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %272 = llvm.extractvalue %188[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %273 = llvm.extractvalue %188[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %274 = llvm.extractvalue %188[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %275 = llvm.extractvalue %188[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%265, %266, %267, %268, %269, %270, %271, %272, %273, %274, %275, %177, %177, %10, %17, %19, %19, %8, %29, %13, %29, %12, %11) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%196) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %276 = llvm.load volatile %148 : !llvm.ptr<11> -> i32
    %277 = llvm.load volatile %149 : !llvm.ptr<11> -> i32
    %278 = llvm.add %276, %31 : i32
    %279 = llvm.add %277, %31 : i32
    llvm.store volatile %278, %148 : i32, !llvm.ptr<11>
    llvm.store volatile %279, %149 : i32, !llvm.ptr<11>
    %280 = llvm.add %182, %31 : i32
    llvm.br ^bb14(%280 : i32)
  ^bb13:  // pred: ^bb9
    llvm.br ^bb14(%182 : i32)
  ^bb14(%281: i32):  // 2 preds: ^bb12, ^bb13
    llvm.br ^bb15
  ^bb15:  // pred: ^bb14
    %282 = llvm.load volatile %152 : !llvm.ptr<11> -> i32
    %283 = llvm.load volatile %153 : !llvm.ptr<11> -> i32
    %284 = llvm.icmp "sgt" %282, %28 : i32
    %285 = llvm.icmp "sgt" %283, %28 : i32
    %286 = llvm.and %284, %285  : i1
    %287 = llvm.load volatile %150 : !llvm.ptr<11> -> i32
    %288 = llvm.load volatile %151 : !llvm.ptr<11> -> i32
    %289 = llvm.icmp "slt" %287, %31 : i32
    %290 = llvm.icmp "slt" %288, %31 : i32
    %291 = llvm.and %289, %290  : i1
    %292 = llvm.and %286, %291  : i1
    %293 = llvm.icmp "slt" %183, %173 : i32
    %294 = llvm.and %292, %293  : i1
    llvm.cond_br %294, ^bb16, ^bb19
  ^bb16:  // pred: ^bb15
    %295 = llvm.mul %183, %26 : i32
    %296 = llvm.add %295, %26 : i32
    %297 = llvm.intr.smin(%296, %171)  : (i32, i32) -> i32
    %298 = llvm.sub %297, %295 : i32
    %299 = llvm.sext %arg17 : i32 to i64
    %300 = llvm.sext %298 : i32 to i64
    %301 = llvm.intr.smax(%300, %10)  : (i64, i64) -> i64
    %302 = llvm.intr.smin(%301, %19)  : (i64, i64) -> i64
    %303 = llvm.intr.smin(%302, %10)  : (i64, i64) -> i64
    %304 = llvm.mul %303, %1 : i64
    %305 = llvm.add %302, %304 : i64
    %306 = llvm.icmp "slt" %305, %19 : i64
    %307 = llvm.sdiv %295, %26  : i32
    %308 = llvm.intr.smin(%307, %174)  : (i32, i32) -> i32
    %309 = llvm.sext %175 : i32 to i64
    %310 = llvm.sext %308 : i32 to i64
    %311 = llvm.add %309, %310 : i64
    %312 = llvm.getelementptr %arg9[%311] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %313 = llvm.load %312 : !llvm.ptr<1> -> i32
    %314 = llvm.mul %313, %arg16 : i32
    %315 = llvm.sext %314 : i32 to i64
    %316 = llvm.mul %303, %1 : i64
    %317 = llvm.add %302, %316 : i64
    %318 = llvm.add %317, %0 : i64
    %319 = llvm.icmp "slt" %318, %10 : i64
    %320 = llvm.sub %1, %318 : i64
    %321 = llvm.select %319, %320, %318 : i1, i64
    %322 = llvm.sdiv %321, %17  : i64
    %323 = llvm.sub %1, %322 : i64
    %324 = llvm.select %319, %323, %322 : i1, i64
    %325 = llvm.extractvalue %190[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %326 = llvm.extractvalue %190[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %327 = llvm.mul %303, %17 : i64
    llvm.cond_br %306, ^bb17, ^bb18
  ^bb17:  // pred: ^bb16
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %328 = llvm.extractvalue %190[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %329 = llvm.extractvalue %190[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%24, %328, %329, %10, %5, %8) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb18
  ^bb18:  // 2 preds: ^bb16, ^bb17
    "hivm.intr.hivm.WAIT.FLAG.REG"(%194) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.call @nd2nz_bfloat16_t(%arg5, %arg5, %315, %305, %18, %299, %8, %325, %326, %327, %17, %324, %17, %17, %7, %18, %17, %8) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%193) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %330 = llvm.extractvalue %190[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %331 = llvm.extractvalue %190[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %332 = llvm.extractvalue %190[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %333 = llvm.extractvalue %190[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %334 = llvm.extractvalue %190[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %335 = llvm.extractvalue %190[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %336 = llvm.extractvalue %190[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %337 = llvm.extractvalue %190[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %338 = llvm.extractvalue %190[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %339 = llvm.extractvalue %190[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %340 = llvm.extractvalue %190[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %341 = llvm.extractvalue %189[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %342 = llvm.extractvalue %189[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %343 = llvm.extractvalue %189[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %344 = llvm.extractvalue %189[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %345 = llvm.extractvalue %189[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %346 = llvm.extractvalue %189[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %347 = llvm.extractvalue %189[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %348 = llvm.extractvalue %189[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %349 = llvm.extractvalue %189[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %350 = llvm.extractvalue %189[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %351 = llvm.extractvalue %189[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float(%176, %176, %10, %9, %8, %17, %17, %18, %18, %17, %8, %330, %331, %332, %333, %334, %335, %336, %337, %338, %339, %340, %32, %17, %19, %18, %341, %342, %343, %344, %345, %346, %347, %348, %349, %350, %351, %36, %29, %36, %194, %36, %36, %36, %11) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 10 : i64}> : () -> ()
    %352 = llvm.extractvalue %189[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %353 = llvm.extractvalue %189[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %354 = llvm.extractvalue %189[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %355 = llvm.extractvalue %189[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %356 = llvm.extractvalue %189[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %357 = llvm.extractvalue %189[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %358 = llvm.extractvalue %189[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %359 = llvm.extractvalue %189[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %360 = llvm.extractvalue %189[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %361 = llvm.extractvalue %189[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %362 = llvm.extractvalue %189[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%352, %353, %354, %355, %356, %357, %358, %359, %360, %361, %362, %178, %178, %10, %17, %18, %18, %8, %29, %13, %29, %12, %11) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%193) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %363 = llvm.load volatile %152 : !llvm.ptr<11> -> i32
    %364 = llvm.load volatile %153 : !llvm.ptr<11> -> i32
    %365 = llvm.sub %363, %31 : i32
    %366 = llvm.sub %364, %31 : i32
    llvm.store volatile %365, %152 : i32, !llvm.ptr<11>
    llvm.store volatile %366, %153 : i32, !llvm.ptr<11>
    %367 = llvm.load volatile %150 : !llvm.ptr<11> -> i32
    %368 = llvm.load volatile %151 : !llvm.ptr<11> -> i32
    %369 = llvm.add %367, %31 : i32
    %370 = llvm.add %368, %31 : i32
    llvm.store volatile %369, %150 : i32, !llvm.ptr<11>
    llvm.store volatile %370, %151 : i32, !llvm.ptr<11>
    %371 = llvm.add %183, %31 : i32
    llvm.br ^bb20(%371 : i32)
  ^bb19:  // pred: ^bb15
    llvm.br ^bb20(%183 : i32)
  ^bb20(%372: i32):  // 2 preds: ^bb18, ^bb19
    llvm.br ^bb21
  ^bb21:  // pred: ^bb20
    %373 = llvm.add %185, %35 : i64
    llvm.store %373, %140 : i64, !llvm.ptr
    %374 = llvm.add %180, %31 overflow<nsw> : i32
    llvm.br ^bb4(%374, %200, %281, %372 : i32, i32, i32, i32)
  ^bb22:  // pred: ^bb4
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 4 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.br ^bb23
  ^bb23:  // 2 preds: ^bb2, ^bb22
    %375 = llvm.add %160, %31 overflow<nsw> : i32
    llvm.br ^bb1(%375 : i32)
  ^bb24:  // pred: ^bb1
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    %376 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %377 = "hivm.intr.hivm.SBITSET1"(%376, %3) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%377) : (i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 6 : i64}> : () -> ()
    llvm.return
  }
  llvm.func private @set_l1_2d_bfloat16_t(%arg0: bf16, %arg1: !llvm.ptr<2>, %arg2: !llvm.ptr<2>, %arg3: i64, %arg4: i64, %arg5: i64) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg1, %1[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg4, %4[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg5, %5[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_set_l1_2d_bfloat16_t(%arg0, %7) : (bf16, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_set_l1_2d_bfloat16_t(bf16, !llvm.ptr) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @nd2nz_bfloat16_t(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<2>, %arg8: !llvm.ptr<2>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %15 = llvm.insertvalue %arg14, %14[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg15, %16[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg12, %17[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg13, %19[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %21, %22 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_nd2nz_bfloat16_t(%10, %22) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_nd2nz_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @mma_tile_bfloat16_t_to_float_tb(%arg0: !llvm.ptr<2>, %arg1: !llvm.ptr<2>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<2>, %arg12: !llvm.ptr<2>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64, %arg21: i64, %arg22: i1, %arg23: i64, %arg24: i64, %arg25: i64, %arg26: !llvm.ptr<5>, %arg27: !llvm.ptr<5>, %arg28: i64, %arg29: i64, %arg30: i64, %arg31: i64, %arg32: i64, %arg33: i64, %arg34: i64, %arg35: i64, %arg36: i64, %arg37: i64, %arg38: i64, %arg39: i64, %arg40: i64, %arg41: i64, %arg42: i64, %arg43: i64, %arg44: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg18, %18[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.insertvalue %arg16, %21[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %24 = llvm.insertvalue %arg17, %23[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %25 = llvm.insertvalue %arg21, %24[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %26 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %25, %26 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %27 = llvm.insertvalue %arg26, %0[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %28 = llvm.insertvalue %arg27, %27[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %29 = llvm.insertvalue %arg28, %28[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %30 = llvm.insertvalue %arg29, %29[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %31 = llvm.insertvalue %arg33, %30[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %32 = llvm.insertvalue %arg30, %31[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %33 = llvm.insertvalue %arg34, %32[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %34 = llvm.insertvalue %arg31, %33[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %35 = llvm.insertvalue %arg35, %34[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %36 = llvm.insertvalue %arg32, %35[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %37 = llvm.insertvalue %arg36, %36[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %38 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %37, %38 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_mma_tile_bfloat16_t_to_float_tb(%14, %26, %arg22, %arg23, %arg24, %arg25, %38, %arg37, %arg38, %arg39, %arg40, %arg41, %arg42, %arg43, %arg44) : (!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_mma_tile_bfloat16_t_to_float_tb(!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%arg0: !llvm.ptr<5>, %arg1: !llvm.ptr<5>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<6>, %arg12: !llvm.ptr<6>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: f32, %arg20: i64, %arg21: i1, %arg22: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %21, %22 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%14, %22, %arg18, %arg19, %arg20, %arg21, %arg22) : (!llvm.ptr, !llvm.ptr, i64, f32, i64, i1, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(!llvm.ptr, !llvm.ptr, i64, f32, i64, i1, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @mma_tile_bfloat16_t_to_float(%arg0: !llvm.ptr<2>, %arg1: !llvm.ptr<2>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<2>, %arg12: !llvm.ptr<2>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64, %arg21: i64, %arg22: i1, %arg23: i64, %arg24: i64, %arg25: i64, %arg26: !llvm.ptr<5>, %arg27: !llvm.ptr<5>, %arg28: i64, %arg29: i64, %arg30: i64, %arg31: i64, %arg32: i64, %arg33: i64, %arg34: i64, %arg35: i64, %arg36: i64, %arg37: i64, %arg38: i64, %arg39: i64, %arg40: i64, %arg41: i64, %arg42: i64, %arg43: i64, %arg44: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg18, %18[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.insertvalue %arg16, %21[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %24 = llvm.insertvalue %arg17, %23[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %25 = llvm.insertvalue %arg21, %24[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %26 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %25, %26 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %27 = llvm.insertvalue %arg26, %0[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %28 = llvm.insertvalue %arg27, %27[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %29 = llvm.insertvalue %arg28, %28[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %30 = llvm.insertvalue %arg29, %29[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %31 = llvm.insertvalue %arg33, %30[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %32 = llvm.insertvalue %arg30, %31[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %33 = llvm.insertvalue %arg34, %32[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %34 = llvm.insertvalue %arg31, %33[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %35 = llvm.insertvalue %arg35, %34[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %36 = llvm.insertvalue %arg32, %35[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %37 = llvm.insertvalue %arg36, %36[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %38 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %37, %38 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_mma_tile_bfloat16_t_to_float(%14, %26, %arg22, %arg23, %arg24, %arg25, %38, %arg37, %arg38, %arg39, %arg40, %arg41, %arg42, %arg43, %arg44) : (!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_mma_tile_bfloat16_t_to_float(!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @indirect_load_2d_bfloat16_t_int64_t(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: !llvm.ptr<6>, %arg13: !llvm.ptr<6>, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: !llvm.ptr<6>, %arg20: !llvm.ptr<6>, %arg21: i64, %arg22: i64, %arg23: i64, %arg24: i64, %arg25: i64, %arg26: !llvm.ptr<6>, %arg27: !llvm.ptr<6>, %arg28: i64, %arg29: i64, %arg30: i64, %arg31: i64, %arg32: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.insertvalue %arg4, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %8 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %7, %8 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %9 = llvm.insertvalue %arg5, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.insertvalue %arg6, %9[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %11 = llvm.insertvalue %arg7, %10[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg9, %13[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg11, %14[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %15, %16 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %17 = llvm.insertvalue %arg12, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.insertvalue %arg13, %17[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.insertvalue %arg14, %18[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.insertvalue %arg16, %21[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %23 = llvm.insertvalue %arg18, %22[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %24 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %23, %24 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %25 = llvm.insertvalue %arg19, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %26 = llvm.insertvalue %arg20, %25[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %27 = llvm.insertvalue %arg21, %26[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %28 = llvm.insertvalue %arg22, %27[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %29 = llvm.insertvalue %arg24, %28[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %30 = llvm.insertvalue %arg23, %29[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %31 = llvm.insertvalue %arg25, %30[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %32 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %31, %32 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %33 = llvm.insertvalue %arg26, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %34 = llvm.insertvalue %arg27, %33[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %35 = llvm.insertvalue %arg28, %34[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %36 = llvm.insertvalue %arg29, %35[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %37 = llvm.insertvalue %arg31, %36[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %38 = llvm.insertvalue %arg30, %37[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %39 = llvm.insertvalue %arg32, %38[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %40 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %39, %40 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_indirect_load_2d_bfloat16_t_int64_t(%8, %16, %24, %32, %40) : (!llvm.ptr, !llvm.ptr, !llvm.ptr, !llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_indirect_load_2d_bfloat16_t_int64_t(!llvm.ptr, !llvm.ptr, !llvm.ptr, !llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_cbuf_2d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<2>, %arg8: !llvm.ptr<2>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg12, %14[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %17, %18 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_cbuf_2d_bfloat16_t(%10, %18) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_cbuf_2d_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_ubuf_1d_float(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg0, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg1, %2[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg2, %3[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg3, %4[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %8 = llvm.insertvalue %arg5, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg7, %9[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg8, %10[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg9, %11[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %12, %13 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_ubuf_1d_float(%7, %13) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_ubuf_1d_float(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @indirect_store_2d_bfloat16_t_int64_t(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: !llvm.ptr<6>, %arg13: !llvm.ptr<6>, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: !llvm.ptr<6>, %arg20: !llvm.ptr<6>, %arg21: i64, %arg22: i64, %arg23: i64, %arg24: i64, %arg25: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.insertvalue %arg4, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %8 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %7, %8 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %9 = llvm.insertvalue %arg5, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.insertvalue %arg6, %9[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %11 = llvm.insertvalue %arg7, %10[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg9, %13[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg11, %14[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %15, %16 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %17 = llvm.insertvalue %arg12, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.insertvalue %arg13, %17[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.insertvalue %arg14, %18[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.insertvalue %arg16, %21[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %23 = llvm.insertvalue %arg18, %22[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %24 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %23, %24 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %25 = llvm.insertvalue %arg19, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %26 = llvm.insertvalue %arg20, %25[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %27 = llvm.insertvalue %arg21, %26[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %28 = llvm.insertvalue %arg22, %27[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %29 = llvm.insertvalue %arg24, %28[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %30 = llvm.insertvalue %arg23, %29[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %31 = llvm.insertvalue %arg25, %30[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %32 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %31, %32 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_indirect_store_2d_bfloat16_t_int64_t(%8, %16, %24, %32) : (!llvm.ptr, !llvm.ptr, !llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_indirect_store_2d_bfloat16_t_int64_t(!llvm.ptr, !llvm.ptr, !llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func @_mlir_ciface_vdiv_int32_t(vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32> attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func @_mlir_ciface_cast_int32_t_to_int64_t(!llvm.ptr, vector<64xi32>, vector<256xi1>) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @masked_store_NORM_B64_int64_t_rank1(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: vector<256xi1>, %arg7: !llvm.ptr) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg0, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg1, %2[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg2, %3[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg3, %4[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_masked_store_NORM_B64_int64_t_rank1(%7, %arg5, %arg6, %arg7) : (!llvm.ptr, i64, vector<256xi1>, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_masked_store_NORM_B64_int64_t_rank1(!llvm.ptr, i64, vector<256xi1>, !llvm.ptr) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @vload_NORM_int64_t_rank1(%arg0: !llvm.ptr, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg1, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg4, %4[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg5, %5[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_vload_NORM_int64_t_rank1(%arg0, %7, %arg6) : (!llvm.ptr, !llvm.ptr, i64) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_vload_NORM_int64_t_rank1(!llvm.ptr, !llvm.ptr, i64) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func @_mlir_ciface_vbr_int64_t(!llvm.ptr, i64) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func @_mlir_ciface_vadd_int64_t(!llvm.ptr, !llvm.ptr, !llvm.ptr, vector<256xi1>) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func @paged_prefill_small_q_grouped_kernel_mix_aiv(%arg0: i64, %arg1: !llvm.ptr<1>, %arg2: !llvm.ptr<1>, %arg3: !llvm.ptr<1>, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<1>, %arg8: !llvm.ptr<1>, %arg9: !llvm.ptr<1>, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: !llvm.ptr<1>, %arg14: !llvm.ptr<1>, %arg15: !llvm.ptr<1>, %arg16: !llvm.ptr<1>, %arg17: i32, %arg18: i32, %arg19: i32, %arg20: i32, %arg21: i32, %arg22: i32, %arg23: i32, %arg24: i32, %arg25: i32, %arg26: i32, %arg27: f32, %arg28: i32, %arg29: i32, %arg30: i32) attributes {DirectlyUsedGMArgIdxList = [5, 2], SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix, hivm.vf_mode = #hivm.vf_mode<MIX>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, mix_mode = "mix", parallel_mode = "mix_simd_simt"} {
    %0 = llvm.mlir.constant(272 : index) : i64
    %1 = llvm.mlir.constant(4 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %3 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %4 = llvm.mlir.constant(4096 : index) : i64
    %5 = llvm.mlir.constant(1 : index) : i64
    %6 = llvm.mlir.constant(256 : index) : i64
    %7 = llvm.mlir.constant(16 : index) : i64
    %8 = llvm.mlir.constant(48 : i64) : i64
    %9 = llvm.mlir.constant(60 : i64) : i64
    %10 = llvm.mlir.constant(0 : index) : i64
    %11 = llvm.mlir.constant(0 : i32) : i32
    %12 = llvm.mlir.constant(63 : i32) : i32
    %13 = llvm.mlir.constant(64 : i32) : i32
    %14 = llvm.mlir.constant(3 : i32) : i32
    %15 = llvm.mlir.constant(2 : i32) : i32
    %16 = llvm.mlir.constant(1024 : i64) : i64
    %17 = llvm.mlir.constant(1032 : i64) : i64
    %18 = llvm.mlir.constant(8 : i64) : i64
    %19 = llvm.mlir.constant(1028 : i64) : i64
    %20 = llvm.mlir.constant(4 : i64) : i64
    %21 = llvm.mlir.constant(0 : i64) : i64
    %22 = llvm.mlir.constant(16384 : i64) : i64
    %23 = llvm.mlir.constant(24576 : i64) : i64
    %24 = llvm.mlir.constant(24640 : i64) : i64
    %25 = llvm.mlir.constant(24704 : i64) : i64
    %26 = llvm.mlir.constant(159392 : i64) : i64
    %27 = llvm.mlir.constant(142944 : i64) : i64
    %28 = llvm.mlir.constant(24736 : i64) : i64
    %29 = llvm.mlir.constant(24992 : i64) : i64
    %30 = llvm.mlir.constant(57760 : i64) : i64
    %31 = llvm.mlir.constant(61856 : i64) : i64
    %32 = llvm.mlir.constant(94624 : i64) : i64
    %33 = llvm.mlir.constant(98720 : i64) : i64
    %34 = llvm.mlir.constant(106912 : i64) : i64
    %35 = llvm.mlir.constant(8192 : i64) : i64
    %36 = llvm.mlir.constant(115616 : i64) : i64
    %37 = llvm.mlir.constant(119712 : i64) : i64
    %38 = llvm.mlir.constant(136096 : i64) : i64
    %39 = llvm.mlir.constant(136160 : i64) : i64
    %40 = llvm.mlir.constant(136224 : i64) : i64
    %41 = llvm.mlir.constant(136288 : i64) : i64
    %42 = llvm.mlir.constant(143008 : i64) : i64
    %43 = llvm.mlir.constant(136352 : i64) : i64
    %44 = llvm.mlir.constant(140448 : i64) : i64
    %45 = llvm.mlir.constant(142816 : i64) : i64
    %46 = llvm.mlir.constant(140512 : i64) : i64
    %47 = llvm.mlir.constant(140576 : i64) : i64
    %48 = llvm.mlir.constant(140640 : i64) : i64
    %49 = llvm.mlir.constant(142880 : i64) : i64
    %50 = llvm.mlir.constant(159456 : i64) : i64
    %51 = llvm.mlir.constant(1 : i32) : i32
    %52 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %53 = "hivm.intr.hivm.SBITSET0"(%52, %9) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%53) : (i64) -> ()
    %54 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %55 = "hivm.intr.hivm.SBITSET1"(%54, %8) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%55) : (i64) -> ()
    %56 = "hivm.intr.hivm.GET.BLOCK.IDX"() : () -> i64
    %57 = llvm.trunc %56 : i64 to i32
    %58 = llvm.srem %57, %arg28  : i32
    %59 = llvm.inttoptr %21 : i64 to !llvm.ptr<11>
    %60 = llvm.inttoptr %16 : i64 to !llvm.ptr<11>
    llvm.store volatile %11, %59 : i32, !llvm.ptr<11>
    llvm.store volatile %11, %60 : i32, !llvm.ptr<11>
    %61 = llvm.inttoptr %20 : i64 to !llvm.ptr<11>
    %62 = llvm.inttoptr %19 : i64 to !llvm.ptr<11>
    llvm.store volatile %11, %61 : i32, !llvm.ptr<11>
    llvm.store volatile %11, %62 : i32, !llvm.ptr<11>
    %63 = llvm.inttoptr %18 : i64 to !llvm.ptr<11>
    %64 = llvm.inttoptr %17 : i64 to !llvm.ptr<11>
    llvm.store volatile %11, %63 : i32, !llvm.ptr<11>
    llvm.store volatile %11, %64 : i32, !llvm.ptr<11>
    %65 = "hivm.intr.hivm.GET.SUBBLOCKID"() : () -> i64
    %66 = llvm.mul %65, %16 : i64
    %67 = llvm.add %66, %20 : i64
    %68 = llvm.inttoptr %67 : i64 to !llvm.ptr<11>
    %69 = llvm.inttoptr %66 : i64 to !llvm.ptr<11>
    %70 = llvm.add %66, %18 : i64
    %71 = llvm.inttoptr %70 : i64 to !llvm.ptr<11>
    %72 = llvm.mul %58, %arg17 : i32
    %73 = llvm.sdiv %72, %arg28  : i32
    %74 = llvm.add %58, %51 : i32
    %75 = llvm.mul %74, %arg17 : i32
    %76 = llvm.sdiv %75, %arg28  : i32
    %77 = llvm.inttoptr %21 : i64 to !llvm.ptr<6>
    %78 = llvm.inttoptr %22 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_small_q_grouped_kernel_outlined_vf_15(%77, %78) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %79 = llvm.inttoptr %21 : i64 to !llvm.ptr<2>
    llvm.br ^bb1(%73 : i32)
  ^bb1(%80: i32):  // 2 preds: ^bb0, ^bb25
    %81 = llvm.icmp "slt" %80, %76 : i32
    llvm.cond_br %81, ^bb2, ^bb26
  ^bb2:  // pred: ^bb1
    %82 = llvm.sext %80 : i32 to i64
    %83 = llvm.getelementptr %arg13[%82] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %84 = llvm.load %83 : !llvm.ptr<1> -> i32
    %85 = llvm.add %82, %5 : i64
    %86 = llvm.getelementptr %arg13[%85] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %87 = llvm.load %86 : !llvm.ptr<1> -> i32
    %88 = llvm.sub %87, %84 : i32
    %89 = llvm.icmp "sgt" %88, %11 : i32
    llvm.cond_br %89, ^bb3, ^bb25
  ^bb3:  // pred: ^bb2
    %90 = llvm.inttoptr %23 : i64 to !llvm.ptr<6>
    %91 = llvm.inttoptr %24 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_small_q_grouped_kernel_outlined_vf_7(%90, %91) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %92 = llvm.sitofp %88 : i32 to f32
    %93 = llvm.inttoptr %25 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_small_q_grouped_kernel_outlined_vf_8(%90, %91, %92, %93) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, f32, !llvm.ptr<6>) -> ()
    %94 = llvm.load %arg16 : !llvm.ptr<1> -> f32
    %95 = llvm.getelementptr %arg16[1] : (!llvm.ptr<1>) -> !llvm.ptr<1>, f32
    %96 = llvm.load %95 : !llvm.ptr<1> -> f32
    %97 = llvm.getelementptr %arg16[2] : (!llvm.ptr<1>) -> !llvm.ptr<1>, f32
    %98 = llvm.load %97 : !llvm.ptr<1> -> f32
    %99 = llvm.getelementptr %arg16[3] : (!llvm.ptr<1>) -> !llvm.ptr<1>, f32
    %100 = llvm.load %99 : !llvm.ptr<1> -> f32
    %101 = llvm.getelementptr %arg16[4] : (!llvm.ptr<1>) -> !llvm.ptr<1>, f32
    %102 = llvm.load %101 : !llvm.ptr<1> -> f32
    %103 = llvm.getelementptr %arg16[5] : (!llvm.ptr<1>) -> !llvm.ptr<1>, f32
    %104 = llvm.load %103 : !llvm.ptr<1> -> f32
    %105 = llvm.inttoptr %26 : i64 to !llvm.ptr<6>
    %106 = llvm.insertvalue %105, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %107 = llvm.insertvalue %105, %106[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %108 = llvm.insertvalue %10, %107[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %109 = llvm.insertvalue %7, %108[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %110 = llvm.insertvalue %5, %109[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %111 = llvm.inttoptr %27 : i64 to !llvm.ptr<6>
    %112 = llvm.insertvalue %111, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %113 = llvm.insertvalue %111, %112[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %114 = llvm.insertvalue %10, %113[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %115 = llvm.insertvalue %7, %114[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %116 = llvm.insertvalue %5, %115[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_small_q_grouped_kernel_outlined_vf_9(%93, %90, %91, %102, %104, %100, %98, %96, %94, %105, %111) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, f32, f32, f32, f32, f32, f32, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %117 = llvm.getelementptr %arg14[%82] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %118 = llvm.load %117 : !llvm.ptr<1> -> i32
    %119 = llvm.sub %118, %88 : i32
    %120 = llvm.add %118, %12 : i32
    %121 = llvm.sdiv %120, %13  : i32
    %122 = llvm.inttoptr %28 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_small_q_grouped_kernel_outlined_vf_10(%122) {hivm.vector_function, no_inline} : (!llvm.ptr<6>) -> ()
    %123 = llvm.sitofp %118 : i32 to f32
    %124 = llvm.mul %84, %arg18 : i32
    %125 = llvm.sext %124 : i32 to i64
    %126 = llvm.inttoptr %29 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_small_q_grouped_kernel_outlined_vf_11(%126) {hivm.vector_function, no_inline} : (!llvm.ptr<6>) -> ()
    %127 = llvm.inttoptr %30 : i64 to !llvm.ptr<6>
    %128 = llvm.inttoptr %31 : i64 to !llvm.ptr<6>
    %129 = llvm.inttoptr %32 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_small_q_grouped_kernel_outlined_vf_12(%91, %119, %90, %93, %126, %arg19, %125, %127, %128, %129) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, i32, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i32, i64, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %130 = llvm.inttoptr %33 : i64 to !llvm.ptr<6>
    llvm.call @indirect_load_2d_bfloat16_t_int64_t(%arg3, %arg3, %arg4, %arg5, %arg6, %128, %128, %10, %7, %6, %6, %5, %130, %130, %10, %7, %6, %6, %5, %129, %129, %10, %7, %6, %6, %5, %78, %78, %10, %7, %6, %6, %5) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64) -> ()
    %131 = llvm.inttoptr %34 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_small_q_grouped_kernel_outlined_vf_13(%130, %131) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    %132 = llvm.icmp "eq" %65, %10 : i64
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %132, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    llvm.call @copy_ubuf_to_cbuf_2d_bfloat16_t(%131, %131, %10, %7, %6, %0, %5, %79, %79, %10, %7, %6, %6, %5) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64) -> ()
    llvm.br ^bb5
  ^bb5:  // 2 preds: ^bb3, ^bb4
    %133 = llvm.inttoptr %35 : i64 to !llvm.ptr<2>
    %134 = llvm.inttoptr %36 : i64 to !llvm.ptr<6>
    %135 = llvm.inttoptr %37 : i64 to !llvm.ptr<6>
    %136 = llvm.inttoptr %38 : i64 to !llvm.ptr<6>
    %137 = llvm.insertvalue %136, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %138 = llvm.insertvalue %136, %137[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %139 = llvm.insertvalue %10, %138[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %140 = llvm.insertvalue %7, %139[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %141 = llvm.insertvalue %5, %140[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %142 = llvm.inttoptr %39 : i64 to !llvm.ptr<6>
    %143 = llvm.insertvalue %142, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %144 = llvm.insertvalue %142, %143[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %145 = llvm.insertvalue %10, %144[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %146 = llvm.insertvalue %7, %145[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %147 = llvm.insertvalue %5, %146[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %148 = llvm.inttoptr %40 : i64 to !llvm.ptr<6>
    %149 = llvm.insertvalue %148, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %150 = llvm.insertvalue %148, %149[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %151 = llvm.insertvalue %10, %150[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %152 = llvm.insertvalue %7, %151[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %153 = llvm.insertvalue %5, %152[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %154 = llvm.inttoptr %41 : i64 to !llvm.ptr<6>
    %155 = llvm.insertvalue %154, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %156 = llvm.insertvalue %154, %155[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %157 = llvm.insertvalue %10, %156[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %158 = llvm.insertvalue %7, %157[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %159 = llvm.insertvalue %5, %158[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %160 = llvm.add %121, %14 : i32
    %161 = llvm.inttoptr %42 : i64 to !llvm.ptr<6>
    %162 = llvm.insertvalue %161, %3[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %163 = llvm.insertvalue %161, %162[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %164 = llvm.insertvalue %10, %163[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %165 = llvm.insertvalue %7, %164[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %166 = llvm.insertvalue %6, %165[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %167 = llvm.insertvalue %6, %166[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %168 = llvm.insertvalue %5, %167[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%77, %77, %10, %4, %5, %161, %161, %10, %4, %5) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.br ^bb6(%11, %116, %168, %110, %11, %11, %11, %11 : i32, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, i32, i32, i32, i32)
  ^bb6(%169: i32, %170: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %171: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %172: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %173: i32, %174: i32, %175: i32, %176: i32):  // 2 preds: ^bb5, ^bb21
    %177 = llvm.icmp "slt" %169, %160 : i32
    llvm.cond_br %177, ^bb7, ^bb22
  ^bb7:  // pred: ^bb6
    %178 = llvm.load volatile %69 : !llvm.ptr<11> -> i32
    %179 = llvm.icmp "sgt" %178, %11 : i32
    %180 = llvm.load volatile %71 : !llvm.ptr<11> -> i32
    %181 = llvm.icmp "slt" %180, %51 : i32
    %182 = llvm.and %179, %181  : i1
    %183 = llvm.icmp "slt" %175, %15 : i32
    %184 = llvm.icmp "slt" %176, %15 : i32
    %185 = llvm.and %183, %184  : i1
    %186 = llvm.icmp "slt" %173, %121 : i32
    %187 = llvm.and %182, %185  : i1
    %188 = llvm.and %187, %186  : i1
    llvm.cond_br %188, ^bb8, ^bb15
  ^bb8:  // pred: ^bb7
    %189 = llvm.mul %173, %13 : i32
    %190 = llvm.inttoptr %43 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_small_q_grouped_kernel_outlined_vf_0(%93, %127, %134, %122, %arg27, %189, %123, %190) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, f32, i32, f32, !llvm.ptr<6>) -> ()
    %191 = llvm.inttoptr %44 : i64 to !llvm.ptr<6>
    %192 = llvm.inttoptr %45 : i64 to !llvm.ptr<6>
    %193 = llvm.insertvalue %192, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %194 = llvm.insertvalue %192, %193[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %195 = llvm.insertvalue %10, %194[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %196 = llvm.insertvalue %7, %195[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %197 = llvm.insertvalue %5, %196[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %198 = llvm.extractvalue %172[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_small_q_grouped_kernel_outlined_vf_1(%190, %191, %198, %192) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %199 = llvm.inttoptr %43 : i64 to !llvm.ptr<6>
    %200 = llvm.inttoptr %46 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_small_q_grouped_kernel_outlined_vf_2(%190, %192, %199, %200) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %201 = llvm.srem %173, %15  : i32
    %202 = llvm.icmp "eq" %201, %11 : i32
    llvm.cond_br %202, ^bb9(%148 : !llvm.ptr<6>), ^bb9(%154 : !llvm.ptr<6>)
  ^bb9(%203: !llvm.ptr<6>):  // 2 preds: ^bb8, ^bb8
    llvm.call @copy_ubuf_to_ubuf_1d_float(%200, %200, %10, %7, %5, %203, %203, %10, %7, %5) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.br ^bb10
  ^bb10:  // pred: ^bb9
    %204 = llvm.inttoptr %47 : i64 to !llvm.ptr<6>
    %205 = llvm.inttoptr %48 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %206 = llvm.extractvalue %172[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_small_q_grouped_kernel_outlined_merged_vf_0(%206, %192, %204, %199, %205) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %202, ^bb11(%136 : !llvm.ptr<6>), ^bb11(%142 : !llvm.ptr<6>)
  ^bb11(%207: !llvm.ptr<6>):  // 2 preds: ^bb10, ^bb10
    llvm.call @copy_ubuf_to_ubuf_1d_float(%204, %204, %10, %7, %5, %207, %207, %10, %7, %5) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.br ^bb12
  ^bb12:  // pred: ^bb11
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %132, ^bb13, ^bb14
  ^bb13:  // pred: ^bb12
    llvm.call @copy_ubuf_to_cbuf_2d_bfloat16_t(%205, %205, %10, %1, %6, %0, %5, %133, %133, %10, %1, %6, %6, %5) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64) -> ()
    llvm.br ^bb14
  ^bb14:  // 2 preds: ^bb12, ^bb13
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %208 = llvm.load volatile %69 : !llvm.ptr<11> -> i32
    %209 = llvm.sub %208, %51 : i32
    llvm.store volatile %209, %69 : i32, !llvm.ptr<11>
    %210 = llvm.load volatile %71 : !llvm.ptr<11> -> i32
    %211 = llvm.add %210, %51 : i32
    llvm.store volatile %211, %71 : i32, !llvm.ptr<11>
    %212 = llvm.add %175, %51 : i32
    %213 = llvm.add %176, %51 : i32
    %214 = llvm.add %173, %51 : i32
    llvm.br ^bb16(%197, %212, %213, %214 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, i32, i32, i32)
  ^bb15:  // pred: ^bb7
    %215 = llvm.inttoptr %45 : i64 to !llvm.ptr<6>
    %216 = llvm.insertvalue %215, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %217 = llvm.insertvalue %215, %216[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %218 = llvm.insertvalue %10, %217[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %219 = llvm.insertvalue %7, %218[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %220 = llvm.insertvalue %5, %219[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %221 = llvm.extractvalue %172[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %222 = llvm.extractvalue %172[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %223 = llvm.extractvalue %172[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %224 = llvm.extractvalue %172[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %225 = llvm.extractvalue %172[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%221, %222, %223, %224, %225, %215, %215, %10, %7, %5) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.br ^bb16(%220, %175, %176, %173 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, i32, i32, i32)
  ^bb16(%226: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %227: i32, %228: i32, %229: i32):  // 2 preds: ^bb14, ^bb15
    llvm.br ^bb17
  ^bb17:  // pred: ^bb16
    %230 = llvm.load volatile %68 : !llvm.ptr<11> -> i32
    %231 = llvm.icmp "sgt" %230, %11 : i32
    %232 = llvm.icmp "sgt" %227, %11 : i32
    %233 = llvm.icmp "sgt" %228, %11 : i32
    %234 = llvm.and %232, %233  : i1
    %235 = llvm.icmp "slt" %174, %121 : i32
    %236 = llvm.and %231, %234  : i1
    %237 = llvm.and %236, %235  : i1
    llvm.cond_br %237, ^bb18, ^bb19
  ^bb18:  // pred: ^bb17
    %238 = llvm.srem %174, %15  : i32
    %239 = llvm.icmp "eq" %238, %11 : i32
    %240 = llvm.select %239, %141, %147 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %241 = llvm.inttoptr %49 : i64 to !llvm.ptr<6>
    %242 = llvm.extractvalue %240[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_small_q_grouped_kernel_outlined_vf_5(%242, %241) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %243 = llvm.select %239, %153, %159 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %244 = llvm.inttoptr %27 : i64 to !llvm.ptr<6>
    %245 = llvm.insertvalue %244, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %246 = llvm.insertvalue %244, %245[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %247 = llvm.insertvalue %10, %246[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %248 = llvm.insertvalue %7, %247[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %249 = llvm.insertvalue %5, %248[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %250 = llvm.inttoptr %42 : i64 to !llvm.ptr<6>
    %251 = llvm.insertvalue %250, %3[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %252 = llvm.insertvalue %250, %251[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %253 = llvm.insertvalue %10, %252[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %254 = llvm.insertvalue %7, %253[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %255 = llvm.insertvalue %6, %254[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %256 = llvm.insertvalue %6, %255[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %257 = llvm.insertvalue %5, %256[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %258 = llvm.extractvalue %170[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %259 = llvm.extractvalue %243[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %260 = llvm.extractvalue %171[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @paged_prefill_small_q_grouped_kernel_outlined_vf_6(%258, %241, %259, %244, %135, %260, %250) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %261 = llvm.load volatile %68 : !llvm.ptr<11> -> i32
    %262 = llvm.sub %261, %51 : i32
    llvm.store volatile %262, %68 : i32, !llvm.ptr<11>
    %263 = llvm.sub %227, %51 : i32
    %264 = llvm.sub %228, %51 : i32
    %265 = llvm.add %174, %51 : i32
    llvm.br ^bb20(%249, %257, %263, %264, %265 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, i32, i32, i32)
  ^bb19:  // pred: ^bb17
    llvm.br ^bb20(%170, %171, %227, %228, %174 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, i32, i32, i32)
  ^bb20(%266: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %267: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %268: i32, %269: i32, %270: i32):  // 2 preds: ^bb18, ^bb19
    llvm.br ^bb21
  ^bb21:  // pred: ^bb20
    %271 = llvm.inttoptr %26 : i64 to !llvm.ptr<6>
    %272 = llvm.insertvalue %271, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %273 = llvm.insertvalue %271, %272[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %274 = llvm.insertvalue %10, %273[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %275 = llvm.insertvalue %7, %274[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %276 = llvm.insertvalue %5, %275[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %277 = llvm.extractvalue %226[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %278 = llvm.extractvalue %226[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %279 = llvm.extractvalue %226[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %280 = llvm.extractvalue %226[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %281 = llvm.extractvalue %226[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%277, %278, %279, %280, %281, %271, %271, %10, %7, %5) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %282 = llvm.add %169, %51 overflow<nsw> : i32
    llvm.br ^bb6(%282, %266, %267, %276, %229, %270, %268, %269 : i32, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, i32, i32, i32, i32)
  ^bb22:  // pred: ^bb6
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %283 = llvm.mul %84, %arg24 : i32
    %284 = llvm.sext %283 : i32 to i64
    %285 = llvm.inttoptr %29 : i64 to !llvm.ptr<6>
    %286 = llvm.inttoptr %50 : i64 to !llvm.ptr<6>
    %287 = llvm.extractvalue %170[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %288 = llvm.extractvalue %171[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @paged_prefill_small_q_grouped_kernel_outlined_vf_14(%90, %287, %126, %arg25, %284, %288, %285, %286) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i32, i64, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    llvm.cond_br %132, ^bb23, ^bb24
  ^bb23:  // pred: ^bb22
    llvm.call @indirect_store_2d_bfloat16_t_int64_t(%arg9, %arg9, %arg10, %arg11, %arg12, %285, %285, %10, %7, %6, %6, %5, %286, %286, %10, %7, %6, %6, %5, %129, %129, %10, %7, %6, %6, %5) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64) -> ()
    llvm.br ^bb24
  ^bb24:  // 2 preds: ^bb22, ^bb23
    llvm.br ^bb25
  ^bb25:  // 2 preds: ^bb2, ^bb24
    %289 = llvm.add %80, %51 overflow<nsw> : i32
    llvm.br ^bb1(%289 : i32)
  ^bb26:  // pred: ^bb1
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 0 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 1 : i64}> : () -> ()
    %290 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %291 = "hivm.intr.hivm.SBITSET1"(%290, %9) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%291) : (i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 6 : i64}> : () -> ()
    llvm.return
  }
}


bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
ld.lld: warning: -z separate-code and -z separate-loadable-segments will be ignored
