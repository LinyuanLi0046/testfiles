// -----// IR Dump After AppendUsePrintDebugData (append-use-print-debug-data) //----- //
module attributes {dlti.target_system_spec = #dlti.target_system_spec<"NPU" : #hacc.target_device_spec<#dlti.dl_entry<"AI_CORE_COUNT", 28 : i32>, #dlti.dl_entry<"CUBE_CORE_COUNT", 28 : i32>, #dlti.dl_entry<"VECTOR_CORE_COUNT", 56 : i32>, #dlti.dl_entry<"UB_SIZE", 2031616 : i32>, #dlti.dl_entry<"L1_SIZE", 4194304 : i32>, #dlti.dl_entry<"L0A_SIZE", 524288 : i32>, #dlti.dl_entry<"L0B_SIZE", 524288 : i32>, #dlti.dl_entry<"L0C_SIZE", 2097152 : i32>, #dlti.dl_entry<"UB_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L1_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L0C_ALIGN_SIZE", 4096 : i32>, #dlti.dl_entry<"MINIMAL_D_CACHE_SIZE", 262144 : i32>, #dlti.dl_entry<"MAXIMUM_D_CACHE_SIZE", 983040 : i32>, #dlti.dl_entry<"ARCH", "dav-c310">>>, hacc.target = #hacc.target<"Ascend950PR_957b">, hivm.aic_bitcode = #hivm.aic_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.aic.c310.bc">, hivm.aiv_bitcode = #hivm.aiv_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.aiv.c310.bc">, hivm.host_bitcode = #hivm.host_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/host-a5.bc">, hivm.mix_aic_bitcode = #hivm.mix_aic_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.mix.aic.c310.bc">, hivm.mix_aiv_bitcode = #hivm.mix_aiv_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.mix.aiv.c310.bc">, hivm.module_core_type = #hivm.module_core_type<MIX>} {
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aic(%arg0: i64, %arg1: !llvm.ptr<1>, %arg2: !llvm.ptr<1>, %arg3: !llvm.ptr<1>, %arg4: !llvm.ptr<1>, %arg5: !llvm.ptr<1>, %arg6: !llvm.ptr<1>, %arg7: !llvm.ptr<1>, %arg8: !llvm.ptr<1>, %arg9: !llvm.ptr<1>, %arg10: !llvm.ptr<1>, %arg11: i32, %arg12: i32, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32, %arg17: i32, %arg18: i32, %arg19: i32, %arg20: i32, %arg21: f32, %arg22: i32, %arg23: i32, %arg24: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, hivm.vf_mode = #hivm.vf_mode<SIMD>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, mix_mode = "mix", parallel_mode = "simd"} {
    %0 = llvm.mlir.constant(3 : index) : i64
    %1 = llvm.mlir.constant(16 : i64) : i64
    %2 = llvm.mlir.constant(5 : index) : i64
    %3 = llvm.mlir.constant(-1 : index) : i64
    %4 = llvm.mlir.constant(12 : index) : i64
    %5 = llvm.mlir.constant(48 : i64) : i64
    %6 = llvm.mlir.constant(60 : i64) : i64
    %7 = llvm.mlir.constant(16384 : index) : i64
    %8 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %9 = llvm.mlir.constant(4096 : index) : i64
    %10 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %11 = llvm.mlir.constant(1024 : index) : i64
    %12 = llvm.mlir.constant(4 : index) : i64
    %13 = llvm.mlir.constant(0 : index) : i64
    %14 = llvm.mlir.constant(0 : i8) : i8
    %15 = llvm.mlir.constant(false) : i1
    %16 = llvm.mlir.constant(1.000000e+00 : f32) : f32
    %17 = llvm.mlir.constant(33920 : i64) : i64
    %18 = llvm.mlir.constant(8192 : i64) : i64
    %19 = llvm.mlir.constant(1152 : i64) : i64
    %20 = llvm.mlir.constant(16 : index) : i64
    %21 = llvm.mlir.constant(2 : i32) : i32
    %22 = llvm.mlir.constant(0 : i32) : i32
    %23 = llvm.mlir.constant(64 : i32) : i32
    %24 = llvm.mlir.constant(63 : i32) : i32
    %25 = llvm.mlir.constant(1 : index) : i64
    %26 = llvm.mlir.constant(0.000000e+00 : bf16) : bf16
    %27 = llvm.mlir.constant(256 : index) : i64
    %28 = llvm.mlir.constant(64 : index) : i64
    %29 = llvm.mlir.constant(1 : i32) : i32
    %30 = llvm.mlir.constant(true) : i1
    %31 = llvm.mlir.constant(2 : index) : i64
    %32 = llvm.mlir.constant(2 : i64) : i64
    %33 = llvm.mlir.constant(1 : i64) : i64
    %34 = llvm.mlir.constant(3 : i64) : i64
    %35 = llvm.mlir.constant(4 : i64) : i64
    %36 = llvm.mlir.constant(-1 : i64) : i64
    %37 = llvm.mlir.constant(118784 : i64) : i64
    %38 = llvm.mlir.constant(45056 : i64) : i64
    %39 = llvm.mlir.constant(24576 : i64) : i64
    %40 = llvm.mlir.constant(4096 : i64) : i64
    %41 = llvm.mlir.constant(86016 : i64) : i64
    %42 = llvm.mlir.constant(12288 : i64) : i64
    %43 = llvm.mlir.constant(77824 : i64) : i64
    %44 = llvm.mlir.constant(0 : i64) : i64
    %45 = llvm.mlir.constant(20480 : i64) : i64
    %46 = llvm.inttoptr %44 : i64 to !llvm.ptr<5>
    %47 = llvm.insertvalue %46, %10[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %48 = llvm.insertvalue %46, %47[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %49 = llvm.insertvalue %13, %48[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %50 = llvm.insertvalue %12, %49[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %51 = llvm.insertvalue %25, %50[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %52 = llvm.insertvalue %20, %51[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %53 = llvm.insertvalue %20, %52[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %54 = llvm.insertvalue %27, %53[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %55 = llvm.insertvalue %27, %54[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %56 = llvm.insertvalue %20, %55[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %57 = llvm.insertvalue %25, %56[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %58 = llvm.inttoptr %45 : i64 to !llvm.ptr<5>
    %59 = llvm.insertvalue %58, %10[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %60 = llvm.insertvalue %58, %59[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %61 = llvm.insertvalue %13, %60[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %62 = llvm.insertvalue %12, %61[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %63 = llvm.insertvalue %25, %62[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %64 = llvm.insertvalue %20, %63[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %65 = llvm.insertvalue %20, %64[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %66 = llvm.insertvalue %27, %65[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %67 = llvm.insertvalue %27, %66[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %68 = llvm.insertvalue %20, %67[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %69 = llvm.insertvalue %25, %68[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %70 = llvm.inttoptr %44 : i64 to !llvm.ptr<2>
    %71 = llvm.insertvalue %70, %8[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %72 = llvm.insertvalue %70, %71[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %73 = llvm.insertvalue %13, %72[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %74 = llvm.insertvalue %20, %73[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %75 = llvm.insertvalue %25, %74[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %76 = llvm.insertvalue %20, %75[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %77 = llvm.insertvalue %20, %76[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %78 = llvm.insertvalue %27, %77[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %79 = llvm.insertvalue %27, %78[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %80 = llvm.insertvalue %20, %79[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %81 = llvm.insertvalue %25, %80[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %82 = llvm.inttoptr %43 : i64 to !llvm.ptr<2>
    %83 = llvm.insertvalue %82, %8[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %84 = llvm.insertvalue %82, %83[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %85 = llvm.insertvalue %13, %84[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %86 = llvm.insertvalue %20, %85[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %87 = llvm.insertvalue %25, %86[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %88 = llvm.insertvalue %20, %87[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %89 = llvm.insertvalue %20, %88[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %90 = llvm.insertvalue %27, %89[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %91 = llvm.insertvalue %27, %90[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %92 = llvm.insertvalue %20, %91[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %93 = llvm.insertvalue %25, %92[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %94 = llvm.inttoptr %42 : i64 to !llvm.ptr<2>
    %95 = llvm.insertvalue %94, %8[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %96 = llvm.insertvalue %94, %95[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %97 = llvm.insertvalue %13, %96[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %98 = llvm.insertvalue %20, %97[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %99 = llvm.insertvalue %12, %98[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %100 = llvm.insertvalue %20, %99[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %101 = llvm.insertvalue %20, %100[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %102 = llvm.insertvalue %11, %101[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %103 = llvm.insertvalue %27, %102[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %104 = llvm.insertvalue %20, %103[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %105 = llvm.insertvalue %25, %104[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %106 = llvm.inttoptr %41 : i64 to !llvm.ptr<2>
    %107 = llvm.insertvalue %106, %8[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %108 = llvm.insertvalue %106, %107[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %109 = llvm.insertvalue %13, %108[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %110 = llvm.insertvalue %20, %109[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %111 = llvm.insertvalue %12, %110[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %112 = llvm.insertvalue %20, %111[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %113 = llvm.insertvalue %20, %112[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %114 = llvm.insertvalue %11, %113[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %115 = llvm.insertvalue %27, %114[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %116 = llvm.insertvalue %20, %115[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %117 = llvm.insertvalue %25, %116[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %118 = llvm.inttoptr %40 : i64 to !llvm.ptr<5>
    %119 = llvm.insertvalue %118, %10[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %120 = llvm.insertvalue %118, %119[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %121 = llvm.insertvalue %13, %120[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %122 = llvm.insertvalue %20, %121[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %123 = llvm.insertvalue %25, %122[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %124 = llvm.insertvalue %20, %123[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %125 = llvm.insertvalue %20, %124[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %126 = llvm.insertvalue %27, %125[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %127 = llvm.insertvalue %27, %126[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %128 = llvm.insertvalue %20, %127[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %129 = llvm.insertvalue %25, %128[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %130 = llvm.inttoptr %39 : i64 to !llvm.ptr<5>
    %131 = llvm.insertvalue %130, %10[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %132 = llvm.insertvalue %130, %131[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %133 = llvm.insertvalue %13, %132[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %134 = llvm.insertvalue %20, %133[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %135 = llvm.insertvalue %25, %134[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %136 = llvm.insertvalue %20, %135[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %137 = llvm.insertvalue %20, %136[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %138 = llvm.insertvalue %27, %137[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %139 = llvm.insertvalue %27, %138[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %140 = llvm.insertvalue %20, %139[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %141 = llvm.insertvalue %25, %140[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %142 = llvm.inttoptr %38 : i64 to !llvm.ptr<2>
    %143 = llvm.insertvalue %142, %8[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %144 = llvm.insertvalue %142, %143[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %145 = llvm.insertvalue %13, %144[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %146 = llvm.insertvalue %20, %145[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %147 = llvm.insertvalue %12, %146[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %148 = llvm.insertvalue %20, %147[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %149 = llvm.insertvalue %20, %148[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %150 = llvm.insertvalue %11, %149[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %151 = llvm.insertvalue %27, %150[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %152 = llvm.insertvalue %20, %151[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %153 = llvm.insertvalue %25, %152[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %154 = llvm.inttoptr %37 : i64 to !llvm.ptr<2>
    %155 = llvm.insertvalue %154, %8[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %156 = llvm.insertvalue %154, %155[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %157 = llvm.insertvalue %13, %156[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %158 = llvm.insertvalue %20, %157[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %159 = llvm.insertvalue %12, %158[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %160 = llvm.insertvalue %20, %159[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %161 = llvm.insertvalue %20, %160[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %162 = llvm.insertvalue %11, %161[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %163 = llvm.insertvalue %27, %162[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %164 = llvm.insertvalue %20, %163[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %165 = llvm.insertvalue %25, %164[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %166 = llvm.alloca %25 x i64 : (i64) -> !llvm.ptr
    llvm.store %44, %166 : i64, !llvm.ptr
    %167 = llvm.alloca %25 x i64 : (i64) -> !llvm.ptr
    llvm.store %44, %167 : i64, !llvm.ptr
    %168 = llvm.alloca %25 x i64 : (i64) -> !llvm.ptr
    llvm.store %44, %168 : i64, !llvm.ptr
    %169 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %170 = "hivm.intr.hivm.SBITSET0"(%169, %6) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%170) : (i64) -> ()
    %171 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %172 = "hivm.intr.hivm.SBITSET1"(%171, %5) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%172) : (i64) -> ()
    %173 = "hivm.intr.hivm.GET.BLOCK.IDX"() : () -> i64
    %174 = llvm.trunc %173 : i64 to i32
    %175 = llvm.srem %174, %arg22  : i32
    %176 = llvm.mul %175, %arg11 : i32
    %177 = llvm.sdiv %176, %arg22  : i32
    %178 = llvm.add %175, %29 : i32
    %179 = llvm.mul %178, %arg11 : i32
    %180 = llvm.sdiv %179, %arg22  : i32
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 19 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 3 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 20 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    llvm.br ^bb1(%177 : i32)
  ^bb1(%181: i32):  // 2 preds: ^bb0, ^bb17
    %182 = llvm.icmp "slt" %181, %180 : i32
    llvm.cond_br %182, ^bb2, ^bb18
  ^bb2:  // pred: ^bb1
    %183 = llvm.load %166 : !llvm.ptr -> i64
    %184 = llvm.urem %183, %32  : i64
    %185 = llvm.icmp "eq" %184, %33 : i64
    %186 = llvm.select %185, %93, %81 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %187 = llvm.trunc %184 : i64 to i1
    %188 = llvm.xor %187, %30  : i1
    %189 = llvm.zext %188 : i1 to i64
    %190 = llvm.sext %181 : i32 to i64
    %191 = llvm.getelementptr %arg7[%190] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %192 = llvm.load %191 : !llvm.ptr<1> -> i32
    %193 = llvm.add %190, %25 : i64
    %194 = llvm.getelementptr %arg7[%193] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %195 = llvm.load %194 : !llvm.ptr<1> -> i32
    %196 = llvm.sub %195, %192 : i32
    %197 = llvm.icmp "sgt" %196, %22 : i32
    llvm.cond_br %197, ^bb3, ^bb17
  ^bb3:  // pred: ^bb2
    %198 = llvm.mul %192, %arg12 : i32
    %199 = llvm.sext %198 : i32 to i64
    %200 = llvm.sext %arg13 : i32 to i64
    %201 = llvm.extractvalue %186[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %202 = llvm.extractvalue %186[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.REG"(%189) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.call @set_l1_2d_bfloat16_t(%26, %201, %202, %13, %9, %25) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    %203 = llvm.extractvalue %186[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %204 = llvm.extractvalue %186[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %205 = llvm.extractvalue %186[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %206 = llvm.extractvalue %186[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %207 = llvm.extractvalue %186[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %208 = llvm.extractvalue %186[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %209 = llvm.extractvalue %186[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %210 = llvm.extractvalue %186[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %211 = llvm.extractvalue %186[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %212 = llvm.extractvalue %186[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %213 = llvm.extractvalue %186[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @nd2nz_bfloat16_t(%arg3, %arg3, %199, %4, %27, %200, %25, %203, %204, %205, %206, %207, %208, %209, %210, %211, %212, %213) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    %214 = llvm.getelementptr %arg8[%190] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %215 = llvm.load %214 : !llvm.ptr<1> -> i32
    %216 = llvm.add %215, %24 : i32
    %217 = llvm.sdiv %216, %23  : i32
    %218 = llvm.sub %arg20, %29 : i32
    %219 = llvm.mul %181, %arg20 : i32
    %220 = llvm.sext %217 : i32 to i64
    %221 = llvm.sext %219 : i32 to i64
    %222 = llvm.sext %arg15 : i32 to i64
    %223 = llvm.sext %arg17 : i32 to i64
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 4 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    llvm.br ^bb4(%22 : i32)
  ^bb4(%224: i32):  // 2 preds: ^bb3, ^bb15
    %225 = llvm.icmp "slt" %224, %217 : i32
    llvm.cond_br %225, ^bb5, ^bb16
  ^bb5:  // pred: ^bb4
    %226 = llvm.inttoptr %19 : i64 to !llvm.ptr<6>
    %227 = llvm.inttoptr %18 : i64 to !llvm.ptr<2>
    %228 = llvm.inttoptr %17 : i64 to !llvm.ptr<6>
    %229 = llvm.sext %224 : i32 to i64
    %230 = llvm.mul %229, %3 : i64
    %231 = llvm.add %220, %230 : i64
    %232 = llvm.intr.umin(%231, %31)  : (i64, i64) -> i64
    llvm.br ^bb6(%13 : i64)
  ^bb6(%233: i64):  // 2 preds: ^bb5, ^bb9
    %234 = llvm.icmp "slt" %233, %232 : i64
    llvm.cond_br %234, ^bb7, ^bb10
  ^bb7:  // pred: ^bb6
    %235 = llvm.load %168 : !llvm.ptr -> i64
    %236 = llvm.urem %235, %32  : i64
    %237 = llvm.icmp "eq" %236, %33 : i64
    %238 = llvm.select %237, %69, %57 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %239 = llvm.select %237, %117, %105 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %240 = llvm.trunc %236 : i64 to i1
    %241 = llvm.xor %240, %30  : i1
    %242 = llvm.zext %241 : i1 to i64
    %243 = llvm.select %240, %34, %35 : i1, i64
    %244 = llvm.add %233, %2 : i64
    %245 = llvm.mul %233, %11 : i64
    %246 = llvm.add %233, %229 : i64
    %247 = llvm.trunc %246 : i64 to i32
    %248 = llvm.mul %247, %23 : i32
    %249 = llvm.add %248, %23 : i32
    %250 = llvm.intr.smin(%249, %215)  : (i32, i32) -> i32
    %251 = llvm.sub %250, %248 : i32
    %252 = llvm.sdiv %248, %23  : i32
    %253 = llvm.intr.smin(%252, %218)  : (i32, i32) -> i32
    %254 = llvm.sext %253 : i32 to i64
    %255 = llvm.add %221, %254 : i64
    %256 = llvm.getelementptr %arg9[%255] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %257 = llvm.load %256 : !llvm.ptr<1> -> i32
    %258 = llvm.mul %257, %arg14 : i32
    %259 = llvm.sext %258 : i32 to i64
    %260 = llvm.sext %251 : i32 to i64
    %261 = llvm.intr.smax(%260, %13)  : (i64, i64) -> i64
    %262 = llvm.intr.smin(%261, %28)  : (i64, i64) -> i64
    %263 = llvm.intr.smin(%262, %13)  : (i64, i64) -> i64
    %264 = llvm.mul %263, %3 : i64
    %265 = llvm.add %262, %264 : i64
    %266 = llvm.icmp "slt" %265, %28 : i64
    %267 = llvm.mul %263, %3 : i64
    %268 = llvm.add %262, %267 : i64
    %269 = llvm.icmp "sle" %268, %13 : i64
    %270 = llvm.sub %13, %268 : i64
    %271 = llvm.sub %268, %25 : i64
    %272 = llvm.select %269, %270, %271 : i1, i64
    %273 = llvm.sdiv %272, %20  : i64
    %274 = llvm.sub %13, %273 : i64
    %275 = llvm.add %273, %25 : i64
    %276 = llvm.select %269, %274, %275 : i1, i64
    %277 = llvm.extractvalue %239[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %278 = llvm.extractvalue %239[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %279 = llvm.mul %263, %20 : i64
    llvm.cond_br %266, ^bb8, ^bb9
  ^bb8:  // pred: ^bb7
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %280 = llvm.extractvalue %239[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %281 = llvm.extractvalue %239[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%26, %280, %281, %13, %7, %25) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb9
  ^bb9:  // 2 preds: ^bb7, ^bb8
    "hivm.intr.hivm.WAIT.FLAG.REG"(%243) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.call @nd2nz_bfloat16_t(%arg4, %arg4, %259, %265, %27, %222, %25, %277, %278, %279, %20, %276, %20, %20, %11, %27, %20, %25) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%242) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %282 = llvm.extractvalue %186[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %283 = llvm.extractvalue %186[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %284 = llvm.extractvalue %186[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %285 = llvm.extractvalue %186[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %286 = llvm.extractvalue %186[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %287 = llvm.extractvalue %186[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %288 = llvm.extractvalue %186[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %289 = llvm.extractvalue %186[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %290 = llvm.extractvalue %186[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %291 = llvm.extractvalue %186[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %292 = llvm.extractvalue %186[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %293 = llvm.extractvalue %239[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %294 = llvm.extractvalue %239[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %295 = llvm.extractvalue %239[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %296 = llvm.extractvalue %239[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %297 = llvm.extractvalue %239[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %298 = llvm.extractvalue %239[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %299 = llvm.extractvalue %239[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %300 = llvm.extractvalue %239[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %301 = llvm.extractvalue %239[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %302 = llvm.extractvalue %239[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %303 = llvm.extractvalue %239[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %304 = llvm.extractvalue %238[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %305 = llvm.extractvalue %238[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %306 = llvm.extractvalue %238[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %307 = llvm.extractvalue %238[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %308 = llvm.extractvalue %238[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %309 = llvm.extractvalue %238[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %310 = llvm.extractvalue %238[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %311 = llvm.extractvalue %238[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %312 = llvm.extractvalue %238[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %313 = llvm.extractvalue %238[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %314 = llvm.extractvalue %238[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float_tb(%282, %283, %284, %285, %286, %287, %288, %289, %290, %291, %292, %293, %294, %295, %296, %297, %298, %299, %300, %301, %302, %303, %30, %20, %27, %28, %304, %305, %306, %307, %308, %309, %310, %311, %312, %313, %314, %36, %44, %36, %243, %36, %36, %36, %14) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %315 = llvm.add %244, %1 : i64
    "hivm.intr.hivm.WAIT.INTRA.BLOCK.mode"(%315) <{pipe = 10 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCK.mode"(%244) <{pipe = 10 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 10 : i64}> : () -> ()
    %316 = llvm.extractvalue %238[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %317 = llvm.extractvalue %238[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %318 = llvm.extractvalue %238[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %319 = llvm.extractvalue %238[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %320 = llvm.extractvalue %238[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %321 = llvm.extractvalue %238[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %322 = llvm.extractvalue %238[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %323 = llvm.extractvalue %238[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %324 = llvm.extractvalue %238[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %325 = llvm.extractvalue %238[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %326 = llvm.extractvalue %238[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%316, %317, %318, %319, %320, %321, %322, %323, %324, %325, %326, %228, %228, %245, %20, %28, %28, %25, %44, %16, %44, %15, %14) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%242) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 16 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 0 : i64}> : () -> ()
    %327 = llvm.add %235, %33 : i64
    llvm.store %327, %168 : i64, !llvm.ptr
    %328 = llvm.add %233, %25 overflow<nsw> : i64
    llvm.br ^bb6(%328 : i64)
  ^bb10:  // pred: ^bb6
    llvm.br ^bb11(%13 : i64)
  ^bb11(%329: i64):  // 2 preds: ^bb10, ^bb14
    %330 = llvm.icmp "slt" %329, %232 : i64
    llvm.cond_br %330, ^bb12, ^bb15
  ^bb12:  // pred: ^bb11
    %331 = llvm.load %167 : !llvm.ptr -> i64
    %332 = llvm.urem %331, %32  : i64
    %333 = llvm.icmp "eq" %332, %33 : i64
    %334 = llvm.select %333, %141, %129 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %335 = llvm.select %333, %165, %153 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %336 = llvm.trunc %332 : i64 to i1
    %337 = llvm.xor %336, %30  : i1
    %338 = llvm.zext %337 : i1 to i64
    %339 = llvm.select %336, %34, %35 : i1, i64
    %340 = llvm.add %329, %0 : i64
    %341 = llvm.add %329, %25 : i64
    %342 = llvm.mul %329, %9 : i64
    %343 = llvm.add %329, %229 : i64
    %344 = llvm.trunc %343 : i64 to i32
    %345 = llvm.mul %344, %23 : i32
    %346 = llvm.add %345, %23 : i32
    %347 = llvm.intr.smin(%346, %215)  : (i32, i32) -> i32
    %348 = llvm.sub %347, %345 : i32
    %349 = llvm.sdiv %345, %23  : i32
    %350 = llvm.intr.smin(%349, %218)  : (i32, i32) -> i32
    %351 = llvm.sext %350 : i32 to i64
    %352 = llvm.add %221, %351 : i64
    %353 = llvm.getelementptr %arg9[%352] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %354 = llvm.load %353 : !llvm.ptr<1> -> i32
    %355 = llvm.mul %354, %arg16 : i32
    %356 = llvm.sext %355 : i32 to i64
    %357 = llvm.sext %348 : i32 to i64
    %358 = llvm.intr.smax(%357, %13)  : (i64, i64) -> i64
    %359 = llvm.intr.smin(%358, %28)  : (i64, i64) -> i64
    %360 = llvm.intr.smin(%359, %13)  : (i64, i64) -> i64
    %361 = llvm.mul %360, %3 : i64
    %362 = llvm.add %359, %361 : i64
    %363 = llvm.icmp "slt" %362, %28 : i64
    %364 = llvm.mul %360, %3 : i64
    %365 = llvm.add %359, %364 : i64
    %366 = llvm.icmp "sle" %365, %13 : i64
    %367 = llvm.sub %13, %365 : i64
    %368 = llvm.sub %365, %25 : i64
    %369 = llvm.select %366, %367, %368 : i1, i64
    %370 = llvm.sdiv %369, %20  : i64
    %371 = llvm.sub %13, %370 : i64
    %372 = llvm.add %370, %25 : i64
    %373 = llvm.select %366, %371, %372 : i1, i64
    %374 = llvm.extractvalue %335[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %375 = llvm.extractvalue %335[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %376 = llvm.mul %360, %20 : i64
    llvm.cond_br %363, ^bb13, ^bb14
  ^bb13:  // pred: ^bb12
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %377 = llvm.extractvalue %335[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %378 = llvm.extractvalue %335[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%26, %377, %378, %13, %7, %25) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb14
  ^bb14:  // 2 preds: ^bb12, ^bb13
    "hivm.intr.hivm.WAIT.FLAG.REG"(%339) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.call @nd2nz_bfloat16_t(%arg5, %arg5, %356, %362, %27, %223, %25, %374, %375, %376, %20, %373, %20, %20, %11, %27, %20, %25) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    %379 = llvm.mul %329, %11 : i64
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 24 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 8 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%338) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %380 = llvm.extractvalue %335[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %381 = llvm.extractvalue %335[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %382 = llvm.extractvalue %335[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %383 = llvm.extractvalue %335[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %384 = llvm.extractvalue %335[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %385 = llvm.extractvalue %335[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %386 = llvm.extractvalue %335[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %387 = llvm.extractvalue %335[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %388 = llvm.extractvalue %335[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %389 = llvm.extractvalue %335[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %390 = llvm.extractvalue %335[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %391 = llvm.extractvalue %334[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %392 = llvm.extractvalue %334[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %393 = llvm.extractvalue %334[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %394 = llvm.extractvalue %334[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %395 = llvm.extractvalue %334[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %396 = llvm.extractvalue %334[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %397 = llvm.extractvalue %334[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %398 = llvm.extractvalue %334[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %399 = llvm.extractvalue %334[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %400 = llvm.extractvalue %334[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %401 = llvm.extractvalue %334[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float(%227, %227, %379, %12, %25, %20, %20, %27, %27, %20, %25, %380, %381, %382, %383, %384, %385, %386, %387, %388, %389, %390, %30, %20, %28, %27, %391, %392, %393, %394, %395, %396, %397, %398, %399, %400, %401, %36, %44, %36, %339, %36, %36, %36, %14) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %402 = llvm.add %340, %1 : i64
    "hivm.intr.hivm.SET.INTRA.BLOCK.mode"(%402) <{pipe = 3 : i64}> : (i64) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCK.mode"(%340) <{pipe = 3 : i64}> : (i64) -> ()
    %403 = llvm.add %341, %1 : i64
    "hivm.intr.hivm.WAIT.INTRA.BLOCK.mode"(%403) <{pipe = 10 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCK.mode"(%341) <{pipe = 10 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 10 : i64}> : () -> ()
    %404 = llvm.extractvalue %334[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %405 = llvm.extractvalue %334[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %406 = llvm.extractvalue %334[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %407 = llvm.extractvalue %334[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %408 = llvm.extractvalue %334[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %409 = llvm.extractvalue %334[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %410 = llvm.extractvalue %334[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %411 = llvm.extractvalue %334[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %412 = llvm.extractvalue %334[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %413 = llvm.extractvalue %334[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %414 = llvm.extractvalue %334[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%404, %405, %406, %407, %408, %409, %410, %411, %412, %413, %414, %226, %226, %342, %20, %27, %27, %25, %44, %16, %44, %15, %14) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%338) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 23 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 7 : i64}> : () -> ()
    %415 = llvm.add %331, %33 : i64
    llvm.store %415, %167 : i64, !llvm.ptr
    %416 = llvm.add %329, %25 overflow<nsw> : i64
    llvm.br ^bb11(%416 : i64)
  ^bb15:  // pred: ^bb11
    %417 = llvm.add %224, %21 overflow<nsw> : i32
    llvm.br ^bb4(%417 : i32)
  ^bb16:  // pred: ^bb4
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 4 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%189) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.br ^bb17
  ^bb17:  // 2 preds: ^bb2, ^bb16
    %418 = llvm.add %183, %33 : i64
    llvm.store %418, %166 : i64, !llvm.ptr
    %419 = llvm.add %181, %29 overflow<nsw> : i32
    llvm.br ^bb1(%419 : i32)
  ^bb18:  // pred: ^bb1
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 17 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 18 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 21 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 22 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 6 : i64}> : () -> ()
    %420 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %421 = "hivm.intr.hivm.SBITSET1"(%420, %6) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%421) : (i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 6 : i64}> : () -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_0(%arg0: !llvm.ptr<6>, %arg1: i32, %arg2: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(0 : i32) : i32
    %1 = llvm.mlir.constant(8 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64s32"(%arg0, %0, %0, %0) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xi32>
    %4 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %5 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%3, %arg1, %4) : (vector<64xi32>, i32, vector<256xi1>) -> vector<64xi32>
    %6 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64s32"(%5, %arg2, %0, %2, %0, %6) : (vector<64xi32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_1(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: f32, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: i64) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(16 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(-1.000000e+00 : f16) : f16
    %4 = llvm.mlir.constant(0.000000e+00 : f16) : f16
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(8 : index) : i64
    %7 = llvm.mlir.constant(3 : i32) : i32
    %8 = llvm.mlir.constant(256 : index) : i64
    %9 = llvm.mlir.constant(4096 : index) : i64
    %10 = llvm.mlir.constant(0 : index) : i64
    %11 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %12 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%4, %11, %0) : (f16, vector<256xi1>, i32) -> vector<128xf16>
    %13 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %14 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%3, %13, %0) : (f16, vector<256xi1>, i32) -> vector<128xf16>
    llvm.br ^bb1(%2 : i32)
  ^bb1(%15: i32):  // 2 preds: ^bb0, ^bb2
    %16 = llvm.icmp "slt" %15, %1 : i32
    llvm.cond_br %16, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %17 = llvm.sext %15 : i32 to i64
    %18 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64s32"(%arg1, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xi32>
    %19 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %20 = "hivm_regbaseintrins.intr.hivm.vcvtif.s322f32.x"(%18, %19, %2) : (vector<64xi32>, vector<256xi1>, i32) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg2) : (f32) -> vector<64xf32>
    %22 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %23 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%20, %21, %22) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %24 = "hivm_regbaseintrins.intr.hivm.vsel"(%14, %12, %23) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    %25 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %26 = "hivm_regbaseintrins.intr.hivm.vcmp.ne.s.z"(%24, %12, %25) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<256xi1>
    %27 = llvm.mul %17, %8 : i64
    %28 = llvm.udiv %27, %6  : i64
    %29 = llvm.getelementptr %arg0[%28] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %30 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%29, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %31 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %32 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%30, %31) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %33 = llvm.extractvalue %32[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %34 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%33, %31) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %35 = llvm.extractvalue %34[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %36 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %37 = "hivm_regbaseintrins.intr.hivm.pand.z"(%35, %26, %36) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %38 = llvm.getelementptr %arg3[%17] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %39 = llvm.add %10, %10 : i64
    %40 = llvm.getelementptr %38[%39] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %41 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%40, %2, %7, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %42 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %43 = "hivm_regbaseintrins.intr.hivm.vcmp.le.s.z"(%20, %41, %42) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %44 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %45 = "hivm_regbaseintrins.intr.hivm.pand.z"(%37, %43, %44) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %46 = llvm.mul %arg5, %9 : i64
    %47 = llvm.mul %17, %8 : i64
    %48 = llvm.add %46, %47 : i64
    %49 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %50 = llvm.udiv %48, %6  : i64
    %51 = llvm.getelementptr %arg4[%50] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %52 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %53 = "hivm_regbaseintrins.intr.hivm.pstu.b32"(%45, %51, %52) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %54 = llvm.extractvalue %53[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %55 = llvm.extractvalue %53[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%54, %55, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %56 = llvm.add %15, %0 overflow<nsw> : i32
    llvm.br ^bb1(%56 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_2(%arg0: !llvm.ptr<6>, %arg1: i64, %arg2: !llvm.ptr<6>, %arg3: f32, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(8 : i32) : i32
    %1 = llvm.mlir.constant(-1.000000e+06 : f32) : f32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(16 : i32) : i32
    %4 = llvm.mlir.constant(1 : i32) : i32
    %5 = llvm.mlir.constant(8 : index) : i64
    %6 = llvm.mlir.constant(2 : i32) : i32
    %7 = llvm.mlir.constant(256 : index) : i64
    %8 = llvm.mlir.constant(4096 : index) : i64
    %9 = llvm.mlir.constant(1024 : index) : i64
    %10 = llvm.mlir.constant(64 : index) : i64
    %11 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %12 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%1, %11, %4) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    llvm.br ^bb1(%2 : i32)
  ^bb1(%13: i32):  // 2 preds: ^bb0, ^bb2
    %14 = llvm.icmp "slt" %13, %3 : i32
    llvm.cond_br %14, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %15 = llvm.sext %13 : i32 to i64
    %16 = llvm.mul %arg1, %8 : i64
    %17 = llvm.mul %15, %7 : i64
    %18 = llvm.add %16, %17 : i64
    %19 = llvm.udiv %18, %5  : i64
    %20 = llvm.getelementptr %arg0[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %21 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%20, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %23 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%21, %22) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %24 = llvm.extractvalue %23[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %25 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%24, %22) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %26 = llvm.extractvalue %25[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %27 = llvm.mul %arg1, %9 : i64
    %28 = llvm.mul %15, %10 : i64
    %29 = llvm.add %27, %28 : i64
    %30 = llvm.getelementptr %arg2[%29] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %31 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%30, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %32 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %33 = "hivm_regbaseintrins.intr.hivm.vmuls.s.x"(%31, %arg3, %32) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %34 = "hivm_regbaseintrins.intr.hivm.vsel"(%33, %12, %26) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %35 = llvm.mul %15, %10 : i64
    %36 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %37 = llvm.getelementptr %arg4[%35] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%34, %37, %2, %6, %2, %36) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %38 = llvm.add %13, %4 overflow<nsw> : i32
    llvm.br ^bb1(%38 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_3(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(16 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(8 : i32) : i32
    %4 = llvm.mlir.constant(4 : i32) : i32
    %5 = llvm.mlir.undef : !llvm.ptr<6>
    %6 = llvm.mlir.constant(64 : index) : i64
    %7 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %7, %5 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%8: i32, %9: vector<32xi8>, %10: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %11 = llvm.icmp "slt" %8, %1 : i32
    llvm.cond_br %11, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %12 = llvm.sext %8 : i32 to i64
    %13 = llvm.mul %12, %6 : i64
    %14 = llvm.getelementptr %arg0[%13] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %15 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%14, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %16 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %17 = "hivm_regbaseintrins.intr.hivm.vcmax.s.x"(%15, %16) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %18 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %19 = llvm.getelementptr %arg1[%12] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %20 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%17, %19, %4, %9) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %21 = llvm.extractvalue %20[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %22 = llvm.extractvalue %20[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %23 = llvm.add %8, %0 overflow<nsw> : i32
    llvm.br ^bb1(%23, %21, %22 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%9, %10, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_4(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %1) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %4 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %5 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %6 = "hivm_regbaseintrins.intr.hivm.vmax.s.x"(%4, %5, %3) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%6, %arg2, %1, %2, %1, %3) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_5(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = llvm.mlir.constant(16 : index) : i64
    %4 = llvm.mul %arg3, %3 : i64
    %5 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %1) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %6 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %7 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %8 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%6, %7, %5, %1) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %9 = llvm.getelementptr %arg2[%4] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%8, %9, %1, %2, %1, %5) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %10 = llvm.getelementptr %arg2[%4] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %11 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%10, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%11, %arg4, %1, %2, %1, %5) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_6(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(16 : i32) : i32
    %3 = llvm.mlir.constant(1 : i32) : i32
    %4 = llvm.mlir.constant(3 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(1114112 : i32) : i32
    %7 = llvm.mlir.constant(4 : i32) : i32
    %8 = llvm.mlir.constant(6 : i32) : i32
    %9 = llvm.mlir.constant(2 : i32) : i32
    %10 = llvm.mlir.undef : !llvm.ptr<6>
    %11 = llvm.mlir.constant(64 : index) : i64
    %12 = llvm.mlir.constant(272 : index) : i64
    %13 = llvm.mlir.constant(16 : index) : i64
    %14 = llvm.mlir.constant(0 : index) : i64
    %15 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%1, %15, %10 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%16: i32, %17: vector<32xi8>, %18: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %19 = llvm.icmp "slt" %16, %2 : i32
    llvm.cond_br %19, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %20 = llvm.sext %16 : i32 to i64
    %21 = llvm.mul %20, %11 : i64
    %22 = llvm.getelementptr %arg0[%21] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%22, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %24 = llvm.getelementptr %arg1[%20] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %25 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%24, %1, %4, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %1) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %27 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%23, %25, %26, %1) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %1) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%27, %0, %28) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %30 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %1) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %31 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%27, %30, %1, %1, %1) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %32 = llvm.mul %20, %13 : i64
    %33 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%5, %1) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %34 = "hivm_regbaseintrins.intr.hivm.vdintlv"(%31, %31) : (vector<128xbf16>, vector<128xbf16>) -> !llvm.struct<(vector<128xbf16>, vector<128xbf16>)>
    %35 = llvm.extractvalue %34[0] : !llvm.struct<(vector<128xbf16>, vector<128xbf16>)> 
    %36 = llvm.getelementptr %arg3[%32] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %37 = llvm.mul %14, %12 : i64
    %38 = llvm.add %37, %14 : i64
    %39 = llvm.getelementptr %36[%38] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vsstb.v128bf16"(%35, %39, %6, %1, %33) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, vector<256xi1>) -> ()
    %40 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %1) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %41 = "hivm_regbaseintrins.intr.hivm.vcadd.s.x"(%29, %40) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %42 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %1) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %43 = llvm.getelementptr %arg2[%20] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %44 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%41, %43, %7, %17) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %45 = llvm.extractvalue %44[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %46 = llvm.extractvalue %44[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %47 = llvm.add %16, %3 overflow<nsw> : i32
    llvm.br ^bb1(%47, %45, %46 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%17, %18, %1, %1) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %48 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %1) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %49 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg4, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %50 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg5, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %51 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg2, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %52 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%49, %50, %48) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %53 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%52, %51, %48) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%53, %arg6, %1, %9, %1, %48) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_7(%arg0: !llvm.ptr<6>, %arg1: i64, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(16 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(256 : i32) : i32
    %4 = llvm.mlir.constant(64 : i32) : i32
    %5 = llvm.mlir.constant(3 : i32) : i32
    %6 = llvm.mlir.constant(8 : i32) : i32
    %7 = llvm.mlir.constant(2 : i32) : i32
    %8 = llvm.mlir.constant(4096 : index) : i64
    %9 = llvm.mlir.constant(256 : index) : i64
    %10 = llvm.mlir.constant(16 : index) : i64
    %11 = llvm.mlir.constant(0 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%12: i32):  // 2 preds: ^bb0, ^bb5
    %13 = llvm.icmp "slt" %12, %1 : i32
    llvm.cond_br %13, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %14 = llvm.sext %12 : i32 to i64
    %15 = llvm.mul %arg1, %10 : i64
    %16 = llvm.add %15, %14 : i64
    llvm.br ^bb3(%2 : i32)
  ^bb3(%17: i32):  // 2 preds: ^bb2, ^bb4
    %18 = llvm.icmp "slt" %17, %3 : i32
    llvm.cond_br %18, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %19 = llvm.sext %17 : i32 to i64
    %20 = llvm.mul %arg1, %8 : i64
    %21 = llvm.mul %14, %9 : i64
    %22 = llvm.add %20, %21 : i64
    %23 = llvm.add %22, %19 : i64
    %24 = llvm.getelementptr %arg2[%23] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %25 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%24, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %26 = llvm.mul %14, %9 : i64
    %27 = llvm.add %26, %19 : i64
    %28 = llvm.getelementptr %arg3[%27] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %29 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%28, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %30 = llvm.getelementptr %arg0[%16] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %31 = llvm.mul %11, %10 : i64
    %32 = llvm.getelementptr %30[%31] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %33 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%32, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %34 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %35 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%29, %33, %34) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %36 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %37 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%25, %35, %36) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %38 = llvm.mul %14, %9 : i64
    %39 = llvm.add %38, %19 : i64
    %40 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %41 = llvm.getelementptr %arg4[%39] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%37, %41, %2, %7, %2, %40) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %42 = llvm.add %17, %4 overflow<nsw> : i32
    llvm.br ^bb3(%42 : i32)
  ^bb5:  // pred: ^bb3
    %43 = llvm.add %12, %0 overflow<nsw> : i32
    llvm.br ^bb1(%43 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_8(%arg0: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(0 : i32) : i32
    %1 = llvm.mlir.constant(8 : i32) : i32
    %2 = llvm.mlir.constant(1 : i32) : i32
    %3 = llvm.mlir.constant(6 : i32) : i32
    %4 = llvm.mlir.constant(2 : i32) : i32
    %5 = "hivm_regbaseintrins.intr.hivm.vci"(%0, %0) : (i32, i32) -> vector<64xi32>
    %6 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %7 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%0, %6, %2) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %8 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %0) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %9 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%7, %5, %8) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64s32"(%9, %arg0, %0, %4, %0, %8) : (vector<64xi32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_9(%arg0: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1.000000e+00 : f32) : f32
    %1 = llvm.mlir.constant(8 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(1 : i32) : i32
    %4 = llvm.mlir.constant(12 : i32) : i32
    %5 = llvm.mlir.constant(2 : i32) : i32
    %6 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %7 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%0, %6, %3) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %8 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%4) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %9 = llvm.extractvalue %8[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%7, %arg0, %2, %5, %2, %9) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_10(%arg0: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(0 : i32) : i32
    %1 = llvm.mlir.constant(8 : i32) : i32
    %2 = llvm.mlir.constant(1 : i32) : i32
    %3 = llvm.mlir.constant(2 : i32) : i32
    %4 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %5 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%0, %4, %2) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %6 = "hivm_regbaseintrins.intr.hivm.vci"(%0, %0) : (i32, i32) -> vector<64xi32>
    %7 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %8 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%5, %6, %7) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    %9 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64s32"(%8, %arg0, %0, %3, %0, %9) : (vector<64xi32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_11(%arg0: !llvm.ptr<6>, %arg1: f32, %arg2: f32, %arg3: f32, %arg4: f32, %arg5: f32, %arg6: f32, %arg7: i32, %arg8: !llvm.ptr<6>, %arg9: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(5 : i32) : i32
    %2 = llvm.mlir.constant(4 : i32) : i32
    %3 = llvm.mlir.constant(3 : i32) : i32
    %4 = llvm.mlir.constant(2 : i32) : i32
    %5 = llvm.mlir.constant(1 : i32) : i32
    %6 = llvm.mlir.constant(8 : i32) : i32
    %7 = llvm.mlir.constant(0 : i32) : i32
    %8 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %7) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %9 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%5, %8, %5) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %10 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %7) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %11 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%4, %10, %5) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %12 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %7) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %13 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%3, %12, %5) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %14 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %7) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %15 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%2, %14, %5) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %16 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %7) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %17 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%1, %16, %5) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %18 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %7) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %19 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%0, %18, %5) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %20 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %7) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %21 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64s32"(%arg0, %7, %7, %7) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xi32>
    %22 = llvm.call @_mlir_ciface_vdiv_int32_t(%21, %19, %20) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    %23 = "hivm_regbaseintrins.intr.hivm.vmuls.s.x"(%22, %0, %20) : (vector<64xi32>, i32, vector<256xi1>) -> vector<64xi32>
    %24 = "hivm_regbaseintrins.intr.hivm.vsub.s.x"(%21, %23, %20) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    %25 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%24, %17, %20) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<256xi1>
    %26 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg1) : (f32) -> vector<64xf32>
    %27 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg2) : (f32) -> vector<64xf32>
    %28 = "hivm_regbaseintrins.intr.hivm.vsel"(%26, %27, %25) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %29 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%24, %15, %20) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<256xi1>
    %30 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg3) : (f32) -> vector<64xf32>
    %31 = "hivm_regbaseintrins.intr.hivm.vsel"(%30, %28, %29) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %32 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%24, %13, %20) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<256xi1>
    %33 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg4) : (f32) -> vector<64xf32>
    %34 = "hivm_regbaseintrins.intr.hivm.vsel"(%33, %31, %32) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %35 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%24, %11, %20) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<256xi1>
    %36 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg5) : (f32) -> vector<64xf32>
    %37 = "hivm_regbaseintrins.intr.hivm.vsel"(%36, %34, %35) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %38 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%24, %9, %20) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<256xi1>
    %39 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg6) : (f32) -> vector<64xf32>
    %40 = "hivm_regbaseintrins.intr.hivm.vsel"(%39, %37, %38) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%40, %arg8, %7, %4, %7, %20) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %41 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%22, %arg7, %20) : (vector<64xi32>, i32, vector<256xi1>) -> vector<64xi32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64s32"(%41, %arg9, %7, %4, %7, %20) : (vector<64xi32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_12(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(8 : i32) : i32
    %1 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %2 = llvm.mlir.constant(0.000000e+00 : f16) : f16
    %3 = llvm.mlir.constant(-1.000000e+00 : f16) : f16
    %4 = llvm.mlir.constant(12 : i32) : i32
    %5 = llvm.mlir.constant(0 : i32) : i32
    %6 = llvm.mlir.constant(16 : i32) : i32
    %7 = llvm.mlir.constant(1 : i32) : i32
    %8 = llvm.mlir.constant(256 : i32) : i32
    %9 = llvm.mlir.constant(64 : i32) : i32
    %10 = llvm.mlir.constant(3 : i32) : i32
    %11 = llvm.mlir.constant(8 : index) : i64
    %12 = llvm.mlir.constant(5 : i32) : i32
    %13 = llvm.mlir.constant(2 : i32) : i32
    %14 = llvm.mlir.constant(256 : index) : i64
    %15 = llvm.mlir.constant(0 : index) : i64
    %16 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %17 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%1, %16, %7) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %18 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %19 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%2, %18, %7) : (f16, vector<256xi1>, i32) -> vector<128xf16>
    %20 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %21 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%3, %20, %7) : (f16, vector<256xi1>, i32) -> vector<128xf16>
    %22 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %23 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%4, %22, %7) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    llvm.br ^bb1(%5 : i32)
  ^bb1(%24: i32):  // 2 preds: ^bb0, ^bb5
    %25 = llvm.icmp "slt" %24, %6 : i32
    llvm.cond_br %25, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %26 = llvm.sext %24 : i32 to i64
    %27 = llvm.getelementptr %arg0[%26] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i32
    %28 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64s32"(%27, %5, %10, %5) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xi32>
    %29 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %30 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%28, %23, %29) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<256xi1>
    %31 = "hivm_regbaseintrins.intr.hivm.vsel"(%21, %19, %30) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    %32 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %33 = "hivm_regbaseintrins.intr.hivm.vcmp.ne.s.z"(%31, %19, %32) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<256xi1>
    %34 = llvm.mul %26, %14 : i64
    %35 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %36 = llvm.udiv %34, %11  : i64
    %37 = llvm.getelementptr %arg2[%36] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %38 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %39 = "hivm_regbaseintrins.intr.hivm.pstu.b32"(%33, %37, %38) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %40 = llvm.extractvalue %39[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %41 = llvm.extractvalue %39[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%40, %41, %5, %5) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %42 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %43 = llvm.getelementptr %arg1[%26] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i32
    %44 = llvm.add %15, %15 : i64
    %45 = llvm.getelementptr %43[%44] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i32
    %46 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64s32"(%45, %5, %10, %5) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xi32>
    %47 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %48 = "hivm_regbaseintrins.intr.hivm.vcvtif.s322f32.x"(%46, %47, %5) : (vector<64xi32>, vector<256xi1>, i32) -> vector<64xf32>
    %49 = llvm.getelementptr %arg3[%26] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %50 = llvm.add %15, %15 : i64
    %51 = llvm.getelementptr %49[%50] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%48, %51, %5, %12, %5, %42) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.br ^bb3(%5 : i32)
  ^bb3(%52: i32):  // 2 preds: ^bb2, ^bb4
    %53 = llvm.icmp "slt" %52, %8 : i32
    llvm.cond_br %53, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %54 = llvm.sext %52 : i32 to i64
    %55 = llvm.mul %26, %14 : i64
    %56 = llvm.add %55, %54 : i64
    %57 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %58 = llvm.getelementptr %arg4[%56] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%17, %58, %5, %13, %5, %57) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %59 = llvm.add %52, %9 overflow<nsw> : i32
    llvm.br ^bb3(%59 : i32)
  ^bb5:  // pred: ^bb3
    %60 = llvm.add %24, %7 overflow<nsw> : i32
    llvm.br ^bb1(%60 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_13(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(16 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(256 : i32) : i32
    %4 = llvm.mlir.constant(64 : i32) : i32
    %5 = llvm.mlir.constant(3 : i32) : i32
    %6 = llvm.mlir.constant(8 : i32) : i32
    %7 = llvm.mlir.constant(7 : i32) : i32
    %8 = llvm.mlir.constant(256 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%9: i32):  // 2 preds: ^bb0, ^bb5
    %10 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %10, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %11 = llvm.sext %9 : i32 to i64
    llvm.br ^bb3(%2 : i32)
  ^bb3(%12: i32):  // 2 preds: ^bb2, ^bb4
    %13 = llvm.icmp "slt" %12, %3 : i32
    llvm.cond_br %13, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %14 = llvm.sext %12 : i32 to i64
    %15 = llvm.mul %11, %8 : i64
    %16 = llvm.add %15, %14 : i64
    %17 = llvm.getelementptr %arg1[%16] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %18 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%17, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %19 = llvm.getelementptr %arg0[%11] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %20 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%19, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.vdiv.s.x"(%18, %20, %21) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %23 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %24 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%22, %23, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %25 = llvm.mul %11, %8 : i64
    %26 = llvm.add %25, %14 : i64
    %27 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %28 = llvm.getelementptr %arg2[%26] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%24, %28, %2, %7, %2, %27) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %29 = llvm.add %12, %4 overflow<nsw> : i32
    llvm.br ^bb3(%29 : i32)
  ^bb5:  // pred: ^bb3
    %30 = llvm.add %9, %0 overflow<nsw> : i32
    llvm.br ^bb1(%30 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_14(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(0xFF800000 : f32) : f32
    %1 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %2 = llvm.mlir.constant(8 : i32) : i32
    %3 = llvm.mlir.constant(0 : i32) : i32
    %4 = llvm.mlir.constant(1 : i32) : i32
    %5 = llvm.mlir.constant(6 : i32) : i32
    %6 = llvm.mlir.constant(2 : i32) : i32
    %7 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %8 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%1, %7, %4) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %9 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %10 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%0, %9, %4) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %11 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %3) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%10, %arg0, %3, %6, %3, %11) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%8, %arg1, %3, %6, %3, %11) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func private @set_l1_2d_bfloat16_t(%arg0: bf16, %arg1: !llvm.ptr<2>, %arg2: !llvm.ptr<2>, %arg3: i64, %arg4: i64, %arg5: i64) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg1, %1[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg4, %4[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg5, %5[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_set_l1_2d_bfloat16_t(%arg0, %7) : (bf16, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_set_l1_2d_bfloat16_t(bf16, !llvm.ptr) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @nd2nz_bfloat16_t(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<2>, %arg8: !llvm.ptr<2>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %15 = llvm.insertvalue %arg14, %14[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg15, %16[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg12, %17[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg13, %19[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %21, %22 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_nd2nz_bfloat16_t(%10, %22) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_nd2nz_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @mma_tile_bfloat16_t_to_float_tb(%arg0: !llvm.ptr<2>, %arg1: !llvm.ptr<2>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<2>, %arg12: !llvm.ptr<2>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64, %arg21: i64, %arg22: i1, %arg23: i64, %arg24: i64, %arg25: i64, %arg26: !llvm.ptr<5>, %arg27: !llvm.ptr<5>, %arg28: i64, %arg29: i64, %arg30: i64, %arg31: i64, %arg32: i64, %arg33: i64, %arg34: i64, %arg35: i64, %arg36: i64, %arg37: i64, %arg38: i64, %arg39: i64, %arg40: i64, %arg41: i64, %arg42: i64, %arg43: i64, %arg44: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg18, %18[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.insertvalue %arg16, %21[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %24 = llvm.insertvalue %arg17, %23[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %25 = llvm.insertvalue %arg21, %24[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %26 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %25, %26 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %27 = llvm.insertvalue %arg26, %0[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %28 = llvm.insertvalue %arg27, %27[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %29 = llvm.insertvalue %arg28, %28[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %30 = llvm.insertvalue %arg29, %29[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %31 = llvm.insertvalue %arg33, %30[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %32 = llvm.insertvalue %arg30, %31[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %33 = llvm.insertvalue %arg34, %32[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %34 = llvm.insertvalue %arg31, %33[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %35 = llvm.insertvalue %arg35, %34[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %36 = llvm.insertvalue %arg32, %35[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %37 = llvm.insertvalue %arg36, %36[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %38 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %37, %38 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_mma_tile_bfloat16_t_to_float_tb(%14, %26, %arg22, %arg23, %arg24, %arg25, %38, %arg37, %arg38, %arg39, %arg40, %arg41, %arg42, %arg43, %arg44) : (!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_mma_tile_bfloat16_t_to_float_tb(!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%arg0: !llvm.ptr<5>, %arg1: !llvm.ptr<5>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<6>, %arg12: !llvm.ptr<6>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: f32, %arg20: i64, %arg21: i1, %arg22: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %21, %22 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%14, %22, %arg18, %arg19, %arg20, %arg21, %arg22) : (!llvm.ptr, !llvm.ptr, i64, f32, i64, i1, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(!llvm.ptr, !llvm.ptr, i64, f32, i64, i1, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @mma_tile_bfloat16_t_to_float(%arg0: !llvm.ptr<2>, %arg1: !llvm.ptr<2>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<2>, %arg12: !llvm.ptr<2>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64, %arg21: i64, %arg22: i1, %arg23: i64, %arg24: i64, %arg25: i64, %arg26: !llvm.ptr<5>, %arg27: !llvm.ptr<5>, %arg28: i64, %arg29: i64, %arg30: i64, %arg31: i64, %arg32: i64, %arg33: i64, %arg34: i64, %arg35: i64, %arg36: i64, %arg37: i64, %arg38: i64, %arg39: i64, %arg40: i64, %arg41: i64, %arg42: i64, %arg43: i64, %arg44: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg18, %18[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.insertvalue %arg16, %21[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %24 = llvm.insertvalue %arg17, %23[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %25 = llvm.insertvalue %arg21, %24[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %26 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %25, %26 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %27 = llvm.insertvalue %arg26, %0[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %28 = llvm.insertvalue %arg27, %27[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %29 = llvm.insertvalue %arg28, %28[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %30 = llvm.insertvalue %arg29, %29[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %31 = llvm.insertvalue %arg33, %30[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %32 = llvm.insertvalue %arg30, %31[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %33 = llvm.insertvalue %arg34, %32[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %34 = llvm.insertvalue %arg31, %33[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %35 = llvm.insertvalue %arg35, %34[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %36 = llvm.insertvalue %arg32, %35[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %37 = llvm.insertvalue %arg36, %36[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %38 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %37, %38 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_mma_tile_bfloat16_t_to_float(%14, %26, %arg22, %arg23, %arg24, %arg25, %38, %arg37, %arg38, %arg39, %arg40, %arg41, %arg42, %arg43, %arg44) : (!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_mma_tile_bfloat16_t_to_float(!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_ubuf_1d_float(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg0, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg1, %2[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg2, %3[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg3, %4[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %8 = llvm.insertvalue %arg5, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg7, %9[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg8, %10[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg9, %11[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %12, %13 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_ubuf_1d_float(%7, %13) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_ubuf_1d_float(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_cbuf_2d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<2>, %arg8: !llvm.ptr<2>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg12, %14[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %17, %18 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_cbuf_2d_bfloat16_t(%10, %18) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_cbuf_2d_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @store_ubuf_to_gm_2d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<1>, %arg8: !llvm.ptr<1>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg12, %14[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %17, %18 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_store_ubuf_to_gm_2d_bfloat16_t(%10, %18, %arg14) : (!llvm.ptr, !llvm.ptr, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_store_ubuf_to_gm_2d_bfloat16_t(!llvm.ptr, !llvm.ptr, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func @_mlir_ciface_vdiv_int32_t(vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32> attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv(%arg0: i64, %arg1: !llvm.ptr<1>, %arg2: !llvm.ptr<1>, %arg3: !llvm.ptr<1>, %arg4: !llvm.ptr<1>, %arg5: !llvm.ptr<1>, %arg6: !llvm.ptr<1>, %arg7: !llvm.ptr<1>, %arg8: !llvm.ptr<1>, %arg9: !llvm.ptr<1>, %arg10: !llvm.ptr<1>, %arg11: i32, %arg12: i32, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32, %arg17: i32, %arg18: i32, %arg19: i32, %arg20: i32, %arg21: f32, %arg22: i32, %arg23: i32, %arg24: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix, hivm.vf_mode = #hivm.vf_mode<SIMD>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, mix_mode = "mix", parallel_mode = "simd"} {
    %0 = llvm.mlir.constant(272 : index) : i64
    %1 = llvm.mlir.constant(-1 : index) : i64
    %2 = llvm.mlir.constant(1024 : index) : i64
    %3 = llvm.mlir.constant(256 : index) : i64
    %4 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %5 = llvm.mlir.constant(12 : index) : i64
    %6 = llvm.mlir.constant(5 : index) : i64
    %7 = llvm.mlir.constant(4 : index) : i64
    %8 = llvm.mlir.constant(3 : index) : i64
    %9 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %10 = llvm.mlir.constant(16 : index) : i64
    %11 = llvm.mlir.constant(48 : i64) : i64
    %12 = llvm.mlir.constant(60 : i64) : i64
    %13 = llvm.mlir.constant(0 : index) : i64
    %14 = llvm.mlir.constant(63 : i32) : i32
    %15 = llvm.mlir.constant(64 : i32) : i32
    %16 = llvm.mlir.constant(0 : i32) : i32
    %17 = llvm.mlir.constant(2 : i32) : i32
    %18 = llvm.mlir.constant(0 : i64) : i64
    %19 = llvm.mlir.constant(64 : i64) : i64
    %20 = llvm.mlir.constant(128 : i64) : i64
    %21 = llvm.mlir.constant(192 : i64) : i64
    %22 = llvm.mlir.constant(50112 : i64) : i64
    %23 = llvm.mlir.constant(256 : i64) : i64
    %24 = llvm.mlir.constant(512 : i64) : i64
    %25 = llvm.mlir.constant(576 : i64) : i64
    %26 = llvm.mlir.constant(50176 : i64) : i64
    %27 = llvm.mlir.constant(640 : i64) : i64
    %28 = llvm.mlir.constant(50240 : i64) : i64
    %29 = llvm.mlir.constant(1152 : i64) : i64
    %30 = llvm.mlir.constant(8192 : i64) : i64
    %31 = llvm.mlir.constant(33920 : i64) : i64
    %32 = llvm.mlir.constant(42112 : i64) : i64
    %33 = llvm.mlir.constant(43136 : i64) : i64
    %34 = llvm.mlir.constant(43392 : i64) : i64
    %35 = llvm.mlir.constant(43520 : i64) : i64
    %36 = llvm.mlir.constant(47616 : i64) : i64
    %37 = llvm.mlir.constant(47680 : i64) : i64
    %38 = llvm.mlir.constant(47808 : i64) : i64
    %39 = llvm.mlir.constant(47872 : i64) : i64
    %40 = llvm.mlir.constant(47936 : i64) : i64
    %41 = llvm.mlir.constant(66624 : i64) : i64
    %42 = llvm.mlir.constant(1 : index) : i64
    %43 = llvm.mlir.constant(1 : i32) : i32
    %44 = llvm.mlir.constant(2 : index) : i64
    %45 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %46 = "hivm.intr.hivm.SBITSET0"(%45, %12) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%46) : (i64) -> ()
    %47 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %48 = "hivm.intr.hivm.SBITSET1"(%47, %11) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%48) : (i64) -> ()
    %49 = "hivm.intr.hivm.GET.BLOCK.IDX"() : () -> i64
    %50 = llvm.trunc %49 : i64 to i32
    %51 = llvm.srem %50, %arg22  : i32
    %52 = llvm.inttoptr %18 : i64 to !llvm.ptr<6>
    %53 = llvm.inttoptr %19 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_14(%52, %53) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %54 = llvm.mul %51, %arg11 : i32
    %55 = llvm.sdiv %54, %arg22  : i32
    %56 = llvm.add %51, %43 : i32
    %57 = llvm.mul %56, %arg11 : i32
    %58 = llvm.sdiv %57, %arg22  : i32
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 5 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 6 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.br ^bb1(%55 : i32)
  ^bb1(%59: i32):  // 2 preds: ^bb0, ^bb20
    %60 = llvm.icmp "slt" %59, %58 : i32
    llvm.cond_br %60, ^bb2, ^bb21
  ^bb2:  // pred: ^bb1
    %61 = llvm.sext %59 : i32 to i64
    %62 = llvm.getelementptr %arg7[%61] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %63 = llvm.load %62 : !llvm.ptr<1> -> i32
    %64 = llvm.add %61, %42 : i64
    %65 = llvm.getelementptr %arg7[%64] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %66 = llvm.load %65 : !llvm.ptr<1> -> i32
    %67 = llvm.sub %66, %63 : i32
    %68 = llvm.icmp "sgt" %67, %16 : i32
    llvm.cond_br %68, ^bb3, ^bb20
  ^bb3:  // pred: ^bb2
    %69 = llvm.inttoptr %20 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_8(%69) {hivm.vector_function, no_inline} : (!llvm.ptr<6>) -> ()
    %70 = llvm.load %arg10 : !llvm.ptr<1> -> f32
    %71 = llvm.getelementptr %arg10[1] : (!llvm.ptr<1>) -> !llvm.ptr<1>, f32
    %72 = llvm.load %71 : !llvm.ptr<1> -> f32
    %73 = llvm.getelementptr %arg10[2] : (!llvm.ptr<1>) -> !llvm.ptr<1>, f32
    %74 = llvm.load %73 : !llvm.ptr<1> -> f32
    %75 = llvm.getelementptr %arg10[3] : (!llvm.ptr<1>) -> !llvm.ptr<1>, f32
    %76 = llvm.load %75 : !llvm.ptr<1> -> f32
    %77 = llvm.getelementptr %arg10[4] : (!llvm.ptr<1>) -> !llvm.ptr<1>, f32
    %78 = llvm.load %77 : !llvm.ptr<1> -> f32
    %79 = llvm.getelementptr %arg10[5] : (!llvm.ptr<1>) -> !llvm.ptr<1>, f32
    %80 = llvm.load %79 : !llvm.ptr<1> -> f32
    %81 = llvm.inttoptr %21 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_9(%81) {hivm.vector_function, no_inline} : (!llvm.ptr<6>) -> ()
    %82 = llvm.inttoptr %22 : i64 to !llvm.ptr<6>
    %83 = llvm.insertvalue %82, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %84 = llvm.insertvalue %82, %83[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %85 = llvm.insertvalue %13, %84[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %86 = llvm.insertvalue %10, %85[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %87 = llvm.insertvalue %42, %86[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%53, %53, %13, %10, %42, %82, %82, %13, %10, %42) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_float(%81, %81, %13, %5, %42, %82, %82, %13, %5, %42) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %88 = llvm.getelementptr %arg8[%61] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %89 = llvm.load %88 : !llvm.ptr<1> -> i32
    %90 = llvm.sub %89, %67 : i32
    %91 = llvm.add %89, %14 : i32
    %92 = llvm.sdiv %91, %15  : i32
    %93 = llvm.inttoptr %23 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_10(%93) {hivm.vector_function, no_inline} : (!llvm.ptr<6>) -> ()
    %94 = llvm.sitofp %89 : i32 to f32
    %95 = llvm.inttoptr %24 : i64 to !llvm.ptr<6>
    %96 = llvm.inttoptr %25 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_11(%69, %78, %80, %76, %74, %72, %70, %90, %95, %96) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, f32, f32, f32, f32, f32, f32, i32, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %97 = llvm.inttoptr %26 : i64 to !llvm.ptr<6>
    %98 = llvm.insertvalue %97, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %99 = llvm.insertvalue %97, %98[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %100 = llvm.insertvalue %13, %99[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %101 = llvm.insertvalue %10, %100[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %102 = llvm.insertvalue %42, %101[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%52, %52, %13, %10, %42, %97, %97, %13, %10, %42) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_float(%95, %95, %13, %5, %42, %97, %97, %13, %5, %42) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %103 = llvm.sext %92 : i32 to i64
    %104 = "hivm.intr.hivm.GET.SUBBLOCKID"() : () -> i64
    %105 = llvm.icmp "eq" %104, %13 : i64
    %106 = llvm.inttoptr %27 : i64 to !llvm.ptr<6>
    %107 = llvm.inttoptr %25 : i64 to !llvm.ptr<6>
    %108 = llvm.inttoptr %28 : i64 to !llvm.ptr<6>
    %109 = llvm.insertvalue %108, %4[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %110 = llvm.insertvalue %108, %109[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %111 = llvm.insertvalue %13, %110[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %112 = llvm.insertvalue %10, %111[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %113 = llvm.insertvalue %3, %112[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %114 = llvm.insertvalue %3, %113[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %115 = llvm.insertvalue %42, %114[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_12(%69, %96, %106, %107, %108) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.br ^bb4(%16, %87, %115, %102 : i32, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>)
  ^bb4(%116: i32, %117: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %118: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %119: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>):  // 2 preds: ^bb3, ^bb16
    %120 = llvm.icmp "slt" %116, %92 : i32
    llvm.cond_br %120, ^bb5, ^bb17
  ^bb5:  // pred: ^bb4
    %121 = llvm.inttoptr %29 : i64 to !llvm.ptr<6>
    %122 = llvm.inttoptr %30 : i64 to !llvm.ptr<2>
    %123 = llvm.inttoptr %31 : i64 to !llvm.ptr<6>
    %124 = llvm.sext %116 : i32 to i64
    %125 = llvm.mul %124, %1 : i64
    %126 = llvm.add %103, %125 : i64
    %127 = llvm.intr.umin(%126, %44)  : (i64, i64) -> i64
    %128 = llvm.inttoptr %32 : i64 to !llvm.ptr<6>
    llvm.br ^bb6(%13 : i64)
  ^bb6(%129: i64):  // 2 preds: ^bb5, ^bb7
    %130 = llvm.icmp "slt" %129, %127 : i64
    llvm.cond_br %130, ^bb7, ^bb8
  ^bb7:  // pred: ^bb6
    %131 = llvm.add %129, %124 : i64
    %132 = llvm.trunc %131 : i64 to i32
    %133 = llvm.mul %132, %15 : i32
    %134 = llvm.inttoptr %33 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_0(%93, %133, %134) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, i32, !llvm.ptr<6>) -> ()
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_1(%106, %134, %94, %107, %128, %129) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, f32, !llvm.ptr<6>, !llvm.ptr<6>, i64) -> ()
    %135 = llvm.add %129, %42 overflow<nsw> : i64
    llvm.br ^bb6(%135 : i64)
  ^bb8:  // pred: ^bb6
    %136 = llvm.inttoptr %34 : i64 to !llvm.ptr<6>
    llvm.br ^bb9(%13, %119, %117 : i64, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>)
  ^bb9(%137: i64, %138: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %139: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>):  // 2 preds: ^bb8, ^bb12
    %140 = llvm.icmp "slt" %137, %127 : i64
    llvm.cond_br %140, ^bb10, ^bb13
  ^bb10:  // pred: ^bb9
    %141 = llvm.add %137, %6 : i64
    %142 = llvm.add %137, %8 : i64
    %143 = llvm.inttoptr %35 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 0 : i64}> : () -> ()
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_2(%128, %137, %123, %arg21, %143) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, i64, !llvm.ptr<6>, f32, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCK.mode"(%141) <{pipe = 1 : i64}> : (i64) -> ()
    %144 = llvm.inttoptr %36 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_3(%143, %144) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %145 = llvm.inttoptr %36 : i64 to !llvm.ptr<6>
    %146 = llvm.extractvalue %138[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_4(%146, %144, %145) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %147 = llvm.inttoptr %37 : i64 to !llvm.ptr<6>
    %148 = llvm.inttoptr %38 : i64 to !llvm.ptr<6>
    %149 = llvm.extractvalue %138[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_5(%149, %145, %147, %137, %148) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>) -> ()
    %150 = llvm.mul %137, %10 : i64
    llvm.call @copy_ubuf_to_ubuf_1d_float(%148, %148, %13, %10, %42, %136, %136, %150, %10, %42) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %151 = llvm.inttoptr %39 : i64 to !llvm.ptr<6>
    %152 = llvm.inttoptr %40 : i64 to !llvm.ptr<6>
    %153 = llvm.inttoptr %22 : i64 to !llvm.ptr<6>
    %154 = llvm.insertvalue %153, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %155 = llvm.insertvalue %153, %154[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %156 = llvm.insertvalue %13, %155[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %157 = llvm.insertvalue %10, %156[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %158 = llvm.insertvalue %42, %157[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %159 = llvm.extractvalue %139[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_6(%143, %145, %151, %152, %159, %148, %153) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCK.mode"(%142) <{pipe = 5 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %105, ^bb11, ^bb12
  ^bb11:  // pred: ^bb10
    %160 = llvm.mul %137, %2 : i64
    llvm.call @copy_ubuf_to_cbuf_2d_bfloat16_t(%152, %152, %13, %7, %3, %0, %42, %122, %122, %160, %7, %3, %3, %42) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64) -> ()
    llvm.br ^bb12
  ^bb12:  // 2 preds: ^bb10, ^bb11
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 8 : i64}> : () -> ()
    %161 = llvm.inttoptr %26 : i64 to !llvm.ptr<6>
    %162 = llvm.insertvalue %161, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %163 = llvm.insertvalue %161, %162[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %164 = llvm.insertvalue %13, %163[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %165 = llvm.insertvalue %10, %164[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %166 = llvm.insertvalue %42, %165[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%145, %145, %13, %10, %42, %161, %161, %13, %10, %42) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %167 = llvm.add %137, %42 overflow<nsw> : i64
    llvm.br ^bb9(%167, %166, %158 : i64, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>)
  ^bb13:  // pred: ^bb9
    llvm.br ^bb14(%13, %118 : i64, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>)
  ^bb14(%168: i64, %169: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>):  // 2 preds: ^bb13, ^bb15
    %170 = llvm.icmp "slt" %168, %127 : i64
    llvm.cond_br %170, ^bb15, ^bb16
  ^bb15:  // pred: ^bb14
    %171 = llvm.add %168, %42 : i64
    %172 = llvm.inttoptr %28 : i64 to !llvm.ptr<6>
    %173 = llvm.insertvalue %172, %4[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %174 = llvm.insertvalue %172, %173[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %175 = llvm.insertvalue %13, %174[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %176 = llvm.insertvalue %10, %175[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %177 = llvm.insertvalue %3, %176[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %178 = llvm.insertvalue %3, %177[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %179 = llvm.insertvalue %42, %178[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 7 : i64}> : () -> ()
    %180 = llvm.extractvalue %169[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_7(%136, %168, %121, %180, %172) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, i64, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCK.mode"(%171) <{pipe = 1 : i64}> : (i64) -> ()
    %181 = llvm.add %168, %42 overflow<nsw> : i64
    llvm.br ^bb14(%181, %179 : i64, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>)
  ^bb16:  // pred: ^bb14
    %182 = llvm.add %116, %17 overflow<nsw> : i32
    llvm.br ^bb4(%182, %139, %169, %138 : i32, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>)
  ^bb17:  // pred: ^bb4
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %183 = llvm.mul %63, %arg18 : i32
    %184 = llvm.sext %183 : i32 to i64
    %185 = llvm.sext %arg19 : i32 to i64
    %186 = llvm.inttoptr %41 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %187 = llvm.extractvalue %117[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %188 = llvm.extractvalue %118[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_13(%187, %188, %186) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %105, ^bb18, ^bb19
  ^bb18:  // pred: ^bb17
    llvm.call @store_ubuf_to_gm_2d_bfloat16_t(%186, %186, %13, %5, %3, %3, %42, %arg6, %arg6, %184, %5, %3, %185, %42, %16) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i32) -> ()
    llvm.br ^bb19
  ^bb19:  // 2 preds: ^bb17, ^bb18
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.br ^bb20
  ^bb20:  // 2 preds: ^bb2, ^bb19
    %189 = llvm.add %59, %43 overflow<nsw> : i32
    llvm.br ^bb1(%189 : i32)
  ^bb21:  // pred: ^bb1
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 4 : i64}> : () -> ()
    %190 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %191 = "hivm.intr.hivm.SBITSET1"(%190, %12) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%191) : (i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 6 : i64}> : () -> ()
    llvm.return
  }
}


bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
ld.lld: warning: -z separate-code and -z separate-loadable-segments will be ignored
