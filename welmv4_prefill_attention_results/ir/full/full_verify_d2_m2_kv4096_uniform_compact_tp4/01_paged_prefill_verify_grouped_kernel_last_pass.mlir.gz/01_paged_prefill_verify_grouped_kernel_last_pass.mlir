// -----// IR Dump After AppendUsePrintDebugData (append-use-print-debug-data) //----- //
module attributes {dlti.target_system_spec = #dlti.target_system_spec<"NPU" : #hacc.target_device_spec<#dlti.dl_entry<"AI_CORE_COUNT", 28 : i32>, #dlti.dl_entry<"CUBE_CORE_COUNT", 28 : i32>, #dlti.dl_entry<"VECTOR_CORE_COUNT", 56 : i32>, #dlti.dl_entry<"UB_SIZE", 2031616 : i32>, #dlti.dl_entry<"L1_SIZE", 4194304 : i32>, #dlti.dl_entry<"L0A_SIZE", 524288 : i32>, #dlti.dl_entry<"L0B_SIZE", 524288 : i32>, #dlti.dl_entry<"L0C_SIZE", 2097152 : i32>, #dlti.dl_entry<"UB_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L1_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L0C_ALIGN_SIZE", 4096 : i32>, #dlti.dl_entry<"MINIMAL_D_CACHE_SIZE", 262144 : i32>, #dlti.dl_entry<"MAXIMUM_D_CACHE_SIZE", 983040 : i32>, #dlti.dl_entry<"ARCH", "dav-c310">>>, hacc.target = #hacc.target<"Ascend950PR_957b">, hivm.aic_bitcode = #hivm.aic_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.aic.c310.bc">, hivm.aiv_bitcode = #hivm.aiv_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.aiv.c310.bc">, hivm.host_bitcode = #hivm.host_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/host-a5.bc">, hivm.mix_aic_bitcode = #hivm.mix_aic_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.mix.aic.c310.bc">, hivm.mix_aiv_bitcode = #hivm.mix_aiv_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.mix.aiv.c310.bc">, hivm.module_core_type = #hivm.module_core_type<MIX>, ssbuffer.enable_ub_refine_opt, ssbuffer.insertionOptimization} {
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_merged_merged_vf_0(%arg0: !llvm.ptr<6>, %arg1: i64, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>, %arg5: i64, %arg6: !llvm.ptr<6>, %arg7: i32, %arg8: f32, %arg9: f32, %arg10: f32, %arg11: !llvm.ptr<6>, %arg12: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(16 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %4 = llvm.mlir.constant(0xFF800000 : f32) : f32
    %5 = llvm.mlir.constant(0.000000e+00 : bf16) : bf16
    %6 = llvm.mlir.constant(9 : i32) : i32
    %7 = llvm.mlir.constant(8 : i32) : i32
    %8 = llvm.mlir.constant(6 : i32) : i32
    %9 = llvm.mlir.constant(24 : i32) : i32
    %10 = llvm.mlir.constant(6 : index) : i64
    %11 = llvm.mlir.constant(1024 : index) : i64
    %12 = llvm.mlir.constant(64 : index) : i64
    %13 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%6, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %14 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%5, %13, %0) : (bf16, vector<256xi1>, i32) -> vector<128xbf16>
    %15 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %16 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%4, %15, %0) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %17 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %18 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%3, %17, %0) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %19 = llvm.mul %arg3, %10 : i64
    %20 = llvm.mul %arg1, %10 : i64
    %21 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%8) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %22 = llvm.getelementptr %arg0[%20] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %24 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%16, %22, %9, %23) : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %25 = llvm.extractvalue %24[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %26 = llvm.extractvalue %24[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%25, %26, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %27 = llvm.getelementptr %arg2[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %28 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %29 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%18, %27, %9, %28) : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %30 = llvm.extractvalue %29[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %31 = llvm.extractvalue %29[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%30, %31, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.br ^bb1(%2 : i32)
  ^bb1(%32: i32):  // 2 preds: ^bb0, ^bb2
    %33 = llvm.icmp "slt" %32, %1 : i32
    llvm.cond_br %33, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %34 = llvm.sext %32 : i32 to i64
    %35 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%7, %2) {mask_bit_width = 16 : i32, mask_op_idx = 1 : i32} : (i32, i32) -> vector<256xi1>
    %36 = llvm.mul %arg5, %11 : i64
    %37 = llvm.mul %34, %12 : i64
    %38 = llvm.add %36, %37 : i64
    %39 = llvm.getelementptr %arg4[%38] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%14, %39, %2, %0, %2, %35) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %40 = llvm.add %32, %0 overflow<nsw> : i32
    llvm.br ^bb1(%40 : i32)
  ^bb3:  // pred: ^bb1
    %41 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64s32"(%arg6, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xi32>
    %42 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %43 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%41, %arg7, %42) : (vector<64xi32>, i32, vector<256xi1>) -> vector<64xi32>
    %44 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %45 = "hivm_regbaseintrins.intr.hivm.vcvtif.s322f32.x"(%43, %44, %2) : (vector<64xi32>, vector<256xi1>, i32) -> vector<64xf32>
    %46 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg8) : (f32) -> vector<64xf32>
    %47 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %48 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%45, %46, %47) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %49 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg9) : (f32) -> vector<64xf32>
    %50 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %51 = "hivm_regbaseintrins.intr.hivm.vcmp.le.s.z"(%45, %49, %50) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %52 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %53 = "hivm_regbaseintrins.intr.hivm.pand.z"(%48, %51, %52) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %54 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %55 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %56 = "hivm_regbaseintrins.intr.hivm.pstu.b32"(%53, %arg11, %55) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %57 = llvm.extractvalue %56[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %58 = llvm.extractvalue %56[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%57, %58, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %59 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg10) : (f32) -> vector<64xf32>
    %60 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %61 = "hivm_regbaseintrins.intr.hivm.vcmp.le.s.z"(%45, %59, %60) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %62 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %63 = "hivm_regbaseintrins.intr.hivm.pand.z"(%48, %61, %62) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %64 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %65 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %66 = "hivm_regbaseintrins.intr.hivm.pstu.b32"(%63, %arg12, %65) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %67 = llvm.extractvalue %66[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %68 = llvm.extractvalue %66[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%67, %68, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_merged_vf_3(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(256 : i32) : i32
    %4 = llvm.mlir.constant(64 : i32) : i32
    %5 = llvm.mlir.constant(3 : i32) : i32
    %6 = llvm.mlir.constant(8 : i32) : i32
    %7 = llvm.mlir.constant(7 : i32) : i32
    %8 = llvm.mlir.constant(256 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%9: i32):  // 2 preds: ^bb0, ^bb5
    %10 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %10, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %11 = llvm.sext %9 : i32 to i64
    llvm.br ^bb3(%2 : i32)
  ^bb3(%12: i32):  // 2 preds: ^bb2, ^bb4
    %13 = llvm.icmp "slt" %12, %3 : i32
    llvm.cond_br %13, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %14 = llvm.sext %12 : i32 to i64
    %15 = llvm.mul %11, %8 : i64
    %16 = llvm.add %15, %14 : i64
    %17 = llvm.getelementptr %arg1[%16] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %18 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%17, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %19 = llvm.getelementptr %arg0[%11] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %20 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%19, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.vdiv.s.x"(%18, %20, %21) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %23 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %24 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%22, %23, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %25 = llvm.mul %11, %8 : i64
    %26 = llvm.add %25, %14 : i64
    %27 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %28 = llvm.getelementptr %arg2[%26] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%24, %28, %2, %7, %2, %27) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %29 = llvm.add %12, %4 overflow<nsw> : i32
    llvm.br ^bb3(%29 : i32)
  ^bb5:  // pred: ^bb3
    %30 = llvm.add %9, %0 overflow<nsw> : i32
    llvm.br ^bb1(%30 : i32)
  ^bb6:  // pred: ^bb1
    llvm.br ^bb7(%2 : i32)
  ^bb7(%31: i32):  // 2 preds: ^bb6, ^bb11
    %32 = llvm.icmp "slt" %31, %1 : i32
    llvm.cond_br %32, ^bb8, ^bb12
  ^bb8:  // pred: ^bb7
    %33 = llvm.sext %31 : i32 to i64
    llvm.br ^bb9(%2 : i32)
  ^bb9(%34: i32):  // 2 preds: ^bb8, ^bb10
    %35 = llvm.icmp "slt" %34, %3 : i32
    llvm.cond_br %35, ^bb10, ^bb11
  ^bb10:  // pred: ^bb9
    %36 = llvm.sext %34 : i32 to i64
    %37 = llvm.mul %33, %8 : i64
    %38 = llvm.add %37, %36 : i64
    %39 = llvm.getelementptr %arg4[%38] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %40 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%39, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %41 = llvm.getelementptr %arg3[%33] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %42 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%41, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %43 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %44 = "hivm_regbaseintrins.intr.hivm.vdiv.s.x"(%40, %42, %43) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %45 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %46 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%44, %45, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %47 = llvm.mul %33, %8 : i64
    %48 = llvm.add %47, %36 : i64
    %49 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %50 = llvm.getelementptr %arg5[%48] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%46, %50, %2, %7, %2, %49) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %51 = llvm.add %34, %4 overflow<nsw> : i32
    llvm.br ^bb9(%51 : i32)
  ^bb11:  // pred: ^bb9
    %52 = llvm.add %31, %0 overflow<nsw> : i32
    llvm.br ^bb7(%52 : i32)
  ^bb12:  // pred: ^bb7
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_merged_vf_2(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>, %arg5: f32, %arg6: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(8 : i32) : i32
    %1 = llvm.mlir.constant(-1.000000e+06 : f32) : f32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(16 : i32) : i32
    %4 = llvm.mlir.constant(1 : i32) : i32
    %5 = llvm.mlir.constant(6 : i32) : i32
    %6 = llvm.mlir.constant(1114112 : i32) : i32
    %7 = llvm.mlir.constant(8 : index) : i64
    %8 = llvm.mlir.constant(2 : i32) : i32
    %9 = llvm.mlir.constant(16 : index) : i64
    %10 = llvm.mlir.constant(272 : index) : i64
    %11 = llvm.mlir.constant(256 : index) : i64
    %12 = llvm.mlir.constant(1536 : index) : i64
    %13 = llvm.mlir.constant(384 : index) : i64
    %14 = llvm.mlir.constant(64 : index) : i64
    %15 = llvm.mlir.constant(0 : index) : i64
    %16 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %17 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%1, %16, %4) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    llvm.br ^bb1(%2 : i32)
  ^bb1(%18: i32):  // 2 preds: ^bb0, ^bb2
    %19 = llvm.icmp "slt" %18, %3 : i32
    llvm.cond_br %19, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %20 = llvm.sext %18 : i32 to i64
    %21 = llvm.mul %20, %14 : i64
    %22 = llvm.getelementptr %arg0[%21] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %23 = llvm.mul %15, %14 : i64
    %24 = llvm.add %23, %15 : i64
    %25 = llvm.getelementptr %22[%24] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %26 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%25, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %27 = llvm.mul %20, %9 : i64
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%0, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %29 = llvm.getelementptr %arg1[%27] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %30 = llvm.mul %15, %10 : i64
    %31 = llvm.add %30, %15 : i64
    %32 = llvm.getelementptr %29[%31] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vsstb.v128bf16"(%26, %32, %6, %2, %28) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, vector<256xi1>) -> ()
    %33 = llvm.add %18, %4 overflow<nsw> : i32
    llvm.br ^bb1(%33 : i32)
  ^bb3:  // pred: ^bb1
    llvm.br ^bb4(%2 : i32)
  ^bb4(%34: i32):  // 2 preds: ^bb3, ^bb5
    %35 = llvm.icmp "slt" %34, %5 : i32
    llvm.cond_br %35, ^bb5, ^bb6
  ^bb5:  // pred: ^bb4
    %36 = llvm.sext %34 : i32 to i64
    %37 = llvm.mul %arg3, %12 : i64
    %38 = llvm.mul %36, %11 : i64
    %39 = llvm.add %37, %38 : i64
    %40 = llvm.udiv %39, %7  : i64
    %41 = llvm.getelementptr %arg2[%40] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %42 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%41, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %43 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %44 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%42, %43) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %45 = llvm.extractvalue %44[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %46 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%45, %43) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %47 = llvm.extractvalue %46[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %48 = llvm.mul %arg3, %13 : i64
    %49 = llvm.mul %36, %14 : i64
    %50 = llvm.add %48, %49 : i64
    %51 = llvm.getelementptr %arg4[%50] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %52 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%51, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %53 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %54 = "hivm_regbaseintrins.intr.hivm.vmuls.s.x"(%52, %arg5, %53) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %55 = "hivm_regbaseintrins.intr.hivm.vsel"(%54, %17, %47) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %56 = llvm.mul %36, %14 : i64
    %57 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %58 = llvm.getelementptr %arg6[%56] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%55, %58, %2, %8, %2, %57) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %59 = llvm.add %34, %4 overflow<nsw> : i32
    llvm.br ^bb4(%59 : i32)
  ^bb6:  // pred: ^bb4
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_merged_vf_0(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(64 : i32) : i32
    %1 = llvm.mlir.constant(256 : i32) : i32
    %2 = llvm.mlir.constant(1 : i32) : i32
    %3 = llvm.mlir.constant(6 : i32) : i32
    %4 = llvm.mlir.constant(0 : i32) : i32
    %5 = llvm.mlir.constant(1.000000e+00 : f32) : f32
    %6 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %7 = llvm.mlir.constant(8 : i32) : i32
    %8 = llvm.mlir.constant(2 : i32) : i32
    %9 = llvm.mlir.constant(256 : index) : i64
    %10 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %11 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%6, %10, %2) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %12 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %13 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%5, %12, %2) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %14 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%3) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %15 = llvm.extractvalue %14[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%13, %arg0, %4, %8, %4, %15) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.br ^bb1(%4 : i32)
  ^bb1(%16: i32):  // 2 preds: ^bb0, ^bb5
    %17 = llvm.icmp "slt" %16, %3 : i32
    llvm.cond_br %17, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %16 : i32 to i64
    llvm.br ^bb3(%4 : i32)
  ^bb3(%19: i32):  // 2 preds: ^bb2, ^bb4
    %20 = llvm.icmp "slt" %19, %1 : i32
    llvm.cond_br %20, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %21 = llvm.sext %19 : i32 to i64
    %22 = llvm.mul %18, %9 : i64
    %23 = llvm.add %22, %21 : i64
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = llvm.getelementptr %arg1[%23] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%11, %25, %4, %8, %4, %24) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %26 = llvm.add %19, %0 overflow<nsw> : i32
    llvm.br ^bb3(%26 : i32)
  ^bb5:  // pred: ^bb3
    %27 = llvm.add %16, %2 overflow<nsw> : i32
    llvm.br ^bb1(%27 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aic(%arg0: i64, %arg1: !llvm.ptr<1>, %arg2: !llvm.ptr<1>, %arg3: !llvm.ptr<1>, %arg4: !llvm.ptr<1>, %arg5: !llvm.ptr<1>, %arg6: !llvm.ptr<1>, %arg7: !llvm.ptr<1>, %arg8: !llvm.ptr<1>, %arg9: !llvm.ptr<1>, %arg10: !llvm.ptr<1>, %arg11: i32, %arg12: i32, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32, %arg17: i32, %arg18: i32, %arg19: i32, %arg20: f32, %arg21: i32, %arg22: i32, %arg23: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, hivm.vf_mode = #hivm.vf_mode<SIMD>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, mix_mode = "mix", parallel_mode = "simd"} {
    %0 = llvm.mlir.constant(5 : index) : i64
    %1 = llvm.mlir.constant(3 : index) : i64
    %2 = llvm.mlir.constant(16 : i64) : i64
    %3 = llvm.mlir.constant(9 : index) : i64
    %4 = llvm.mlir.constant(7 : index) : i64
    %5 = llvm.mlir.constant(-1 : index) : i64
    %6 = llvm.mlir.constant(384 : index) : i64
    %7 = llvm.mlir.constant(1536 : index) : i64
    %8 = llvm.mlir.constant(48 : i64) : i64
    %9 = llvm.mlir.constant(60 : i64) : i64
    %10 = llvm.mlir.constant(16384 : index) : i64
    %11 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %12 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %13 = llvm.mlir.constant(1024 : index) : i64
    %14 = llvm.mlir.constant(16 : index) : i64
    %15 = llvm.mlir.constant(4 : index) : i64
    %16 = llvm.mlir.constant(0 : index) : i64
    %17 = llvm.mlir.constant(0 : i8) : i8
    %18 = llvm.mlir.constant(false) : i1
    %19 = llvm.mlir.constant(1.000000e+00 : f32) : f32
    %20 = llvm.mlir.constant(34112 : i64) : i64
    %21 = llvm.mlir.constant(31040 : i64) : i64
    %22 = llvm.mlir.constant(20480 : i64) : i64
    %23 = llvm.mlir.constant(16384 : i64) : i64
    %24 = llvm.mlir.constant(18752 : i64) : i64
    %25 = llvm.mlir.constant(6464 : i64) : i64
    %26 = llvm.mlir.constant(0 : i32) : i32
    %27 = llvm.mlir.constant(64 : i32) : i32
    %28 = llvm.mlir.constant(63 : i32) : i32
    %29 = llvm.mlir.constant(1 : index) : i64
    %30 = llvm.mlir.constant(64 : index) : i64
    %31 = llvm.mlir.constant(256 : index) : i64
    %32 = llvm.mlir.constant(0.000000e+00 : bf16) : bf16
    %33 = llvm.mlir.constant(1 : i32) : i32
    %34 = llvm.mlir.constant(6 : index) : i64
    %35 = llvm.mlir.constant(true) : i1
    %36 = llvm.mlir.constant(2 : index) : i64
    %37 = llvm.mlir.constant(2 : i32) : i32
    %38 = llvm.mlir.constant(2 : i64) : i64
    %39 = llvm.mlir.constant(1 : i64) : i64
    %40 = llvm.mlir.constant(3 : i64) : i64
    %41 = llvm.mlir.constant(4 : i64) : i64
    %42 = llvm.mlir.constant(-1 : i64) : i64
    %43 = llvm.mlir.constant(139264 : i64) : i64
    %44 = llvm.mlir.constant(57344 : i64) : i64
    %45 = llvm.mlir.constant(49152 : i64) : i64
    %46 = llvm.mlir.constant(65536 : i64) : i64
    %47 = llvm.mlir.constant(106496 : i64) : i64
    %48 = llvm.mlir.constant(24576 : i64) : i64
    %49 = llvm.mlir.constant(45056 : i64) : i64
    %50 = llvm.mlir.constant(4096 : i64) : i64
    %51 = llvm.mlir.constant(98304 : i64) : i64
    %52 = llvm.mlir.constant(8192 : i64) : i64
    %53 = llvm.mlir.constant(90112 : i64) : i64
    %54 = llvm.mlir.constant(0 : i64) : i64
    %55 = llvm.mlir.constant(40960 : i64) : i64
    %56 = llvm.inttoptr %54 : i64 to !llvm.ptr<5>
    %57 = llvm.insertvalue %56, %12[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %58 = llvm.insertvalue %56, %57[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %59 = llvm.insertvalue %16, %58[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %60 = llvm.insertvalue %15, %59[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %61 = llvm.insertvalue %29, %60[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %62 = llvm.insertvalue %14, %61[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %63 = llvm.insertvalue %14, %62[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %64 = llvm.insertvalue %31, %63[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %65 = llvm.insertvalue %31, %64[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %66 = llvm.insertvalue %14, %65[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %67 = llvm.insertvalue %29, %66[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %68 = llvm.inttoptr %55 : i64 to !llvm.ptr<5>
    %69 = llvm.insertvalue %68, %12[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %70 = llvm.insertvalue %68, %69[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %71 = llvm.insertvalue %16, %70[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %72 = llvm.insertvalue %15, %71[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %73 = llvm.insertvalue %29, %72[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %74 = llvm.insertvalue %14, %73[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %75 = llvm.insertvalue %14, %74[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %76 = llvm.insertvalue %31, %75[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %77 = llvm.insertvalue %31, %76[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %78 = llvm.insertvalue %14, %77[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %79 = llvm.insertvalue %29, %78[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %80 = llvm.inttoptr %54 : i64 to !llvm.ptr<2>
    %81 = llvm.insertvalue %80, %11[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %82 = llvm.insertvalue %80, %81[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %83 = llvm.insertvalue %16, %82[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %84 = llvm.insertvalue %14, %83[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %85 = llvm.insertvalue %29, %84[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %86 = llvm.insertvalue %14, %85[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %87 = llvm.insertvalue %14, %86[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %88 = llvm.insertvalue %31, %87[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %89 = llvm.insertvalue %31, %88[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %90 = llvm.insertvalue %14, %89[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %91 = llvm.insertvalue %29, %90[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %92 = llvm.inttoptr %53 : i64 to !llvm.ptr<2>
    %93 = llvm.insertvalue %92, %11[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %94 = llvm.insertvalue %92, %93[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %95 = llvm.insertvalue %16, %94[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %96 = llvm.insertvalue %14, %95[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %97 = llvm.insertvalue %29, %96[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %98 = llvm.insertvalue %14, %97[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %99 = llvm.insertvalue %14, %98[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %100 = llvm.insertvalue %31, %99[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %101 = llvm.insertvalue %31, %100[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %102 = llvm.insertvalue %14, %101[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %103 = llvm.insertvalue %29, %102[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %104 = llvm.inttoptr %52 : i64 to !llvm.ptr<2>
    %105 = llvm.insertvalue %104, %11[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %106 = llvm.insertvalue %104, %105[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %107 = llvm.insertvalue %16, %106[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %108 = llvm.insertvalue %14, %107[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %109 = llvm.insertvalue %29, %108[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %110 = llvm.insertvalue %14, %109[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %111 = llvm.insertvalue %14, %110[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %112 = llvm.insertvalue %31, %111[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %113 = llvm.insertvalue %31, %112[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %114 = llvm.insertvalue %14, %113[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %115 = llvm.insertvalue %29, %114[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %116 = llvm.inttoptr %51 : i64 to !llvm.ptr<2>
    %117 = llvm.insertvalue %116, %11[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %118 = llvm.insertvalue %116, %117[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %119 = llvm.insertvalue %16, %118[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %120 = llvm.insertvalue %14, %119[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %121 = llvm.insertvalue %29, %120[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %122 = llvm.insertvalue %14, %121[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %123 = llvm.insertvalue %14, %122[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %124 = llvm.insertvalue %31, %123[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %125 = llvm.insertvalue %31, %124[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %126 = llvm.insertvalue %14, %125[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %127 = llvm.insertvalue %29, %126[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %128 = llvm.inttoptr %50 : i64 to !llvm.ptr<5>
    %129 = llvm.insertvalue %128, %12[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %130 = llvm.insertvalue %128, %129[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %131 = llvm.insertvalue %16, %130[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %132 = llvm.insertvalue %15, %131[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %133 = llvm.insertvalue %29, %132[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %134 = llvm.insertvalue %14, %133[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %135 = llvm.insertvalue %14, %134[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %136 = llvm.insertvalue %31, %135[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %137 = llvm.insertvalue %31, %136[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %138 = llvm.insertvalue %14, %137[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %139 = llvm.insertvalue %29, %138[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %140 = llvm.inttoptr %49 : i64 to !llvm.ptr<5>
    %141 = llvm.insertvalue %140, %12[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %142 = llvm.insertvalue %140, %141[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %143 = llvm.insertvalue %16, %142[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %144 = llvm.insertvalue %15, %143[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %145 = llvm.insertvalue %29, %144[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %146 = llvm.insertvalue %14, %145[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %147 = llvm.insertvalue %14, %146[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %148 = llvm.insertvalue %31, %147[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %149 = llvm.insertvalue %31, %148[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %150 = llvm.insertvalue %14, %149[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %151 = llvm.insertvalue %29, %150[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %152 = llvm.inttoptr %48 : i64 to !llvm.ptr<2>
    %153 = llvm.insertvalue %152, %11[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %154 = llvm.insertvalue %152, %153[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %155 = llvm.insertvalue %16, %154[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %156 = llvm.insertvalue %14, %155[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %157 = llvm.insertvalue %15, %156[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %158 = llvm.insertvalue %14, %157[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %159 = llvm.insertvalue %14, %158[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %160 = llvm.insertvalue %13, %159[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %161 = llvm.insertvalue %31, %160[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %162 = llvm.insertvalue %14, %161[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %163 = llvm.insertvalue %29, %162[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %164 = llvm.inttoptr %47 : i64 to !llvm.ptr<2>
    %165 = llvm.insertvalue %164, %11[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %166 = llvm.insertvalue %164, %165[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %167 = llvm.insertvalue %16, %166[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %168 = llvm.insertvalue %14, %167[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %169 = llvm.insertvalue %15, %168[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %170 = llvm.insertvalue %14, %169[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %171 = llvm.insertvalue %14, %170[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %172 = llvm.insertvalue %13, %171[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %173 = llvm.insertvalue %31, %172[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %174 = llvm.insertvalue %14, %173[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %175 = llvm.insertvalue %29, %174[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %176 = llvm.inttoptr %48 : i64 to !llvm.ptr<5>
    %177 = llvm.insertvalue %176, %12[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %178 = llvm.insertvalue %176, %177[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %179 = llvm.insertvalue %16, %178[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %180 = llvm.insertvalue %14, %179[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %181 = llvm.insertvalue %29, %180[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %182 = llvm.insertvalue %14, %181[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %183 = llvm.insertvalue %14, %182[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %184 = llvm.insertvalue %31, %183[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %185 = llvm.insertvalue %31, %184[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %186 = llvm.insertvalue %14, %185[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %187 = llvm.insertvalue %29, %186[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %188 = llvm.inttoptr %46 : i64 to !llvm.ptr<5>
    %189 = llvm.insertvalue %188, %12[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %190 = llvm.insertvalue %188, %189[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %191 = llvm.insertvalue %16, %190[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %192 = llvm.insertvalue %14, %191[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %193 = llvm.insertvalue %29, %192[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %194 = llvm.insertvalue %14, %193[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %195 = llvm.insertvalue %14, %194[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %196 = llvm.insertvalue %31, %195[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %197 = llvm.insertvalue %31, %196[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %198 = llvm.insertvalue %14, %197[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %199 = llvm.insertvalue %29, %198[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %200 = llvm.inttoptr %52 : i64 to !llvm.ptr<5>
    %201 = llvm.insertvalue %200, %12[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %202 = llvm.insertvalue %200, %201[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %203 = llvm.insertvalue %16, %202[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %204 = llvm.insertvalue %14, %203[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %205 = llvm.insertvalue %29, %204[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %206 = llvm.insertvalue %14, %205[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %207 = llvm.insertvalue %14, %206[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %208 = llvm.insertvalue %31, %207[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %209 = llvm.insertvalue %31, %208[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %210 = llvm.insertvalue %14, %209[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %211 = llvm.insertvalue %29, %210[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %212 = llvm.inttoptr %45 : i64 to !llvm.ptr<5>
    %213 = llvm.insertvalue %212, %12[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %214 = llvm.insertvalue %212, %213[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %215 = llvm.insertvalue %16, %214[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %216 = llvm.insertvalue %14, %215[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %217 = llvm.insertvalue %29, %216[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %218 = llvm.insertvalue %14, %217[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %219 = llvm.insertvalue %14, %218[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %220 = llvm.insertvalue %31, %219[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %221 = llvm.insertvalue %31, %220[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %222 = llvm.insertvalue %14, %221[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %223 = llvm.insertvalue %29, %222[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %224 = llvm.inttoptr %44 : i64 to !llvm.ptr<2>
    %225 = llvm.insertvalue %224, %11[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %226 = llvm.insertvalue %224, %225[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %227 = llvm.insertvalue %16, %226[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %228 = llvm.insertvalue %14, %227[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %229 = llvm.insertvalue %15, %228[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %230 = llvm.insertvalue %14, %229[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %231 = llvm.insertvalue %14, %230[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %232 = llvm.insertvalue %13, %231[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %233 = llvm.insertvalue %31, %232[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %234 = llvm.insertvalue %14, %233[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %235 = llvm.insertvalue %29, %234[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %236 = llvm.inttoptr %43 : i64 to !llvm.ptr<2>
    %237 = llvm.insertvalue %236, %11[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %238 = llvm.insertvalue %236, %237[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %239 = llvm.insertvalue %16, %238[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %240 = llvm.insertvalue %14, %239[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %241 = llvm.insertvalue %15, %240[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %242 = llvm.insertvalue %14, %241[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %243 = llvm.insertvalue %14, %242[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %244 = llvm.insertvalue %13, %243[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %245 = llvm.insertvalue %31, %244[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %246 = llvm.insertvalue %14, %245[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %247 = llvm.insertvalue %29, %246[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %248 = llvm.alloca %29 x i64 : (i64) -> !llvm.ptr
    llvm.store %54, %248 : i64, !llvm.ptr
    %249 = llvm.alloca %29 x i64 : (i64) -> !llvm.ptr
    llvm.store %54, %249 : i64, !llvm.ptr
    %250 = llvm.alloca %29 x i64 : (i64) -> !llvm.ptr
    llvm.store %54, %250 : i64, !llvm.ptr
    %251 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %252 = "hivm.intr.hivm.SBITSET0"(%251, %9) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%252) : (i64) -> ()
    %253 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %254 = "hivm.intr.hivm.SBITSET1"(%253, %8) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%254) : (i64) -> ()
    %255 = "hivm.intr.hivm.GET.BLOCK.IDX"() : () -> i64
    %256 = llvm.trunc %255 : i64 to i32
    %257 = llvm.srem %256, %arg21  : i32
    %258 = llvm.sdiv %257, %arg21  : i32
    %259 = llvm.add %257, %33 : i32
    %260 = llvm.sdiv %259, %arg21  : i32
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 19 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 3 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 20 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 21 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 5 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 22 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 6 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    llvm.br ^bb1(%258 : i32)
  ^bb1(%261: i32):  // 2 preds: ^bb0, ^bb17
    %262 = llvm.icmp "slt" %261, %260 : i32
    llvm.cond_br %262, ^bb2, ^bb18
  ^bb2:  // pred: ^bb1
    %263 = llvm.load %248 : !llvm.ptr -> i64
    %264 = llvm.urem %263, %38  : i64
    %265 = llvm.icmp "eq" %264, %39 : i64
    %266 = llvm.select %265, %103, %91 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %267 = llvm.select %265, %127, %115 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %268 = llvm.trunc %264 : i64 to i1
    %269 = llvm.xor %268, %35  : i1
    %270 = llvm.zext %269 : i1 to i64
    %271 = llvm.sext %261 : i32 to i64
    %272 = llvm.getelementptr %arg7[%271] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %273 = llvm.load %272 : !llvm.ptr<1> -> i32
    %274 = llvm.add %271, %29 : i64
    %275 = llvm.getelementptr %arg7[%274] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %276 = llvm.load %275 : !llvm.ptr<1> -> i32
    %277 = llvm.sub %276, %273 : i32
    %278 = llvm.icmp "sgt" %277, %26 : i32
    llvm.cond_br %278, ^bb3, ^bb17
  ^bb3:  // pred: ^bb2
    %279 = llvm.mul %273, %arg11 : i32
    %280 = llvm.sext %279 : i32 to i64
    %281 = llvm.sext %arg12 : i32 to i64
    "hivm.intr.hivm.WAIT.FLAG.REG"(%270) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    %282 = llvm.extractvalue %266[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %283 = llvm.extractvalue %266[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %284 = llvm.extractvalue %266[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %285 = llvm.extractvalue %266[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %286 = llvm.extractvalue %266[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %287 = llvm.extractvalue %266[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %288 = llvm.extractvalue %266[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %289 = llvm.extractvalue %266[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %290 = llvm.extractvalue %266[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %291 = llvm.extractvalue %266[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %292 = llvm.extractvalue %266[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @nd2nz_bfloat16_t(%arg3, %arg3, %280, %34, %31, %281, %29, %282, %283, %284, %285, %286, %287, %288, %289, %290, %291, %292) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    %293 = llvm.sext %arg11 : i32 to i64
    %294 = llvm.add %280, %293 : i64
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    %295 = llvm.extractvalue %267[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %296 = llvm.extractvalue %267[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %297 = llvm.extractvalue %267[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %298 = llvm.extractvalue %267[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %299 = llvm.extractvalue %267[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %300 = llvm.extractvalue %267[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %301 = llvm.extractvalue %267[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %302 = llvm.extractvalue %267[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %303 = llvm.extractvalue %267[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %304 = llvm.extractvalue %267[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %305 = llvm.extractvalue %267[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @nd2nz_bfloat16_t(%arg3, %arg3, %294, %34, %31, %281, %29, %295, %296, %297, %298, %299, %300, %301, %302, %303, %304, %305) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    %306 = llvm.getelementptr %arg8[%271] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %307 = llvm.load %306 : !llvm.ptr<1> -> i32
    %308 = llvm.add %307, %28 : i32
    %309 = llvm.sdiv %308, %27  : i32
    %310 = llvm.sub %arg19, %33 : i32
    %311 = llvm.mul %261, %arg19 : i32
    %312 = llvm.sext %309 : i32 to i64
    %313 = llvm.sext %311 : i32 to i64
    %314 = llvm.sext %arg14 : i32 to i64
    %315 = llvm.sext %arg16 : i32 to i64
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 4 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    llvm.br ^bb4(%26 : i32)
  ^bb4(%316: i32):  // 2 preds: ^bb3, ^bb15
    %317 = llvm.icmp "slt" %316, %309 : i32
    llvm.cond_br %317, ^bb5, ^bb16
  ^bb5:  // pred: ^bb4
    %318 = llvm.inttoptr %25 : i64 to !llvm.ptr<6>
    %319 = llvm.inttoptr %24 : i64 to !llvm.ptr<6>
    %320 = llvm.inttoptr %23 : i64 to !llvm.ptr<2>
    %321 = llvm.inttoptr %22 : i64 to !llvm.ptr<2>
    %322 = llvm.inttoptr %21 : i64 to !llvm.ptr<6>
    %323 = llvm.inttoptr %20 : i64 to !llvm.ptr<6>
    %324 = llvm.sext %316 : i32 to i64
    %325 = llvm.mul %324, %5 : i64
    %326 = llvm.add %312, %325 : i64
    %327 = llvm.intr.umin(%326, %36)  : (i64, i64) -> i64
    llvm.br ^bb6(%16 : i64)
  ^bb6(%328: i64):  // 2 preds: ^bb5, ^bb9
    %329 = llvm.icmp "slt" %328, %327 : i64
    llvm.cond_br %329, ^bb7, ^bb10
  ^bb7:  // pred: ^bb6
    %330 = llvm.load %250 : !llvm.ptr -> i64
    %331 = llvm.urem %330, %38  : i64
    %332 = llvm.icmp "eq" %331, %39 : i64
    %333 = llvm.select %332, %79, %67 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %334 = llvm.select %332, %151, %139 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %335 = llvm.select %332, %175, %163 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %336 = llvm.trunc %331 : i64 to i1
    %337 = llvm.select %336, %38, %40 : i1, i64
    %338 = llvm.xor %336, %35  : i1
    %339 = llvm.zext %338 : i1 to i64
    %340 = llvm.select %336, %40, %41 : i1, i64
    %341 = llvm.add %328, %4 : i64
    %342 = llvm.add %328, %3 : i64
    %343 = llvm.mul %328, %6 : i64
    %344 = llvm.mul %328, %6 : i64
    %345 = llvm.add %328, %324 : i64
    %346 = llvm.trunc %345 : i64 to i32
    %347 = llvm.mul %346, %27 : i32
    %348 = llvm.add %347, %27 : i32
    %349 = llvm.intr.smin(%348, %307)  : (i32, i32) -> i32
    %350 = llvm.sub %349, %347 : i32
    %351 = llvm.sdiv %347, %27  : i32
    %352 = llvm.intr.smin(%351, %310)  : (i32, i32) -> i32
    %353 = llvm.sext %352 : i32 to i64
    %354 = llvm.add %313, %353 : i64
    %355 = llvm.getelementptr %arg9[%354] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %356 = llvm.load %355 : !llvm.ptr<1> -> i32
    %357 = llvm.mul %356, %arg13 : i32
    %358 = llvm.sext %357 : i32 to i64
    %359 = llvm.sext %350 : i32 to i64
    %360 = llvm.intr.smax(%359, %16)  : (i64, i64) -> i64
    %361 = llvm.intr.smin(%360, %30)  : (i64, i64) -> i64
    %362 = llvm.intr.smin(%361, %16)  : (i64, i64) -> i64
    %363 = llvm.mul %362, %5 : i64
    %364 = llvm.add %361, %363 : i64
    %365 = llvm.icmp "slt" %364, %30 : i64
    %366 = llvm.mul %362, %5 : i64
    %367 = llvm.add %361, %366 : i64
    %368 = llvm.icmp "sle" %367, %16 : i64
    %369 = llvm.sub %16, %367 : i64
    %370 = llvm.sub %367, %29 : i64
    %371 = llvm.select %368, %369, %370 : i1, i64
    %372 = llvm.sdiv %371, %14  : i64
    %373 = llvm.sub %16, %372 : i64
    %374 = llvm.add %372, %29 : i64
    %375 = llvm.select %368, %373, %374 : i1, i64
    %376 = llvm.extractvalue %335[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %377 = llvm.extractvalue %335[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %378 = llvm.mul %362, %14 : i64
    llvm.cond_br %365, ^bb8, ^bb9
  ^bb8:  // pred: ^bb7
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %379 = llvm.extractvalue %335[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %380 = llvm.extractvalue %335[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%32, %379, %380, %16, %10, %29) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb9
  ^bb9:  // 2 preds: ^bb7, ^bb8
    "hivm.intr.hivm.WAIT.FLAG.REG"(%340) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.call @nd2nz_bfloat16_t(%arg4, %arg4, %358, %364, %31, %314, %29, %376, %377, %378, %14, %375, %14, %14, %13, %31, %14, %29) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%339) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %381 = llvm.extractvalue %266[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %382 = llvm.extractvalue %266[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %383 = llvm.extractvalue %266[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %384 = llvm.extractvalue %266[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %385 = llvm.extractvalue %266[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %386 = llvm.extractvalue %266[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %387 = llvm.extractvalue %266[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %388 = llvm.extractvalue %266[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %389 = llvm.extractvalue %266[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %390 = llvm.extractvalue %266[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %391 = llvm.extractvalue %266[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %392 = llvm.extractvalue %335[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %393 = llvm.extractvalue %335[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %394 = llvm.extractvalue %335[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %395 = llvm.extractvalue %335[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %396 = llvm.extractvalue %335[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %397 = llvm.extractvalue %335[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %398 = llvm.extractvalue %335[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %399 = llvm.extractvalue %335[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %400 = llvm.extractvalue %335[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %401 = llvm.extractvalue %335[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %402 = llvm.extractvalue %335[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %403 = llvm.extractvalue %333[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %404 = llvm.extractvalue %333[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %405 = llvm.extractvalue %333[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %406 = llvm.extractvalue %333[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %407 = llvm.extractvalue %333[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %408 = llvm.extractvalue %333[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %409 = llvm.extractvalue %333[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %410 = llvm.extractvalue %333[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %411 = llvm.extractvalue %333[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %412 = llvm.extractvalue %333[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %413 = llvm.extractvalue %333[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float_tb(%381, %382, %383, %384, %385, %386, %387, %388, %389, %390, %391, %392, %393, %394, %395, %396, %397, %398, %399, %400, %401, %402, %35, %34, %31, %30, %403, %404, %405, %406, %407, %408, %409, %410, %411, %412, %413, %42, %54, %42, %42, %42, %42, %42, %17) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %414 = llvm.add %342, %2 : i64
    "hivm.intr.hivm.WAIT.INTRA.BLOCK.mode"(%414) <{pipe = 10 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCK.mode"(%342) <{pipe = 10 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 10 : i64}> : () -> ()
    %415 = llvm.extractvalue %333[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %416 = llvm.extractvalue %333[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %417 = llvm.extractvalue %333[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %418 = llvm.extractvalue %333[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %419 = llvm.extractvalue %333[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %420 = llvm.extractvalue %333[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %421 = llvm.extractvalue %333[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %422 = llvm.extractvalue %333[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %423 = llvm.extractvalue %333[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %424 = llvm.extractvalue %333[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %425 = llvm.extractvalue %333[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%415, %416, %417, %418, %419, %420, %421, %422, %423, %424, %425, %322, %322, %344, %34, %30, %30, %29, %54, %19, %54, %18, %17) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%339) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 16 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 0 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%337) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %426 = llvm.extractvalue %267[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %427 = llvm.extractvalue %267[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %428 = llvm.extractvalue %267[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %429 = llvm.extractvalue %267[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %430 = llvm.extractvalue %267[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %431 = llvm.extractvalue %267[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %432 = llvm.extractvalue %267[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %433 = llvm.extractvalue %267[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %434 = llvm.extractvalue %267[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %435 = llvm.extractvalue %267[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %436 = llvm.extractvalue %267[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %437 = llvm.extractvalue %335[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %438 = llvm.extractvalue %335[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %439 = llvm.extractvalue %335[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %440 = llvm.extractvalue %335[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %441 = llvm.extractvalue %335[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %442 = llvm.extractvalue %335[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %443 = llvm.extractvalue %335[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %444 = llvm.extractvalue %335[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %445 = llvm.extractvalue %335[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %446 = llvm.extractvalue %335[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %447 = llvm.extractvalue %335[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %448 = llvm.extractvalue %334[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %449 = llvm.extractvalue %334[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %450 = llvm.extractvalue %334[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %451 = llvm.extractvalue %334[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %452 = llvm.extractvalue %334[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %453 = llvm.extractvalue %334[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %454 = llvm.extractvalue %334[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %455 = llvm.extractvalue %334[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %456 = llvm.extractvalue %334[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %457 = llvm.extractvalue %334[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %458 = llvm.extractvalue %334[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float_tb(%426, %427, %428, %429, %430, %431, %432, %433, %434, %435, %436, %437, %438, %439, %440, %441, %442, %443, %444, %445, %446, %447, %35, %34, %31, %30, %448, %449, %450, %451, %452, %453, %454, %455, %456, %457, %458, %42, %42, %42, %340, %42, %42, %42, %17) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %459 = llvm.add %341, %2 : i64
    "hivm.intr.hivm.WAIT.INTRA.BLOCK.mode"(%459) <{pipe = 10 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCK.mode"(%341) <{pipe = 10 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %460 = llvm.extractvalue %334[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %461 = llvm.extractvalue %334[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %462 = llvm.extractvalue %334[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %463 = llvm.extractvalue %334[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %464 = llvm.extractvalue %334[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %465 = llvm.extractvalue %334[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %466 = llvm.extractvalue %334[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %467 = llvm.extractvalue %334[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %468 = llvm.extractvalue %334[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %469 = llvm.extractvalue %334[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %470 = llvm.extractvalue %334[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%460, %461, %462, %463, %464, %465, %466, %467, %468, %469, %470, %323, %323, %343, %34, %30, %30, %29, %54, %19, %54, %18, %17) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%337) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 29 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 13 : i64}> : () -> ()
    %471 = llvm.add %330, %39 : i64
    llvm.store %471, %250 : i64, !llvm.ptr
    %472 = llvm.add %328, %29 overflow<nsw> : i64
    llvm.br ^bb6(%472 : i64)
  ^bb10:  // pred: ^bb6
    llvm.br ^bb11(%16 : i64)
  ^bb11(%473: i64):  // 2 preds: ^bb10, ^bb14
    %474 = llvm.icmp "slt" %473, %327 : i64
    llvm.cond_br %474, ^bb12, ^bb15
  ^bb12:  // pred: ^bb11
    %475 = llvm.load %249 : !llvm.ptr -> i64
    %476 = llvm.urem %475, %38  : i64
    %477 = llvm.icmp "eq" %476, %39 : i64
    %478 = llvm.select %477, %199, %187 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %479 = llvm.select %477, %223, %211 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %480 = llvm.select %477, %247, %235 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %481 = llvm.trunc %476 : i64 to i1
    %482 = llvm.select %481, %38, %40 : i1, i64
    %483 = llvm.xor %481, %35  : i1
    %484 = llvm.zext %483 : i1 to i64
    %485 = llvm.select %481, %40, %41 : i1, i64
    %486 = llvm.add %473, %1 : i64
    %487 = llvm.add %473, %0 : i64
    %488 = llvm.add %473, %29 : i64
    %489 = llvm.mul %473, %7 : i64
    %490 = llvm.mul %473, %7 : i64
    %491 = llvm.add %473, %324 : i64
    %492 = llvm.trunc %491 : i64 to i32
    %493 = llvm.mul %492, %27 : i32
    %494 = llvm.add %493, %27 : i32
    %495 = llvm.intr.smin(%494, %307)  : (i32, i32) -> i32
    %496 = llvm.sub %495, %493 : i32
    %497 = llvm.sdiv %493, %27  : i32
    %498 = llvm.intr.smin(%497, %310)  : (i32, i32) -> i32
    %499 = llvm.sext %498 : i32 to i64
    %500 = llvm.add %313, %499 : i64
    %501 = llvm.getelementptr %arg9[%500] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %502 = llvm.load %501 : !llvm.ptr<1> -> i32
    %503 = llvm.mul %502, %arg15 : i32
    %504 = llvm.sext %503 : i32 to i64
    %505 = llvm.sext %496 : i32 to i64
    %506 = llvm.intr.smax(%505, %16)  : (i64, i64) -> i64
    %507 = llvm.intr.smin(%506, %30)  : (i64, i64) -> i64
    %508 = llvm.intr.smin(%507, %16)  : (i64, i64) -> i64
    %509 = llvm.mul %508, %5 : i64
    %510 = llvm.add %507, %509 : i64
    %511 = llvm.icmp "slt" %510, %30 : i64
    %512 = llvm.mul %508, %5 : i64
    %513 = llvm.add %507, %512 : i64
    %514 = llvm.icmp "sle" %513, %16 : i64
    %515 = llvm.sub %16, %513 : i64
    %516 = llvm.sub %513, %29 : i64
    %517 = llvm.select %514, %515, %516 : i1, i64
    %518 = llvm.sdiv %517, %14  : i64
    %519 = llvm.sub %16, %518 : i64
    %520 = llvm.add %518, %29 : i64
    %521 = llvm.select %514, %519, %520 : i1, i64
    %522 = llvm.extractvalue %480[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %523 = llvm.extractvalue %480[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %524 = llvm.mul %508, %14 : i64
    llvm.cond_br %511, ^bb13, ^bb14
  ^bb13:  // pred: ^bb12
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %525 = llvm.extractvalue %480[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %526 = llvm.extractvalue %480[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%32, %525, %526, %16, %10, %29) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb14
  ^bb14:  // 2 preds: ^bb12, ^bb13
    "hivm.intr.hivm.WAIT.FLAG.REG"(%485) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.call @nd2nz_bfloat16_t(%arg5, %arg5, %504, %510, %31, %315, %29, %522, %523, %524, %14, %521, %14, %14, %13, %31, %14, %29) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    %527 = llvm.mul %473, %13 : i64
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 28 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 12 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%484) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %528 = llvm.extractvalue %480[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %529 = llvm.extractvalue %480[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %530 = llvm.extractvalue %480[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %531 = llvm.extractvalue %480[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %532 = llvm.extractvalue %480[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %533 = llvm.extractvalue %480[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %534 = llvm.extractvalue %480[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %535 = llvm.extractvalue %480[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %536 = llvm.extractvalue %480[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %537 = llvm.extractvalue %480[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %538 = llvm.extractvalue %480[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %539 = llvm.extractvalue %479[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %540 = llvm.extractvalue %479[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %541 = llvm.extractvalue %479[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %542 = llvm.extractvalue %479[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %543 = llvm.extractvalue %479[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %544 = llvm.extractvalue %479[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %545 = llvm.extractvalue %479[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %546 = llvm.extractvalue %479[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %547 = llvm.extractvalue %479[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %548 = llvm.extractvalue %479[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %549 = llvm.extractvalue %479[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float(%320, %320, %527, %15, %29, %14, %14, %31, %31, %14, %29, %528, %529, %530, %531, %532, %533, %534, %535, %536, %537, %538, %35, %34, %30, %31, %539, %540, %541, %542, %543, %544, %545, %546, %547, %548, %549, %42, %54, %42, %42, %42, %42, %42, %17) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %550 = llvm.add %487, %2 : i64
    "hivm.intr.hivm.SET.INTRA.BLOCK.mode"(%550) <{pipe = 3 : i64}> : (i64) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCK.mode"(%487) <{pipe = 3 : i64}> : (i64) -> ()
    %551 = llvm.add %488, %2 : i64
    "hivm.intr.hivm.WAIT.INTRA.BLOCK.mode"(%551) <{pipe = 10 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCK.mode"(%488) <{pipe = 10 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 10 : i64}> : () -> ()
    %552 = llvm.extractvalue %479[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %553 = llvm.extractvalue %479[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %554 = llvm.extractvalue %479[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %555 = llvm.extractvalue %479[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %556 = llvm.extractvalue %479[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %557 = llvm.extractvalue %479[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %558 = llvm.extractvalue %479[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %559 = llvm.extractvalue %479[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %560 = llvm.extractvalue %479[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %561 = llvm.extractvalue %479[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %562 = llvm.extractvalue %479[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%552, %553, %554, %555, %556, %557, %558, %559, %560, %561, %562, %318, %318, %490, %34, %31, %31, %29, %54, %19, %54, %18, %17) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%484) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %563 = llvm.mul %473, %13 : i64
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 27 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 11 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%482) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %564 = llvm.extractvalue %480[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %565 = llvm.extractvalue %480[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %566 = llvm.extractvalue %480[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %567 = llvm.extractvalue %480[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %568 = llvm.extractvalue %480[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %569 = llvm.extractvalue %480[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %570 = llvm.extractvalue %480[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %571 = llvm.extractvalue %480[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %572 = llvm.extractvalue %480[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %573 = llvm.extractvalue %480[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %574 = llvm.extractvalue %480[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %575 = llvm.extractvalue %478[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %576 = llvm.extractvalue %478[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %577 = llvm.extractvalue %478[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %578 = llvm.extractvalue %478[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %579 = llvm.extractvalue %478[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %580 = llvm.extractvalue %478[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %581 = llvm.extractvalue %478[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %582 = llvm.extractvalue %478[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %583 = llvm.extractvalue %478[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %584 = llvm.extractvalue %478[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %585 = llvm.extractvalue %478[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float(%321, %321, %563, %15, %29, %14, %14, %31, %31, %14, %29, %564, %565, %566, %567, %568, %569, %570, %571, %572, %573, %574, %35, %34, %30, %31, %575, %576, %577, %578, %579, %580, %581, %582, %583, %584, %585, %42, %42, %42, %485, %42, %42, %42, %17) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %586 = llvm.add %486, %2 : i64
    "hivm.intr.hivm.SET.INTRA.BLOCK.mode"(%586) <{pipe = 3 : i64}> : (i64) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCK.mode"(%486) <{pipe = 3 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %587 = llvm.extractvalue %478[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %588 = llvm.extractvalue %478[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %589 = llvm.extractvalue %478[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %590 = llvm.extractvalue %478[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %591 = llvm.extractvalue %478[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %592 = llvm.extractvalue %478[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %593 = llvm.extractvalue %478[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %594 = llvm.extractvalue %478[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %595 = llvm.extractvalue %478[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %596 = llvm.extractvalue %478[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %597 = llvm.extractvalue %478[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%587, %588, %589, %590, %591, %592, %593, %594, %595, %596, %597, %319, %319, %489, %34, %31, %31, %29, %54, %19, %54, %18, %17) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%482) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 16 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 0 : i64}> : () -> ()
    %598 = llvm.add %475, %39 : i64
    llvm.store %598, %249 : i64, !llvm.ptr
    %599 = llvm.add %473, %29 overflow<nsw> : i64
    llvm.br ^bb11(%599 : i64)
  ^bb15:  // pred: ^bb11
    %600 = llvm.add %316, %37 overflow<nsw> : i32
    llvm.br ^bb4(%600 : i32)
  ^bb16:  // pred: ^bb4
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 4 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%270) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.br ^bb17
  ^bb17:  // 2 preds: ^bb2, ^bb16
    %601 = llvm.add %263, %39 : i64
    llvm.store %601, %248 : i64, !llvm.ptr
    %602 = llvm.add %261, %33 overflow<nsw> : i32
    llvm.br ^bb1(%602 : i32)
  ^bb18:  // pred: ^bb1
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 17 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 18 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 23 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 7 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 24 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 8 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 25 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 9 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 26 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 10 : i64}> : () -> ()
    %603 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %604 = "hivm.intr.hivm.SBITSET1"(%603, %9) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%604) : (i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 6 : i64}> : () -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_3(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>, %arg5: i64) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(-1.000000e+00 : f16) : f16
    %4 = llvm.mlir.constant(0.000000e+00 : f16) : f16
    %5 = llvm.mlir.constant(9 : i32) : i32
    %6 = llvm.mlir.constant(8 : i32) : i32
    %7 = llvm.mlir.constant(8 : index) : i64
    %8 = llvm.mlir.constant(256 : index) : i64
    %9 = llvm.mlir.constant(1536 : index) : i64
    %10 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%5, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %11 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%4, %10, %0) : (f16, vector<256xi1>, i32) -> vector<128xf16>
    %12 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%5, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %13 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%3, %12, %0) : (f16, vector<256xi1>, i32) -> vector<128xf16>
    llvm.br ^bb1(%2 : i32)
  ^bb1(%14: i32):  // 2 preds: ^bb0, ^bb2
    %15 = llvm.icmp "slt" %14, %1 : i32
    llvm.cond_br %15, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %16 = llvm.sext %14 : i32 to i64
    %17 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%6, %2) {mask_bit_width = 16 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %18 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%arg0, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %19 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %20 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%18, %19) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %21 = llvm.extractvalue %20[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %22 = "hivm_regbaseintrins.intr.hivm.vsel"(%13, %11, %21) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    %23 = "hivm_regbaseintrins.intr.hivm.vcmp.ne.s.z"(%22, %11, %17) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<256xi1>
    %24 = llvm.mul %arg3, %9 : i64
    %25 = llvm.mul %16, %8 : i64
    %26 = llvm.add %24, %25 : i64
    %27 = llvm.udiv %26, %7  : i64
    %28 = llvm.getelementptr %arg2[%27] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %29 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %30 = "hivm_regbaseintrins.intr.hivm.pstu.b16"(%23, %28, %29) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %31 = llvm.extractvalue %30[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %32 = llvm.extractvalue %30[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%31, %32, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %33 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%arg1, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %34 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %35 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%33, %34) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %36 = llvm.extractvalue %35[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %37 = "hivm_regbaseintrins.intr.hivm.vsel"(%13, %11, %36) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    %38 = "hivm_regbaseintrins.intr.hivm.vcmp.ne.s.z"(%37, %11, %17) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<256xi1>
    %39 = llvm.mul %arg5, %9 : i64
    %40 = llvm.mul %16, %8 : i64
    %41 = llvm.add %39, %40 : i64
    %42 = llvm.udiv %41, %7  : i64
    %43 = llvm.getelementptr %arg4[%42] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %44 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %45 = "hivm_regbaseintrins.intr.hivm.pstu.b16"(%38, %43, %44) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %46 = llvm.extractvalue %45[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %47 = llvm.extractvalue %45[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%46, %47, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %48 = llvm.add %14, %0 overflow<nsw> : i32
    llvm.br ^bb1(%48 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_4(%arg0: !llvm.ptr<6>, %arg1: i64, %arg2: !llvm.ptr<6>, %arg3: f32, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(8 : i32) : i32
    %1 = llvm.mlir.constant(-1.000000e+06 : f32) : f32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(6 : i32) : i32
    %4 = llvm.mlir.constant(1 : i32) : i32
    %5 = llvm.mlir.constant(8 : index) : i64
    %6 = llvm.mlir.constant(2 : i32) : i32
    %7 = llvm.mlir.constant(256 : index) : i64
    %8 = llvm.mlir.constant(1536 : index) : i64
    %9 = llvm.mlir.constant(384 : index) : i64
    %10 = llvm.mlir.constant(64 : index) : i64
    %11 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %12 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%1, %11, %4) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    llvm.br ^bb1(%2 : i32)
  ^bb1(%13: i32):  // 2 preds: ^bb0, ^bb2
    %14 = llvm.icmp "slt" %13, %3 : i32
    llvm.cond_br %14, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %15 = llvm.sext %13 : i32 to i64
    %16 = llvm.mul %arg1, %8 : i64
    %17 = llvm.mul %15, %7 : i64
    %18 = llvm.add %16, %17 : i64
    %19 = llvm.udiv %18, %5  : i64
    %20 = llvm.getelementptr %arg0[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %21 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%20, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %23 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%21, %22) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %24 = llvm.extractvalue %23[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %25 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%24, %22) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %26 = llvm.extractvalue %25[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %27 = llvm.mul %arg1, %9 : i64
    %28 = llvm.mul %15, %10 : i64
    %29 = llvm.add %27, %28 : i64
    %30 = llvm.getelementptr %arg2[%29] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %31 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%30, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %32 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %33 = "hivm_regbaseintrins.intr.hivm.vmuls.s.x"(%31, %arg3, %32) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %34 = "hivm_regbaseintrins.intr.hivm.vsel"(%33, %12, %26) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %35 = llvm.mul %15, %10 : i64
    %36 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %37 = llvm.getelementptr %arg4[%35] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%34, %37, %2, %6, %2, %36) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %38 = llvm.add %13, %4 overflow<nsw> : i32
    llvm.br ^bb1(%38 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_5(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(8 : i32) : i32
    %4 = llvm.mlir.constant(4 : i32) : i32
    %5 = llvm.mlir.undef : !llvm.ptr<6>
    %6 = llvm.mlir.constant(64 : index) : i64
    %7 = llvm.mlir.constant(6 : index) : i64
    %8 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %8, %5 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%9: i32, %10: vector<32xi8>, %11: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %12 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %12, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %13 = llvm.sext %9 : i32 to i64
    %14 = llvm.mul %13, %6 : i64
    %15 = llvm.getelementptr %arg0[%14] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %16 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%15, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %17 = llvm.mul %arg2, %7 : i64
    %18 = llvm.add %17, %13 : i64
    %19 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %20 = "hivm_regbaseintrins.intr.hivm.vcmax.s.x"(%16, %19) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%20, %22, %4, %10) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %24 = llvm.extractvalue %23[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %25 = llvm.extractvalue %23[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %26 = llvm.add %9, %0 overflow<nsw> : i32
    llvm.br ^bb1(%26, %24, %25 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%10, %11, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_6(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = llvm.mlir.constant(6 : index) : i64
    %4 = llvm.mul %arg2, %3 : i64
    %5 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %6 = llvm.extractvalue %5[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %7 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %8 = llvm.getelementptr %arg1[%4] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %9 = "hivm_regbaseintrins.intr.hivm.vldas"(%8) : (!llvm.ptr<6>) -> vector<32xi8>
    %10 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%8, %9, %1) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %11 = llvm.extractvalue %10[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    %12 = "hivm_regbaseintrins.intr.hivm.vmax.s.x"(%7, %11, %6) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%12, %arg3, %1, %2, %1, %6) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_7(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = llvm.mlir.constant(24 : i32) : i32
    %4 = llvm.mlir.constant(6 : index) : i64
    %5 = llvm.mul %arg3, %4 : i64
    %6 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %7 = llvm.extractvalue %6[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %8 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %10 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%8, %9, %7, %1) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %11 = llvm.getelementptr %arg2[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %12 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %13 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%10, %11, %3, %12) : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %14 = llvm.extractvalue %13[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %15 = llvm.extractvalue %13[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%14, %15, %1, %1) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %16 = llvm.getelementptr %arg2[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %17 = "hivm_regbaseintrins.intr.hivm.vldas"(%16) : (!llvm.ptr<6>) -> vector<32xi8>
    %18 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%16, %17, %1) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %19 = llvm.extractvalue %18[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%19, %arg4, %1, %2, %1, %7) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_8(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %4 = llvm.mlir.constant(3 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(7 : i32) : i32
    %7 = llvm.mlir.constant(4 : i32) : i32
    %8 = llvm.mlir.constant(2 : i32) : i32
    %9 = llvm.mlir.undef : !llvm.ptr<6>
    %10 = llvm.mlir.constant(64 : index) : i64
    %11 = llvm.mlir.constant(6 : index) : i64
    %12 = llvm.mul %arg3, %11 : i64
    %13 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %13, %9 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%14: i32, %15: vector<32xi8>, %16: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %17 = llvm.icmp "slt" %14, %1 : i32
    llvm.cond_br %17, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %14 : i32 to i64
    %19 = llvm.mul %18, %10 : i64
    %20 = llvm.getelementptr %arg0[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %21 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%20, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %22 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%22, %2, %4, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%21, %23, %24, %2) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %27 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%25, %3, %26) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%25, %28, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %30 = llvm.mul %18, %10 : i64
    %31 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %32 = llvm.getelementptr %arg4[%30] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%29, %32, %2, %6, %2, %31) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %33 = llvm.mul %arg3, %11 : i64
    %34 = llvm.add %33, %18 : i64
    %35 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %36 = "hivm_regbaseintrins.intr.hivm.vcadd.s.x"(%27, %35) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %37 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %38 = llvm.getelementptr %arg2[%34] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %39 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%36, %38, %7, %15) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %40 = llvm.extractvalue %39[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %41 = llvm.extractvalue %39[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %42 = llvm.add %14, %0 overflow<nsw> : i32
    llvm.br ^bb1(%42, %40, %41 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%15, %16, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %43 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%1) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %44 = llvm.extractvalue %43[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %45 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg5, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %46 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg6, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %47 = llvm.getelementptr %arg2[%12] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %48 = "hivm_regbaseintrins.intr.hivm.vldas"(%47) : (!llvm.ptr<6>) -> vector<32xi8>
    %49 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%47, %48, %2) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %50 = llvm.extractvalue %49[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    %51 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%45, %46, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %52 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%51, %50, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%52, %arg7, %2, %8, %2, %44) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_11(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(8 : i32) : i32
    %4 = llvm.mlir.constant(4 : i32) : i32
    %5 = llvm.mlir.undef : !llvm.ptr<6>
    %6 = llvm.mlir.constant(64 : index) : i64
    %7 = llvm.mlir.constant(6 : index) : i64
    %8 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %8, %5 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%9: i32, %10: vector<32xi8>, %11: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %12 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %12, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %13 = llvm.sext %9 : i32 to i64
    %14 = llvm.mul %13, %6 : i64
    %15 = llvm.getelementptr %arg0[%14] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %16 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%15, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %17 = llvm.mul %arg2, %7 : i64
    %18 = llvm.add %17, %13 : i64
    %19 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %20 = "hivm_regbaseintrins.intr.hivm.vcmax.s.x"(%16, %19) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%20, %22, %4, %10) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %24 = llvm.extractvalue %23[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %25 = llvm.extractvalue %23[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %26 = llvm.add %9, %0 overflow<nsw> : i32
    llvm.br ^bb1(%26, %24, %25 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%10, %11, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_12(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = llvm.mlir.constant(6 : index) : i64
    %4 = llvm.mul %arg2, %3 : i64
    %5 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %6 = llvm.extractvalue %5[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %7 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %8 = llvm.getelementptr %arg1[%4] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %9 = "hivm_regbaseintrins.intr.hivm.vldas"(%8) : (!llvm.ptr<6>) -> vector<32xi8>
    %10 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%8, %9, %1) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %11 = llvm.extractvalue %10[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    %12 = "hivm_regbaseintrins.intr.hivm.vmax.s.x"(%7, %11, %6) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%12, %arg3, %1, %2, %1, %6) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_13(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = llvm.mlir.constant(24 : i32) : i32
    %4 = llvm.mlir.constant(6 : index) : i64
    %5 = llvm.mul %arg3, %4 : i64
    %6 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %7 = llvm.extractvalue %6[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %8 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %10 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%8, %9, %7, %1) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %11 = llvm.getelementptr %arg2[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %12 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %13 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%10, %11, %3, %12) : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %14 = llvm.extractvalue %13[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %15 = llvm.extractvalue %13[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%14, %15, %1, %1) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %16 = llvm.getelementptr %arg2[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %17 = "hivm_regbaseintrins.intr.hivm.vldas"(%16) : (!llvm.ptr<6>) -> vector<32xi8>
    %18 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%16, %17, %1) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %19 = llvm.extractvalue %18[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%19, %arg4, %1, %2, %1, %7) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_14(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %4 = llvm.mlir.constant(3 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(7 : i32) : i32
    %7 = llvm.mlir.constant(4 : i32) : i32
    %8 = llvm.mlir.constant(2 : i32) : i32
    %9 = llvm.mlir.undef : !llvm.ptr<6>
    %10 = llvm.mlir.constant(64 : index) : i64
    %11 = llvm.mlir.constant(6 : index) : i64
    %12 = llvm.mul %arg3, %11 : i64
    %13 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %13, %9 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%14: i32, %15: vector<32xi8>, %16: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %17 = llvm.icmp "slt" %14, %1 : i32
    llvm.cond_br %17, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %14 : i32 to i64
    %19 = llvm.mul %18, %10 : i64
    %20 = llvm.getelementptr %arg0[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %21 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%20, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %22 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%22, %2, %4, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%21, %23, %24, %2) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %27 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%25, %3, %26) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%25, %28, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %30 = llvm.mul %18, %10 : i64
    %31 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %32 = llvm.getelementptr %arg4[%30] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%29, %32, %2, %6, %2, %31) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %33 = llvm.mul %arg3, %11 : i64
    %34 = llvm.add %33, %18 : i64
    %35 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %36 = "hivm_regbaseintrins.intr.hivm.vcadd.s.x"(%27, %35) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %37 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %38 = llvm.getelementptr %arg2[%34] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %39 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%36, %38, %7, %15) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %40 = llvm.extractvalue %39[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %41 = llvm.extractvalue %39[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %42 = llvm.add %14, %0 overflow<nsw> : i32
    llvm.br ^bb1(%42, %40, %41 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%15, %16, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %43 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%1) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %44 = llvm.extractvalue %43[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %45 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg5, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %46 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg6, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %47 = llvm.getelementptr %arg2[%12] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %48 = "hivm_regbaseintrins.intr.hivm.vldas"(%47) : (!llvm.ptr<6>) -> vector<32xi8>
    %49 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%47, %48, %2) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %50 = llvm.extractvalue %49[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    %51 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%45, %46, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %52 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%51, %50, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%52, %arg7, %2, %8, %2, %44) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_15(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(16 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(8 : i32) : i32
    %4 = llvm.mlir.constant(1114112 : i32) : i32
    %5 = llvm.mlir.constant(64 : index) : i64
    %6 = llvm.mlir.constant(16 : index) : i64
    %7 = llvm.mlir.constant(272 : index) : i64
    %8 = llvm.mlir.constant(0 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%9: i32):  // 2 preds: ^bb0, ^bb2
    %10 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %10, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %11 = llvm.sext %9 : i32 to i64
    %12 = llvm.mul %11, %5 : i64
    %13 = llvm.getelementptr %arg0[%12] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %14 = llvm.mul %8, %5 : i64
    %15 = llvm.add %14, %8 : i64
    %16 = llvm.getelementptr %13[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %17 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%16, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %18 = llvm.mul %11, %6 : i64
    %19 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%3, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %20 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %21 = llvm.mul %8, %7 : i64
    %22 = llvm.add %21, %8 : i64
    %23 = llvm.getelementptr %20[%22] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vsstb.v128bf16"(%17, %23, %4, %2, %19) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, vector<256xi1>) -> ()
    %24 = llvm.add %9, %0 overflow<nsw> : i32
    llvm.br ^bb1(%24 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_16(%arg0: !llvm.ptr<6>, %arg1: i64, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>, %arg8: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(256 : i32) : i32
    %4 = llvm.mlir.constant(64 : i32) : i32
    %5 = llvm.mlir.constant(3 : i32) : i32
    %6 = llvm.mlir.constant(8 : i32) : i32
    %7 = llvm.mlir.constant(2 : i32) : i32
    %8 = llvm.mlir.constant(1536 : index) : i64
    %9 = llvm.mlir.constant(256 : index) : i64
    %10 = llvm.mlir.constant(6 : index) : i64
    %11 = llvm.mlir.constant(0 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%12: i32):  // 2 preds: ^bb0, ^bb5
    %13 = llvm.icmp "slt" %12, %1 : i32
    llvm.cond_br %13, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %14 = llvm.sext %12 : i32 to i64
    %15 = llvm.mul %arg1, %10 : i64
    %16 = llvm.add %15, %14 : i64
    %17 = llvm.mul %arg1, %10 : i64
    %18 = llvm.add %17, %14 : i64
    llvm.br ^bb3(%2 : i32)
  ^bb3(%19: i32):  // 2 preds: ^bb2, ^bb4
    %20 = llvm.icmp "slt" %19, %3 : i32
    llvm.cond_br %20, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %21 = llvm.sext %19 : i32 to i64
    %22 = llvm.mul %arg1, %8 : i64
    %23 = llvm.mul %14, %9 : i64
    %24 = llvm.add %22, %23 : i64
    %25 = llvm.add %24, %21 : i64
    %26 = llvm.getelementptr %arg3[%25] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %27 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%26, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %28 = llvm.mul %14, %9 : i64
    %29 = llvm.add %28, %21 : i64
    %30 = llvm.getelementptr %arg4[%29] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %31 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%30, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %32 = llvm.getelementptr %arg0[%16] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %33 = llvm.mul %11, %10 : i64
    %34 = llvm.getelementptr %32[%33] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %35 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%34, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %36 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %37 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%31, %35, %36) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %38 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %39 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%27, %37, %38) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %40 = llvm.mul %14, %9 : i64
    %41 = llvm.add %40, %21 : i64
    %42 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %43 = llvm.getelementptr %arg7[%41] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%39, %43, %2, %7, %2, %42) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %44 = llvm.mul %arg1, %8 : i64
    %45 = llvm.mul %14, %9 : i64
    %46 = llvm.add %44, %45 : i64
    %47 = llvm.add %46, %21 : i64
    %48 = llvm.getelementptr %arg5[%47] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %49 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%48, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %50 = llvm.mul %14, %9 : i64
    %51 = llvm.add %50, %21 : i64
    %52 = llvm.getelementptr %arg6[%51] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %53 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%52, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %54 = llvm.getelementptr %arg2[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %55 = llvm.mul %11, %10 : i64
    %56 = llvm.getelementptr %54[%55] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %57 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%56, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %58 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %59 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%53, %57, %58) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %60 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %61 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%49, %59, %60) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %62 = llvm.mul %14, %9 : i64
    %63 = llvm.add %62, %21 : i64
    %64 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %65 = llvm.getelementptr %arg8[%63] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%61, %65, %2, %7, %2, %64) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %66 = llvm.add %19, %4 overflow<nsw> : i32
    llvm.br ^bb3(%66 : i32)
  ^bb5:  // pred: ^bb3
    %67 = llvm.add %12, %0 overflow<nsw> : i32
    llvm.br ^bb1(%67 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_17(%arg0: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(0 : i32) : i32
    %1 = llvm.mlir.constant(8 : i32) : i32
    %2 = llvm.mlir.constant(1 : i32) : i32
    %3 = llvm.mlir.constant(2 : i32) : i32
    %4 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %5 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%0, %4, %2) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %6 = "hivm_regbaseintrins.intr.hivm.vci"(%0, %0) : (i32, i32) -> vector<64xi32>
    %7 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %8 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%5, %6, %7) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    %9 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64s32"(%8, %arg0, %0, %3, %0, %9) : (vector<64xi32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func private @nd2nz_bfloat16_t(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<2>, %arg8: !llvm.ptr<2>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %15 = llvm.insertvalue %arg14, %14[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg15, %16[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg12, %17[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg13, %19[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %21, %22 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_nd2nz_bfloat16_t(%10, %22) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_nd2nz_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @set_l1_2d_bfloat16_t(%arg0: bf16, %arg1: !llvm.ptr<2>, %arg2: !llvm.ptr<2>, %arg3: i64, %arg4: i64, %arg5: i64) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg1, %1[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg4, %4[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg5, %5[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_set_l1_2d_bfloat16_t(%arg0, %7) : (bf16, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_set_l1_2d_bfloat16_t(bf16, !llvm.ptr) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @mma_tile_bfloat16_t_to_float_tb(%arg0: !llvm.ptr<2>, %arg1: !llvm.ptr<2>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<2>, %arg12: !llvm.ptr<2>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64, %arg21: i64, %arg22: i1, %arg23: i64, %arg24: i64, %arg25: i64, %arg26: !llvm.ptr<5>, %arg27: !llvm.ptr<5>, %arg28: i64, %arg29: i64, %arg30: i64, %arg31: i64, %arg32: i64, %arg33: i64, %arg34: i64, %arg35: i64, %arg36: i64, %arg37: i64, %arg38: i64, %arg39: i64, %arg40: i64, %arg41: i64, %arg42: i64, %arg43: i64, %arg44: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg18, %18[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.insertvalue %arg16, %21[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %24 = llvm.insertvalue %arg17, %23[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %25 = llvm.insertvalue %arg21, %24[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %26 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %25, %26 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %27 = llvm.insertvalue %arg26, %0[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %28 = llvm.insertvalue %arg27, %27[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %29 = llvm.insertvalue %arg28, %28[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %30 = llvm.insertvalue %arg29, %29[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %31 = llvm.insertvalue %arg33, %30[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %32 = llvm.insertvalue %arg30, %31[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %33 = llvm.insertvalue %arg34, %32[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %34 = llvm.insertvalue %arg31, %33[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %35 = llvm.insertvalue %arg35, %34[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %36 = llvm.insertvalue %arg32, %35[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %37 = llvm.insertvalue %arg36, %36[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %38 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %37, %38 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_mma_tile_bfloat16_t_to_float_tb(%14, %26, %arg22, %arg23, %arg24, %arg25, %38, %arg37, %arg38, %arg39, %arg40, %arg41, %arg42, %arg43, %arg44) : (!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_mma_tile_bfloat16_t_to_float_tb(!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%arg0: !llvm.ptr<5>, %arg1: !llvm.ptr<5>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<6>, %arg12: !llvm.ptr<6>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: f32, %arg20: i64, %arg21: i1, %arg22: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %21, %22 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%14, %22, %arg18, %arg19, %arg20, %arg21, %arg22) : (!llvm.ptr, !llvm.ptr, i64, f32, i64, i1, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(!llvm.ptr, !llvm.ptr, i64, f32, i64, i1, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @mma_tile_bfloat16_t_to_float(%arg0: !llvm.ptr<2>, %arg1: !llvm.ptr<2>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<2>, %arg12: !llvm.ptr<2>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64, %arg21: i64, %arg22: i1, %arg23: i64, %arg24: i64, %arg25: i64, %arg26: !llvm.ptr<5>, %arg27: !llvm.ptr<5>, %arg28: i64, %arg29: i64, %arg30: i64, %arg31: i64, %arg32: i64, %arg33: i64, %arg34: i64, %arg35: i64, %arg36: i64, %arg37: i64, %arg38: i64, %arg39: i64, %arg40: i64, %arg41: i64, %arg42: i64, %arg43: i64, %arg44: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg18, %18[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.insertvalue %arg16, %21[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %24 = llvm.insertvalue %arg17, %23[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %25 = llvm.insertvalue %arg21, %24[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %26 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %25, %26 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %27 = llvm.insertvalue %arg26, %0[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %28 = llvm.insertvalue %arg27, %27[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %29 = llvm.insertvalue %arg28, %28[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %30 = llvm.insertvalue %arg29, %29[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %31 = llvm.insertvalue %arg33, %30[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %32 = llvm.insertvalue %arg30, %31[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %33 = llvm.insertvalue %arg34, %32[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %34 = llvm.insertvalue %arg31, %33[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %35 = llvm.insertvalue %arg35, %34[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %36 = llvm.insertvalue %arg32, %35[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %37 = llvm.insertvalue %arg36, %36[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %38 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %37, %38 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_mma_tile_bfloat16_t_to_float(%14, %26, %arg22, %arg23, %arg24, %arg25, %38, %arg37, %arg38, %arg39, %arg40, %arg41, %arg42, %arg43, %arg44) : (!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_mma_tile_bfloat16_t_to_float(!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @load_gm_to_ubuf_1d_float(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i32, %arg11: f32, %arg12: i64, %arg13: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.insertvalue %arg4, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %8 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %7, %8 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %9 = llvm.insertvalue %arg5, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg6, %9[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg7, %10[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_load_gm_to_ubuf_1d_float(%8, %14, %arg10, %arg11, %arg12, %arg13) : (!llvm.ptr, !llvm.ptr, i32, f32, i64, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_load_gm_to_ubuf_1d_float(!llvm.ptr, !llvm.ptr, i32, f32, i64, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_ubuf_1d_float(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg0, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg1, %2[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg2, %3[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg3, %4[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %8 = llvm.insertvalue %arg5, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg7, %9[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg8, %10[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg9, %11[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %12, %13 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_ubuf_1d_float(%7, %13) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_ubuf_1d_float(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_ubuf_1d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg0, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg1, %2[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg2, %3[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg3, %4[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %8 = llvm.insertvalue %arg5, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg7, %9[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg8, %10[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg9, %11[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %12, %13 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_ubuf_1d_bfloat16_t(%7, %13) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_ubuf_1d_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_cbuf_2d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<2>, %arg8: !llvm.ptr<2>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg12, %14[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %17, %18 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_cbuf_2d_bfloat16_t(%10, %18) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_cbuf_2d_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @store_ubuf_to_gm_2d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<1>, %arg8: !llvm.ptr<1>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg12, %14[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %17, %18 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_store_ubuf_to_gm_2d_bfloat16_t(%10, %18, %arg14) : (!llvm.ptr, !llvm.ptr, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_store_ubuf_to_gm_2d_bfloat16_t(!llvm.ptr, !llvm.ptr, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv(%arg0: i64, %arg1: !llvm.ptr<1>, %arg2: !llvm.ptr<1>, %arg3: !llvm.ptr<1>, %arg4: !llvm.ptr<1>, %arg5: !llvm.ptr<1>, %arg6: !llvm.ptr<1>, %arg7: !llvm.ptr<1>, %arg8: !llvm.ptr<1>, %arg9: !llvm.ptr<1>, %arg10: !llvm.ptr<1>, %arg11: i32, %arg12: i32, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32, %arg17: i32, %arg18: i32, %arg19: i32, %arg20: f32, %arg21: i32, %arg22: i32, %arg23: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix, hivm.vf_mode = #hivm.vf_mode<SIMD>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, mix_mode = "mix", parallel_mode = "simd"} {
    %0 = llvm.mlir.constant(272 : index) : i64
    %1 = llvm.mlir.constant(5 : index) : i64
    %2 = llvm.mlir.constant(3 : index) : i64
    %3 = llvm.mlir.constant(9 : index) : i64
    %4 = llvm.mlir.constant(7 : index) : i64
    %5 = llvm.mlir.constant(12 : index) : i64
    %6 = llvm.mlir.constant(-1 : index) : i64
    %7 = llvm.mlir.constant(384 : index) : i64
    %8 = llvm.mlir.constant(1024 : index) : i64
    %9 = llvm.mlir.constant(4 : index) : i64
    %10 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %11 = llvm.mlir.constant(1536 : index) : i64
    %12 = llvm.mlir.constant(256 : index) : i64
    %13 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %14 = llvm.mlir.constant(6 : index) : i64
    %15 = llvm.mlir.constant(48 : i64) : i64
    %16 = llvm.mlir.constant(60 : i64) : i64
    %17 = llvm.mlir.constant(0 : index) : i64
    %18 = llvm.mlir.constant(63 : i32) : i32
    %19 = llvm.mlir.constant(64 : i32) : i32
    %20 = llvm.mlir.constant(0 : i32) : i32
    %21 = llvm.mlir.constant(0 : i64) : i64
    %22 = llvm.mlir.constant(32 : i64) : i64
    %23 = llvm.mlir.constant(6176 : i64) : i64
    %24 = llvm.mlir.constant(6208 : i64) : i64
    %25 = llvm.mlir.constant(56064 : i64) : i64
    %26 = llvm.mlir.constant(44928 : i64) : i64
    %27 = llvm.mlir.constant(56000 : i64) : i64
    %28 = llvm.mlir.constant(62208 : i64) : i64
    %29 = llvm.mlir.constant(51744 : i64) : i64
    %30 = llvm.mlir.constant(56032 : i64) : i64
    %31 = llvm.mlir.constant(6464 : i64) : i64
    %32 = llvm.mlir.constant(18752 : i64) : i64
    %33 = llvm.mlir.constant(16384 : i64) : i64
    %34 = llvm.mlir.constant(20480 : i64) : i64
    %35 = llvm.mlir.constant(31040 : i64) : i64
    %36 = llvm.mlir.constant(34112 : i64) : i64
    %37 = llvm.mlir.constant(37568 : i64) : i64
    %38 = llvm.mlir.constant(42112 : i64) : i64
    %39 = llvm.mlir.constant(42048 : i64) : i64
    %40 = llvm.mlir.constant(37952 : i64) : i64
    %41 = llvm.mlir.constant(37184 : i64) : i64
    %42 = llvm.mlir.constant(42176 : i64) : i64
    %43 = llvm.mlir.constant(42208 : i64) : i64
    %44 = llvm.mlir.constant(42240 : i64) : i64
    %45 = llvm.mlir.constant(42304 : i64) : i64
    %46 = llvm.mlir.constant(42368 : i64) : i64
    %47 = llvm.mlir.constant(43904 : i64) : i64
    %48 = llvm.mlir.constant(43968 : i64) : i64
    %49 = llvm.mlir.constant(44000 : i64) : i64
    %50 = llvm.mlir.constant(44064 : i64) : i64
    %51 = llvm.mlir.constant(44160 : i64) : i64
    %52 = llvm.mlir.constant(44096 : i64) : i64
    %53 = llvm.mlir.constant(44960 : i64) : i64
    %54 = llvm.mlir.constant(47008 : i64) : i64
    %55 = llvm.mlir.constant(49184 : i64) : i64
    %56 = llvm.mlir.constant(50720 : i64) : i64
    %57 = llvm.mlir.constant(50784 : i64) : i64
    %58 = llvm.mlir.constant(50816 : i64) : i64
    %59 = llvm.mlir.constant(50880 : i64) : i64
    %60 = llvm.mlir.constant(50976 : i64) : i64
    %61 = llvm.mlir.constant(50912 : i64) : i64
    %62 = llvm.mlir.constant(51776 : i64) : i64
    %63 = llvm.mlir.constant(53824 : i64) : i64
    %64 = llvm.mlir.constant(68352 : i64) : i64
    %65 = llvm.mlir.constant(71424 : i64) : i64
    %66 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %67 = llvm.mlir.constant(1 : index) : i64
    %68 = llvm.mlir.constant(1 : i32) : i32
    %69 = llvm.mlir.constant(2 : index) : i64
    %70 = llvm.mlir.constant(2 : i32) : i32
    %71 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %72 = "hivm.intr.hivm.SBITSET0"(%71, %16) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%72) : (i64) -> ()
    %73 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %74 = "hivm.intr.hivm.SBITSET1"(%73, %15) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%74) : (i64) -> ()
    %75 = "hivm.intr.hivm.GET.BLOCK.IDX"() : () -> i64
    %76 = llvm.trunc %75 : i64 to i32
    %77 = llvm.srem %76, %arg21  : i32
    %78 = llvm.inttoptr %21 : i64 to !llvm.ptr<6>
    %79 = llvm.inttoptr %22 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_merged_vf_0(%78, %79) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %80 = llvm.sdiv %77, %arg21  : i32
    %81 = llvm.add %77, %68 : i32
    %82 = llvm.sdiv %81, %arg21  : i32
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 7 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 8 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 9 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 10 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.br ^bb1(%80 : i32)
  ^bb1(%83: i32):  // 2 preds: ^bb0, ^bb22
    %84 = llvm.icmp "slt" %83, %82 : i32
    llvm.cond_br %84, ^bb2, ^bb23
  ^bb2:  // pred: ^bb1
    %85 = llvm.sext %83 : i32 to i64
    %86 = llvm.getelementptr %arg7[%85] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %87 = llvm.load %86 : !llvm.ptr<1> -> i32
    %88 = llvm.add %85, %67 : i64
    %89 = llvm.getelementptr %arg7[%88] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %90 = llvm.load %89 : !llvm.ptr<1> -> i32
    %91 = llvm.sub %90, %87 : i32
    %92 = llvm.icmp "sgt" %91, %20 : i32
    llvm.cond_br %92, ^bb3, ^bb22
  ^bb3:  // pred: ^bb2
    %93 = llvm.inttoptr %23 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @load_gm_to_ubuf_1d_float(%arg10, %arg10, %17, %14, %67, %93, %93, %17, %14, %67, %20, %66, %17, %20) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i32, f32, i64, i32) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    %94 = llvm.getelementptr %arg8[%85] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %95 = llvm.load %94 : !llvm.ptr<1> -> i32
    %96 = llvm.sub %95, %91 : i32
    %97 = llvm.add %95, %18 : i32
    %98 = llvm.sdiv %97, %19  : i32
    %99 = llvm.inttoptr %24 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_17(%99) {hivm.vector_function, no_inline} : (!llvm.ptr<6>) -> ()
    %100 = llvm.sitofp %95 : i32 to f32
    %101 = llvm.sitofp %96 : i32 to f32
    %102 = llvm.add %96, %68 : i32
    %103 = llvm.sitofp %102 : i32 to f32
    %104 = llvm.sext %98 : i32 to i64
    %105 = "hivm.intr.hivm.GET.SUBBLOCKID"() : () -> i64
    %106 = llvm.icmp "eq" %105, %17 : i64
    %107 = llvm.inttoptr %25 : i64 to !llvm.ptr<6>
    %108 = llvm.insertvalue %107, %10[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %109 = llvm.insertvalue %107, %108[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %110 = llvm.insertvalue %17, %109[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %111 = llvm.insertvalue %14, %110[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %112 = llvm.insertvalue %12, %111[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %113 = llvm.insertvalue %12, %112[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %114 = llvm.insertvalue %67, %113[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%79, %79, %17, %11, %67, %107, %107, %17, %11, %67) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %115 = llvm.inttoptr %26 : i64 to !llvm.ptr<6>
    %116 = llvm.insertvalue %115, %13[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %117 = llvm.insertvalue %115, %116[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %118 = llvm.insertvalue %17, %117[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %119 = llvm.insertvalue %14, %118[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %120 = llvm.insertvalue %67, %119[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%78, %78, %17, %14, %67, %115, %115, %17, %14, %67) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %121 = llvm.inttoptr %27 : i64 to !llvm.ptr<6>
    %122 = llvm.insertvalue %121, %13[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %123 = llvm.insertvalue %121, %122[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %124 = llvm.insertvalue %17, %123[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %125 = llvm.insertvalue %14, %124[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %126 = llvm.insertvalue %67, %125[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_float(%93, %93, %17, %14, %67, %121, %121, %17, %14, %67) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %127 = llvm.inttoptr %28 : i64 to !llvm.ptr<6>
    %128 = llvm.insertvalue %127, %10[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %129 = llvm.insertvalue %127, %128[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %130 = llvm.insertvalue %17, %129[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %131 = llvm.insertvalue %14, %130[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %132 = llvm.insertvalue %12, %131[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %133 = llvm.insertvalue %12, %132[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %134 = llvm.insertvalue %67, %133[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%79, %79, %17, %11, %67, %127, %127, %17, %11, %67) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %135 = llvm.inttoptr %29 : i64 to !llvm.ptr<6>
    %136 = llvm.insertvalue %135, %13[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %137 = llvm.insertvalue %135, %136[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %138 = llvm.insertvalue %17, %137[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %139 = llvm.insertvalue %14, %138[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %140 = llvm.insertvalue %67, %139[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%78, %78, %17, %14, %67, %135, %135, %17, %14, %67) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %141 = llvm.inttoptr %30 : i64 to !llvm.ptr<6>
    %142 = llvm.insertvalue %141, %13[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %143 = llvm.insertvalue %141, %142[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %144 = llvm.insertvalue %17, %143[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %145 = llvm.insertvalue %14, %144[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %146 = llvm.insertvalue %67, %145[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%93, %93, %17, %14, %67, %141, %141, %17, %14, %67) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.br ^bb4(%20, %114, %120, %126, %134, %140, %146 : i32, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>)
  ^bb4(%147: i32, %148: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %149: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %150: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %151: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %152: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %153: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>):  // 2 preds: ^bb3, ^bb18
    %154 = llvm.icmp "slt" %147, %98 : i32
    llvm.cond_br %154, ^bb5, ^bb19
  ^bb5:  // pred: ^bb4
    %155 = llvm.inttoptr %31 : i64 to !llvm.ptr<6>
    %156 = llvm.inttoptr %32 : i64 to !llvm.ptr<6>
    %157 = llvm.inttoptr %33 : i64 to !llvm.ptr<2>
    %158 = llvm.inttoptr %34 : i64 to !llvm.ptr<2>
    %159 = llvm.inttoptr %35 : i64 to !llvm.ptr<6>
    %160 = llvm.inttoptr %36 : i64 to !llvm.ptr<6>
    %161 = llvm.sext %147 : i32 to i64
    %162 = llvm.mul %161, %6 : i64
    %163 = llvm.add %104, %162 : i64
    %164 = llvm.intr.umin(%163, %69)  : (i64, i64) -> i64
    %165 = llvm.inttoptr %37 : i64 to !llvm.ptr<6>
    %166 = llvm.inttoptr %38 : i64 to !llvm.ptr<6>
    %167 = llvm.inttoptr %39 : i64 to !llvm.ptr<6>
    %168 = llvm.inttoptr %40 : i64 to !llvm.ptr<6>
    %169 = llvm.inttoptr %41 : i64 to !llvm.ptr<6>
    llvm.br ^bb6(%17 : i64)
  ^bb6(%170: i64):  // 2 preds: ^bb5, ^bb7
    %171 = llvm.icmp "slt" %170, %164 : i64
    llvm.cond_br %171, ^bb7, ^bb8
  ^bb7:  // pred: ^bb6
    %172 = llvm.add %170, %161 : i64
    %173 = llvm.trunc %172 : i64 to i32
    %174 = llvm.mul %173, %19 : i32
    %175 = llvm.inttoptr %42 : i64 to !llvm.ptr<6>
    %176 = llvm.inttoptr %43 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_merged_merged_vf_0(%166, %170, %167, %170, %168, %170, %99, %174, %100, %101, %103, %175, %176) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, i64, !llvm.ptr<6>, i64, !llvm.ptr<6>, i64, !llvm.ptr<6>, i32, f32, f32, f32, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_3(%175, %176, %165, %170, %169, %170) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>, i64) -> ()
    %177 = llvm.add %170, %67 overflow<nsw> : i64
    llvm.br ^bb6(%177 : i64)
  ^bb8:  // pred: ^bb6
    %178 = llvm.inttoptr %44 : i64 to !llvm.ptr<6>
    %179 = llvm.inttoptr %45 : i64 to !llvm.ptr<6>
    llvm.br ^bb9(%17, %150, %149, %153, %152 : i64, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>)
  ^bb9(%180: i64, %181: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %182: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %183: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %184: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>):  // 2 preds: ^bb8, ^bb14
    %185 = llvm.icmp "slt" %180, %164 : i64
    llvm.cond_br %185, ^bb10, ^bb15
  ^bb10:  // pred: ^bb9
    %186 = llvm.add %180, %4 : i64
    %187 = llvm.add %180, %3 : i64
    %188 = llvm.add %180, %2 : i64
    %189 = llvm.add %180, %1 : i64
    %190 = llvm.inttoptr %46 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 0 : i64}> : () -> ()
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_4(%165, %180, %159, %arg20, %190) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, i64, !llvm.ptr<6>, f32, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCK.mode"(%187) <{pipe = 1 : i64}> : (i64) -> ()
    %191 = llvm.inttoptr %47 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%166, %166, %17, %5, %67, %191, %191, %17, %5, %67) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_5(%190, %191, %180) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i64) -> ()
    %192 = llvm.inttoptr %48 : i64 to !llvm.ptr<6>
    %193 = llvm.extractvalue %181[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_6(%193, %191, %180, %192) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>) -> ()
    %194 = llvm.inttoptr %49 : i64 to !llvm.ptr<6>
    %195 = llvm.inttoptr %50 : i64 to !llvm.ptr<6>
    %196 = llvm.extractvalue %181[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_7(%196, %192, %194, %180, %195) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>) -> ()
    %197 = llvm.mul %180, %14 : i64
    llvm.call @copy_ubuf_to_ubuf_1d_float(%195, %195, %17, %14, %67, %178, %178, %197, %14, %67) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %198 = llvm.inttoptr %51 : i64 to !llvm.ptr<6>
    %199 = llvm.inttoptr %26 : i64 to !llvm.ptr<6>
    %200 = llvm.insertvalue %199, %13[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %201 = llvm.insertvalue %199, %200[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %202 = llvm.insertvalue %17, %201[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %203 = llvm.insertvalue %14, %202[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %204 = llvm.insertvalue %67, %203[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %205 = llvm.inttoptr %52 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%167, %167, %17, %5, %67, %205, %205, %17, %5, %67) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %206 = llvm.extractvalue %182[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_8(%190, %192, %205, %180, %198, %206, %195, %199) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %207 = llvm.inttoptr %53 : i64 to !llvm.ptr<6>
    %208 = llvm.mul %180, %8 : i64
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%168, %168, %208, %8, %67, %207, %207, %17, %8, %67) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%198, %198, %17, %7, %67, %207, %207, %17, %7, %67) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %209 = llvm.inttoptr %54 : i64 to !llvm.ptr<6>
    %210 = llvm.inttoptr %55 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 13 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_merged_vf_2(%207, %209, %169, %180, %160, %arg20, %210) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>, f32, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCK.mode"(%186) <{pipe = 1 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCK.mode"(%189) <{pipe = 5 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %106, ^bb11, ^bb12
  ^bb11:  // pred: ^bb10
    %211 = llvm.mul %180, %8 : i64
    llvm.call @copy_ubuf_to_cbuf_2d_bfloat16_t(%209, %209, %17, %9, %12, %0, %67, %157, %157, %211, %9, %12, %12, %67) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64) -> ()
    llvm.br ^bb12
  ^bb12:  // 2 preds: ^bb10, ^bb11
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 12 : i64}> : () -> ()
    %212 = llvm.inttoptr %56 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%166, %166, %17, %5, %67, %212, %212, %17, %5, %67) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_11(%210, %212, %180) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i64) -> ()
    %213 = llvm.inttoptr %57 : i64 to !llvm.ptr<6>
    %214 = llvm.extractvalue %183[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_12(%214, %212, %180, %213) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>) -> ()
    %215 = llvm.inttoptr %58 : i64 to !llvm.ptr<6>
    %216 = llvm.inttoptr %59 : i64 to !llvm.ptr<6>
    %217 = llvm.extractvalue %183[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_13(%217, %213, %215, %180, %216) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>) -> ()
    %218 = llvm.mul %180, %14 : i64
    llvm.call @copy_ubuf_to_ubuf_1d_float(%216, %216, %17, %14, %67, %179, %179, %218, %14, %67) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %219 = llvm.inttoptr %60 : i64 to !llvm.ptr<6>
    %220 = llvm.inttoptr %29 : i64 to !llvm.ptr<6>
    %221 = llvm.insertvalue %220, %13[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %222 = llvm.insertvalue %220, %221[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %223 = llvm.insertvalue %17, %222[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %224 = llvm.insertvalue %14, %223[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %225 = llvm.insertvalue %67, %224[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %226 = llvm.inttoptr %61 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%167, %167, %17, %5, %67, %226, %226, %17, %5, %67) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %227 = llvm.extractvalue %184[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_14(%210, %213, %226, %180, %219, %227, %216, %220) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %228 = llvm.inttoptr %62 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%168, %168, %208, %8, %67, %228, %228, %17, %8, %67) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%219, %219, %17, %7, %67, %228, %228, %17, %7, %67) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %229 = llvm.inttoptr %63 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_15(%228, %229) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCK.mode"(%188) <{pipe = 5 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %106, ^bb13, ^bb14
  ^bb13:  // pred: ^bb12
    %230 = llvm.mul %180, %8 : i64
    llvm.call @copy_ubuf_to_cbuf_2d_bfloat16_t(%229, %229, %17, %9, %12, %0, %67, %158, %158, %230, %9, %12, %12, %67) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64) -> ()
    llvm.br ^bb14
  ^bb14:  // 2 preds: ^bb12, ^bb13
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 11 : i64}> : () -> ()
    %231 = llvm.inttoptr %27 : i64 to !llvm.ptr<6>
    %232 = llvm.insertvalue %231, %13[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %233 = llvm.insertvalue %231, %232[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %234 = llvm.insertvalue %17, %233[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %235 = llvm.insertvalue %14, %234[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %236 = llvm.insertvalue %67, %235[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%192, %192, %17, %14, %67, %231, %231, %17, %14, %67) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %237 = llvm.inttoptr %30 : i64 to !llvm.ptr<6>
    %238 = llvm.insertvalue %237, %13[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %239 = llvm.insertvalue %237, %238[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %240 = llvm.insertvalue %17, %239[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %241 = llvm.insertvalue %14, %240[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %242 = llvm.insertvalue %67, %241[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%213, %213, %17, %14, %67, %237, %237, %17, %14, %67) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %243 = llvm.add %180, %67 overflow<nsw> : i64
    llvm.br ^bb9(%243, %236, %204, %242, %225 : i64, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>)
  ^bb15:  // pred: ^bb9
    llvm.br ^bb16(%17, %148, %151 : i64, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>)
  ^bb16(%244: i64, %245: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %246: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>):  // 2 preds: ^bb15, ^bb17
    %247 = llvm.icmp "slt" %244, %164 : i64
    llvm.cond_br %247, ^bb17, ^bb18
  ^bb17:  // pred: ^bb16
    %248 = llvm.add %244, %67 : i64
    %249 = llvm.inttoptr %25 : i64 to !llvm.ptr<6>
    %250 = llvm.insertvalue %249, %10[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %251 = llvm.insertvalue %249, %250[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %252 = llvm.insertvalue %17, %251[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %253 = llvm.insertvalue %14, %252[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %254 = llvm.insertvalue %12, %253[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %255 = llvm.insertvalue %12, %254[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %256 = llvm.insertvalue %67, %255[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %257 = llvm.inttoptr %28 : i64 to !llvm.ptr<6>
    %258 = llvm.insertvalue %257, %10[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %259 = llvm.insertvalue %257, %258[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %260 = llvm.insertvalue %17, %259[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %261 = llvm.insertvalue %14, %260[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %262 = llvm.insertvalue %12, %261[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %263 = llvm.insertvalue %12, %262[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %264 = llvm.insertvalue %67, %263[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 0 : i64}> : () -> ()
    %265 = llvm.extractvalue %245[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %266 = llvm.extractvalue %246[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_16(%178, %244, %179, %155, %265, %156, %266, %249, %257) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, i64, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCK.mode"(%248) <{pipe = 1 : i64}> : (i64) -> ()
    %267 = llvm.add %244, %67 overflow<nsw> : i64
    llvm.br ^bb16(%267, %256, %264 : i64, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>)
  ^bb18:  // pred: ^bb16
    %268 = llvm.add %147, %70 overflow<nsw> : i32
    llvm.br ^bb4(%268, %245, %182, %181, %246, %184, %183 : i32, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>)
  ^bb19:  // pred: ^bb4
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %269 = llvm.mul %87, %arg17 : i32
    %270 = llvm.sext %269 : i32 to i64
    %271 = llvm.sext %arg18 : i32 to i64
    %272 = llvm.inttoptr %64 : i64 to !llvm.ptr<6>
    %273 = llvm.sext %arg17 : i32 to i64
    %274 = llvm.add %270, %273 : i64
    %275 = llvm.inttoptr %65 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %276 = llvm.extractvalue %149[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %277 = llvm.extractvalue %148[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %278 = llvm.extractvalue %152[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %279 = llvm.extractvalue %151[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_merged_vf_3(%276, %277, %272, %278, %279, %275) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %106, ^bb20, ^bb21
  ^bb20:  // pred: ^bb19
    llvm.call @store_ubuf_to_gm_2d_bfloat16_t(%272, %272, %17, %14, %12, %12, %67, %arg6, %arg6, %270, %14, %12, %271, %67, %20) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i32) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 5 : i64}> : () -> ()
    llvm.call @store_ubuf_to_gm_2d_bfloat16_t(%275, %275, %17, %14, %12, %12, %67, %arg6, %arg6, %274, %14, %12, %271, %67, %20) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i32) -> ()
    llvm.br ^bb21
  ^bb21:  // 2 preds: ^bb19, ^bb20
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.br ^bb22
  ^bb22:  // 2 preds: ^bb2, ^bb21
    %280 = llvm.add %83, %68 overflow<nsw> : i32
    llvm.br ^bb1(%280 : i32)
  ^bb23:  // pred: ^bb1
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 6 : i64}> : () -> ()
    %281 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %282 = "hivm.intr.hivm.SBITSET1"(%281, %16) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%282) : (i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 6 : i64}> : () -> ()
    llvm.return
  }
}


bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
ld.lld: warning: -z separate-code and -z separate-loadable-segments will be ignored
