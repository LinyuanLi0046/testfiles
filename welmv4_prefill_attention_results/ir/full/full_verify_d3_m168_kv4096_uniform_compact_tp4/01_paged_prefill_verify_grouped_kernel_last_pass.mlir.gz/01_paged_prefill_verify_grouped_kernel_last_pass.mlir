// -----// IR Dump After AppendUsePrintDebugData (append-use-print-debug-data) //----- //
module attributes {dlti.target_system_spec = #dlti.target_system_spec<"NPU" : #hacc.target_device_spec<#dlti.dl_entry<"AI_CORE_COUNT", 28 : i32>, #dlti.dl_entry<"CUBE_CORE_COUNT", 28 : i32>, #dlti.dl_entry<"VECTOR_CORE_COUNT", 56 : i32>, #dlti.dl_entry<"UB_SIZE", 2031616 : i32>, #dlti.dl_entry<"L1_SIZE", 4194304 : i32>, #dlti.dl_entry<"L0A_SIZE", 524288 : i32>, #dlti.dl_entry<"L0B_SIZE", 524288 : i32>, #dlti.dl_entry<"L0C_SIZE", 2097152 : i32>, #dlti.dl_entry<"UB_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L1_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L0C_ALIGN_SIZE", 4096 : i32>, #dlti.dl_entry<"MINIMAL_D_CACHE_SIZE", 262144 : i32>, #dlti.dl_entry<"MAXIMUM_D_CACHE_SIZE", 983040 : i32>, #dlti.dl_entry<"ARCH", "dav-c310">>>, hacc.target = #hacc.target<"Ascend950PR_957b">, hivm.aic_bitcode = #hivm.aic_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.aic.c310.bc">, hivm.aiv_bitcode = #hivm.aiv_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.aiv.c310.bc">, hivm.host_bitcode = #hivm.host_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/host-a5.bc">, hivm.mix_aic_bitcode = #hivm.mix_aic_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.mix.aic.c310.bc">, hivm.mix_aiv_bitcode = #hivm.mix_aiv_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.mix.aiv.c310.bc">, hivm.module_core_type = #hivm.module_core_type<MIX>} {
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_merged_merged_vf_1(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>, %arg8: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(256 : i32) : i32
    %4 = llvm.mlir.constant(64 : i32) : i32
    %5 = llvm.mlir.constant(3 : i32) : i32
    %6 = llvm.mlir.constant(8 : i32) : i32
    %7 = llvm.mlir.constant(7 : i32) : i32
    %8 = llvm.mlir.constant(256 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%9: i32):  // 2 preds: ^bb0, ^bb5
    %10 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %10, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %11 = llvm.sext %9 : i32 to i64
    llvm.br ^bb3(%2 : i32)
  ^bb3(%12: i32):  // 2 preds: ^bb2, ^bb4
    %13 = llvm.icmp "slt" %12, %3 : i32
    llvm.cond_br %13, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %14 = llvm.sext %12 : i32 to i64
    %15 = llvm.mul %11, %8 : i64
    %16 = llvm.add %15, %14 : i64
    %17 = llvm.getelementptr %arg1[%16] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %18 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%17, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %19 = llvm.getelementptr %arg0[%11] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %20 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%19, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.vdiv.s.x"(%18, %20, %21) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %23 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %24 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%22, %23, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %25 = llvm.mul %11, %8 : i64
    %26 = llvm.add %25, %14 : i64
    %27 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %28 = llvm.getelementptr %arg2[%26] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%24, %28, %2, %7, %2, %27) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %29 = llvm.add %12, %4 overflow<nsw> : i32
    llvm.br ^bb3(%29 : i32)
  ^bb5:  // pred: ^bb3
    %30 = llvm.add %9, %0 overflow<nsw> : i32
    llvm.br ^bb1(%30 : i32)
  ^bb6:  // pred: ^bb1
    llvm.br ^bb7(%2 : i32)
  ^bb7(%31: i32):  // 2 preds: ^bb6, ^bb11
    %32 = llvm.icmp "slt" %31, %1 : i32
    llvm.cond_br %32, ^bb8, ^bb12
  ^bb8:  // pred: ^bb7
    %33 = llvm.sext %31 : i32 to i64
    llvm.br ^bb9(%2 : i32)
  ^bb9(%34: i32):  // 2 preds: ^bb8, ^bb10
    %35 = llvm.icmp "slt" %34, %3 : i32
    llvm.cond_br %35, ^bb10, ^bb11
  ^bb10:  // pred: ^bb9
    %36 = llvm.sext %34 : i32 to i64
    %37 = llvm.mul %33, %8 : i64
    %38 = llvm.add %37, %36 : i64
    %39 = llvm.getelementptr %arg4[%38] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %40 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%39, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %41 = llvm.getelementptr %arg3[%33] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %42 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%41, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %43 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %44 = "hivm_regbaseintrins.intr.hivm.vdiv.s.x"(%40, %42, %43) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %45 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %46 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%44, %45, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %47 = llvm.mul %33, %8 : i64
    %48 = llvm.add %47, %36 : i64
    %49 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %50 = llvm.getelementptr %arg5[%48] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%46, %50, %2, %7, %2, %49) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %51 = llvm.add %34, %4 overflow<nsw> : i32
    llvm.br ^bb9(%51 : i32)
  ^bb11:  // pred: ^bb9
    %52 = llvm.add %31, %0 overflow<nsw> : i32
    llvm.br ^bb7(%52 : i32)
  ^bb12:  // pred: ^bb7
    llvm.br ^bb13(%2 : i32)
  ^bb13(%53: i32):  // 2 preds: ^bb12, ^bb17
    %54 = llvm.icmp "slt" %53, %1 : i32
    llvm.cond_br %54, ^bb14, ^bb18
  ^bb14:  // pred: ^bb13
    %55 = llvm.sext %53 : i32 to i64
    llvm.br ^bb15(%2 : i32)
  ^bb15(%56: i32):  // 2 preds: ^bb14, ^bb16
    %57 = llvm.icmp "slt" %56, %3 : i32
    llvm.cond_br %57, ^bb16, ^bb17
  ^bb16:  // pred: ^bb15
    %58 = llvm.sext %56 : i32 to i64
    %59 = llvm.mul %55, %8 : i64
    %60 = llvm.add %59, %58 : i64
    %61 = llvm.getelementptr %arg7[%60] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %62 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%61, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %63 = llvm.getelementptr %arg6[%55] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %64 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%63, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %65 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %66 = "hivm_regbaseintrins.intr.hivm.vdiv.s.x"(%62, %64, %65) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %67 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %68 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%66, %67, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %69 = llvm.mul %55, %8 : i64
    %70 = llvm.add %69, %58 : i64
    %71 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %72 = llvm.getelementptr %arg8[%70] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%68, %72, %2, %7, %2, %71) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %73 = llvm.add %56, %4 overflow<nsw> : i32
    llvm.br ^bb15(%73 : i32)
  ^bb17:  // pred: ^bb15
    %74 = llvm.add %53, %0 overflow<nsw> : i32
    llvm.br ^bb13(%74 : i32)
  ^bb18:  // pred: ^bb13
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_merged_merged_vf_0(%arg0: !llvm.ptr<6>, %arg1: i64, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>, %arg5: i64, %arg6: !llvm.ptr<6>, %arg7: i32, %arg8: f32, %arg9: f32, %arg10: f32, %arg11: f32, %arg12: !llvm.ptr<6>, %arg13: !llvm.ptr<6>, %arg14: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(16 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %4 = llvm.mlir.constant(0xFF800000 : f32) : f32
    %5 = llvm.mlir.constant(0.000000e+00 : bf16) : bf16
    %6 = llvm.mlir.constant(9 : i32) : i32
    %7 = llvm.mlir.constant(8 : i32) : i32
    %8 = llvm.mlir.constant(6 : i32) : i32
    %9 = llvm.mlir.constant(24 : i32) : i32
    %10 = llvm.mlir.constant(6 : index) : i64
    %11 = llvm.mlir.constant(1024 : index) : i64
    %12 = llvm.mlir.constant(64 : index) : i64
    %13 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%6, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %14 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%5, %13, %0) : (bf16, vector<256xi1>, i32) -> vector<128xbf16>
    %15 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %16 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%4, %15, %0) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %17 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %18 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%3, %17, %0) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %19 = llvm.mul %arg3, %10 : i64
    %20 = llvm.mul %arg1, %10 : i64
    %21 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%8) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %22 = llvm.getelementptr %arg0[%20] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %24 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%16, %22, %9, %23) : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %25 = llvm.extractvalue %24[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %26 = llvm.extractvalue %24[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%25, %26, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %27 = llvm.getelementptr %arg2[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %28 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %29 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%18, %27, %9, %28) : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %30 = llvm.extractvalue %29[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %31 = llvm.extractvalue %29[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%30, %31, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.br ^bb1(%2 : i32)
  ^bb1(%32: i32):  // 2 preds: ^bb0, ^bb2
    %33 = llvm.icmp "slt" %32, %1 : i32
    llvm.cond_br %33, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %34 = llvm.sext %32 : i32 to i64
    %35 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%7, %2) {mask_bit_width = 16 : i32, mask_op_idx = 1 : i32} : (i32, i32) -> vector<256xi1>
    %36 = llvm.mul %arg5, %11 : i64
    %37 = llvm.mul %34, %12 : i64
    %38 = llvm.add %36, %37 : i64
    %39 = llvm.getelementptr %arg4[%38] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%14, %39, %2, %0, %2, %35) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %40 = llvm.add %32, %0 overflow<nsw> : i32
    llvm.br ^bb1(%40 : i32)
  ^bb3:  // pred: ^bb1
    %41 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64s32"(%arg6, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xi32>
    %42 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %43 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%41, %arg7, %42) : (vector<64xi32>, i32, vector<256xi1>) -> vector<64xi32>
    %44 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %45 = "hivm_regbaseintrins.intr.hivm.vcvtif.s322f32.x"(%43, %44, %2) : (vector<64xi32>, vector<256xi1>, i32) -> vector<64xf32>
    %46 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg8) : (f32) -> vector<64xf32>
    %47 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %48 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%45, %46, %47) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %49 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg9) : (f32) -> vector<64xf32>
    %50 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %51 = "hivm_regbaseintrins.intr.hivm.vcmp.le.s.z"(%45, %49, %50) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %52 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %53 = "hivm_regbaseintrins.intr.hivm.pand.z"(%48, %51, %52) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %54 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %55 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %56 = "hivm_regbaseintrins.intr.hivm.pstu.b32"(%53, %arg12, %55) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %57 = llvm.extractvalue %56[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %58 = llvm.extractvalue %56[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%57, %58, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %59 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg10) : (f32) -> vector<64xf32>
    %60 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %61 = "hivm_regbaseintrins.intr.hivm.vcmp.le.s.z"(%45, %59, %60) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %62 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %63 = "hivm_regbaseintrins.intr.hivm.pand.z"(%48, %61, %62) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %64 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %65 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %66 = "hivm_regbaseintrins.intr.hivm.pstu.b32"(%63, %arg13, %65) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %67 = llvm.extractvalue %66[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %68 = llvm.extractvalue %66[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%67, %68, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %69 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg11) : (f32) -> vector<64xf32>
    %70 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %71 = "hivm_regbaseintrins.intr.hivm.vcmp.le.s.z"(%45, %69, %70) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %72 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %73 = "hivm_regbaseintrins.intr.hivm.pand.z"(%48, %71, %72) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %74 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %75 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %76 = "hivm_regbaseintrins.intr.hivm.pstu.b32"(%73, %arg14, %75) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %77 = llvm.extractvalue %76[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %78 = llvm.extractvalue %76[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%77, %78, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_merged_vf_3(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>, %arg5: f32, %arg6: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(8 : i32) : i32
    %1 = llvm.mlir.constant(-1.000000e+06 : f32) : f32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(16 : i32) : i32
    %4 = llvm.mlir.constant(1 : i32) : i32
    %5 = llvm.mlir.constant(6 : i32) : i32
    %6 = llvm.mlir.constant(1114112 : i32) : i32
    %7 = llvm.mlir.constant(8 : index) : i64
    %8 = llvm.mlir.constant(2 : i32) : i32
    %9 = llvm.mlir.constant(16 : index) : i64
    %10 = llvm.mlir.constant(272 : index) : i64
    %11 = llvm.mlir.constant(256 : index) : i64
    %12 = llvm.mlir.constant(1536 : index) : i64
    %13 = llvm.mlir.constant(384 : index) : i64
    %14 = llvm.mlir.constant(64 : index) : i64
    %15 = llvm.mlir.constant(0 : index) : i64
    %16 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %17 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%1, %16, %4) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    llvm.br ^bb1(%2 : i32)
  ^bb1(%18: i32):  // 2 preds: ^bb0, ^bb2
    %19 = llvm.icmp "slt" %18, %3 : i32
    llvm.cond_br %19, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %20 = llvm.sext %18 : i32 to i64
    %21 = llvm.mul %20, %14 : i64
    %22 = llvm.getelementptr %arg0[%21] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %23 = llvm.mul %15, %14 : i64
    %24 = llvm.add %23, %15 : i64
    %25 = llvm.getelementptr %22[%24] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %26 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%25, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %27 = llvm.mul %20, %9 : i64
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%0, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %29 = llvm.getelementptr %arg1[%27] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %30 = llvm.mul %15, %10 : i64
    %31 = llvm.add %30, %15 : i64
    %32 = llvm.getelementptr %29[%31] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vsstb.v128bf16"(%26, %32, %6, %2, %28) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, vector<256xi1>) -> ()
    %33 = llvm.add %18, %4 overflow<nsw> : i32
    llvm.br ^bb1(%33 : i32)
  ^bb3:  // pred: ^bb1
    llvm.br ^bb4(%2 : i32)
  ^bb4(%34: i32):  // 2 preds: ^bb3, ^bb5
    %35 = llvm.icmp "slt" %34, %5 : i32
    llvm.cond_br %35, ^bb5, ^bb6
  ^bb5:  // pred: ^bb4
    %36 = llvm.sext %34 : i32 to i64
    %37 = llvm.mul %arg3, %12 : i64
    %38 = llvm.mul %36, %11 : i64
    %39 = llvm.add %37, %38 : i64
    %40 = llvm.udiv %39, %7  : i64
    %41 = llvm.getelementptr %arg2[%40] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %42 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%41, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %43 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %44 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%42, %43) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %45 = llvm.extractvalue %44[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %46 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%45, %43) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %47 = llvm.extractvalue %46[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %48 = llvm.mul %arg3, %13 : i64
    %49 = llvm.mul %36, %14 : i64
    %50 = llvm.add %48, %49 : i64
    %51 = llvm.getelementptr %arg4[%50] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %52 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%51, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %53 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %54 = "hivm_regbaseintrins.intr.hivm.vmuls.s.x"(%52, %arg5, %53) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %55 = "hivm_regbaseintrins.intr.hivm.vsel"(%54, %17, %47) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %56 = llvm.mul %36, %14 : i64
    %57 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %58 = llvm.getelementptr %arg6[%56] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%55, %58, %2, %8, %2, %57) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %59 = llvm.add %34, %4 overflow<nsw> : i32
    llvm.br ^bb4(%59 : i32)
  ^bb6:  // pred: ^bb4
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_merged_vf_2(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>, %arg5: f32, %arg6: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(8 : i32) : i32
    %1 = llvm.mlir.constant(-1.000000e+06 : f32) : f32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(16 : i32) : i32
    %4 = llvm.mlir.constant(1 : i32) : i32
    %5 = llvm.mlir.constant(6 : i32) : i32
    %6 = llvm.mlir.constant(1114112 : i32) : i32
    %7 = llvm.mlir.constant(8 : index) : i64
    %8 = llvm.mlir.constant(2 : i32) : i32
    %9 = llvm.mlir.constant(16 : index) : i64
    %10 = llvm.mlir.constant(272 : index) : i64
    %11 = llvm.mlir.constant(256 : index) : i64
    %12 = llvm.mlir.constant(1536 : index) : i64
    %13 = llvm.mlir.constant(384 : index) : i64
    %14 = llvm.mlir.constant(64 : index) : i64
    %15 = llvm.mlir.constant(0 : index) : i64
    %16 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %17 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%1, %16, %4) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    llvm.br ^bb1(%2 : i32)
  ^bb1(%18: i32):  // 2 preds: ^bb0, ^bb2
    %19 = llvm.icmp "slt" %18, %3 : i32
    llvm.cond_br %19, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %20 = llvm.sext %18 : i32 to i64
    %21 = llvm.mul %20, %14 : i64
    %22 = llvm.getelementptr %arg0[%21] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %23 = llvm.mul %15, %14 : i64
    %24 = llvm.add %23, %15 : i64
    %25 = llvm.getelementptr %22[%24] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %26 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%25, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %27 = llvm.mul %20, %9 : i64
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%0, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %29 = llvm.getelementptr %arg1[%27] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %30 = llvm.mul %15, %10 : i64
    %31 = llvm.add %30, %15 : i64
    %32 = llvm.getelementptr %29[%31] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vsstb.v128bf16"(%26, %32, %6, %2, %28) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, vector<256xi1>) -> ()
    %33 = llvm.add %18, %4 overflow<nsw> : i32
    llvm.br ^bb1(%33 : i32)
  ^bb3:  // pred: ^bb1
    llvm.br ^bb4(%2 : i32)
  ^bb4(%34: i32):  // 2 preds: ^bb3, ^bb5
    %35 = llvm.icmp "slt" %34, %5 : i32
    llvm.cond_br %35, ^bb5, ^bb6
  ^bb5:  // pred: ^bb4
    %36 = llvm.sext %34 : i32 to i64
    %37 = llvm.mul %arg3, %12 : i64
    %38 = llvm.mul %36, %11 : i64
    %39 = llvm.add %37, %38 : i64
    %40 = llvm.udiv %39, %7  : i64
    %41 = llvm.getelementptr %arg2[%40] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %42 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%41, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %43 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %44 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%42, %43) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %45 = llvm.extractvalue %44[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %46 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%45, %43) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %47 = llvm.extractvalue %46[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %48 = llvm.mul %arg3, %13 : i64
    %49 = llvm.mul %36, %14 : i64
    %50 = llvm.add %48, %49 : i64
    %51 = llvm.getelementptr %arg4[%50] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %52 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%51, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %53 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %54 = "hivm_regbaseintrins.intr.hivm.vmuls.s.x"(%52, %arg5, %53) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %55 = "hivm_regbaseintrins.intr.hivm.vsel"(%54, %17, %47) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %56 = llvm.mul %36, %14 : i64
    %57 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %58 = llvm.getelementptr %arg6[%56] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%55, %58, %2, %8, %2, %57) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %59 = llvm.add %34, %4 overflow<nsw> : i32
    llvm.br ^bb4(%59 : i32)
  ^bb6:  // pred: ^bb4
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_merged_vf_0(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(64 : i32) : i32
    %1 = llvm.mlir.constant(256 : i32) : i32
    %2 = llvm.mlir.constant(1 : i32) : i32
    %3 = llvm.mlir.constant(6 : i32) : i32
    %4 = llvm.mlir.constant(0 : i32) : i32
    %5 = llvm.mlir.constant(1.000000e+00 : f32) : f32
    %6 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %7 = llvm.mlir.constant(8 : i32) : i32
    %8 = llvm.mlir.constant(2 : i32) : i32
    %9 = llvm.mlir.constant(256 : index) : i64
    %10 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %11 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%6, %10, %2) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %12 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %13 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%5, %12, %2) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %14 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%3) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %15 = llvm.extractvalue %14[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%13, %arg0, %4, %8, %4, %15) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.br ^bb1(%4 : i32)
  ^bb1(%16: i32):  // 2 preds: ^bb0, ^bb5
    %17 = llvm.icmp "slt" %16, %3 : i32
    llvm.cond_br %17, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %16 : i32 to i64
    llvm.br ^bb3(%4 : i32)
  ^bb3(%19: i32):  // 2 preds: ^bb2, ^bb4
    %20 = llvm.icmp "slt" %19, %1 : i32
    llvm.cond_br %20, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %21 = llvm.sext %19 : i32 to i64
    %22 = llvm.mul %18, %9 : i64
    %23 = llvm.add %22, %21 : i64
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = llvm.getelementptr %arg1[%23] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%11, %25, %4, %8, %4, %24) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %26 = llvm.add %19, %0 overflow<nsw> : i32
    llvm.br ^bb3(%26 : i32)
  ^bb5:  // pred: ^bb3
    %27 = llvm.add %16, %2 overflow<nsw> : i32
    llvm.br ^bb1(%27 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aic(%arg0: i64, %arg1: !llvm.ptr<1>, %arg2: !llvm.ptr<1>, %arg3: !llvm.ptr<1>, %arg4: !llvm.ptr<1>, %arg5: !llvm.ptr<1>, %arg6: !llvm.ptr<1>, %arg7: !llvm.ptr<1>, %arg8: !llvm.ptr<1>, %arg9: !llvm.ptr<1>, %arg10: !llvm.ptr<1>, %arg11: i32, %arg12: i32, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32, %arg17: i32, %arg18: i32, %arg19: i32, %arg20: i32, %arg21: f32, %arg22: i32, %arg23: i32, %arg24: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, hivm.vf_mode = #hivm.vf_mode<SIMD>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, mix_mode = "mix", parallel_mode = "simd"} {
    %0 = llvm.mlir.constant(-1 : index) : i64
    %1 = llvm.mlir.constant(384 : index) : i64
    %2 = llvm.mlir.constant(1536 : index) : i64
    %3 = llvm.mlir.constant(48 : i64) : i64
    %4 = llvm.mlir.constant(60 : i64) : i64
    %5 = llvm.mlir.constant(16384 : index) : i64
    %6 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %7 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %8 = llvm.mlir.constant(1024 : index) : i64
    %9 = llvm.mlir.constant(16 : index) : i64
    %10 = llvm.mlir.constant(4 : index) : i64
    %11 = llvm.mlir.constant(0 : index) : i64
    %12 = llvm.mlir.constant(0 : i8) : i8
    %13 = llvm.mlir.constant(false) : i1
    %14 = llvm.mlir.constant(1.000000e+00 : f32) : f32
    %15 = llvm.mlir.constant(49472 : i64) : i64
    %16 = llvm.mlir.constant(46400 : i64) : i64
    %17 = llvm.mlir.constant(43328 : i64) : i64
    %18 = llvm.mlir.constant(32768 : i64) : i64
    %19 = llvm.mlir.constant(24576 : i64) : i64
    %20 = llvm.mlir.constant(31040 : i64) : i64
    %21 = llvm.mlir.constant(18752 : i64) : i64
    %22 = llvm.mlir.constant(6464 : i64) : i64
    %23 = llvm.mlir.constant(2 : i32) : i32
    %24 = llvm.mlir.constant(0 : i32) : i32
    %25 = llvm.mlir.constant(64 : i32) : i32
    %26 = llvm.mlir.constant(63 : i32) : i32
    %27 = llvm.mlir.constant(1 : index) : i64
    %28 = llvm.mlir.constant(64 : index) : i64
    %29 = llvm.mlir.constant(256 : index) : i64
    %30 = llvm.mlir.constant(0.000000e+00 : bf16) : bf16
    %31 = llvm.mlir.constant(1 : i32) : i32
    %32 = llvm.mlir.constant(6 : index) : i64
    %33 = llvm.mlir.constant(true) : i1
    %34 = llvm.mlir.constant(2 : index) : i64
    %35 = llvm.mlir.constant(2 : i64) : i64
    %36 = llvm.mlir.constant(1 : i64) : i64
    %37 = llvm.mlir.constant(4 : i64) : i64
    %38 = llvm.mlir.constant(5 : i64) : i64
    %39 = llvm.mlir.constant(3 : i64) : i64
    %40 = llvm.mlir.constant(-1 : i64) : i64
    %41 = llvm.mlir.constant(159744 : i64) : i64
    %42 = llvm.mlir.constant(73728 : i64) : i64
    %43 = llvm.mlir.constant(12288 : i64) : i64
    %44 = llvm.mlir.constant(90112 : i64) : i64
    %45 = llvm.mlir.constant(28672 : i64) : i64
    %46 = llvm.mlir.constant(106496 : i64) : i64
    %47 = llvm.mlir.constant(45056 : i64) : i64
    %48 = llvm.mlir.constant(126976 : i64) : i64
    %49 = llvm.mlir.constant(36864 : i64) : i64
    %50 = llvm.mlir.constant(65536 : i64) : i64
    %51 = llvm.mlir.constant(4096 : i64) : i64
    %52 = llvm.mlir.constant(69632 : i64) : i64
    %53 = llvm.mlir.constant(110592 : i64) : i64
    %54 = llvm.mlir.constant(8192 : i64) : i64
    %55 = llvm.mlir.constant(118784 : i64) : i64
    %56 = llvm.mlir.constant(16384 : i64) : i64
    %57 = llvm.mlir.constant(102400 : i64) : i64
    %58 = llvm.mlir.constant(0 : i64) : i64
    %59 = llvm.mlir.constant(61440 : i64) : i64
    %60 = llvm.inttoptr %58 : i64 to !llvm.ptr<5>
    %61 = llvm.insertvalue %60, %7[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %62 = llvm.insertvalue %60, %61[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %63 = llvm.insertvalue %11, %62[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %64 = llvm.insertvalue %10, %63[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %65 = llvm.insertvalue %27, %64[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %66 = llvm.insertvalue %9, %65[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %67 = llvm.insertvalue %9, %66[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %68 = llvm.insertvalue %29, %67[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %69 = llvm.insertvalue %29, %68[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %70 = llvm.insertvalue %9, %69[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %71 = llvm.insertvalue %27, %70[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %72 = llvm.inttoptr %59 : i64 to !llvm.ptr<5>
    %73 = llvm.insertvalue %72, %7[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %74 = llvm.insertvalue %72, %73[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %75 = llvm.insertvalue %11, %74[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %76 = llvm.insertvalue %10, %75[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %77 = llvm.insertvalue %27, %76[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %78 = llvm.insertvalue %9, %77[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %79 = llvm.insertvalue %9, %78[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %80 = llvm.insertvalue %29, %79[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %81 = llvm.insertvalue %29, %80[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %82 = llvm.insertvalue %9, %81[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %83 = llvm.insertvalue %27, %82[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %84 = llvm.inttoptr %58 : i64 to !llvm.ptr<2>
    %85 = llvm.insertvalue %84, %6[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %86 = llvm.insertvalue %84, %85[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %87 = llvm.insertvalue %11, %86[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %88 = llvm.insertvalue %9, %87[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %89 = llvm.insertvalue %27, %88[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %90 = llvm.insertvalue %9, %89[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %91 = llvm.insertvalue %9, %90[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %92 = llvm.insertvalue %29, %91[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %93 = llvm.insertvalue %29, %92[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %94 = llvm.insertvalue %9, %93[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %95 = llvm.insertvalue %27, %94[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %96 = llvm.inttoptr %57 : i64 to !llvm.ptr<2>
    %97 = llvm.insertvalue %96, %6[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %98 = llvm.insertvalue %96, %97[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %99 = llvm.insertvalue %11, %98[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %100 = llvm.insertvalue %9, %99[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %101 = llvm.insertvalue %27, %100[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %102 = llvm.insertvalue %9, %101[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %103 = llvm.insertvalue %9, %102[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %104 = llvm.insertvalue %29, %103[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %105 = llvm.insertvalue %29, %104[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %106 = llvm.insertvalue %9, %105[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %107 = llvm.insertvalue %27, %106[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %108 = llvm.inttoptr %56 : i64 to !llvm.ptr<2>
    %109 = llvm.insertvalue %108, %6[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %110 = llvm.insertvalue %108, %109[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %111 = llvm.insertvalue %11, %110[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %112 = llvm.insertvalue %9, %111[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %113 = llvm.insertvalue %27, %112[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %114 = llvm.insertvalue %9, %113[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %115 = llvm.insertvalue %9, %114[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %116 = llvm.insertvalue %29, %115[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %117 = llvm.insertvalue %29, %116[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %118 = llvm.insertvalue %9, %117[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %119 = llvm.insertvalue %27, %118[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %120 = llvm.inttoptr %55 : i64 to !llvm.ptr<2>
    %121 = llvm.insertvalue %120, %6[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %122 = llvm.insertvalue %120, %121[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %123 = llvm.insertvalue %11, %122[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %124 = llvm.insertvalue %9, %123[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %125 = llvm.insertvalue %27, %124[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %126 = llvm.insertvalue %9, %125[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %127 = llvm.insertvalue %9, %126[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %128 = llvm.insertvalue %29, %127[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %129 = llvm.insertvalue %29, %128[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %130 = llvm.insertvalue %9, %129[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %131 = llvm.insertvalue %27, %130[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %132 = llvm.inttoptr %54 : i64 to !llvm.ptr<2>
    %133 = llvm.insertvalue %132, %6[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %134 = llvm.insertvalue %132, %133[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %135 = llvm.insertvalue %11, %134[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %136 = llvm.insertvalue %9, %135[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %137 = llvm.insertvalue %27, %136[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %138 = llvm.insertvalue %9, %137[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %139 = llvm.insertvalue %9, %138[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %140 = llvm.insertvalue %29, %139[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %141 = llvm.insertvalue %29, %140[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %142 = llvm.insertvalue %9, %141[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %143 = llvm.insertvalue %27, %142[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %144 = llvm.inttoptr %53 : i64 to !llvm.ptr<2>
    %145 = llvm.insertvalue %144, %6[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %146 = llvm.insertvalue %144, %145[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %147 = llvm.insertvalue %11, %146[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %148 = llvm.insertvalue %9, %147[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %149 = llvm.insertvalue %27, %148[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %150 = llvm.insertvalue %9, %149[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %151 = llvm.insertvalue %9, %150[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %152 = llvm.insertvalue %29, %151[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %153 = llvm.insertvalue %29, %152[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %154 = llvm.insertvalue %9, %153[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %155 = llvm.insertvalue %27, %154[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %156 = llvm.inttoptr %54 : i64 to !llvm.ptr<5>
    %157 = llvm.insertvalue %156, %7[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %158 = llvm.insertvalue %156, %157[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %159 = llvm.insertvalue %11, %158[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %160 = llvm.insertvalue %10, %159[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %161 = llvm.insertvalue %27, %160[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %162 = llvm.insertvalue %9, %161[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %163 = llvm.insertvalue %9, %162[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %164 = llvm.insertvalue %29, %163[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %165 = llvm.insertvalue %29, %164[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %166 = llvm.insertvalue %9, %165[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %167 = llvm.insertvalue %27, %166[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %168 = llvm.inttoptr %52 : i64 to !llvm.ptr<5>
    %169 = llvm.insertvalue %168, %7[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %170 = llvm.insertvalue %168, %169[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %171 = llvm.insertvalue %11, %170[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %172 = llvm.insertvalue %10, %171[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %173 = llvm.insertvalue %27, %172[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %174 = llvm.insertvalue %9, %173[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %175 = llvm.insertvalue %9, %174[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %176 = llvm.insertvalue %29, %175[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %177 = llvm.insertvalue %29, %176[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %178 = llvm.insertvalue %9, %177[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %179 = llvm.insertvalue %27, %178[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %180 = llvm.inttoptr %51 : i64 to !llvm.ptr<5>
    %181 = llvm.insertvalue %180, %7[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %182 = llvm.insertvalue %180, %181[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %183 = llvm.insertvalue %11, %182[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %184 = llvm.insertvalue %10, %183[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %185 = llvm.insertvalue %27, %184[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %186 = llvm.insertvalue %9, %185[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %187 = llvm.insertvalue %9, %186[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %188 = llvm.insertvalue %29, %187[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %189 = llvm.insertvalue %29, %188[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %190 = llvm.insertvalue %9, %189[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %191 = llvm.insertvalue %27, %190[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %192 = llvm.inttoptr %50 : i64 to !llvm.ptr<5>
    %193 = llvm.insertvalue %192, %7[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %194 = llvm.insertvalue %192, %193[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %195 = llvm.insertvalue %11, %194[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %196 = llvm.insertvalue %10, %195[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %197 = llvm.insertvalue %27, %196[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %198 = llvm.insertvalue %9, %197[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %199 = llvm.insertvalue %9, %198[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %200 = llvm.insertvalue %29, %199[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %201 = llvm.insertvalue %29, %200[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %202 = llvm.insertvalue %9, %201[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %203 = llvm.insertvalue %27, %202[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %204 = llvm.inttoptr %49 : i64 to !llvm.ptr<2>
    %205 = llvm.insertvalue %204, %6[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %206 = llvm.insertvalue %204, %205[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %207 = llvm.insertvalue %11, %206[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %208 = llvm.insertvalue %9, %207[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %209 = llvm.insertvalue %10, %208[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %210 = llvm.insertvalue %9, %209[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %211 = llvm.insertvalue %9, %210[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %212 = llvm.insertvalue %8, %211[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %213 = llvm.insertvalue %29, %212[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %214 = llvm.insertvalue %9, %213[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %215 = llvm.insertvalue %27, %214[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %216 = llvm.inttoptr %48 : i64 to !llvm.ptr<2>
    %217 = llvm.insertvalue %216, %6[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %218 = llvm.insertvalue %216, %217[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %219 = llvm.insertvalue %11, %218[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %220 = llvm.insertvalue %9, %219[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %221 = llvm.insertvalue %10, %220[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %222 = llvm.insertvalue %9, %221[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %223 = llvm.insertvalue %9, %222[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %224 = llvm.insertvalue %8, %223[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %225 = llvm.insertvalue %29, %224[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %226 = llvm.insertvalue %9, %225[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %227 = llvm.insertvalue %27, %226[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %228 = llvm.inttoptr %47 : i64 to !llvm.ptr<5>
    %229 = llvm.insertvalue %228, %7[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %230 = llvm.insertvalue %228, %229[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %231 = llvm.insertvalue %11, %230[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %232 = llvm.insertvalue %9, %231[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %233 = llvm.insertvalue %27, %232[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %234 = llvm.insertvalue %9, %233[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %235 = llvm.insertvalue %9, %234[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %236 = llvm.insertvalue %29, %235[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %237 = llvm.insertvalue %29, %236[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %238 = llvm.insertvalue %9, %237[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %239 = llvm.insertvalue %27, %238[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %240 = llvm.inttoptr %46 : i64 to !llvm.ptr<5>
    %241 = llvm.insertvalue %240, %7[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %242 = llvm.insertvalue %240, %241[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %243 = llvm.insertvalue %11, %242[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %244 = llvm.insertvalue %9, %243[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %245 = llvm.insertvalue %27, %244[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %246 = llvm.insertvalue %9, %245[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %247 = llvm.insertvalue %9, %246[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %248 = llvm.insertvalue %29, %247[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %249 = llvm.insertvalue %29, %248[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %250 = llvm.insertvalue %9, %249[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %251 = llvm.insertvalue %27, %250[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %252 = llvm.inttoptr %45 : i64 to !llvm.ptr<5>
    %253 = llvm.insertvalue %252, %7[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %254 = llvm.insertvalue %252, %253[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %255 = llvm.insertvalue %11, %254[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %256 = llvm.insertvalue %9, %255[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %257 = llvm.insertvalue %27, %256[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %258 = llvm.insertvalue %9, %257[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %259 = llvm.insertvalue %9, %258[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %260 = llvm.insertvalue %29, %259[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %261 = llvm.insertvalue %29, %260[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %262 = llvm.insertvalue %9, %261[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %263 = llvm.insertvalue %27, %262[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %264 = llvm.inttoptr %44 : i64 to !llvm.ptr<5>
    %265 = llvm.insertvalue %264, %7[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %266 = llvm.insertvalue %264, %265[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %267 = llvm.insertvalue %11, %266[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %268 = llvm.insertvalue %9, %267[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %269 = llvm.insertvalue %27, %268[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %270 = llvm.insertvalue %9, %269[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %271 = llvm.insertvalue %9, %270[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %272 = llvm.insertvalue %29, %271[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %273 = llvm.insertvalue %29, %272[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %274 = llvm.insertvalue %9, %273[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %275 = llvm.insertvalue %27, %274[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %276 = llvm.inttoptr %43 : i64 to !llvm.ptr<5>
    %277 = llvm.insertvalue %276, %7[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %278 = llvm.insertvalue %276, %277[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %279 = llvm.insertvalue %11, %278[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %280 = llvm.insertvalue %9, %279[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %281 = llvm.insertvalue %27, %280[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %282 = llvm.insertvalue %9, %281[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %283 = llvm.insertvalue %9, %282[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %284 = llvm.insertvalue %29, %283[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %285 = llvm.insertvalue %29, %284[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %286 = llvm.insertvalue %9, %285[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %287 = llvm.insertvalue %27, %286[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %288 = llvm.inttoptr %42 : i64 to !llvm.ptr<5>
    %289 = llvm.insertvalue %288, %7[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %290 = llvm.insertvalue %288, %289[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %291 = llvm.insertvalue %11, %290[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %292 = llvm.insertvalue %9, %291[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %293 = llvm.insertvalue %27, %292[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %294 = llvm.insertvalue %9, %293[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %295 = llvm.insertvalue %9, %294[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %296 = llvm.insertvalue %29, %295[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %297 = llvm.insertvalue %29, %296[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %298 = llvm.insertvalue %9, %297[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %299 = llvm.insertvalue %27, %298[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %300 = llvm.inttoptr %52 : i64 to !llvm.ptr<2>
    %301 = llvm.insertvalue %300, %6[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %302 = llvm.insertvalue %300, %301[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %303 = llvm.insertvalue %11, %302[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %304 = llvm.insertvalue %9, %303[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %305 = llvm.insertvalue %10, %304[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %306 = llvm.insertvalue %9, %305[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %307 = llvm.insertvalue %9, %306[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %308 = llvm.insertvalue %8, %307[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %309 = llvm.insertvalue %29, %308[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %310 = llvm.insertvalue %9, %309[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %311 = llvm.insertvalue %27, %310[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %312 = llvm.inttoptr %41 : i64 to !llvm.ptr<2>
    %313 = llvm.insertvalue %312, %6[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %314 = llvm.insertvalue %312, %313[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %315 = llvm.insertvalue %11, %314[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %316 = llvm.insertvalue %9, %315[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %317 = llvm.insertvalue %10, %316[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %318 = llvm.insertvalue %9, %317[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %319 = llvm.insertvalue %9, %318[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %320 = llvm.insertvalue %8, %319[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %321 = llvm.insertvalue %29, %320[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %322 = llvm.insertvalue %9, %321[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %323 = llvm.insertvalue %27, %322[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %324 = llvm.alloca %27 x i64 : (i64) -> !llvm.ptr
    llvm.store %58, %324 : i64, !llvm.ptr
    %325 = llvm.alloca %27 x i64 : (i64) -> !llvm.ptr
    llvm.store %58, %325 : i64, !llvm.ptr
    %326 = llvm.alloca %27 x i64 : (i64) -> !llvm.ptr
    llvm.store %58, %326 : i64, !llvm.ptr
    %327 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %328 = "hivm.intr.hivm.SBITSET0"(%327, %4) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%328) : (i64) -> ()
    %329 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %330 = "hivm.intr.hivm.SBITSET1"(%329, %3) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%330) : (i64) -> ()
    %331 = "hivm.intr.hivm.GET.BLOCK.IDX"() : () -> i64
    %332 = llvm.trunc %331 : i64 to i32
    %333 = llvm.srem %332, %arg22  : i32
    %334 = llvm.mul %333, %arg11 : i32
    %335 = llvm.sdiv %334, %arg22  : i32
    %336 = llvm.add %333, %31 : i32
    %337 = llvm.mul %336, %arg11 : i32
    %338 = llvm.sdiv %337, %arg22  : i32
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    llvm.br ^bb1(%335 : i32)
  ^bb1(%339: i32):  // 2 preds: ^bb0, ^bb17
    %340 = llvm.icmp "slt" %339, %338 : i32
    llvm.cond_br %340, ^bb2, ^bb18
  ^bb2:  // pred: ^bb1
    %341 = llvm.load %324 : !llvm.ptr -> i64
    %342 = llvm.urem %341, %35  : i64
    %343 = llvm.icmp "eq" %342, %36 : i64
    %344 = llvm.select %343, %107, %95 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %345 = llvm.select %343, %131, %119 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %346 = llvm.select %343, %155, %143 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %347 = llvm.trunc %342 : i64 to i1
    %348 = llvm.xor %347, %33  : i1
    %349 = llvm.zext %348 : i1 to i64
    %350 = llvm.sext %339 : i32 to i64
    %351 = llvm.getelementptr %arg7[%350] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %352 = llvm.load %351 : !llvm.ptr<1> -> i32
    %353 = llvm.add %350, %27 : i64
    %354 = llvm.getelementptr %arg7[%353] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %355 = llvm.load %354 : !llvm.ptr<1> -> i32
    %356 = llvm.sub %355, %352 : i32
    %357 = llvm.icmp "sgt" %356, %24 : i32
    llvm.cond_br %357, ^bb3, ^bb17
  ^bb3:  // pred: ^bb2
    %358 = llvm.mul %352, %arg12 : i32
    %359 = llvm.sext %358 : i32 to i64
    %360 = llvm.sext %arg13 : i32 to i64
    "hivm.intr.hivm.WAIT.FLAG.REG"(%349) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    %361 = llvm.extractvalue %344[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %362 = llvm.extractvalue %344[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %363 = llvm.extractvalue %344[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %364 = llvm.extractvalue %344[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %365 = llvm.extractvalue %344[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %366 = llvm.extractvalue %344[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %367 = llvm.extractvalue %344[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %368 = llvm.extractvalue %344[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %369 = llvm.extractvalue %344[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %370 = llvm.extractvalue %344[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %371 = llvm.extractvalue %344[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @nd2nz_bfloat16_t(%arg3, %arg3, %359, %32, %29, %360, %27, %361, %362, %363, %364, %365, %366, %367, %368, %369, %370, %371) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    %372 = llvm.sext %arg12 : i32 to i64
    %373 = llvm.add %359, %372 : i64
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    %374 = llvm.extractvalue %346[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %375 = llvm.extractvalue %346[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %376 = llvm.extractvalue %346[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %377 = llvm.extractvalue %346[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %378 = llvm.extractvalue %346[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %379 = llvm.extractvalue %346[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %380 = llvm.extractvalue %346[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %381 = llvm.extractvalue %346[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %382 = llvm.extractvalue %346[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %383 = llvm.extractvalue %346[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %384 = llvm.extractvalue %346[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @nd2nz_bfloat16_t(%arg3, %arg3, %373, %32, %29, %360, %27, %374, %375, %376, %377, %378, %379, %380, %381, %382, %383, %384) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    %385 = llvm.mul %arg12, %23 : i32
    %386 = llvm.sext %385 : i32 to i64
    %387 = llvm.add %359, %386 : i64
    %388 = llvm.extractvalue %345[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %389 = llvm.extractvalue %345[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %390 = llvm.extractvalue %345[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %391 = llvm.extractvalue %345[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %392 = llvm.extractvalue %345[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %393 = llvm.extractvalue %345[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %394 = llvm.extractvalue %345[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %395 = llvm.extractvalue %345[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %396 = llvm.extractvalue %345[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %397 = llvm.extractvalue %345[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %398 = llvm.extractvalue %345[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @nd2nz_bfloat16_t(%arg3, %arg3, %387, %32, %29, %360, %27, %388, %389, %390, %391, %392, %393, %394, %395, %396, %397, %398) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    %399 = llvm.getelementptr %arg8[%350] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %400 = llvm.load %399 : !llvm.ptr<1> -> i32
    %401 = llvm.add %400, %26 : i32
    %402 = llvm.sdiv %401, %25  : i32
    %403 = llvm.sub %arg20, %31 : i32
    %404 = llvm.mul %339, %arg20 : i32
    %405 = llvm.sext %402 : i32 to i64
    %406 = llvm.sext %404 : i32 to i64
    %407 = llvm.sext %arg15 : i32 to i64
    %408 = llvm.sext %arg17 : i32 to i64
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 18 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 18 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 19 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 3 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 19 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 3 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 20 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 20 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 4 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 4 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 5 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    llvm.br ^bb4(%24 : i32)
  ^bb4(%409: i32):  // 2 preds: ^bb3, ^bb15
    %410 = llvm.icmp "slt" %409, %402 : i32
    llvm.cond_br %410, ^bb5, ^bb16
  ^bb5:  // pred: ^bb4
    %411 = llvm.inttoptr %22 : i64 to !llvm.ptr<6>
    %412 = llvm.inttoptr %21 : i64 to !llvm.ptr<6>
    %413 = llvm.inttoptr %20 : i64 to !llvm.ptr<6>
    %414 = llvm.inttoptr %19 : i64 to !llvm.ptr<2>
    %415 = llvm.inttoptr %45 : i64 to !llvm.ptr<2>
    %416 = llvm.inttoptr %18 : i64 to !llvm.ptr<2>
    %417 = llvm.inttoptr %17 : i64 to !llvm.ptr<6>
    %418 = llvm.inttoptr %16 : i64 to !llvm.ptr<6>
    %419 = llvm.inttoptr %15 : i64 to !llvm.ptr<6>
    %420 = llvm.sext %409 : i32 to i64
    %421 = llvm.mul %420, %0 : i64
    %422 = llvm.add %405, %421 : i64
    %423 = llvm.intr.umin(%422, %34)  : (i64, i64) -> i64
    llvm.br ^bb6(%11 : i64)
  ^bb6(%424: i64):  // 2 preds: ^bb5, ^bb9
    %425 = llvm.icmp "slt" %424, %423 : i64
    llvm.cond_br %425, ^bb7, ^bb10
  ^bb7:  // pred: ^bb6
    %426 = llvm.load %326 : !llvm.ptr -> i64
    %427 = llvm.urem %426, %35  : i64
    %428 = llvm.icmp "eq" %427, %36 : i64
    %429 = llvm.select %428, %83, %71 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %430 = llvm.select %428, %179, %167 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %431 = llvm.select %428, %203, %191 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %432 = llvm.select %428, %227, %215 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %433 = llvm.trunc %427 : i64 to i1
    %434 = llvm.select %433, %37, %38 : i1, i64
    %435 = llvm.select %433, %35, %39 : i1, i64
    %436 = llvm.xor %433, %33  : i1
    %437 = llvm.zext %436 : i1 to i64
    %438 = llvm.select %433, %39, %37 : i1, i64
    %439 = llvm.mul %424, %1 : i64
    %440 = llvm.mul %424, %1 : i64
    %441 = llvm.mul %424, %1 : i64
    %442 = llvm.add %424, %420 : i64
    %443 = llvm.trunc %442 : i64 to i32
    %444 = llvm.mul %443, %25 : i32
    %445 = llvm.add %444, %25 : i32
    %446 = llvm.intr.smin(%445, %400)  : (i32, i32) -> i32
    %447 = llvm.sub %446, %444 : i32
    %448 = llvm.sdiv %444, %25  : i32
    %449 = llvm.intr.smin(%448, %403)  : (i32, i32) -> i32
    %450 = llvm.sext %449 : i32 to i64
    %451 = llvm.add %406, %450 : i64
    %452 = llvm.getelementptr %arg9[%451] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %453 = llvm.load %452 : !llvm.ptr<1> -> i32
    %454 = llvm.mul %453, %arg14 : i32
    %455 = llvm.sext %454 : i32 to i64
    %456 = llvm.sext %447 : i32 to i64
    %457 = llvm.intr.smax(%456, %11)  : (i64, i64) -> i64
    %458 = llvm.intr.smin(%457, %28)  : (i64, i64) -> i64
    %459 = llvm.intr.smin(%458, %11)  : (i64, i64) -> i64
    %460 = llvm.mul %459, %0 : i64
    %461 = llvm.add %458, %460 : i64
    %462 = llvm.icmp "slt" %461, %28 : i64
    %463 = llvm.mul %459, %0 : i64
    %464 = llvm.add %458, %463 : i64
    %465 = llvm.icmp "sle" %464, %11 : i64
    %466 = llvm.sub %11, %464 : i64
    %467 = llvm.sub %464, %27 : i64
    %468 = llvm.select %465, %466, %467 : i1, i64
    %469 = llvm.sdiv %468, %9  : i64
    %470 = llvm.sub %11, %469 : i64
    %471 = llvm.add %469, %27 : i64
    %472 = llvm.select %465, %470, %471 : i1, i64
    %473 = llvm.extractvalue %432[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %474 = llvm.extractvalue %432[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %475 = llvm.mul %459, %9 : i64
    llvm.cond_br %462, ^bb8, ^bb9
  ^bb8:  // pred: ^bb7
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %476 = llvm.extractvalue %432[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %477 = llvm.extractvalue %432[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%30, %476, %477, %11, %5, %27) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb9
  ^bb9:  // 2 preds: ^bb7, ^bb8
    "hivm.intr.hivm.WAIT.FLAG.REG"(%438) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.call @nd2nz_bfloat16_t(%arg4, %arg4, %455, %461, %29, %407, %27, %473, %474, %475, %9, %472, %9, %9, %8, %29, %9, %27) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%437) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %478 = llvm.extractvalue %344[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %479 = llvm.extractvalue %344[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %480 = llvm.extractvalue %344[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %481 = llvm.extractvalue %344[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %482 = llvm.extractvalue %344[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %483 = llvm.extractvalue %344[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %484 = llvm.extractvalue %344[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %485 = llvm.extractvalue %344[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %486 = llvm.extractvalue %344[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %487 = llvm.extractvalue %344[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %488 = llvm.extractvalue %344[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %489 = llvm.extractvalue %432[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %490 = llvm.extractvalue %432[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %491 = llvm.extractvalue %432[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %492 = llvm.extractvalue %432[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %493 = llvm.extractvalue %432[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %494 = llvm.extractvalue %432[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %495 = llvm.extractvalue %432[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %496 = llvm.extractvalue %432[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %497 = llvm.extractvalue %432[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %498 = llvm.extractvalue %432[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %499 = llvm.extractvalue %432[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %500 = llvm.extractvalue %429[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %501 = llvm.extractvalue %429[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %502 = llvm.extractvalue %429[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %503 = llvm.extractvalue %429[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %504 = llvm.extractvalue %429[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %505 = llvm.extractvalue %429[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %506 = llvm.extractvalue %429[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %507 = llvm.extractvalue %429[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %508 = llvm.extractvalue %429[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %509 = llvm.extractvalue %429[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %510 = llvm.extractvalue %429[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float_tb(%478, %479, %480, %481, %482, %483, %484, %485, %486, %487, %488, %489, %490, %491, %492, %493, %494, %495, %496, %497, %498, %499, %33, %32, %29, %28, %500, %501, %502, %503, %504, %505, %506, %507, %508, %509, %510, %40, %58, %40, %40, %40, %40, %40, %12) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 23 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 7 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 10 : i64}> : () -> ()
    %511 = llvm.extractvalue %429[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %512 = llvm.extractvalue %429[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %513 = llvm.extractvalue %429[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %514 = llvm.extractvalue %429[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %515 = llvm.extractvalue %429[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %516 = llvm.extractvalue %429[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %517 = llvm.extractvalue %429[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %518 = llvm.extractvalue %429[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %519 = llvm.extractvalue %429[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %520 = llvm.extractvalue %429[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %521 = llvm.extractvalue %429[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%511, %512, %513, %514, %515, %516, %517, %518, %519, %520, %521, %417, %417, %441, %32, %28, %28, %27, %58, %14, %58, %13, %12) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%437) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 29 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 13 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%435) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %522 = llvm.extractvalue %346[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %523 = llvm.extractvalue %346[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %524 = llvm.extractvalue %346[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %525 = llvm.extractvalue %346[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %526 = llvm.extractvalue %346[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %527 = llvm.extractvalue %346[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %528 = llvm.extractvalue %346[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %529 = llvm.extractvalue %346[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %530 = llvm.extractvalue %346[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %531 = llvm.extractvalue %346[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %532 = llvm.extractvalue %346[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %533 = llvm.extractvalue %432[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %534 = llvm.extractvalue %432[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %535 = llvm.extractvalue %432[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %536 = llvm.extractvalue %432[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %537 = llvm.extractvalue %432[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %538 = llvm.extractvalue %432[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %539 = llvm.extractvalue %432[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %540 = llvm.extractvalue %432[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %541 = llvm.extractvalue %432[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %542 = llvm.extractvalue %432[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %543 = llvm.extractvalue %432[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %544 = llvm.extractvalue %431[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %545 = llvm.extractvalue %431[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %546 = llvm.extractvalue %431[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %547 = llvm.extractvalue %431[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %548 = llvm.extractvalue %431[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %549 = llvm.extractvalue %431[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %550 = llvm.extractvalue %431[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %551 = llvm.extractvalue %431[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %552 = llvm.extractvalue %431[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %553 = llvm.extractvalue %431[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %554 = llvm.extractvalue %431[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float_tb(%522, %523, %524, %525, %526, %527, %528, %529, %530, %531, %532, %533, %534, %535, %536, %537, %538, %539, %540, %541, %542, %543, %33, %32, %29, %28, %544, %545, %546, %547, %548, %549, %550, %551, %552, %553, %554, %40, %40, %40, %40, %40, %40, %40, %12) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 22 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 6 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %555 = llvm.extractvalue %431[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %556 = llvm.extractvalue %431[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %557 = llvm.extractvalue %431[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %558 = llvm.extractvalue %431[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %559 = llvm.extractvalue %431[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %560 = llvm.extractvalue %431[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %561 = llvm.extractvalue %431[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %562 = llvm.extractvalue %431[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %563 = llvm.extractvalue %431[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %564 = llvm.extractvalue %431[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %565 = llvm.extractvalue %431[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%555, %556, %557, %558, %559, %560, %561, %562, %563, %564, %565, %418, %418, %440, %32, %28, %28, %27, %58, %14, %58, %13, %12) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%435) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 28 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 12 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%434) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %566 = llvm.extractvalue %345[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %567 = llvm.extractvalue %345[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %568 = llvm.extractvalue %345[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %569 = llvm.extractvalue %345[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %570 = llvm.extractvalue %345[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %571 = llvm.extractvalue %345[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %572 = llvm.extractvalue %345[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %573 = llvm.extractvalue %345[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %574 = llvm.extractvalue %345[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %575 = llvm.extractvalue %345[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %576 = llvm.extractvalue %345[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %577 = llvm.extractvalue %432[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %578 = llvm.extractvalue %432[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %579 = llvm.extractvalue %432[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %580 = llvm.extractvalue %432[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %581 = llvm.extractvalue %432[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %582 = llvm.extractvalue %432[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %583 = llvm.extractvalue %432[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %584 = llvm.extractvalue %432[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %585 = llvm.extractvalue %432[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %586 = llvm.extractvalue %432[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %587 = llvm.extractvalue %432[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %588 = llvm.extractvalue %430[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %589 = llvm.extractvalue %430[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %590 = llvm.extractvalue %430[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %591 = llvm.extractvalue %430[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %592 = llvm.extractvalue %430[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %593 = llvm.extractvalue %430[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %594 = llvm.extractvalue %430[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %595 = llvm.extractvalue %430[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %596 = llvm.extractvalue %430[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %597 = llvm.extractvalue %430[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %598 = llvm.extractvalue %430[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float_tb(%566, %567, %568, %569, %570, %571, %572, %573, %574, %575, %576, %577, %578, %579, %580, %581, %582, %583, %584, %585, %586, %587, %33, %32, %29, %28, %588, %589, %590, %591, %592, %593, %594, %595, %596, %597, %598, %40, %40, %40, %438, %40, %40, %40, %12) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 21 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %599 = llvm.extractvalue %430[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %600 = llvm.extractvalue %430[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %601 = llvm.extractvalue %430[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %602 = llvm.extractvalue %430[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %603 = llvm.extractvalue %430[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %604 = llvm.extractvalue %430[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %605 = llvm.extractvalue %430[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %606 = llvm.extractvalue %430[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %607 = llvm.extractvalue %430[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %608 = llvm.extractvalue %430[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %609 = llvm.extractvalue %430[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%599, %600, %601, %602, %603, %604, %605, %606, %607, %608, %609, %419, %419, %439, %32, %28, %28, %27, %58, %14, %58, %13, %12) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%434) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 27 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 11 : i64}> : () -> ()
    %610 = llvm.add %426, %36 : i64
    llvm.store %610, %326 : i64, !llvm.ptr
    %611 = llvm.add %424, %27 overflow<nsw> : i64
    llvm.br ^bb6(%611 : i64)
  ^bb10:  // pred: ^bb6
    llvm.br ^bb11(%11 : i64)
  ^bb11(%612: i64):  // 2 preds: ^bb10, ^bb14
    %613 = llvm.icmp "slt" %612, %423 : i64
    llvm.cond_br %613, ^bb12, ^bb15
  ^bb12:  // pred: ^bb11
    %614 = llvm.load %325 : !llvm.ptr -> i64
    %615 = llvm.urem %614, %35  : i64
    %616 = llvm.icmp "eq" %615, %36 : i64
    %617 = llvm.select %616, %251, %239 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %618 = llvm.select %616, %275, %263 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %619 = llvm.select %616, %299, %287 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %620 = llvm.select %616, %323, %311 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %621 = llvm.trunc %615 : i64 to i1
    %622 = llvm.select %621, %37, %38 : i1, i64
    %623 = llvm.select %621, %35, %39 : i1, i64
    %624 = llvm.xor %621, %33  : i1
    %625 = llvm.zext %624 : i1 to i64
    %626 = llvm.select %621, %39, %37 : i1, i64
    %627 = llvm.mul %612, %2 : i64
    %628 = llvm.mul %612, %2 : i64
    %629 = llvm.mul %612, %2 : i64
    %630 = llvm.add %612, %420 : i64
    %631 = llvm.trunc %630 : i64 to i32
    %632 = llvm.mul %631, %25 : i32
    %633 = llvm.add %632, %25 : i32
    %634 = llvm.intr.smin(%633, %400)  : (i32, i32) -> i32
    %635 = llvm.sub %634, %632 : i32
    %636 = llvm.sdiv %632, %25  : i32
    %637 = llvm.intr.smin(%636, %403)  : (i32, i32) -> i32
    %638 = llvm.sext %637 : i32 to i64
    %639 = llvm.add %406, %638 : i64
    %640 = llvm.getelementptr %arg9[%639] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %641 = llvm.load %640 : !llvm.ptr<1> -> i32
    %642 = llvm.mul %641, %arg16 : i32
    %643 = llvm.sext %642 : i32 to i64
    %644 = llvm.sext %635 : i32 to i64
    %645 = llvm.intr.smax(%644, %11)  : (i64, i64) -> i64
    %646 = llvm.intr.smin(%645, %28)  : (i64, i64) -> i64
    %647 = llvm.intr.smin(%646, %11)  : (i64, i64) -> i64
    %648 = llvm.mul %647, %0 : i64
    %649 = llvm.add %646, %648 : i64
    %650 = llvm.icmp "slt" %649, %28 : i64
    %651 = llvm.mul %647, %0 : i64
    %652 = llvm.add %646, %651 : i64
    %653 = llvm.icmp "sle" %652, %11 : i64
    %654 = llvm.sub %11, %652 : i64
    %655 = llvm.sub %652, %27 : i64
    %656 = llvm.select %653, %654, %655 : i1, i64
    %657 = llvm.sdiv %656, %9  : i64
    %658 = llvm.sub %11, %657 : i64
    %659 = llvm.add %657, %27 : i64
    %660 = llvm.select %653, %658, %659 : i1, i64
    %661 = llvm.extractvalue %620[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %662 = llvm.extractvalue %620[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %663 = llvm.mul %647, %9 : i64
    llvm.cond_br %650, ^bb13, ^bb14
  ^bb13:  // pred: ^bb12
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %664 = llvm.extractvalue %620[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %665 = llvm.extractvalue %620[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%30, %664, %665, %11, %5, %27) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb14
  ^bb14:  // 2 preds: ^bb12, ^bb13
    "hivm.intr.hivm.WAIT.FLAG.REG"(%626) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.call @nd2nz_bfloat16_t(%arg5, %arg5, %643, %649, %29, %408, %27, %661, %662, %663, %9, %660, %9, %9, %8, %29, %9, %27) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    %666 = llvm.mul %612, %8 : i64
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 26 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 10 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%625) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %667 = llvm.extractvalue %620[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %668 = llvm.extractvalue %620[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %669 = llvm.extractvalue %620[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %670 = llvm.extractvalue %620[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %671 = llvm.extractvalue %620[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %672 = llvm.extractvalue %620[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %673 = llvm.extractvalue %620[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %674 = llvm.extractvalue %620[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %675 = llvm.extractvalue %620[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %676 = llvm.extractvalue %620[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %677 = llvm.extractvalue %620[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %678 = llvm.extractvalue %619[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %679 = llvm.extractvalue %619[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %680 = llvm.extractvalue %619[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %681 = llvm.extractvalue %619[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %682 = llvm.extractvalue %619[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %683 = llvm.extractvalue %619[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %684 = llvm.extractvalue %619[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %685 = llvm.extractvalue %619[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %686 = llvm.extractvalue %619[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %687 = llvm.extractvalue %619[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %688 = llvm.extractvalue %619[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float(%414, %414, %666, %10, %27, %9, %9, %29, %29, %9, %27, %667, %668, %669, %670, %671, %672, %673, %674, %675, %676, %677, %33, %32, %28, %29, %678, %679, %680, %681, %682, %683, %684, %685, %686, %687, %688, %40, %58, %40, %40, %40, %40, %40, %12) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 20 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 17 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 10 : i64}> : () -> ()
    %689 = llvm.extractvalue %619[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %690 = llvm.extractvalue %619[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %691 = llvm.extractvalue %619[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %692 = llvm.extractvalue %619[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %693 = llvm.extractvalue %619[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %694 = llvm.extractvalue %619[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %695 = llvm.extractvalue %619[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %696 = llvm.extractvalue %619[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %697 = llvm.extractvalue %619[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %698 = llvm.extractvalue %619[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %699 = llvm.extractvalue %619[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%689, %690, %691, %692, %693, %694, %695, %696, %697, %698, %699, %411, %411, %629, %32, %29, %29, %27, %58, %14, %58, %13, %12) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%625) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %700 = llvm.mul %612, %8 : i64
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 25 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 9 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%623) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %701 = llvm.extractvalue %620[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %702 = llvm.extractvalue %620[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %703 = llvm.extractvalue %620[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %704 = llvm.extractvalue %620[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %705 = llvm.extractvalue %620[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %706 = llvm.extractvalue %620[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %707 = llvm.extractvalue %620[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %708 = llvm.extractvalue %620[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %709 = llvm.extractvalue %620[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %710 = llvm.extractvalue %620[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %711 = llvm.extractvalue %620[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %712 = llvm.extractvalue %618[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %713 = llvm.extractvalue %618[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %714 = llvm.extractvalue %618[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %715 = llvm.extractvalue %618[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %716 = llvm.extractvalue %618[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %717 = llvm.extractvalue %618[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %718 = llvm.extractvalue %618[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %719 = llvm.extractvalue %618[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %720 = llvm.extractvalue %618[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %721 = llvm.extractvalue %618[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %722 = llvm.extractvalue %618[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float(%415, %415, %700, %10, %27, %9, %9, %29, %29, %9, %27, %701, %702, %703, %704, %705, %706, %707, %708, %709, %710, %711, %33, %32, %28, %29, %712, %713, %714, %715, %716, %717, %718, %719, %720, %721, %722, %40, %40, %40, %40, %40, %40, %40, %12) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 19 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %723 = llvm.extractvalue %618[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %724 = llvm.extractvalue %618[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %725 = llvm.extractvalue %618[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %726 = llvm.extractvalue %618[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %727 = llvm.extractvalue %618[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %728 = llvm.extractvalue %618[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %729 = llvm.extractvalue %618[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %730 = llvm.extractvalue %618[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %731 = llvm.extractvalue %618[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %732 = llvm.extractvalue %618[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %733 = llvm.extractvalue %618[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%723, %724, %725, %726, %727, %728, %729, %730, %731, %732, %733, %412, %412, %628, %32, %29, %29, %27, %58, %14, %58, %13, %12) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%623) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %734 = llvm.mul %612, %8 : i64
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 24 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 8 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%622) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %735 = llvm.extractvalue %620[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %736 = llvm.extractvalue %620[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %737 = llvm.extractvalue %620[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %738 = llvm.extractvalue %620[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %739 = llvm.extractvalue %620[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %740 = llvm.extractvalue %620[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %741 = llvm.extractvalue %620[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %742 = llvm.extractvalue %620[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %743 = llvm.extractvalue %620[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %744 = llvm.extractvalue %620[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %745 = llvm.extractvalue %620[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %746 = llvm.extractvalue %617[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %747 = llvm.extractvalue %617[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %748 = llvm.extractvalue %617[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %749 = llvm.extractvalue %617[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %750 = llvm.extractvalue %617[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %751 = llvm.extractvalue %617[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %752 = llvm.extractvalue %617[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %753 = llvm.extractvalue %617[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %754 = llvm.extractvalue %617[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %755 = llvm.extractvalue %617[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %756 = llvm.extractvalue %617[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float(%416, %416, %734, %10, %27, %9, %9, %29, %29, %9, %27, %735, %736, %737, %738, %739, %740, %741, %742, %743, %744, %745, %33, %32, %28, %29, %746, %747, %748, %749, %750, %751, %752, %753, %754, %755, %756, %40, %40, %40, %626, %40, %40, %40, %12) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 18 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %757 = llvm.extractvalue %617[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %758 = llvm.extractvalue %617[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %759 = llvm.extractvalue %617[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %760 = llvm.extractvalue %617[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %761 = llvm.extractvalue %617[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %762 = llvm.extractvalue %617[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %763 = llvm.extractvalue %617[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %764 = llvm.extractvalue %617[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %765 = llvm.extractvalue %617[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %766 = llvm.extractvalue %617[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %767 = llvm.extractvalue %617[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%757, %758, %759, %760, %761, %762, %763, %764, %765, %766, %767, %413, %413, %627, %32, %29, %29, %27, %58, %14, %58, %13, %12) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%622) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 16 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 0 : i64}> : () -> ()
    %768 = llvm.add %614, %36 : i64
    llvm.store %768, %325 : i64, !llvm.ptr
    %769 = llvm.add %612, %27 overflow<nsw> : i64
    llvm.br ^bb11(%769 : i64)
  ^bb15:  // pred: ^bb11
    %770 = llvm.add %409, %23 overflow<nsw> : i32
    llvm.br ^bb4(%770 : i32)
  ^bb16:  // pred: ^bb4
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 4 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 5 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 4 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%349) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 17 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 17 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 21 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 21 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 22 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 6 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 22 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 6 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 23 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 7 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 23 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 7 : i64}> : () -> ()
    llvm.br ^bb17
  ^bb17:  // 2 preds: ^bb2, ^bb16
    %771 = llvm.add %341, %36 : i64
    llvm.store %771, %324 : i64, !llvm.ptr
    %772 = llvm.add %339, %31 overflow<nsw> : i32
    llvm.br ^bb1(%772 : i32)
  ^bb18:  // pred: ^bb1
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %773 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %774 = "hivm.intr.hivm.SBITSET1"(%773, %4) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%774) : (i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 6 : i64}> : () -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_3(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: i64, %arg7: !llvm.ptr<6>, %arg8: i64) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(-1.000000e+00 : f16) : f16
    %4 = llvm.mlir.constant(0.000000e+00 : f16) : f16
    %5 = llvm.mlir.constant(9 : i32) : i32
    %6 = llvm.mlir.constant(8 : i32) : i32
    %7 = llvm.mlir.constant(8 : index) : i64
    %8 = llvm.mlir.constant(256 : index) : i64
    %9 = llvm.mlir.constant(1536 : index) : i64
    %10 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%5, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %11 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%4, %10, %0) : (f16, vector<256xi1>, i32) -> vector<128xf16>
    %12 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%5, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %13 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%3, %12, %0) : (f16, vector<256xi1>, i32) -> vector<128xf16>
    llvm.br ^bb1(%2 : i32)
  ^bb1(%14: i32):  // 2 preds: ^bb0, ^bb2
    %15 = llvm.icmp "slt" %14, %1 : i32
    llvm.cond_br %15, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %16 = llvm.sext %14 : i32 to i64
    %17 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%6, %2) {mask_bit_width = 16 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %18 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%arg0, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %19 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %20 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%18, %19) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %21 = llvm.extractvalue %20[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %22 = "hivm_regbaseintrins.intr.hivm.vsel"(%13, %11, %21) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    %23 = "hivm_regbaseintrins.intr.hivm.vcmp.ne.s.z"(%22, %11, %17) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<256xi1>
    %24 = llvm.mul %arg4, %9 : i64
    %25 = llvm.mul %16, %8 : i64
    %26 = llvm.add %24, %25 : i64
    %27 = llvm.udiv %26, %7  : i64
    %28 = llvm.getelementptr %arg3[%27] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %29 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %30 = "hivm_regbaseintrins.intr.hivm.pstu.b16"(%23, %28, %29) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %31 = llvm.extractvalue %30[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %32 = llvm.extractvalue %30[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%31, %32, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %33 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%arg1, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %34 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %35 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%33, %34) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %36 = llvm.extractvalue %35[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %37 = "hivm_regbaseintrins.intr.hivm.vsel"(%13, %11, %36) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    %38 = "hivm_regbaseintrins.intr.hivm.vcmp.ne.s.z"(%37, %11, %17) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<256xi1>
    %39 = llvm.mul %arg6, %9 : i64
    %40 = llvm.mul %16, %8 : i64
    %41 = llvm.add %39, %40 : i64
    %42 = llvm.udiv %41, %7  : i64
    %43 = llvm.getelementptr %arg5[%42] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %44 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %45 = "hivm_regbaseintrins.intr.hivm.pstu.b16"(%38, %43, %44) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %46 = llvm.extractvalue %45[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %47 = llvm.extractvalue %45[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%46, %47, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %48 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%arg2, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %49 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %50 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%48, %49) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %51 = llvm.extractvalue %50[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %52 = "hivm_regbaseintrins.intr.hivm.vsel"(%13, %11, %51) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    %53 = "hivm_regbaseintrins.intr.hivm.vcmp.ne.s.z"(%52, %11, %17) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<256xi1>
    %54 = llvm.mul %arg8, %9 : i64
    %55 = llvm.mul %16, %8 : i64
    %56 = llvm.add %54, %55 : i64
    %57 = llvm.udiv %56, %7  : i64
    %58 = llvm.getelementptr %arg7[%57] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %59 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %60 = "hivm_regbaseintrins.intr.hivm.pstu.b16"(%53, %58, %59) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %61 = llvm.extractvalue %60[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %62 = llvm.extractvalue %60[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%61, %62, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %63 = llvm.add %14, %0 overflow<nsw> : i32
    llvm.br ^bb1(%63 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_4(%arg0: !llvm.ptr<6>, %arg1: i64, %arg2: !llvm.ptr<6>, %arg3: f32, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(8 : i32) : i32
    %1 = llvm.mlir.constant(-1.000000e+06 : f32) : f32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(6 : i32) : i32
    %4 = llvm.mlir.constant(1 : i32) : i32
    %5 = llvm.mlir.constant(8 : index) : i64
    %6 = llvm.mlir.constant(2 : i32) : i32
    %7 = llvm.mlir.constant(256 : index) : i64
    %8 = llvm.mlir.constant(1536 : index) : i64
    %9 = llvm.mlir.constant(384 : index) : i64
    %10 = llvm.mlir.constant(64 : index) : i64
    %11 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %12 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%1, %11, %4) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    llvm.br ^bb1(%2 : i32)
  ^bb1(%13: i32):  // 2 preds: ^bb0, ^bb2
    %14 = llvm.icmp "slt" %13, %3 : i32
    llvm.cond_br %14, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %15 = llvm.sext %13 : i32 to i64
    %16 = llvm.mul %arg1, %8 : i64
    %17 = llvm.mul %15, %7 : i64
    %18 = llvm.add %16, %17 : i64
    %19 = llvm.udiv %18, %5  : i64
    %20 = llvm.getelementptr %arg0[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %21 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%20, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %23 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%21, %22) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %24 = llvm.extractvalue %23[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %25 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%24, %22) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %26 = llvm.extractvalue %25[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %27 = llvm.mul %arg1, %9 : i64
    %28 = llvm.mul %15, %10 : i64
    %29 = llvm.add %27, %28 : i64
    %30 = llvm.getelementptr %arg2[%29] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %31 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%30, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %32 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %33 = "hivm_regbaseintrins.intr.hivm.vmuls.s.x"(%31, %arg3, %32) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %34 = "hivm_regbaseintrins.intr.hivm.vsel"(%33, %12, %26) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %35 = llvm.mul %15, %10 : i64
    %36 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %37 = llvm.getelementptr %arg4[%35] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%34, %37, %2, %6, %2, %36) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %38 = llvm.add %13, %4 overflow<nsw> : i32
    llvm.br ^bb1(%38 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_5(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(8 : i32) : i32
    %4 = llvm.mlir.constant(4 : i32) : i32
    %5 = llvm.mlir.undef : !llvm.ptr<6>
    %6 = llvm.mlir.constant(64 : index) : i64
    %7 = llvm.mlir.constant(6 : index) : i64
    %8 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %8, %5 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%9: i32, %10: vector<32xi8>, %11: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %12 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %12, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %13 = llvm.sext %9 : i32 to i64
    %14 = llvm.mul %13, %6 : i64
    %15 = llvm.getelementptr %arg0[%14] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %16 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%15, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %17 = llvm.mul %arg2, %7 : i64
    %18 = llvm.add %17, %13 : i64
    %19 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %20 = "hivm_regbaseintrins.intr.hivm.vcmax.s.x"(%16, %19) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%20, %22, %4, %10) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %24 = llvm.extractvalue %23[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %25 = llvm.extractvalue %23[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %26 = llvm.add %9, %0 overflow<nsw> : i32
    llvm.br ^bb1(%26, %24, %25 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%10, %11, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_6(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = llvm.mlir.constant(6 : index) : i64
    %4 = llvm.mul %arg2, %3 : i64
    %5 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %6 = llvm.extractvalue %5[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %7 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %8 = llvm.getelementptr %arg1[%4] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %9 = "hivm_regbaseintrins.intr.hivm.vldas"(%8) : (!llvm.ptr<6>) -> vector<32xi8>
    %10 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%8, %9, %1) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %11 = llvm.extractvalue %10[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    %12 = "hivm_regbaseintrins.intr.hivm.vmax.s.x"(%7, %11, %6) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%12, %arg3, %1, %2, %1, %6) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_7(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = llvm.mlir.constant(24 : i32) : i32
    %4 = llvm.mlir.constant(6 : index) : i64
    %5 = llvm.mul %arg3, %4 : i64
    %6 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %7 = llvm.extractvalue %6[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %8 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %10 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%8, %9, %7, %1) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %11 = llvm.getelementptr %arg2[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %12 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %13 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%10, %11, %3, %12) : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %14 = llvm.extractvalue %13[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %15 = llvm.extractvalue %13[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%14, %15, %1, %1) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %16 = llvm.getelementptr %arg2[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %17 = "hivm_regbaseintrins.intr.hivm.vldas"(%16) : (!llvm.ptr<6>) -> vector<32xi8>
    %18 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%16, %17, %1) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %19 = llvm.extractvalue %18[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%19, %arg4, %1, %2, %1, %7) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_8(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %4 = llvm.mlir.constant(3 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(7 : i32) : i32
    %7 = llvm.mlir.constant(4 : i32) : i32
    %8 = llvm.mlir.constant(2 : i32) : i32
    %9 = llvm.mlir.undef : !llvm.ptr<6>
    %10 = llvm.mlir.constant(64 : index) : i64
    %11 = llvm.mlir.constant(6 : index) : i64
    %12 = llvm.mul %arg3, %11 : i64
    %13 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %13, %9 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%14: i32, %15: vector<32xi8>, %16: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %17 = llvm.icmp "slt" %14, %1 : i32
    llvm.cond_br %17, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %14 : i32 to i64
    %19 = llvm.mul %18, %10 : i64
    %20 = llvm.getelementptr %arg0[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %21 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%20, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %22 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%22, %2, %4, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%21, %23, %24, %2) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %27 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%25, %3, %26) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%25, %28, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %30 = llvm.mul %18, %10 : i64
    %31 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %32 = llvm.getelementptr %arg4[%30] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%29, %32, %2, %6, %2, %31) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %33 = llvm.mul %arg3, %11 : i64
    %34 = llvm.add %33, %18 : i64
    %35 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %36 = "hivm_regbaseintrins.intr.hivm.vcadd.s.x"(%27, %35) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %37 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %38 = llvm.getelementptr %arg2[%34] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %39 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%36, %38, %7, %15) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %40 = llvm.extractvalue %39[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %41 = llvm.extractvalue %39[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %42 = llvm.add %14, %0 overflow<nsw> : i32
    llvm.br ^bb1(%42, %40, %41 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%15, %16, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %43 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%1) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %44 = llvm.extractvalue %43[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %45 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg5, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %46 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg6, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %47 = llvm.getelementptr %arg2[%12] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %48 = "hivm_regbaseintrins.intr.hivm.vldas"(%47) : (!llvm.ptr<6>) -> vector<32xi8>
    %49 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%47, %48, %2) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %50 = llvm.extractvalue %49[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    %51 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%45, %46, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %52 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%51, %50, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%52, %arg7, %2, %8, %2, %44) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_11(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(8 : i32) : i32
    %4 = llvm.mlir.constant(4 : i32) : i32
    %5 = llvm.mlir.undef : !llvm.ptr<6>
    %6 = llvm.mlir.constant(64 : index) : i64
    %7 = llvm.mlir.constant(6 : index) : i64
    %8 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %8, %5 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%9: i32, %10: vector<32xi8>, %11: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %12 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %12, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %13 = llvm.sext %9 : i32 to i64
    %14 = llvm.mul %13, %6 : i64
    %15 = llvm.getelementptr %arg0[%14] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %16 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%15, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %17 = llvm.mul %arg2, %7 : i64
    %18 = llvm.add %17, %13 : i64
    %19 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %20 = "hivm_regbaseintrins.intr.hivm.vcmax.s.x"(%16, %19) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%20, %22, %4, %10) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %24 = llvm.extractvalue %23[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %25 = llvm.extractvalue %23[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %26 = llvm.add %9, %0 overflow<nsw> : i32
    llvm.br ^bb1(%26, %24, %25 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%10, %11, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_12(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = llvm.mlir.constant(6 : index) : i64
    %4 = llvm.mul %arg2, %3 : i64
    %5 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %6 = llvm.extractvalue %5[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %7 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %8 = llvm.getelementptr %arg1[%4] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %9 = "hivm_regbaseintrins.intr.hivm.vldas"(%8) : (!llvm.ptr<6>) -> vector<32xi8>
    %10 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%8, %9, %1) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %11 = llvm.extractvalue %10[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    %12 = "hivm_regbaseintrins.intr.hivm.vmax.s.x"(%7, %11, %6) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%12, %arg3, %1, %2, %1, %6) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_13(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = llvm.mlir.constant(24 : i32) : i32
    %4 = llvm.mlir.constant(6 : index) : i64
    %5 = llvm.mul %arg3, %4 : i64
    %6 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %7 = llvm.extractvalue %6[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %8 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %10 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%8, %9, %7, %1) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %11 = llvm.getelementptr %arg2[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %12 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %13 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%10, %11, %3, %12) : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %14 = llvm.extractvalue %13[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %15 = llvm.extractvalue %13[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%14, %15, %1, %1) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %16 = llvm.getelementptr %arg2[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %17 = "hivm_regbaseintrins.intr.hivm.vldas"(%16) : (!llvm.ptr<6>) -> vector<32xi8>
    %18 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%16, %17, %1) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %19 = llvm.extractvalue %18[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%19, %arg4, %1, %2, %1, %7) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_14(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %4 = llvm.mlir.constant(3 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(7 : i32) : i32
    %7 = llvm.mlir.constant(4 : i32) : i32
    %8 = llvm.mlir.constant(2 : i32) : i32
    %9 = llvm.mlir.undef : !llvm.ptr<6>
    %10 = llvm.mlir.constant(64 : index) : i64
    %11 = llvm.mlir.constant(6 : index) : i64
    %12 = llvm.mul %arg3, %11 : i64
    %13 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %13, %9 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%14: i32, %15: vector<32xi8>, %16: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %17 = llvm.icmp "slt" %14, %1 : i32
    llvm.cond_br %17, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %14 : i32 to i64
    %19 = llvm.mul %18, %10 : i64
    %20 = llvm.getelementptr %arg0[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %21 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%20, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %22 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%22, %2, %4, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%21, %23, %24, %2) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %27 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%25, %3, %26) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%25, %28, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %30 = llvm.mul %18, %10 : i64
    %31 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %32 = llvm.getelementptr %arg4[%30] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%29, %32, %2, %6, %2, %31) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %33 = llvm.mul %arg3, %11 : i64
    %34 = llvm.add %33, %18 : i64
    %35 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %36 = "hivm_regbaseintrins.intr.hivm.vcadd.s.x"(%27, %35) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %37 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %38 = llvm.getelementptr %arg2[%34] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %39 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%36, %38, %7, %15) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %40 = llvm.extractvalue %39[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %41 = llvm.extractvalue %39[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %42 = llvm.add %14, %0 overflow<nsw> : i32
    llvm.br ^bb1(%42, %40, %41 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%15, %16, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %43 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%1) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %44 = llvm.extractvalue %43[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %45 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg5, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %46 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg6, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %47 = llvm.getelementptr %arg2[%12] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %48 = "hivm_regbaseintrins.intr.hivm.vldas"(%47) : (!llvm.ptr<6>) -> vector<32xi8>
    %49 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%47, %48, %2) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %50 = llvm.extractvalue %49[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    %51 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%45, %46, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %52 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%51, %50, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%52, %arg7, %2, %8, %2, %44) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_17(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(8 : i32) : i32
    %4 = llvm.mlir.constant(4 : i32) : i32
    %5 = llvm.mlir.undef : !llvm.ptr<6>
    %6 = llvm.mlir.constant(64 : index) : i64
    %7 = llvm.mlir.constant(6 : index) : i64
    %8 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %8, %5 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%9: i32, %10: vector<32xi8>, %11: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %12 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %12, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %13 = llvm.sext %9 : i32 to i64
    %14 = llvm.mul %13, %6 : i64
    %15 = llvm.getelementptr %arg0[%14] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %16 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%15, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %17 = llvm.mul %arg2, %7 : i64
    %18 = llvm.add %17, %13 : i64
    %19 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %20 = "hivm_regbaseintrins.intr.hivm.vcmax.s.x"(%16, %19) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%20, %22, %4, %10) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %24 = llvm.extractvalue %23[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %25 = llvm.extractvalue %23[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %26 = llvm.add %9, %0 overflow<nsw> : i32
    llvm.br ^bb1(%26, %24, %25 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%10, %11, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_18(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = llvm.mlir.constant(6 : index) : i64
    %4 = llvm.mul %arg2, %3 : i64
    %5 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %6 = llvm.extractvalue %5[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %7 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %8 = llvm.getelementptr %arg1[%4] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %9 = "hivm_regbaseintrins.intr.hivm.vldas"(%8) : (!llvm.ptr<6>) -> vector<32xi8>
    %10 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%8, %9, %1) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %11 = llvm.extractvalue %10[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    %12 = "hivm_regbaseintrins.intr.hivm.vmax.s.x"(%7, %11, %6) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%12, %arg3, %1, %2, %1, %6) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_19(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = llvm.mlir.constant(24 : i32) : i32
    %4 = llvm.mlir.constant(6 : index) : i64
    %5 = llvm.mul %arg3, %4 : i64
    %6 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %7 = llvm.extractvalue %6[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %8 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %10 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%8, %9, %7, %1) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %11 = llvm.getelementptr %arg2[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %12 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %13 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%10, %11, %3, %12) : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %14 = llvm.extractvalue %13[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %15 = llvm.extractvalue %13[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%14, %15, %1, %1) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %16 = llvm.getelementptr %arg2[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %17 = "hivm_regbaseintrins.intr.hivm.vldas"(%16) : (!llvm.ptr<6>) -> vector<32xi8>
    %18 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%16, %17, %1) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %19 = llvm.extractvalue %18[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%19, %arg4, %1, %2, %1, %7) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_20(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %4 = llvm.mlir.constant(3 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(7 : i32) : i32
    %7 = llvm.mlir.constant(4 : i32) : i32
    %8 = llvm.mlir.constant(2 : i32) : i32
    %9 = llvm.mlir.undef : !llvm.ptr<6>
    %10 = llvm.mlir.constant(64 : index) : i64
    %11 = llvm.mlir.constant(6 : index) : i64
    %12 = llvm.mul %arg3, %11 : i64
    %13 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %13, %9 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%14: i32, %15: vector<32xi8>, %16: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %17 = llvm.icmp "slt" %14, %1 : i32
    llvm.cond_br %17, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %14 : i32 to i64
    %19 = llvm.mul %18, %10 : i64
    %20 = llvm.getelementptr %arg0[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %21 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%20, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %22 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%22, %2, %4, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%21, %23, %24, %2) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %27 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%25, %3, %26) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%25, %28, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %30 = llvm.mul %18, %10 : i64
    %31 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %32 = llvm.getelementptr %arg4[%30] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%29, %32, %2, %6, %2, %31) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %33 = llvm.mul %arg3, %11 : i64
    %34 = llvm.add %33, %18 : i64
    %35 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %36 = "hivm_regbaseintrins.intr.hivm.vcadd.s.x"(%27, %35) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %37 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %38 = llvm.getelementptr %arg2[%34] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %39 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%36, %38, %7, %15) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %40 = llvm.extractvalue %39[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %41 = llvm.extractvalue %39[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %42 = llvm.add %14, %0 overflow<nsw> : i32
    llvm.br ^bb1(%42, %40, %41 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%15, %16, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %43 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%1) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %44 = llvm.extractvalue %43[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %45 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg5, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %46 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg6, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %47 = llvm.getelementptr %arg2[%12] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %48 = "hivm_regbaseintrins.intr.hivm.vldas"(%47) : (!llvm.ptr<6>) -> vector<32xi8>
    %49 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%47, %48, %2) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %50 = llvm.extractvalue %49[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    %51 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%45, %46, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %52 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%51, %50, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%52, %arg7, %2, %8, %2, %44) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_21(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(16 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(8 : i32) : i32
    %4 = llvm.mlir.constant(1114112 : i32) : i32
    %5 = llvm.mlir.constant(64 : index) : i64
    %6 = llvm.mlir.constant(16 : index) : i64
    %7 = llvm.mlir.constant(272 : index) : i64
    %8 = llvm.mlir.constant(0 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%9: i32):  // 2 preds: ^bb0, ^bb2
    %10 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %10, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %11 = llvm.sext %9 : i32 to i64
    %12 = llvm.mul %11, %5 : i64
    %13 = llvm.getelementptr %arg0[%12] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %14 = llvm.mul %8, %5 : i64
    %15 = llvm.add %14, %8 : i64
    %16 = llvm.getelementptr %13[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %17 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%16, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %18 = llvm.mul %11, %6 : i64
    %19 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%3, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %20 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %21 = llvm.mul %8, %7 : i64
    %22 = llvm.add %21, %8 : i64
    %23 = llvm.getelementptr %20[%22] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vsstb.v128bf16"(%17, %23, %4, %2, %19) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, vector<256xi1>) -> ()
    %24 = llvm.add %9, %0 overflow<nsw> : i32
    llvm.br ^bb1(%24 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_22(%arg0: !llvm.ptr<6>, %arg1: i64, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>, %arg8: !llvm.ptr<6>, %arg9: !llvm.ptr<6>, %arg10: !llvm.ptr<6>, %arg11: !llvm.ptr<6>, %arg12: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(256 : i32) : i32
    %4 = llvm.mlir.constant(64 : i32) : i32
    %5 = llvm.mlir.constant(3 : i32) : i32
    %6 = llvm.mlir.constant(8 : i32) : i32
    %7 = llvm.mlir.constant(2 : i32) : i32
    %8 = llvm.mlir.constant(1536 : index) : i64
    %9 = llvm.mlir.constant(256 : index) : i64
    %10 = llvm.mlir.constant(6 : index) : i64
    %11 = llvm.mlir.constant(0 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%12: i32):  // 2 preds: ^bb0, ^bb5
    %13 = llvm.icmp "slt" %12, %1 : i32
    llvm.cond_br %13, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %14 = llvm.sext %12 : i32 to i64
    %15 = llvm.mul %arg1, %10 : i64
    %16 = llvm.add %15, %14 : i64
    %17 = llvm.mul %arg1, %10 : i64
    %18 = llvm.add %17, %14 : i64
    %19 = llvm.mul %arg1, %10 : i64
    %20 = llvm.add %19, %14 : i64
    llvm.br ^bb3(%2 : i32)
  ^bb3(%21: i32):  // 2 preds: ^bb2, ^bb4
    %22 = llvm.icmp "slt" %21, %3 : i32
    llvm.cond_br %22, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %23 = llvm.sext %21 : i32 to i64
    %24 = llvm.mul %arg1, %8 : i64
    %25 = llvm.mul %14, %9 : i64
    %26 = llvm.add %24, %25 : i64
    %27 = llvm.add %26, %23 : i64
    %28 = llvm.getelementptr %arg4[%27] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %29 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%28, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %30 = llvm.mul %14, %9 : i64
    %31 = llvm.add %30, %23 : i64
    %32 = llvm.getelementptr %arg5[%31] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %33 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%32, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %34 = llvm.getelementptr %arg0[%16] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %35 = llvm.mul %11, %10 : i64
    %36 = llvm.getelementptr %34[%35] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %37 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%36, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %38 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %39 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%33, %37, %38) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %40 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %41 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%29, %39, %40) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %42 = llvm.mul %14, %9 : i64
    %43 = llvm.add %42, %23 : i64
    %44 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %45 = llvm.getelementptr %arg10[%43] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%41, %45, %2, %7, %2, %44) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %46 = llvm.mul %arg1, %8 : i64
    %47 = llvm.mul %14, %9 : i64
    %48 = llvm.add %46, %47 : i64
    %49 = llvm.add %48, %23 : i64
    %50 = llvm.getelementptr %arg6[%49] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %51 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%50, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %52 = llvm.mul %14, %9 : i64
    %53 = llvm.add %52, %23 : i64
    %54 = llvm.getelementptr %arg7[%53] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %55 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%54, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %56 = llvm.getelementptr %arg2[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %57 = llvm.mul %11, %10 : i64
    %58 = llvm.getelementptr %56[%57] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %59 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%58, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %60 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %61 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%55, %59, %60) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %62 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %63 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%51, %61, %62) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %64 = llvm.mul %14, %9 : i64
    %65 = llvm.add %64, %23 : i64
    %66 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %67 = llvm.getelementptr %arg11[%65] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%63, %67, %2, %7, %2, %66) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %68 = llvm.mul %arg1, %8 : i64
    %69 = llvm.mul %14, %9 : i64
    %70 = llvm.add %68, %69 : i64
    %71 = llvm.add %70, %23 : i64
    %72 = llvm.getelementptr %arg8[%71] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %73 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%72, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %74 = llvm.mul %14, %9 : i64
    %75 = llvm.add %74, %23 : i64
    %76 = llvm.getelementptr %arg9[%75] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %77 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%76, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %78 = llvm.getelementptr %arg3[%20] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %79 = llvm.mul %11, %10 : i64
    %80 = llvm.getelementptr %78[%79] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %81 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%80, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %82 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %83 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%77, %81, %82) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %84 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %85 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%73, %83, %84) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %86 = llvm.mul %14, %9 : i64
    %87 = llvm.add %86, %23 : i64
    %88 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %89 = llvm.getelementptr %arg12[%87] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%85, %89, %2, %7, %2, %88) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %90 = llvm.add %21, %4 overflow<nsw> : i32
    llvm.br ^bb3(%90 : i32)
  ^bb5:  // pred: ^bb3
    %91 = llvm.add %12, %0 overflow<nsw> : i32
    llvm.br ^bb1(%91 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_23(%arg0: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(0 : i32) : i32
    %1 = llvm.mlir.constant(8 : i32) : i32
    %2 = llvm.mlir.constant(1 : i32) : i32
    %3 = llvm.mlir.constant(2 : i32) : i32
    %4 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %5 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%0, %4, %2) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %6 = "hivm_regbaseintrins.intr.hivm.vci"(%0, %0) : (i32, i32) -> vector<64xi32>
    %7 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %8 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%5, %6, %7) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    %9 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64s32"(%8, %arg0, %0, %3, %0, %9) : (vector<64xi32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func private @nd2nz_bfloat16_t(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<2>, %arg8: !llvm.ptr<2>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %15 = llvm.insertvalue %arg14, %14[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg15, %16[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg12, %17[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg13, %19[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %21, %22 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_nd2nz_bfloat16_t(%10, %22) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_nd2nz_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @set_l1_2d_bfloat16_t(%arg0: bf16, %arg1: !llvm.ptr<2>, %arg2: !llvm.ptr<2>, %arg3: i64, %arg4: i64, %arg5: i64) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg1, %1[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg4, %4[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg5, %5[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_set_l1_2d_bfloat16_t(%arg0, %7) : (bf16, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_set_l1_2d_bfloat16_t(bf16, !llvm.ptr) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @mma_tile_bfloat16_t_to_float_tb(%arg0: !llvm.ptr<2>, %arg1: !llvm.ptr<2>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<2>, %arg12: !llvm.ptr<2>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64, %arg21: i64, %arg22: i1, %arg23: i64, %arg24: i64, %arg25: i64, %arg26: !llvm.ptr<5>, %arg27: !llvm.ptr<5>, %arg28: i64, %arg29: i64, %arg30: i64, %arg31: i64, %arg32: i64, %arg33: i64, %arg34: i64, %arg35: i64, %arg36: i64, %arg37: i64, %arg38: i64, %arg39: i64, %arg40: i64, %arg41: i64, %arg42: i64, %arg43: i64, %arg44: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg18, %18[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.insertvalue %arg16, %21[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %24 = llvm.insertvalue %arg17, %23[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %25 = llvm.insertvalue %arg21, %24[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %26 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %25, %26 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %27 = llvm.insertvalue %arg26, %0[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %28 = llvm.insertvalue %arg27, %27[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %29 = llvm.insertvalue %arg28, %28[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %30 = llvm.insertvalue %arg29, %29[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %31 = llvm.insertvalue %arg33, %30[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %32 = llvm.insertvalue %arg30, %31[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %33 = llvm.insertvalue %arg34, %32[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %34 = llvm.insertvalue %arg31, %33[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %35 = llvm.insertvalue %arg35, %34[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %36 = llvm.insertvalue %arg32, %35[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %37 = llvm.insertvalue %arg36, %36[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %38 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %37, %38 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_mma_tile_bfloat16_t_to_float_tb(%14, %26, %arg22, %arg23, %arg24, %arg25, %38, %arg37, %arg38, %arg39, %arg40, %arg41, %arg42, %arg43, %arg44) : (!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_mma_tile_bfloat16_t_to_float_tb(!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%arg0: !llvm.ptr<5>, %arg1: !llvm.ptr<5>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<6>, %arg12: !llvm.ptr<6>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: f32, %arg20: i64, %arg21: i1, %arg22: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %21, %22 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%14, %22, %arg18, %arg19, %arg20, %arg21, %arg22) : (!llvm.ptr, !llvm.ptr, i64, f32, i64, i1, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(!llvm.ptr, !llvm.ptr, i64, f32, i64, i1, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @mma_tile_bfloat16_t_to_float(%arg0: !llvm.ptr<2>, %arg1: !llvm.ptr<2>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<2>, %arg12: !llvm.ptr<2>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64, %arg21: i64, %arg22: i1, %arg23: i64, %arg24: i64, %arg25: i64, %arg26: !llvm.ptr<5>, %arg27: !llvm.ptr<5>, %arg28: i64, %arg29: i64, %arg30: i64, %arg31: i64, %arg32: i64, %arg33: i64, %arg34: i64, %arg35: i64, %arg36: i64, %arg37: i64, %arg38: i64, %arg39: i64, %arg40: i64, %arg41: i64, %arg42: i64, %arg43: i64, %arg44: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg18, %18[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.insertvalue %arg16, %21[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %24 = llvm.insertvalue %arg17, %23[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %25 = llvm.insertvalue %arg21, %24[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %26 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %25, %26 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %27 = llvm.insertvalue %arg26, %0[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %28 = llvm.insertvalue %arg27, %27[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %29 = llvm.insertvalue %arg28, %28[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %30 = llvm.insertvalue %arg29, %29[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %31 = llvm.insertvalue %arg33, %30[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %32 = llvm.insertvalue %arg30, %31[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %33 = llvm.insertvalue %arg34, %32[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %34 = llvm.insertvalue %arg31, %33[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %35 = llvm.insertvalue %arg35, %34[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %36 = llvm.insertvalue %arg32, %35[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %37 = llvm.insertvalue %arg36, %36[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %38 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %37, %38 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_mma_tile_bfloat16_t_to_float(%14, %26, %arg22, %arg23, %arg24, %arg25, %38, %arg37, %arg38, %arg39, %arg40, %arg41, %arg42, %arg43, %arg44) : (!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_mma_tile_bfloat16_t_to_float(!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @load_gm_to_ubuf_1d_float(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i32, %arg11: f32, %arg12: i64, %arg13: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.insertvalue %arg4, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %8 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %7, %8 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %9 = llvm.insertvalue %arg5, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg6, %9[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg7, %10[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_load_gm_to_ubuf_1d_float(%8, %14, %arg10, %arg11, %arg12, %arg13) : (!llvm.ptr, !llvm.ptr, i32, f32, i64, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_load_gm_to_ubuf_1d_float(!llvm.ptr, !llvm.ptr, i32, f32, i64, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_ubuf_1d_float(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg0, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg1, %2[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg2, %3[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg3, %4[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %8 = llvm.insertvalue %arg5, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg7, %9[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg8, %10[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg9, %11[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %12, %13 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_ubuf_1d_float(%7, %13) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_ubuf_1d_float(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_ubuf_1d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg0, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg1, %2[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg2, %3[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg3, %4[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %8 = llvm.insertvalue %arg5, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg7, %9[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg8, %10[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg9, %11[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %12, %13 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_ubuf_1d_bfloat16_t(%7, %13) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_ubuf_1d_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_cbuf_2d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<2>, %arg8: !llvm.ptr<2>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg12, %14[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %17, %18 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_cbuf_2d_bfloat16_t(%10, %18) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_cbuf_2d_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @store_ubuf_to_gm_2d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<1>, %arg8: !llvm.ptr<1>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg12, %14[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %17, %18 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_store_ubuf_to_gm_2d_bfloat16_t(%10, %18, %arg14) : (!llvm.ptr, !llvm.ptr, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_store_ubuf_to_gm_2d_bfloat16_t(!llvm.ptr, !llvm.ptr, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func @paged_prefill_verify_grouped_kernel_mix_aiv(%arg0: i64, %arg1: !llvm.ptr<1>, %arg2: !llvm.ptr<1>, %arg3: !llvm.ptr<1>, %arg4: !llvm.ptr<1>, %arg5: !llvm.ptr<1>, %arg6: !llvm.ptr<1>, %arg7: !llvm.ptr<1>, %arg8: !llvm.ptr<1>, %arg9: !llvm.ptr<1>, %arg10: !llvm.ptr<1>, %arg11: i32, %arg12: i32, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32, %arg17: i32, %arg18: i32, %arg19: i32, %arg20: i32, %arg21: f32, %arg22: i32, %arg23: i32, %arg24: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix, hivm.vf_mode = #hivm.vf_mode<SIMD>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, mix_mode = "mix", parallel_mode = "simd"} {
    %0 = llvm.mlir.constant(272 : index) : i64
    %1 = llvm.mlir.constant(12 : index) : i64
    %2 = llvm.mlir.constant(-1 : index) : i64
    %3 = llvm.mlir.constant(384 : index) : i64
    %4 = llvm.mlir.constant(1024 : index) : i64
    %5 = llvm.mlir.constant(4 : index) : i64
    %6 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %7 = llvm.mlir.constant(1536 : index) : i64
    %8 = llvm.mlir.constant(256 : index) : i64
    %9 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %10 = llvm.mlir.constant(6 : index) : i64
    %11 = llvm.mlir.constant(48 : i64) : i64
    %12 = llvm.mlir.constant(60 : i64) : i64
    %13 = llvm.mlir.constant(0 : index) : i64
    %14 = llvm.mlir.constant(63 : i32) : i32
    %15 = llvm.mlir.constant(64 : i32) : i32
    %16 = llvm.mlir.constant(0 : i32) : i32
    %17 = llvm.mlir.constant(2 : i32) : i32
    %18 = llvm.mlir.constant(0 : i64) : i64
    %19 = llvm.mlir.constant(32 : i64) : i64
    %20 = llvm.mlir.constant(6176 : i64) : i64
    %21 = llvm.mlir.constant(6208 : i64) : i64
    %22 = llvm.mlir.constant(78752 : i64) : i64
    %23 = llvm.mlir.constant(60768 : i64) : i64
    %24 = llvm.mlir.constant(78656 : i64) : i64
    %25 = llvm.mlir.constant(84896 : i64) : i64
    %26 = llvm.mlir.constant(67584 : i64) : i64
    %27 = llvm.mlir.constant(78688 : i64) : i64
    %28 = llvm.mlir.constant(91040 : i64) : i64
    %29 = llvm.mlir.constant(74400 : i64) : i64
    %30 = llvm.mlir.constant(78720 : i64) : i64
    %31 = llvm.mlir.constant(6464 : i64) : i64
    %32 = llvm.mlir.constant(18752 : i64) : i64
    %33 = llvm.mlir.constant(31040 : i64) : i64
    %34 = llvm.mlir.constant(24576 : i64) : i64
    %35 = llvm.mlir.constant(28672 : i64) : i64
    %36 = llvm.mlir.constant(32768 : i64) : i64
    %37 = llvm.mlir.constant(43328 : i64) : i64
    %38 = llvm.mlir.constant(46400 : i64) : i64
    %39 = llvm.mlir.constant(49472 : i64) : i64
    %40 = llvm.mlir.constant(56704 : i64) : i64
    %41 = llvm.mlir.constant(52544 : i64) : i64
    %42 = llvm.mlir.constant(57088 : i64) : i64
    %43 = llvm.mlir.constant(52608 : i64) : i64
    %44 = llvm.mlir.constant(57536 : i64) : i64
    %45 = llvm.mlir.constant(57152 : i64) : i64
    %46 = llvm.mlir.constant(57920 : i64) : i64
    %47 = llvm.mlir.constant(57952 : i64) : i64
    %48 = llvm.mlir.constant(57984 : i64) : i64
    %49 = llvm.mlir.constant(58080 : i64) : i64
    %50 = llvm.mlir.constant(58016 : i64) : i64
    %51 = llvm.mlir.constant(58144 : i64) : i64
    %52 = llvm.mlir.constant(58208 : i64) : i64
    %53 = llvm.mlir.constant(59744 : i64) : i64
    %54 = llvm.mlir.constant(59808 : i64) : i64
    %55 = llvm.mlir.constant(59840 : i64) : i64
    %56 = llvm.mlir.constant(59904 : i64) : i64
    %57 = llvm.mlir.constant(60000 : i64) : i64
    %58 = llvm.mlir.constant(59936 : i64) : i64
    %59 = llvm.mlir.constant(60800 : i64) : i64
    %60 = llvm.mlir.constant(62848 : i64) : i64
    %61 = llvm.mlir.constant(65024 : i64) : i64
    %62 = llvm.mlir.constant(66560 : i64) : i64
    %63 = llvm.mlir.constant(66624 : i64) : i64
    %64 = llvm.mlir.constant(66656 : i64) : i64
    %65 = llvm.mlir.constant(66720 : i64) : i64
    %66 = llvm.mlir.constant(66816 : i64) : i64
    %67 = llvm.mlir.constant(66752 : i64) : i64
    %68 = llvm.mlir.constant(67616 : i64) : i64
    %69 = llvm.mlir.constant(69664 : i64) : i64
    %70 = llvm.mlir.constant(71840 : i64) : i64
    %71 = llvm.mlir.constant(73376 : i64) : i64
    %72 = llvm.mlir.constant(73440 : i64) : i64
    %73 = llvm.mlir.constant(73472 : i64) : i64
    %74 = llvm.mlir.constant(73536 : i64) : i64
    %75 = llvm.mlir.constant(73632 : i64) : i64
    %76 = llvm.mlir.constant(73568 : i64) : i64
    %77 = llvm.mlir.constant(74432 : i64) : i64
    %78 = llvm.mlir.constant(76480 : i64) : i64
    %79 = llvm.mlir.constant(97184 : i64) : i64
    %80 = llvm.mlir.constant(100256 : i64) : i64
    %81 = llvm.mlir.constant(103328 : i64) : i64
    %82 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %83 = llvm.mlir.constant(1 : index) : i64
    %84 = llvm.mlir.constant(1 : i32) : i32
    %85 = llvm.mlir.constant(2 : index) : i64
    %86 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %87 = "hivm.intr.hivm.SBITSET0"(%86, %12) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%87) : (i64) -> ()
    %88 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %89 = "hivm.intr.hivm.SBITSET1"(%88, %11) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%89) : (i64) -> ()
    %90 = "hivm.intr.hivm.GET.BLOCK.IDX"() : () -> i64
    %91 = llvm.trunc %90 : i64 to i32
    %92 = llvm.srem %91, %arg22  : i32
    %93 = llvm.inttoptr %18 : i64 to !llvm.ptr<6>
    %94 = llvm.inttoptr %19 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_merged_vf_0(%93, %94) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %95 = llvm.mul %92, %arg11 : i32
    %96 = llvm.sdiv %95, %arg22  : i32
    %97 = llvm.add %92, %84 : i32
    %98 = llvm.mul %97, %arg11 : i32
    %99 = llvm.sdiv %98, %arg22  : i32
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.br ^bb1(%96 : i32)
  ^bb1(%100: i32):  // 2 preds: ^bb0, ^bb24
    %101 = llvm.icmp "slt" %100, %99 : i32
    llvm.cond_br %101, ^bb2, ^bb25
  ^bb2:  // pred: ^bb1
    %102 = llvm.sext %100 : i32 to i64
    %103 = llvm.getelementptr %arg7[%102] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %104 = llvm.load %103 : !llvm.ptr<1> -> i32
    %105 = llvm.add %102, %83 : i64
    %106 = llvm.getelementptr %arg7[%105] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %107 = llvm.load %106 : !llvm.ptr<1> -> i32
    %108 = llvm.sub %107, %104 : i32
    %109 = llvm.icmp "sgt" %108, %16 : i32
    llvm.cond_br %109, ^bb3, ^bb24
  ^bb3:  // pred: ^bb2
    %110 = llvm.inttoptr %20 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @load_gm_to_ubuf_1d_float(%arg10, %arg10, %13, %10, %83, %110, %110, %13, %10, %83, %16, %82, %13, %16) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i32, f32, i64, i32) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    %111 = llvm.getelementptr %arg8[%102] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %112 = llvm.load %111 : !llvm.ptr<1> -> i32
    %113 = llvm.sub %112, %108 : i32
    %114 = llvm.add %112, %14 : i32
    %115 = llvm.sdiv %114, %15  : i32
    %116 = llvm.inttoptr %21 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_23(%116) {hivm.vector_function, no_inline} : (!llvm.ptr<6>) -> ()
    %117 = llvm.sitofp %112 : i32 to f32
    %118 = llvm.sitofp %113 : i32 to f32
    %119 = llvm.add %113, %84 : i32
    %120 = llvm.sitofp %119 : i32 to f32
    %121 = llvm.add %113, %17 : i32
    %122 = llvm.sitofp %121 : i32 to f32
    %123 = llvm.sext %115 : i32 to i64
    %124 = "hivm.intr.hivm.GET.SUBBLOCKID"() : () -> i64
    %125 = llvm.icmp "eq" %124, %13 : i64
    %126 = llvm.inttoptr %22 : i64 to !llvm.ptr<6>
    %127 = llvm.insertvalue %126, %6[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %128 = llvm.insertvalue %126, %127[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %129 = llvm.insertvalue %13, %128[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %130 = llvm.insertvalue %10, %129[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %131 = llvm.insertvalue %8, %130[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %132 = llvm.insertvalue %8, %131[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %133 = llvm.insertvalue %83, %132[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%94, %94, %13, %7, %83, %126, %126, %13, %7, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %134 = llvm.inttoptr %23 : i64 to !llvm.ptr<6>
    %135 = llvm.insertvalue %134, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %136 = llvm.insertvalue %134, %135[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %137 = llvm.insertvalue %13, %136[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %138 = llvm.insertvalue %10, %137[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %139 = llvm.insertvalue %83, %138[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%93, %93, %13, %10, %83, %134, %134, %13, %10, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %140 = llvm.inttoptr %24 : i64 to !llvm.ptr<6>
    %141 = llvm.insertvalue %140, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %142 = llvm.insertvalue %140, %141[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %143 = llvm.insertvalue %13, %142[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %144 = llvm.insertvalue %10, %143[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %145 = llvm.insertvalue %83, %144[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_float(%110, %110, %13, %10, %83, %140, %140, %13, %10, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %146 = llvm.inttoptr %25 : i64 to !llvm.ptr<6>
    %147 = llvm.insertvalue %146, %6[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %148 = llvm.insertvalue %146, %147[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %149 = llvm.insertvalue %13, %148[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %150 = llvm.insertvalue %10, %149[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %151 = llvm.insertvalue %8, %150[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %152 = llvm.insertvalue %8, %151[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %153 = llvm.insertvalue %83, %152[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%94, %94, %13, %7, %83, %146, %146, %13, %7, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %154 = llvm.inttoptr %26 : i64 to !llvm.ptr<6>
    %155 = llvm.insertvalue %154, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %156 = llvm.insertvalue %154, %155[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %157 = llvm.insertvalue %13, %156[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %158 = llvm.insertvalue %10, %157[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %159 = llvm.insertvalue %83, %158[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%93, %93, %13, %10, %83, %154, %154, %13, %10, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %160 = llvm.inttoptr %27 : i64 to !llvm.ptr<6>
    %161 = llvm.insertvalue %160, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %162 = llvm.insertvalue %160, %161[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %163 = llvm.insertvalue %13, %162[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %164 = llvm.insertvalue %10, %163[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %165 = llvm.insertvalue %83, %164[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%110, %110, %13, %10, %83, %160, %160, %13, %10, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %166 = llvm.inttoptr %28 : i64 to !llvm.ptr<6>
    %167 = llvm.insertvalue %166, %6[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %168 = llvm.insertvalue %166, %167[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %169 = llvm.insertvalue %13, %168[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %170 = llvm.insertvalue %10, %169[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %171 = llvm.insertvalue %8, %170[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %172 = llvm.insertvalue %8, %171[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %173 = llvm.insertvalue %83, %172[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%94, %94, %13, %7, %83, %166, %166, %13, %7, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %174 = llvm.inttoptr %29 : i64 to !llvm.ptr<6>
    %175 = llvm.insertvalue %174, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %176 = llvm.insertvalue %174, %175[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %177 = llvm.insertvalue %13, %176[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %178 = llvm.insertvalue %10, %177[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %179 = llvm.insertvalue %83, %178[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%93, %93, %13, %10, %83, %174, %174, %13, %10, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %180 = llvm.inttoptr %30 : i64 to !llvm.ptr<6>
    %181 = llvm.insertvalue %180, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %182 = llvm.insertvalue %180, %181[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %183 = llvm.insertvalue %13, %182[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %184 = llvm.insertvalue %10, %183[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %185 = llvm.insertvalue %83, %184[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%110, %110, %13, %10, %83, %180, %180, %13, %10, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 5 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 5 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 6 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 6 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 7 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 7 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.br ^bb4(%16, %133, %139, %145, %153, %159, %165, %173, %179, %185 : i32, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>)
  ^bb4(%186: i32, %187: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %188: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %189: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %190: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %191: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %192: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %193: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %194: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %195: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>):  // 2 preds: ^bb3, ^bb20
    %196 = llvm.icmp "slt" %186, %115 : i32
    llvm.cond_br %196, ^bb5, ^bb21
  ^bb5:  // pred: ^bb4
    %197 = llvm.inttoptr %31 : i64 to !llvm.ptr<6>
    %198 = llvm.inttoptr %32 : i64 to !llvm.ptr<6>
    %199 = llvm.inttoptr %33 : i64 to !llvm.ptr<6>
    %200 = llvm.inttoptr %34 : i64 to !llvm.ptr<2>
    %201 = llvm.inttoptr %35 : i64 to !llvm.ptr<2>
    %202 = llvm.inttoptr %36 : i64 to !llvm.ptr<2>
    %203 = llvm.inttoptr %37 : i64 to !llvm.ptr<6>
    %204 = llvm.inttoptr %38 : i64 to !llvm.ptr<6>
    %205 = llvm.inttoptr %39 : i64 to !llvm.ptr<6>
    %206 = llvm.sext %186 : i32 to i64
    %207 = llvm.mul %206, %2 : i64
    %208 = llvm.add %123, %207 : i64
    %209 = llvm.intr.umin(%208, %85)  : (i64, i64) -> i64
    %210 = llvm.inttoptr %40 : i64 to !llvm.ptr<6>
    %211 = llvm.inttoptr %41 : i64 to !llvm.ptr<6>
    %212 = llvm.inttoptr %42 : i64 to !llvm.ptr<6>
    %213 = llvm.inttoptr %43 : i64 to !llvm.ptr<6>
    %214 = llvm.inttoptr %44 : i64 to !llvm.ptr<6>
    %215 = llvm.inttoptr %45 : i64 to !llvm.ptr<6>
    llvm.br ^bb6(%13 : i64)
  ^bb6(%216: i64):  // 2 preds: ^bb5, ^bb7
    %217 = llvm.icmp "slt" %216, %209 : i64
    llvm.cond_br %217, ^bb7, ^bb8
  ^bb7:  // pred: ^bb6
    %218 = llvm.add %216, %206 : i64
    %219 = llvm.trunc %218 : i64 to i32
    %220 = llvm.mul %219, %15 : i32
    %221 = llvm.inttoptr %46 : i64 to !llvm.ptr<6>
    %222 = llvm.inttoptr %47 : i64 to !llvm.ptr<6>
    %223 = llvm.inttoptr %48 : i64 to !llvm.ptr<6>
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_merged_merged_vf_0(%211, %216, %212, %216, %213, %216, %116, %220, %117, %118, %120, %122, %221, %222, %223) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, i64, !llvm.ptr<6>, i64, !llvm.ptr<6>, i64, !llvm.ptr<6>, i32, f32, f32, f32, f32, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_3(%221, %222, %223, %210, %216, %214, %216, %215, %216) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>, i64, !llvm.ptr<6>, i64) -> ()
    %224 = llvm.add %216, %83 overflow<nsw> : i64
    llvm.br ^bb6(%224 : i64)
  ^bb8:  // pred: ^bb6
    %225 = llvm.inttoptr %49 : i64 to !llvm.ptr<6>
    %226 = llvm.inttoptr %50 : i64 to !llvm.ptr<6>
    %227 = llvm.inttoptr %51 : i64 to !llvm.ptr<6>
    llvm.br ^bb9(%13, %189, %188, %192, %191, %195, %194 : i64, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>)
  ^bb9(%228: i64, %229: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %230: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %231: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %232: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %233: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %234: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>):  // 2 preds: ^bb8, ^bb16
    %235 = llvm.icmp "slt" %228, %209 : i64
    llvm.cond_br %235, ^bb10, ^bb17
  ^bb10:  // pred: ^bb9
    %236 = llvm.inttoptr %52 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 13 : i64}> : () -> ()
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_4(%210, %228, %203, %arg21, %236) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, i64, !llvm.ptr<6>, f32, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 7 : i64}> : () -> ()
    %237 = llvm.inttoptr %53 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%211, %211, %13, %1, %83, %237, %237, %13, %1, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_5(%236, %237, %228) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i64) -> ()
    %238 = llvm.inttoptr %54 : i64 to !llvm.ptr<6>
    %239 = llvm.extractvalue %229[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_6(%239, %237, %228, %238) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>) -> ()
    %240 = llvm.inttoptr %55 : i64 to !llvm.ptr<6>
    %241 = llvm.inttoptr %56 : i64 to !llvm.ptr<6>
    %242 = llvm.extractvalue %229[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_7(%242, %238, %240, %228, %241) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>) -> ()
    %243 = llvm.mul %228, %10 : i64
    llvm.call @copy_ubuf_to_ubuf_1d_float(%241, %241, %13, %10, %83, %225, %225, %243, %10, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %244 = llvm.inttoptr %57 : i64 to !llvm.ptr<6>
    %245 = llvm.inttoptr %23 : i64 to !llvm.ptr<6>
    %246 = llvm.insertvalue %245, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %247 = llvm.insertvalue %245, %246[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %248 = llvm.insertvalue %13, %247[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %249 = llvm.insertvalue %10, %248[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %250 = llvm.insertvalue %83, %249[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %251 = llvm.inttoptr %58 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%212, %212, %13, %1, %83, %251, %251, %13, %1, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %252 = llvm.extractvalue %230[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_8(%236, %238, %251, %228, %244, %252, %241, %245) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %253 = llvm.inttoptr %59 : i64 to !llvm.ptr<6>
    %254 = llvm.mul %228, %4 : i64
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%213, %213, %254, %4, %83, %253, %253, %13, %4, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%244, %244, %13, %3, %83, %253, %253, %13, %3, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %255 = llvm.inttoptr %60 : i64 to !llvm.ptr<6>
    %256 = llvm.inttoptr %61 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 12 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_merged_vf_2(%253, %255, %214, %228, %204, %arg21, %256) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>, f32, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 6 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %125, ^bb11, ^bb12
  ^bb11:  // pred: ^bb10
    %257 = llvm.mul %228, %4 : i64
    llvm.call @copy_ubuf_to_cbuf_2d_bfloat16_t(%255, %255, %13, %5, %8, %0, %83, %200, %200, %257, %5, %8, %8, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64) -> ()
    llvm.br ^bb12
  ^bb12:  // 2 preds: ^bb10, ^bb11
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 10 : i64}> : () -> ()
    %258 = llvm.inttoptr %62 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%211, %211, %13, %1, %83, %258, %258, %13, %1, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_11(%256, %258, %228) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i64) -> ()
    %259 = llvm.inttoptr %63 : i64 to !llvm.ptr<6>
    %260 = llvm.extractvalue %231[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_12(%260, %258, %228, %259) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>) -> ()
    %261 = llvm.inttoptr %64 : i64 to !llvm.ptr<6>
    %262 = llvm.inttoptr %65 : i64 to !llvm.ptr<6>
    %263 = llvm.extractvalue %231[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_13(%263, %259, %261, %228, %262) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>) -> ()
    %264 = llvm.mul %228, %10 : i64
    llvm.call @copy_ubuf_to_ubuf_1d_float(%262, %262, %13, %10, %83, %226, %226, %264, %10, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %265 = llvm.inttoptr %66 : i64 to !llvm.ptr<6>
    %266 = llvm.inttoptr %26 : i64 to !llvm.ptr<6>
    %267 = llvm.insertvalue %266, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %268 = llvm.insertvalue %266, %267[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %269 = llvm.insertvalue %13, %268[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %270 = llvm.insertvalue %10, %269[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %271 = llvm.insertvalue %83, %270[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %272 = llvm.inttoptr %67 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%212, %212, %13, %1, %83, %272, %272, %13, %1, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %273 = llvm.extractvalue %232[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_14(%256, %259, %272, %228, %265, %273, %262, %266) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %274 = llvm.inttoptr %68 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%213, %213, %254, %4, %83, %274, %274, %13, %4, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%265, %265, %13, %3, %83, %274, %274, %13, %3, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %275 = llvm.inttoptr %69 : i64 to !llvm.ptr<6>
    %276 = llvm.inttoptr %70 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 11 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_merged_vf_3(%274, %275, %215, %228, %205, %arg21, %276) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>, f32, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %125, ^bb13, ^bb14
  ^bb13:  // pred: ^bb12
    %277 = llvm.mul %228, %4 : i64
    llvm.call @copy_ubuf_to_cbuf_2d_bfloat16_t(%275, %275, %13, %5, %8, %0, %83, %201, %201, %277, %5, %8, %8, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64) -> ()
    llvm.br ^bb14
  ^bb14:  // 2 preds: ^bb12, ^bb13
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 9 : i64}> : () -> ()
    %278 = llvm.inttoptr %71 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%211, %211, %13, %1, %83, %278, %278, %13, %1, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_17(%276, %278, %228) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i64) -> ()
    %279 = llvm.inttoptr %72 : i64 to !llvm.ptr<6>
    %280 = llvm.extractvalue %233[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_18(%280, %278, %228, %279) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>) -> ()
    %281 = llvm.inttoptr %73 : i64 to !llvm.ptr<6>
    %282 = llvm.inttoptr %74 : i64 to !llvm.ptr<6>
    %283 = llvm.extractvalue %233[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_19(%283, %279, %281, %228, %282) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>) -> ()
    %284 = llvm.mul %228, %10 : i64
    llvm.call @copy_ubuf_to_ubuf_1d_float(%282, %282, %13, %10, %83, %227, %227, %284, %10, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %285 = llvm.inttoptr %75 : i64 to !llvm.ptr<6>
    %286 = llvm.inttoptr %29 : i64 to !llvm.ptr<6>
    %287 = llvm.insertvalue %286, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %288 = llvm.insertvalue %286, %287[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %289 = llvm.insertvalue %13, %288[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %290 = llvm.insertvalue %10, %289[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %291 = llvm.insertvalue %83, %290[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %292 = llvm.inttoptr %76 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%212, %212, %13, %1, %83, %292, %292, %13, %1, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %293 = llvm.extractvalue %234[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_20(%276, %279, %292, %228, %285, %293, %282, %286) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %294 = llvm.inttoptr %77 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%213, %213, %254, %4, %83, %294, %294, %13, %4, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%285, %285, %13, %3, %83, %294, %294, %13, %3, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %295 = llvm.inttoptr %78 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_21(%294, %295) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %125, ^bb15, ^bb16
  ^bb15:  // pred: ^bb14
    %296 = llvm.mul %228, %4 : i64
    llvm.call @copy_ubuf_to_cbuf_2d_bfloat16_t(%295, %295, %13, %5, %8, %0, %83, %202, %202, %296, %5, %8, %8, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64) -> ()
    llvm.br ^bb16
  ^bb16:  // 2 preds: ^bb14, ^bb15
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 8 : i64}> : () -> ()
    %297 = llvm.inttoptr %24 : i64 to !llvm.ptr<6>
    %298 = llvm.insertvalue %297, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %299 = llvm.insertvalue %297, %298[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %300 = llvm.insertvalue %13, %299[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %301 = llvm.insertvalue %10, %300[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %302 = llvm.insertvalue %83, %301[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%238, %238, %13, %10, %83, %297, %297, %13, %10, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %303 = llvm.inttoptr %27 : i64 to !llvm.ptr<6>
    %304 = llvm.insertvalue %303, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %305 = llvm.insertvalue %303, %304[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %306 = llvm.insertvalue %13, %305[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %307 = llvm.insertvalue %10, %306[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %308 = llvm.insertvalue %83, %307[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%259, %259, %13, %10, %83, %303, %303, %13, %10, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %309 = llvm.inttoptr %30 : i64 to !llvm.ptr<6>
    %310 = llvm.insertvalue %309, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %311 = llvm.insertvalue %309, %310[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %312 = llvm.insertvalue %13, %311[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %313 = llvm.insertvalue %10, %312[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %314 = llvm.insertvalue %83, %313[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%279, %279, %13, %10, %83, %309, %309, %13, %10, %83) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %315 = llvm.add %228, %83 overflow<nsw> : i64
    llvm.br ^bb9(%315, %302, %250, %308, %271, %314, %291 : i64, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>)
  ^bb17:  // pred: ^bb9
    llvm.br ^bb18(%13, %187, %190, %193 : i64, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>)
  ^bb18(%316: i64, %317: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %318: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %319: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>):  // 2 preds: ^bb17, ^bb19
    %320 = llvm.icmp "slt" %316, %209 : i64
    llvm.cond_br %320, ^bb19, ^bb20
  ^bb19:  // pred: ^bb18
    %321 = llvm.inttoptr %22 : i64 to !llvm.ptr<6>
    %322 = llvm.insertvalue %321, %6[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %323 = llvm.insertvalue %321, %322[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %324 = llvm.insertvalue %13, %323[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %325 = llvm.insertvalue %10, %324[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %326 = llvm.insertvalue %8, %325[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %327 = llvm.insertvalue %8, %326[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %328 = llvm.insertvalue %83, %327[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %329 = llvm.inttoptr %25 : i64 to !llvm.ptr<6>
    %330 = llvm.insertvalue %329, %6[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %331 = llvm.insertvalue %329, %330[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %332 = llvm.insertvalue %13, %331[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %333 = llvm.insertvalue %10, %332[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %334 = llvm.insertvalue %8, %333[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %335 = llvm.insertvalue %8, %334[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %336 = llvm.insertvalue %83, %335[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %337 = llvm.inttoptr %28 : i64 to !llvm.ptr<6>
    %338 = llvm.insertvalue %337, %6[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %339 = llvm.insertvalue %337, %338[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %340 = llvm.insertvalue %13, %339[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %341 = llvm.insertvalue %10, %340[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %342 = llvm.insertvalue %8, %341[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %343 = llvm.insertvalue %8, %342[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %344 = llvm.insertvalue %83, %343[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 0 : i64}> : () -> ()
    %345 = llvm.extractvalue %317[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %346 = llvm.extractvalue %318[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %347 = llvm.extractvalue %319[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_vf_22(%225, %316, %226, %227, %197, %345, %198, %346, %199, %347, %321, %329, %337) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, i64, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 1 : i64}> : () -> ()
    %348 = llvm.add %316, %83 overflow<nsw> : i64
    llvm.br ^bb18(%348, %328, %336, %344 : i64, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>)
  ^bb20:  // pred: ^bb18
    %349 = llvm.add %186, %17 overflow<nsw> : i32
    llvm.br ^bb4(%349, %317, %230, %229, %318, %232, %231, %319, %234, %233 : i32, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>)
  ^bb21:  // pred: ^bb4
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 4 : i64}> : () -> ()
    %350 = llvm.mul %104, %arg18 : i32
    %351 = llvm.sext %350 : i32 to i64
    %352 = llvm.sext %arg19 : i32 to i64
    %353 = llvm.inttoptr %79 : i64 to !llvm.ptr<6>
    %354 = llvm.sext %arg18 : i32 to i64
    %355 = llvm.add %351, %354 : i64
    %356 = llvm.inttoptr %80 : i64 to !llvm.ptr<6>
    %357 = llvm.mul %arg18, %17 : i32
    %358 = llvm.sext %357 : i32 to i64
    %359 = llvm.add %351, %358 : i64
    %360 = llvm.inttoptr %81 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %361 = llvm.extractvalue %188[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %362 = llvm.extractvalue %187[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %363 = llvm.extractvalue %191[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %364 = llvm.extractvalue %190[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %365 = llvm.extractvalue %194[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %366 = llvm.extractvalue %193[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @paged_prefill_verify_grouped_kernel_mix_aiv_outlined_merged_merged_vf_1(%361, %362, %353, %363, %364, %356, %365, %366, %360) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %125, ^bb22, ^bb23
  ^bb22:  // pred: ^bb21
    llvm.call @store_ubuf_to_gm_2d_bfloat16_t(%353, %353, %13, %10, %8, %8, %83, %arg6, %arg6, %351, %10, %8, %352, %83, %16) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i32) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 5 : i64}> : () -> ()
    llvm.call @store_ubuf_to_gm_2d_bfloat16_t(%356, %356, %13, %10, %8, %8, %83, %arg6, %arg6, %355, %10, %8, %352, %83, %16) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i32) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 5 : i64}> : () -> ()
    llvm.call @store_ubuf_to_gm_2d_bfloat16_t(%360, %360, %13, %10, %8, %8, %83, %arg6, %arg6, %359, %10, %8, %352, %83, %16) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i32) -> ()
    llvm.br ^bb23
  ^bb23:  // 2 preds: ^bb21, ^bb22
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.br ^bb24
  ^bb24:  // 2 preds: ^bb2, ^bb23
    %367 = llvm.add %100, %84 overflow<nsw> : i32
    llvm.br ^bb1(%367 : i32)
  ^bb25:  // pred: ^bb1
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %368 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %369 = "hivm.intr.hivm.SBITSET1"(%368, %12) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%369) : (i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 6 : i64}> : () -> ()
    llvm.return
  }
}


bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
ld.lld: warning: -z separate-code and -z separate-loadable-segments will be ignored
