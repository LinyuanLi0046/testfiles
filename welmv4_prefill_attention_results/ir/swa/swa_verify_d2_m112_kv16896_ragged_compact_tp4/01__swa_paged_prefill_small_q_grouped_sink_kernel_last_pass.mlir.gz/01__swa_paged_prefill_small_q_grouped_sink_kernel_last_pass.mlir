// -----// IR Dump After AppendUsePrintDebugData (append-use-print-debug-data) //----- //
module attributes {dlti.target_system_spec = #dlti.target_system_spec<"NPU" : #hacc.target_device_spec<#dlti.dl_entry<"AI_CORE_COUNT", 28 : i32>, #dlti.dl_entry<"CUBE_CORE_COUNT", 28 : i32>, #dlti.dl_entry<"VECTOR_CORE_COUNT", 56 : i32>, #dlti.dl_entry<"UB_SIZE", 2031616 : i32>, #dlti.dl_entry<"L1_SIZE", 4194304 : i32>, #dlti.dl_entry<"L0A_SIZE", 524288 : i32>, #dlti.dl_entry<"L0B_SIZE", 524288 : i32>, #dlti.dl_entry<"L0C_SIZE", 2097152 : i32>, #dlti.dl_entry<"UB_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L1_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L0C_ALIGN_SIZE", 4096 : i32>, #dlti.dl_entry<"MINIMAL_D_CACHE_SIZE", 262144 : i32>, #dlti.dl_entry<"MAXIMUM_D_CACHE_SIZE", 983040 : i32>, #dlti.dl_entry<"ARCH", "dav-c310">>>, hacc.target = #hacc.target<"Ascend950PR_957b">, hivm.aic_bitcode = #hivm.aic_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.aic.c310.bc">, hivm.aiv_bitcode = #hivm.aiv_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.aiv.c310.bc">, hivm.host_bitcode = #hivm.host_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/host-a5.bc">, hivm.mix_aic_bitcode = #hivm.mix_aic_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.mix.aic.c310.bc">, hivm.mix_aiv_bitcode = #hivm.mix_aiv_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.mix.aiv.c310.bc">, hivm.module_core_type = #hivm.module_core_type<MIX>} {
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_merged_merged_vf_0(%arg0: !llvm.ptr<6>, %arg1: i64, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>, %arg5: i64, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>, %arg8: !llvm.ptr<6>, %arg9: i64, %arg10: !llvm.ptr<6>, %arg11: i64) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(1 : i32) : i32
    %2 = llvm.mlir.constant(16 : i32) : i32
    %3 = llvm.mlir.constant(0 : i32) : i32
    %4 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %5 = llvm.mlir.constant(0xFF800000 : f32) : f32
    %6 = llvm.mlir.constant(0.000000e+00 : bf16) : bf16
    %7 = llvm.mlir.constant(-1.000000e+00 : f16) : f16
    %8 = llvm.mlir.constant(0.000000e+00 : f16) : f16
    %9 = llvm.mlir.constant(9 : i32) : i32
    %10 = llvm.mlir.constant(8 : i32) : i32
    %11 = llvm.mlir.constant(24 : i32) : i32
    %12 = llvm.mlir.constant(8 : index) : i64
    %13 = llvm.mlir.constant(1024 : index) : i64
    %14 = llvm.mlir.constant(64 : index) : i64
    %15 = llvm.mlir.constant(256 : index) : i64
    %16 = llvm.mlir.constant(6 : index) : i64
    %17 = llvm.mlir.constant(1536 : index) : i64
    %18 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%9, %3) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %19 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%8, %18, %1) : (f16, vector<256xi1>, i32) -> vector<128xf16>
    %20 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%9, %3) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %21 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%7, %20, %1) : (f16, vector<256xi1>, i32) -> vector<128xf16>
    %22 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%9, %3) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %23 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%6, %22, %1) : (bf16, vector<256xi1>, i32) -> vector<128xbf16>
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%10, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%5, %24, %1) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%10, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %27 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%4, %26, %1) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %28 = llvm.mul %arg3, %16 : i64
    %29 = llvm.mul %arg1, %16 : i64
    %30 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %31 = llvm.getelementptr %arg0[%29] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %32 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %33 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%25, %31, %11, %32) : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %34 = llvm.extractvalue %33[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %35 = llvm.extractvalue %33[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%34, %35, %3, %3) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %36 = llvm.getelementptr %arg2[%28] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %37 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %38 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%27, %36, %11, %37) : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %39 = llvm.extractvalue %38[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %40 = llvm.extractvalue %38[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%39, %40, %3, %3) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.br ^bb1(%3 : i32)
  ^bb1(%41: i32):  // 2 preds: ^bb0, ^bb2
    %42 = llvm.icmp "slt" %41, %2 : i32
    llvm.cond_br %42, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %43 = llvm.sext %41 : i32 to i64
    %44 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%10, %3) {mask_bit_width = 16 : i32, mask_op_idx = 1 : i32} : (i32, i32) -> vector<256xi1>
    %45 = llvm.mul %arg5, %13 : i64
    %46 = llvm.mul %43, %14 : i64
    %47 = llvm.add %45, %46 : i64
    %48 = llvm.getelementptr %arg4[%47] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%23, %48, %3, %1, %3, %44) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %49 = llvm.add %41, %1 overflow<nsw> : i32
    llvm.br ^bb1(%49 : i32)
  ^bb3:  // pred: ^bb1
    llvm.br ^bb4(%3 : i32)
  ^bb4(%50: i32):  // 2 preds: ^bb3, ^bb5
    %51 = llvm.icmp "slt" %50, %0 : i32
    llvm.cond_br %51, ^bb5, ^bb6
  ^bb5:  // pred: ^bb4
    %52 = llvm.sext %50 : i32 to i64
    %53 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%10, %3) {mask_bit_width = 16 : i32, mask_op_idx = 2 : i32} : (i32, i32) -> vector<256xi1>
    %54 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%arg6, %3, %3, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %55 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%3, %3) : (i32, i32) -> vector<256xi1>
    %56 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%54, %55) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %57 = llvm.extractvalue %56[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %58 = "hivm_regbaseintrins.intr.hivm.vsel"(%21, %19, %57) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    %59 = "hivm_regbaseintrins.intr.hivm.vcmp.ne.s.z"(%58, %19, %53) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<256xi1>
    %60 = llvm.mul %arg9, %17 : i64
    %61 = llvm.mul %52, %15 : i64
    %62 = llvm.add %60, %61 : i64
    %63 = llvm.udiv %62, %12  : i64
    %64 = llvm.getelementptr %arg8[%63] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %65 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %66 = "hivm_regbaseintrins.intr.hivm.pstu.b16"(%59, %64, %65) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %67 = llvm.extractvalue %66[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %68 = llvm.extractvalue %66[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%67, %68, %3, %3) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %69 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%arg7, %3, %3, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %70 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%3, %3) : (i32, i32) -> vector<256xi1>
    %71 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%69, %70) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %72 = llvm.extractvalue %71[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %73 = "hivm_regbaseintrins.intr.hivm.vsel"(%21, %19, %72) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    %74 = "hivm_regbaseintrins.intr.hivm.vcmp.ne.s.z"(%73, %19, %53) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<256xi1>
    %75 = llvm.mul %arg11, %17 : i64
    %76 = llvm.mul %52, %15 : i64
    %77 = llvm.add %75, %76 : i64
    %78 = llvm.udiv %77, %12  : i64
    %79 = llvm.getelementptr %arg10[%78] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %80 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %81 = "hivm_regbaseintrins.intr.hivm.pstu.b16"(%74, %79, %80) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %82 = llvm.extractvalue %81[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %83 = llvm.extractvalue %81[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%82, %83, %3, %3) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %84 = llvm.add %50, %1 overflow<nsw> : i32
    llvm.br ^bb4(%84 : i32)
  ^bb6:  // pred: ^bb4
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_merged_vf_3(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(256 : i32) : i32
    %4 = llvm.mlir.constant(64 : i32) : i32
    %5 = llvm.mlir.constant(3 : i32) : i32
    %6 = llvm.mlir.constant(8 : i32) : i32
    %7 = llvm.mlir.constant(7 : i32) : i32
    %8 = llvm.mlir.constant(256 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%9: i32):  // 2 preds: ^bb0, ^bb5
    %10 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %10, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %11 = llvm.sext %9 : i32 to i64
    llvm.br ^bb3(%2 : i32)
  ^bb3(%12: i32):  // 2 preds: ^bb2, ^bb4
    %13 = llvm.icmp "slt" %12, %3 : i32
    llvm.cond_br %13, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %14 = llvm.sext %12 : i32 to i64
    %15 = llvm.mul %11, %8 : i64
    %16 = llvm.add %15, %14 : i64
    %17 = llvm.getelementptr %arg1[%16] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %18 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%17, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %19 = llvm.getelementptr %arg0[%11] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %20 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%19, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.vdiv.s.x"(%18, %20, %21) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %23 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %24 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%22, %23, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %25 = llvm.mul %11, %8 : i64
    %26 = llvm.add %25, %14 : i64
    %27 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %28 = llvm.getelementptr %arg2[%26] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%24, %28, %2, %7, %2, %27) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %29 = llvm.add %12, %4 overflow<nsw> : i32
    llvm.br ^bb3(%29 : i32)
  ^bb5:  // pred: ^bb3
    %30 = llvm.add %9, %0 overflow<nsw> : i32
    llvm.br ^bb1(%30 : i32)
  ^bb6:  // pred: ^bb1
    llvm.br ^bb7(%2 : i32)
  ^bb7(%31: i32):  // 2 preds: ^bb6, ^bb11
    %32 = llvm.icmp "slt" %31, %1 : i32
    llvm.cond_br %32, ^bb8, ^bb12
  ^bb8:  // pred: ^bb7
    %33 = llvm.sext %31 : i32 to i64
    llvm.br ^bb9(%2 : i32)
  ^bb9(%34: i32):  // 2 preds: ^bb8, ^bb10
    %35 = llvm.icmp "slt" %34, %3 : i32
    llvm.cond_br %35, ^bb10, ^bb11
  ^bb10:  // pred: ^bb9
    %36 = llvm.sext %34 : i32 to i64
    %37 = llvm.mul %33, %8 : i64
    %38 = llvm.add %37, %36 : i64
    %39 = llvm.getelementptr %arg4[%38] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %40 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%39, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %41 = llvm.getelementptr %arg3[%33] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %42 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%41, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %43 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %44 = "hivm_regbaseintrins.intr.hivm.vdiv.s.x"(%40, %42, %43) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %45 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %46 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%44, %45, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %47 = llvm.mul %33, %8 : i64
    %48 = llvm.add %47, %36 : i64
    %49 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %50 = llvm.getelementptr %arg5[%48] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%46, %50, %2, %7, %2, %49) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %51 = llvm.add %34, %4 overflow<nsw> : i32
    llvm.br ^bb9(%51 : i32)
  ^bb11:  // pred: ^bb9
    %52 = llvm.add %31, %0 overflow<nsw> : i32
    llvm.br ^bb7(%52 : i32)
  ^bb12:  // pred: ^bb7
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_merged_vf_2(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>, %arg5: f32, %arg6: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(8 : i32) : i32
    %1 = llvm.mlir.constant(-1.000000e+06 : f32) : f32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(16 : i32) : i32
    %4 = llvm.mlir.constant(1 : i32) : i32
    %5 = llvm.mlir.constant(6 : i32) : i32
    %6 = llvm.mlir.constant(1114112 : i32) : i32
    %7 = llvm.mlir.constant(8 : index) : i64
    %8 = llvm.mlir.constant(2 : i32) : i32
    %9 = llvm.mlir.constant(16 : index) : i64
    %10 = llvm.mlir.constant(272 : index) : i64
    %11 = llvm.mlir.constant(256 : index) : i64
    %12 = llvm.mlir.constant(1536 : index) : i64
    %13 = llvm.mlir.constant(384 : index) : i64
    %14 = llvm.mlir.constant(64 : index) : i64
    %15 = llvm.mlir.constant(0 : index) : i64
    %16 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %17 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%1, %16, %4) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    llvm.br ^bb1(%2 : i32)
  ^bb1(%18: i32):  // 2 preds: ^bb0, ^bb2
    %19 = llvm.icmp "slt" %18, %3 : i32
    llvm.cond_br %19, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %20 = llvm.sext %18 : i32 to i64
    %21 = llvm.mul %20, %14 : i64
    %22 = llvm.getelementptr %arg0[%21] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %23 = llvm.mul %15, %14 : i64
    %24 = llvm.add %23, %15 : i64
    %25 = llvm.getelementptr %22[%24] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %26 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%25, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %27 = llvm.mul %20, %9 : i64
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%0, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %29 = llvm.getelementptr %arg1[%27] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %30 = llvm.mul %15, %10 : i64
    %31 = llvm.add %30, %15 : i64
    %32 = llvm.getelementptr %29[%31] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vsstb.v128bf16"(%26, %32, %6, %2, %28) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, vector<256xi1>) -> ()
    %33 = llvm.add %18, %4 overflow<nsw> : i32
    llvm.br ^bb1(%33 : i32)
  ^bb3:  // pred: ^bb1
    llvm.br ^bb4(%2 : i32)
  ^bb4(%34: i32):  // 2 preds: ^bb3, ^bb5
    %35 = llvm.icmp "slt" %34, %5 : i32
    llvm.cond_br %35, ^bb5, ^bb6
  ^bb5:  // pred: ^bb4
    %36 = llvm.sext %34 : i32 to i64
    %37 = llvm.mul %arg3, %12 : i64
    %38 = llvm.mul %36, %11 : i64
    %39 = llvm.add %37, %38 : i64
    %40 = llvm.udiv %39, %7  : i64
    %41 = llvm.getelementptr %arg2[%40] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %42 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%41, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %43 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %44 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%42, %43) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %45 = llvm.extractvalue %44[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %46 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%45, %43) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %47 = llvm.extractvalue %46[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %48 = llvm.mul %arg3, %13 : i64
    %49 = llvm.mul %36, %14 : i64
    %50 = llvm.add %48, %49 : i64
    %51 = llvm.getelementptr %arg4[%50] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %52 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%51, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %53 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %54 = "hivm_regbaseintrins.intr.hivm.vmuls.s.x"(%52, %arg5, %53) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %55 = "hivm_regbaseintrins.intr.hivm.vsel"(%54, %17, %47) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %56 = llvm.mul %36, %14 : i64
    %57 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %58 = llvm.getelementptr %arg6[%56] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%55, %58, %2, %8, %2, %57) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %59 = llvm.add %34, %4 overflow<nsw> : i32
    llvm.br ^bb4(%59 : i32)
  ^bb6:  // pred: ^bb4
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_merged_vf_0(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(64 : i32) : i32
    %1 = llvm.mlir.constant(256 : i32) : i32
    %2 = llvm.mlir.constant(1 : i32) : i32
    %3 = llvm.mlir.constant(6 : i32) : i32
    %4 = llvm.mlir.constant(0 : i32) : i32
    %5 = llvm.mlir.constant(1.000000e+00 : f32) : f32
    %6 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %7 = llvm.mlir.constant(8 : i32) : i32
    %8 = llvm.mlir.constant(2 : i32) : i32
    %9 = llvm.mlir.constant(256 : index) : i64
    %10 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %11 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%6, %10, %2) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %12 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %13 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%5, %12, %2) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %14 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%3) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %15 = llvm.extractvalue %14[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%13, %arg0, %4, %8, %4, %15) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.br ^bb1(%4 : i32)
  ^bb1(%16: i32):  // 2 preds: ^bb0, ^bb5
    %17 = llvm.icmp "slt" %16, %3 : i32
    llvm.cond_br %17, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %16 : i32 to i64
    llvm.br ^bb3(%4 : i32)
  ^bb3(%19: i32):  // 2 preds: ^bb2, ^bb4
    %20 = llvm.icmp "slt" %19, %1 : i32
    llvm.cond_br %20, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %21 = llvm.sext %19 : i32 to i64
    %22 = llvm.mul %18, %9 : i64
    %23 = llvm.add %22, %21 : i64
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = llvm.getelementptr %arg1[%23] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%11, %25, %4, %8, %4, %24) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %26 = llvm.add %19, %0 overflow<nsw> : i32
    llvm.br ^bb3(%26 : i32)
  ^bb5:  // pred: ^bb3
    %27 = llvm.add %16, %2 overflow<nsw> : i32
    llvm.br ^bb1(%27 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aic(%arg0: i64, %arg1: !llvm.ptr<1>, %arg2: !llvm.ptr<1>, %arg3: !llvm.ptr<1>, %arg4: !llvm.ptr<1>, %arg5: !llvm.ptr<1>, %arg6: !llvm.ptr<1>, %arg7: !llvm.ptr<1>, %arg8: i32, %arg9: !llvm.ptr<1>, %arg10: !llvm.ptr<1>, %arg11: !llvm.ptr<1>, %arg12: f32, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32, %arg17: i32, %arg18: i32, %arg19: i32, %arg20: i32, %arg21: i32, %arg22: i32, %arg23: i32, %arg24: i32, %arg25: i32, %arg26: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, hivm.vf_mode = #hivm.vf_mode<SIMD>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, mix_mode = "mix", parallel_mode = "simd"} {
    %0 = llvm.mlir.constant(5 : index) : i64
    %1 = llvm.mlir.constant(16 : i64) : i64
    %2 = llvm.mlir.constant(9 : index) : i64
    %3 = llvm.mlir.constant(7 : index) : i64
    %4 = llvm.mlir.constant(-1 : index) : i64
    %5 = llvm.mlir.constant(384 : index) : i64
    %6 = llvm.mlir.constant(1536 : index) : i64
    %7 = llvm.mlir.constant(8 : index) : i64
    %8 = llvm.mlir.constant(3 : index) : i64
    %9 = llvm.mlir.constant(48 : i64) : i64
    %10 = llvm.mlir.constant(60 : i64) : i64
    %11 = llvm.mlir.constant(16384 : index) : i64
    %12 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %13 = llvm.mlir.constant(4096 : index) : i64
    %14 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %15 = llvm.mlir.constant(1024 : index) : i64
    %16 = llvm.mlir.constant(16 : index) : i64
    %17 = llvm.mlir.constant(4 : index) : i64
    %18 = llvm.mlir.constant(0 : index) : i64
    %19 = llvm.mlir.constant(0 : i8) : i8
    %20 = llvm.mlir.constant(false) : i1
    %21 = llvm.mlir.constant(1.000000e+00 : f32) : f32
    %22 = llvm.mlir.constant(34176 : i64) : i64
    %23 = llvm.mlir.constant(31104 : i64) : i64
    %24 = llvm.mlir.constant(20480 : i64) : i64
    %25 = llvm.mlir.constant(16384 : i64) : i64
    %26 = llvm.mlir.constant(18816 : i64) : i64
    %27 = llvm.mlir.constant(6528 : i64) : i64
    %28 = llvm.mlir.constant(0 : i32) : i32
    %29 = llvm.mlir.constant(64 : i32) : i32
    %30 = llvm.mlir.constant(63 : i32) : i32
    %31 = llvm.mlir.constant(511 : i32) : i32
    %32 = llvm.mlir.constant(1 : index) : i64
    %33 = llvm.mlir.constant(6 : index) : i64
    %34 = llvm.mlir.constant(256 : index) : i64
    %35 = llvm.mlir.constant(0.000000e+00 : bf16) : bf16
    %36 = llvm.mlir.constant(64 : index) : i64
    %37 = llvm.mlir.constant(1 : i32) : i32
    %38 = llvm.mlir.constant(true) : i1
    %39 = llvm.mlir.constant(2 : index) : i64
    %40 = llvm.mlir.constant(2 : i32) : i32
    %41 = llvm.mlir.constant(2 : i64) : i64
    %42 = llvm.mlir.constant(1 : i64) : i64
    %43 = llvm.mlir.constant(3 : i64) : i64
    %44 = llvm.mlir.constant(4 : i64) : i64
    %45 = llvm.mlir.constant(-1 : i64) : i64
    %46 = llvm.mlir.constant(139264 : i64) : i64
    %47 = llvm.mlir.constant(57344 : i64) : i64
    %48 = llvm.mlir.constant(49152 : i64) : i64
    %49 = llvm.mlir.constant(65536 : i64) : i64
    %50 = llvm.mlir.constant(106496 : i64) : i64
    %51 = llvm.mlir.constant(24576 : i64) : i64
    %52 = llvm.mlir.constant(45056 : i64) : i64
    %53 = llvm.mlir.constant(4096 : i64) : i64
    %54 = llvm.mlir.constant(98304 : i64) : i64
    %55 = llvm.mlir.constant(8192 : i64) : i64
    %56 = llvm.mlir.constant(90112 : i64) : i64
    %57 = llvm.mlir.constant(0 : i64) : i64
    %58 = llvm.mlir.constant(40960 : i64) : i64
    %59 = llvm.inttoptr %57 : i64 to !llvm.ptr<5>
    %60 = llvm.insertvalue %59, %14[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %61 = llvm.insertvalue %59, %60[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %62 = llvm.insertvalue %18, %61[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %63 = llvm.insertvalue %17, %62[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %64 = llvm.insertvalue %32, %63[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %65 = llvm.insertvalue %16, %64[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %66 = llvm.insertvalue %16, %65[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %67 = llvm.insertvalue %34, %66[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %68 = llvm.insertvalue %34, %67[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %69 = llvm.insertvalue %16, %68[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %70 = llvm.insertvalue %32, %69[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %71 = llvm.inttoptr %58 : i64 to !llvm.ptr<5>
    %72 = llvm.insertvalue %71, %14[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %73 = llvm.insertvalue %71, %72[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %74 = llvm.insertvalue %18, %73[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %75 = llvm.insertvalue %17, %74[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %76 = llvm.insertvalue %32, %75[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %77 = llvm.insertvalue %16, %76[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %78 = llvm.insertvalue %16, %77[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %79 = llvm.insertvalue %34, %78[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %80 = llvm.insertvalue %34, %79[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %81 = llvm.insertvalue %16, %80[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %82 = llvm.insertvalue %32, %81[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %83 = llvm.inttoptr %57 : i64 to !llvm.ptr<2>
    %84 = llvm.insertvalue %83, %12[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %85 = llvm.insertvalue %83, %84[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %86 = llvm.insertvalue %18, %85[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %87 = llvm.insertvalue %16, %86[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %88 = llvm.insertvalue %32, %87[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %89 = llvm.insertvalue %16, %88[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %90 = llvm.insertvalue %16, %89[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %91 = llvm.insertvalue %34, %90[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %92 = llvm.insertvalue %34, %91[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %93 = llvm.insertvalue %16, %92[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %94 = llvm.insertvalue %32, %93[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %95 = llvm.inttoptr %56 : i64 to !llvm.ptr<2>
    %96 = llvm.insertvalue %95, %12[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %97 = llvm.insertvalue %95, %96[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %98 = llvm.insertvalue %18, %97[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %99 = llvm.insertvalue %16, %98[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %100 = llvm.insertvalue %32, %99[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %101 = llvm.insertvalue %16, %100[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %102 = llvm.insertvalue %16, %101[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %103 = llvm.insertvalue %34, %102[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %104 = llvm.insertvalue %34, %103[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %105 = llvm.insertvalue %16, %104[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %106 = llvm.insertvalue %32, %105[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %107 = llvm.inttoptr %55 : i64 to !llvm.ptr<2>
    %108 = llvm.insertvalue %107, %12[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %109 = llvm.insertvalue %107, %108[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %110 = llvm.insertvalue %18, %109[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %111 = llvm.insertvalue %16, %110[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %112 = llvm.insertvalue %32, %111[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %113 = llvm.insertvalue %16, %112[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %114 = llvm.insertvalue %16, %113[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %115 = llvm.insertvalue %34, %114[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %116 = llvm.insertvalue %34, %115[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %117 = llvm.insertvalue %16, %116[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %118 = llvm.insertvalue %32, %117[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %119 = llvm.inttoptr %54 : i64 to !llvm.ptr<2>
    %120 = llvm.insertvalue %119, %12[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %121 = llvm.insertvalue %119, %120[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %122 = llvm.insertvalue %18, %121[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %123 = llvm.insertvalue %16, %122[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %124 = llvm.insertvalue %32, %123[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %125 = llvm.insertvalue %16, %124[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %126 = llvm.insertvalue %16, %125[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %127 = llvm.insertvalue %34, %126[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %128 = llvm.insertvalue %34, %127[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %129 = llvm.insertvalue %16, %128[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %130 = llvm.insertvalue %32, %129[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %131 = llvm.inttoptr %53 : i64 to !llvm.ptr<5>
    %132 = llvm.insertvalue %131, %14[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %133 = llvm.insertvalue %131, %132[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %134 = llvm.insertvalue %18, %133[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %135 = llvm.insertvalue %17, %134[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %136 = llvm.insertvalue %32, %135[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %137 = llvm.insertvalue %16, %136[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %138 = llvm.insertvalue %16, %137[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %139 = llvm.insertvalue %34, %138[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %140 = llvm.insertvalue %34, %139[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %141 = llvm.insertvalue %16, %140[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %142 = llvm.insertvalue %32, %141[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %143 = llvm.inttoptr %52 : i64 to !llvm.ptr<5>
    %144 = llvm.insertvalue %143, %14[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %145 = llvm.insertvalue %143, %144[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %146 = llvm.insertvalue %18, %145[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %147 = llvm.insertvalue %17, %146[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %148 = llvm.insertvalue %32, %147[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %149 = llvm.insertvalue %16, %148[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %150 = llvm.insertvalue %16, %149[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %151 = llvm.insertvalue %34, %150[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %152 = llvm.insertvalue %34, %151[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %153 = llvm.insertvalue %16, %152[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %154 = llvm.insertvalue %32, %153[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %155 = llvm.inttoptr %51 : i64 to !llvm.ptr<2>
    %156 = llvm.insertvalue %155, %12[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %157 = llvm.insertvalue %155, %156[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %158 = llvm.insertvalue %18, %157[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %159 = llvm.insertvalue %16, %158[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %160 = llvm.insertvalue %17, %159[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %161 = llvm.insertvalue %16, %160[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %162 = llvm.insertvalue %16, %161[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %163 = llvm.insertvalue %15, %162[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %164 = llvm.insertvalue %34, %163[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %165 = llvm.insertvalue %16, %164[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %166 = llvm.insertvalue %32, %165[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %167 = llvm.inttoptr %50 : i64 to !llvm.ptr<2>
    %168 = llvm.insertvalue %167, %12[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %169 = llvm.insertvalue %167, %168[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %170 = llvm.insertvalue %18, %169[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %171 = llvm.insertvalue %16, %170[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %172 = llvm.insertvalue %17, %171[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %173 = llvm.insertvalue %16, %172[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %174 = llvm.insertvalue %16, %173[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %175 = llvm.insertvalue %15, %174[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %176 = llvm.insertvalue %34, %175[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %177 = llvm.insertvalue %16, %176[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %178 = llvm.insertvalue %32, %177[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %179 = llvm.inttoptr %51 : i64 to !llvm.ptr<5>
    %180 = llvm.insertvalue %179, %14[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %181 = llvm.insertvalue %179, %180[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %182 = llvm.insertvalue %18, %181[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %183 = llvm.insertvalue %16, %182[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %184 = llvm.insertvalue %32, %183[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %185 = llvm.insertvalue %16, %184[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %186 = llvm.insertvalue %16, %185[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %187 = llvm.insertvalue %34, %186[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %188 = llvm.insertvalue %34, %187[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %189 = llvm.insertvalue %16, %188[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %190 = llvm.insertvalue %32, %189[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %191 = llvm.inttoptr %49 : i64 to !llvm.ptr<5>
    %192 = llvm.insertvalue %191, %14[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %193 = llvm.insertvalue %191, %192[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %194 = llvm.insertvalue %18, %193[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %195 = llvm.insertvalue %16, %194[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %196 = llvm.insertvalue %32, %195[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %197 = llvm.insertvalue %16, %196[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %198 = llvm.insertvalue %16, %197[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %199 = llvm.insertvalue %34, %198[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %200 = llvm.insertvalue %34, %199[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %201 = llvm.insertvalue %16, %200[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %202 = llvm.insertvalue %32, %201[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %203 = llvm.inttoptr %55 : i64 to !llvm.ptr<5>
    %204 = llvm.insertvalue %203, %14[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %205 = llvm.insertvalue %203, %204[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %206 = llvm.insertvalue %18, %205[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %207 = llvm.insertvalue %16, %206[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %208 = llvm.insertvalue %32, %207[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %209 = llvm.insertvalue %16, %208[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %210 = llvm.insertvalue %16, %209[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %211 = llvm.insertvalue %34, %210[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %212 = llvm.insertvalue %34, %211[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %213 = llvm.insertvalue %16, %212[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %214 = llvm.insertvalue %32, %213[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %215 = llvm.inttoptr %48 : i64 to !llvm.ptr<5>
    %216 = llvm.insertvalue %215, %14[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %217 = llvm.insertvalue %215, %216[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %218 = llvm.insertvalue %18, %217[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %219 = llvm.insertvalue %16, %218[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %220 = llvm.insertvalue %32, %219[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %221 = llvm.insertvalue %16, %220[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %222 = llvm.insertvalue %16, %221[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %223 = llvm.insertvalue %34, %222[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %224 = llvm.insertvalue %34, %223[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %225 = llvm.insertvalue %16, %224[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %226 = llvm.insertvalue %32, %225[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %227 = llvm.inttoptr %47 : i64 to !llvm.ptr<2>
    %228 = llvm.insertvalue %227, %12[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %229 = llvm.insertvalue %227, %228[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %230 = llvm.insertvalue %18, %229[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %231 = llvm.insertvalue %16, %230[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %232 = llvm.insertvalue %17, %231[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %233 = llvm.insertvalue %16, %232[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %234 = llvm.insertvalue %16, %233[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %235 = llvm.insertvalue %15, %234[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %236 = llvm.insertvalue %34, %235[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %237 = llvm.insertvalue %16, %236[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %238 = llvm.insertvalue %32, %237[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %239 = llvm.inttoptr %46 : i64 to !llvm.ptr<2>
    %240 = llvm.insertvalue %239, %12[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %241 = llvm.insertvalue %239, %240[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %242 = llvm.insertvalue %18, %241[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %243 = llvm.insertvalue %16, %242[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %244 = llvm.insertvalue %17, %243[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %245 = llvm.insertvalue %16, %244[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %246 = llvm.insertvalue %16, %245[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %247 = llvm.insertvalue %15, %246[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %248 = llvm.insertvalue %34, %247[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %249 = llvm.insertvalue %16, %248[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %250 = llvm.insertvalue %32, %249[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %251 = llvm.alloca %32 x i64 : (i64) -> !llvm.ptr
    llvm.store %57, %251 : i64, !llvm.ptr
    %252 = llvm.alloca %32 x i64 : (i64) -> !llvm.ptr
    llvm.store %57, %252 : i64, !llvm.ptr
    %253 = llvm.alloca %32 x i64 : (i64) -> !llvm.ptr
    llvm.store %57, %253 : i64, !llvm.ptr
    %254 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %255 = "hivm.intr.hivm.SBITSET0"(%254, %10) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%255) : (i64) -> ()
    %256 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %257 = "hivm.intr.hivm.SBITSET1"(%256, %9) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%257) : (i64) -> ()
    %258 = "hivm.intr.hivm.GET.BLOCK.IDX"() : () -> i64
    %259 = llvm.trunc %258 : i64 to i32
    %260 = llvm.srem %259, %arg24  : i32
    %261 = llvm.mul %260, %arg8 : i32
    %262 = llvm.sdiv %261, %arg24  : i32
    %263 = llvm.add %260, %37 : i32
    %264 = llvm.mul %263, %arg8 : i32
    %265 = llvm.sdiv %264, %arg24  : i32
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 19 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 3 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 20 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 21 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 5 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 22 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 6 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    llvm.br ^bb1(%262 : i32)
  ^bb1(%266: i32):  // 2 preds: ^bb0, ^bb19
    %267 = llvm.icmp "slt" %266, %265 : i32
    llvm.cond_br %267, ^bb2, ^bb20
  ^bb2:  // pred: ^bb1
    %268 = llvm.load %251 : !llvm.ptr -> i64
    %269 = llvm.urem %268, %41  : i64
    %270 = llvm.icmp "eq" %269, %42 : i64
    %271 = llvm.select %270, %106, %94 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %272 = llvm.select %270, %130, %118 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %273 = llvm.trunc %269 : i64 to i1
    %274 = llvm.xor %273, %38  : i1
    %275 = llvm.zext %274 : i1 to i64
    %276 = llvm.sext %266 : i32 to i64
    %277 = llvm.getelementptr %arg9[%276] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %278 = llvm.load %277 : !llvm.ptr<1> -> i32
    %279 = llvm.add %276, %32 : i64
    %280 = llvm.getelementptr %arg9[%279] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %281 = llvm.load %280 : !llvm.ptr<1> -> i32
    %282 = llvm.sub %281, %278 : i32
    %283 = llvm.icmp "sgt" %282, %28 : i32
    llvm.cond_br %283, ^bb3, ^bb19
  ^bb3:  // pred: ^bb2
    %284 = llvm.getelementptr %arg10[%276] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %285 = llvm.load %284 : !llvm.ptr<1> -> i32
    %286 = llvm.sub %285, %282 : i32
    %287 = llvm.mul %278, %arg15 : i32
    %288 = llvm.sext %287 : i32 to i64
    %289 = llvm.sext %arg16 : i32 to i64
    "hivm.intr.hivm.WAIT.FLAG.REG"(%275) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    %290 = llvm.extractvalue %271[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %291 = llvm.extractvalue %271[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %292 = llvm.extractvalue %271[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %293 = llvm.extractvalue %271[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %294 = llvm.extractvalue %271[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %295 = llvm.extractvalue %271[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %296 = llvm.extractvalue %271[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %297 = llvm.extractvalue %271[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %298 = llvm.extractvalue %271[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %299 = llvm.extractvalue %271[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %300 = llvm.extractvalue %271[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @nd2nz_bfloat16_t(%arg4, %arg4, %288, %33, %34, %289, %32, %290, %291, %292, %293, %294, %295, %296, %297, %298, %299, %300) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    %301 = llvm.icmp "sgt" %282, %37 : i32
    %302 = llvm.sext %arg15 : i32 to i64
    %303 = llvm.add %288, %302 : i64
    %304 = llvm.zext %301 : i1 to i64
    %305 = llvm.mul %304, %33 : i64
    %306 = llvm.mul %304, %34 : i64
    %307 = llvm.icmp "slt" %305, %33 : i64
    %308 = llvm.icmp "slt" %306, %34 : i64
    %309 = llvm.or %307, %308  : i1
    %310 = llvm.mul %304, %8 : i64
    %311 = llvm.icmp "sle" %310, %18 : i64
    %312 = llvm.sub %18, %310 : i64
    %313 = llvm.sub %310, %32 : i64
    %314 = llvm.select %311, %312, %313 : i1, i64
    %315 = llvm.sdiv %314, %7  : i64
    %316 = llvm.sub %18, %315 : i64
    %317 = llvm.add %315, %32 : i64
    %318 = llvm.select %311, %316, %317 : i1, i64
    %319 = llvm.mul %304, %16 : i64
    %320 = llvm.extractvalue %272[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %321 = llvm.extractvalue %272[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.cond_br %309, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %322 = llvm.extractvalue %272[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %323 = llvm.extractvalue %272[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%35, %322, %323, %18, %13, %32) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb5
  ^bb5:  // 2 preds: ^bb3, ^bb4
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.call @nd2nz_bfloat16_t(%arg4, %arg4, %303, %305, %306, %289, %32, %320, %321, %18, %319, %318, %16, %16, %34, %34, %16, %32) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    %324 = llvm.add %285, %30 : i32
    %325 = llvm.sdiv %324, %29  : i32
    %326 = llvm.intr.smin(%325, %28)  : (i32, i32) -> i32
    %327 = llvm.sub %286, %31 : i32
    %328 = llvm.intr.smax(%327, %28)  : (i32, i32) -> i32
    %329 = llvm.sdiv %328, %29  : i32
    %330 = llvm.intr.smax(%326, %329)  : (i32, i32) -> i32
    %331 = llvm.intr.smax(%326, %330)  : (i32, i32) -> i32
    %332 = llvm.sub %325, %331 : i32
    %333 = llvm.intr.smax(%332, %28)  : (i32, i32) -> i32
    %334 = llvm.add %326, %333 : i32
    %335 = llvm.intr.smin(%334, %325)  : (i32, i32) -> i32
    %336 = llvm.sitofp %326 : i32 to f32
    %337 = llvm.sub %arg23, %37 : i32
    %338 = llvm.mul %266, %arg23 : i32
    %339 = llvm.sext %335 : i32 to i64
    %340 = llvm.sext %338 : i32 to i64
    %341 = llvm.sext %arg19 : i32 to i64
    %342 = llvm.sext %arg22 : i32 to i64
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 4 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    llvm.br ^bb6(%28 : i32)
  ^bb6(%343: i32):  // 2 preds: ^bb5, ^bb17
    %344 = llvm.icmp "slt" %343, %335 : i32
    llvm.cond_br %344, ^bb7, ^bb18
  ^bb7:  // pred: ^bb6
    %345 = llvm.inttoptr %27 : i64 to !llvm.ptr<6>
    %346 = llvm.inttoptr %26 : i64 to !llvm.ptr<6>
    %347 = llvm.inttoptr %25 : i64 to !llvm.ptr<2>
    %348 = llvm.inttoptr %24 : i64 to !llvm.ptr<2>
    %349 = llvm.inttoptr %23 : i64 to !llvm.ptr<6>
    %350 = llvm.inttoptr %22 : i64 to !llvm.ptr<6>
    %351 = llvm.sext %343 : i32 to i64
    %352 = llvm.mul %351, %4 : i64
    %353 = llvm.add %339, %352 : i64
    %354 = llvm.intr.umin(%353, %39)  : (i64, i64) -> i64
    llvm.br ^bb8(%18 : i64)
  ^bb8(%355: i64):  // 2 preds: ^bb7, ^bb11
    %356 = llvm.icmp "slt" %355, %354 : i64
    llvm.cond_br %356, ^bb9, ^bb12
  ^bb9:  // pred: ^bb8
    %357 = llvm.load %253 : !llvm.ptr -> i64
    %358 = llvm.urem %357, %41  : i64
    %359 = llvm.icmp "eq" %358, %42 : i64
    %360 = llvm.select %359, %82, %70 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %361 = llvm.select %359, %154, %142 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %362 = llvm.select %359, %178, %166 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %363 = llvm.trunc %358 : i64 to i1
    %364 = llvm.select %363, %41, %43 : i1, i64
    %365 = llvm.xor %363, %38  : i1
    %366 = llvm.zext %365 : i1 to i64
    %367 = llvm.select %363, %43, %44 : i1, i64
    %368 = llvm.add %355, %3 : i64
    %369 = llvm.add %355, %2 : i64
    %370 = llvm.mul %355, %5 : i64
    %371 = llvm.mul %355, %5 : i64
    %372 = llvm.add %355, %351 : i64
    %373 = llvm.trunc %372 : i64 to i32
    %374 = llvm.sitofp %373 : i32 to f32
    %375 = llvm.fcmp "olt" %374, %336 : f32
    %376 = llvm.zext %375 : i1 to i32
    %377 = llvm.mul %376, %373 : i32
    %378 = llvm.sub %37, %376 : i32
    %379 = llvm.add %331, %373 : i32
    %380 = llvm.sub %379, %326 : i32
    %381 = llvm.mul %378, %380 : i32
    %382 = llvm.add %377, %381 : i32
    %383 = llvm.mul %382, %29 : i32
    %384 = llvm.add %383, %29 : i32
    %385 = llvm.intr.smin(%384, %285)  : (i32, i32) -> i32
    %386 = llvm.sub %385, %383 : i32
    %387 = llvm.intr.smax(%386, %28)  : (i32, i32) -> i32
    %388 = llvm.sdiv %383, %29  : i32
    %389 = llvm.intr.smin(%388, %337)  : (i32, i32) -> i32
    %390 = llvm.sext %389 : i32 to i64
    %391 = llvm.add %340, %390 : i64
    %392 = llvm.getelementptr %arg11[%391] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %393 = llvm.load %392 : !llvm.ptr<1> -> i32
    %394 = llvm.mul %393, %arg17 : i32
    %395 = llvm.sext %394 : i32 to i64
    %396 = llvm.sext %387 : i32 to i64
    %397 = llvm.intr.smax(%396, %18)  : (i64, i64) -> i64
    %398 = llvm.intr.smin(%397, %36)  : (i64, i64) -> i64
    %399 = llvm.intr.smin(%398, %18)  : (i64, i64) -> i64
    %400 = llvm.mul %399, %4 : i64
    %401 = llvm.add %398, %400 : i64
    %402 = llvm.icmp "slt" %401, %36 : i64
    %403 = llvm.mul %399, %4 : i64
    %404 = llvm.add %398, %403 : i64
    %405 = llvm.icmp "sle" %404, %18 : i64
    %406 = llvm.sub %18, %404 : i64
    %407 = llvm.sub %404, %32 : i64
    %408 = llvm.select %405, %406, %407 : i1, i64
    %409 = llvm.sdiv %408, %16  : i64
    %410 = llvm.sub %18, %409 : i64
    %411 = llvm.add %409, %32 : i64
    %412 = llvm.select %405, %410, %411 : i1, i64
    %413 = llvm.extractvalue %362[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %414 = llvm.extractvalue %362[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %415 = llvm.mul %399, %16 : i64
    llvm.cond_br %402, ^bb10, ^bb11
  ^bb10:  // pred: ^bb9
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %416 = llvm.extractvalue %362[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %417 = llvm.extractvalue %362[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%35, %416, %417, %18, %11, %32) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb11
  ^bb11:  // 2 preds: ^bb9, ^bb10
    "hivm.intr.hivm.WAIT.FLAG.REG"(%367) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.call @nd2nz_bfloat16_t(%arg5, %arg5, %395, %401, %34, %341, %32, %413, %414, %415, %16, %412, %16, %16, %15, %34, %16, %32) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%366) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %418 = llvm.extractvalue %271[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %419 = llvm.extractvalue %271[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %420 = llvm.extractvalue %271[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %421 = llvm.extractvalue %271[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %422 = llvm.extractvalue %271[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %423 = llvm.extractvalue %271[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %424 = llvm.extractvalue %271[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %425 = llvm.extractvalue %271[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %426 = llvm.extractvalue %271[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %427 = llvm.extractvalue %271[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %428 = llvm.extractvalue %271[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %429 = llvm.extractvalue %362[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %430 = llvm.extractvalue %362[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %431 = llvm.extractvalue %362[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %432 = llvm.extractvalue %362[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %433 = llvm.extractvalue %362[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %434 = llvm.extractvalue %362[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %435 = llvm.extractvalue %362[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %436 = llvm.extractvalue %362[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %437 = llvm.extractvalue %362[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %438 = llvm.extractvalue %362[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %439 = llvm.extractvalue %362[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %440 = llvm.extractvalue %360[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %441 = llvm.extractvalue %360[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %442 = llvm.extractvalue %360[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %443 = llvm.extractvalue %360[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %444 = llvm.extractvalue %360[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %445 = llvm.extractvalue %360[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %446 = llvm.extractvalue %360[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %447 = llvm.extractvalue %360[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %448 = llvm.extractvalue %360[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %449 = llvm.extractvalue %360[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %450 = llvm.extractvalue %360[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float_tb(%418, %419, %420, %421, %422, %423, %424, %425, %426, %427, %428, %429, %430, %431, %432, %433, %434, %435, %436, %437, %438, %439, %38, %33, %34, %36, %440, %441, %442, %443, %444, %445, %446, %447, %448, %449, %450, %45, %57, %45, %45, %45, %45, %45, %19) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %451 = llvm.add %369, %1 : i64
    "hivm.intr.hivm.WAIT.INTRA.BLOCK.mode"(%451) <{pipe = 10 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCK.mode"(%369) <{pipe = 10 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 10 : i64}> : () -> ()
    %452 = llvm.extractvalue %360[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %453 = llvm.extractvalue %360[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %454 = llvm.extractvalue %360[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %455 = llvm.extractvalue %360[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %456 = llvm.extractvalue %360[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %457 = llvm.extractvalue %360[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %458 = llvm.extractvalue %360[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %459 = llvm.extractvalue %360[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %460 = llvm.extractvalue %360[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %461 = llvm.extractvalue %360[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %462 = llvm.extractvalue %360[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%452, %453, %454, %455, %456, %457, %458, %459, %460, %461, %462, %349, %349, %371, %33, %36, %36, %32, %57, %21, %57, %20, %19) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%366) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 16 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 0 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%364) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %463 = llvm.extractvalue %272[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %464 = llvm.extractvalue %272[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %465 = llvm.extractvalue %272[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %466 = llvm.extractvalue %272[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %467 = llvm.extractvalue %272[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %468 = llvm.extractvalue %272[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %469 = llvm.extractvalue %272[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %470 = llvm.extractvalue %272[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %471 = llvm.extractvalue %272[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %472 = llvm.extractvalue %272[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %473 = llvm.extractvalue %272[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %474 = llvm.extractvalue %362[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %475 = llvm.extractvalue %362[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %476 = llvm.extractvalue %362[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %477 = llvm.extractvalue %362[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %478 = llvm.extractvalue %362[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %479 = llvm.extractvalue %362[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %480 = llvm.extractvalue %362[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %481 = llvm.extractvalue %362[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %482 = llvm.extractvalue %362[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %483 = llvm.extractvalue %362[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %484 = llvm.extractvalue %362[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %485 = llvm.extractvalue %361[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %486 = llvm.extractvalue %361[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %487 = llvm.extractvalue %361[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %488 = llvm.extractvalue %361[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %489 = llvm.extractvalue %361[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %490 = llvm.extractvalue %361[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %491 = llvm.extractvalue %361[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %492 = llvm.extractvalue %361[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %493 = llvm.extractvalue %361[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %494 = llvm.extractvalue %361[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %495 = llvm.extractvalue %361[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float_tb(%463, %464, %465, %466, %467, %468, %469, %470, %471, %472, %473, %474, %475, %476, %477, %478, %479, %480, %481, %482, %483, %484, %38, %33, %34, %36, %485, %486, %487, %488, %489, %490, %491, %492, %493, %494, %495, %45, %45, %45, %367, %45, %45, %45, %19) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %496 = llvm.add %368, %1 : i64
    "hivm.intr.hivm.WAIT.INTRA.BLOCK.mode"(%496) <{pipe = 10 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCK.mode"(%368) <{pipe = 10 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %497 = llvm.extractvalue %361[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %498 = llvm.extractvalue %361[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %499 = llvm.extractvalue %361[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %500 = llvm.extractvalue %361[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %501 = llvm.extractvalue %361[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %502 = llvm.extractvalue %361[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %503 = llvm.extractvalue %361[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %504 = llvm.extractvalue %361[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %505 = llvm.extractvalue %361[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %506 = llvm.extractvalue %361[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %507 = llvm.extractvalue %361[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%497, %498, %499, %500, %501, %502, %503, %504, %505, %506, %507, %350, %350, %370, %33, %36, %36, %32, %57, %21, %57, %20, %19) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%364) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 29 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 13 : i64}> : () -> ()
    %508 = llvm.add %357, %42 : i64
    llvm.store %508, %253 : i64, !llvm.ptr
    %509 = llvm.add %355, %32 overflow<nsw> : i64
    llvm.br ^bb8(%509 : i64)
  ^bb12:  // pred: ^bb8
    llvm.br ^bb13(%18 : i64)
  ^bb13(%510: i64):  // 2 preds: ^bb12, ^bb16
    %511 = llvm.icmp "slt" %510, %354 : i64
    llvm.cond_br %511, ^bb14, ^bb17
  ^bb14:  // pred: ^bb13
    %512 = llvm.load %252 : !llvm.ptr -> i64
    %513 = llvm.urem %512, %41  : i64
    %514 = llvm.icmp "eq" %513, %42 : i64
    %515 = llvm.select %514, %202, %190 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %516 = llvm.select %514, %226, %214 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %517 = llvm.select %514, %250, %238 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %518 = llvm.trunc %513 : i64 to i1
    %519 = llvm.select %518, %41, %43 : i1, i64
    %520 = llvm.xor %518, %38  : i1
    %521 = llvm.zext %520 : i1 to i64
    %522 = llvm.select %518, %43, %44 : i1, i64
    %523 = llvm.add %510, %8 : i64
    %524 = llvm.add %510, %0 : i64
    %525 = llvm.add %510, %32 : i64
    %526 = llvm.mul %510, %6 : i64
    %527 = llvm.mul %510, %6 : i64
    %528 = llvm.add %510, %351 : i64
    %529 = llvm.trunc %528 : i64 to i32
    %530 = llvm.sitofp %529 : i32 to f32
    %531 = llvm.fcmp "olt" %530, %336 : f32
    %532 = llvm.zext %531 : i1 to i32
    %533 = llvm.mul %532, %529 : i32
    %534 = llvm.sub %37, %532 : i32
    %535 = llvm.add %331, %529 : i32
    %536 = llvm.sub %535, %326 : i32
    %537 = llvm.mul %534, %536 : i32
    %538 = llvm.add %533, %537 : i32
    %539 = llvm.mul %538, %29 : i32
    %540 = llvm.add %539, %29 : i32
    %541 = llvm.intr.smin(%540, %285)  : (i32, i32) -> i32
    %542 = llvm.sub %541, %539 : i32
    %543 = llvm.intr.smax(%542, %28)  : (i32, i32) -> i32
    %544 = llvm.sdiv %539, %29  : i32
    %545 = llvm.intr.smin(%544, %337)  : (i32, i32) -> i32
    %546 = llvm.sext %545 : i32 to i64
    %547 = llvm.add %340, %546 : i64
    %548 = llvm.getelementptr %arg11[%547] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %549 = llvm.load %548 : !llvm.ptr<1> -> i32
    %550 = llvm.mul %549, %arg20 : i32
    %551 = llvm.sext %550 : i32 to i64
    %552 = llvm.sext %543 : i32 to i64
    %553 = llvm.intr.smax(%552, %18)  : (i64, i64) -> i64
    %554 = llvm.intr.smin(%553, %36)  : (i64, i64) -> i64
    %555 = llvm.intr.smin(%554, %18)  : (i64, i64) -> i64
    %556 = llvm.mul %555, %4 : i64
    %557 = llvm.add %554, %556 : i64
    %558 = llvm.icmp "slt" %557, %36 : i64
    %559 = llvm.mul %555, %4 : i64
    %560 = llvm.add %554, %559 : i64
    %561 = llvm.icmp "sle" %560, %18 : i64
    %562 = llvm.sub %18, %560 : i64
    %563 = llvm.sub %560, %32 : i64
    %564 = llvm.select %561, %562, %563 : i1, i64
    %565 = llvm.sdiv %564, %16  : i64
    %566 = llvm.sub %18, %565 : i64
    %567 = llvm.add %565, %32 : i64
    %568 = llvm.select %561, %566, %567 : i1, i64
    %569 = llvm.extractvalue %517[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %570 = llvm.extractvalue %517[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %571 = llvm.mul %555, %16 : i64
    llvm.cond_br %558, ^bb15, ^bb16
  ^bb15:  // pred: ^bb14
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %572 = llvm.extractvalue %517[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %573 = llvm.extractvalue %517[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%35, %572, %573, %18, %11, %32) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb16
  ^bb16:  // 2 preds: ^bb14, ^bb15
    "hivm.intr.hivm.WAIT.FLAG.REG"(%522) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.call @nd2nz_bfloat16_t(%arg6, %arg6, %551, %557, %34, %342, %32, %569, %570, %571, %16, %568, %16, %16, %15, %34, %16, %32) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    %574 = llvm.mul %510, %15 : i64
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 28 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 12 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%521) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %575 = llvm.extractvalue %517[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %576 = llvm.extractvalue %517[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %577 = llvm.extractvalue %517[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %578 = llvm.extractvalue %517[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %579 = llvm.extractvalue %517[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %580 = llvm.extractvalue %517[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %581 = llvm.extractvalue %517[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %582 = llvm.extractvalue %517[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %583 = llvm.extractvalue %517[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %584 = llvm.extractvalue %517[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %585 = llvm.extractvalue %517[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %586 = llvm.extractvalue %516[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %587 = llvm.extractvalue %516[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %588 = llvm.extractvalue %516[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %589 = llvm.extractvalue %516[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %590 = llvm.extractvalue %516[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %591 = llvm.extractvalue %516[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %592 = llvm.extractvalue %516[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %593 = llvm.extractvalue %516[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %594 = llvm.extractvalue %516[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %595 = llvm.extractvalue %516[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %596 = llvm.extractvalue %516[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float(%347, %347, %574, %17, %32, %16, %16, %34, %34, %16, %32, %575, %576, %577, %578, %579, %580, %581, %582, %583, %584, %585, %38, %33, %36, %34, %586, %587, %588, %589, %590, %591, %592, %593, %594, %595, %596, %45, %57, %45, %45, %45, %45, %45, %19) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %597 = llvm.add %524, %1 : i64
    "hivm.intr.hivm.SET.INTRA.BLOCK.mode"(%597) <{pipe = 3 : i64}> : (i64) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCK.mode"(%524) <{pipe = 3 : i64}> : (i64) -> ()
    %598 = llvm.add %525, %1 : i64
    "hivm.intr.hivm.WAIT.INTRA.BLOCK.mode"(%598) <{pipe = 10 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCK.mode"(%525) <{pipe = 10 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 10 : i64}> : () -> ()
    %599 = llvm.extractvalue %516[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %600 = llvm.extractvalue %516[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %601 = llvm.extractvalue %516[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %602 = llvm.extractvalue %516[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %603 = llvm.extractvalue %516[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %604 = llvm.extractvalue %516[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %605 = llvm.extractvalue %516[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %606 = llvm.extractvalue %516[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %607 = llvm.extractvalue %516[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %608 = llvm.extractvalue %516[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %609 = llvm.extractvalue %516[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%599, %600, %601, %602, %603, %604, %605, %606, %607, %608, %609, %345, %345, %527, %33, %34, %34, %32, %57, %21, %57, %20, %19) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%521) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %610 = llvm.mul %510, %15 : i64
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 27 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 11 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%519) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %611 = llvm.extractvalue %517[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %612 = llvm.extractvalue %517[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %613 = llvm.extractvalue %517[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %614 = llvm.extractvalue %517[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %615 = llvm.extractvalue %517[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %616 = llvm.extractvalue %517[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %617 = llvm.extractvalue %517[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %618 = llvm.extractvalue %517[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %619 = llvm.extractvalue %517[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %620 = llvm.extractvalue %517[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %621 = llvm.extractvalue %517[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %622 = llvm.extractvalue %515[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %623 = llvm.extractvalue %515[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %624 = llvm.extractvalue %515[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %625 = llvm.extractvalue %515[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %626 = llvm.extractvalue %515[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %627 = llvm.extractvalue %515[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %628 = llvm.extractvalue %515[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %629 = llvm.extractvalue %515[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %630 = llvm.extractvalue %515[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %631 = llvm.extractvalue %515[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %632 = llvm.extractvalue %515[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float(%348, %348, %610, %17, %32, %16, %16, %34, %34, %16, %32, %611, %612, %613, %614, %615, %616, %617, %618, %619, %620, %621, %38, %33, %36, %34, %622, %623, %624, %625, %626, %627, %628, %629, %630, %631, %632, %45, %45, %45, %522, %45, %45, %45, %19) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %633 = llvm.add %523, %1 : i64
    "hivm.intr.hivm.SET.INTRA.BLOCK.mode"(%633) <{pipe = 3 : i64}> : (i64) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCK.mode"(%523) <{pipe = 3 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %634 = llvm.extractvalue %515[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %635 = llvm.extractvalue %515[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %636 = llvm.extractvalue %515[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %637 = llvm.extractvalue %515[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %638 = llvm.extractvalue %515[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %639 = llvm.extractvalue %515[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %640 = llvm.extractvalue %515[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %641 = llvm.extractvalue %515[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %642 = llvm.extractvalue %515[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %643 = llvm.extractvalue %515[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %644 = llvm.extractvalue %515[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%634, %635, %636, %637, %638, %639, %640, %641, %642, %643, %644, %346, %346, %526, %33, %34, %34, %32, %57, %21, %57, %20, %19) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%519) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 16 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 0 : i64}> : () -> ()
    %645 = llvm.add %512, %42 : i64
    llvm.store %645, %252 : i64, !llvm.ptr
    %646 = llvm.add %510, %32 overflow<nsw> : i64
    llvm.br ^bb13(%646 : i64)
  ^bb17:  // pred: ^bb13
    %647 = llvm.add %343, %40 overflow<nsw> : i32
    llvm.br ^bb6(%647 : i32)
  ^bb18:  // pred: ^bb6
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 4 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%275) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.br ^bb19
  ^bb19:  // 2 preds: ^bb2, ^bb18
    %648 = llvm.add %268, %42 : i64
    llvm.store %648, %251 : i64, !llvm.ptr
    %649 = llvm.add %266, %37 overflow<nsw> : i32
    llvm.br ^bb1(%649 : i32)
  ^bb20:  // pred: ^bb1
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 17 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 18 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 23 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 7 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 24 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 8 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 25 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 9 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 26 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 10 : i64}> : () -> ()
    %650 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %651 = "hivm.intr.hivm.SBITSET1"(%650, %10) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%651) : (i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 6 : i64}> : () -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_0(%arg0: !llvm.ptr<6>, %arg1: i32, %arg2: f32, %arg3: f32, %arg4: !llvm.ptr<6>, %arg5: f32, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %1 = llvm.mlir.constant(5.110000e+02 : f32) : f32
    %2 = llvm.mlir.constant(8 : i32) : i32
    %3 = llvm.mlir.constant(0 : i32) : i32
    %4 = llvm.mlir.constant(1 : i32) : i32
    %5 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %6 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%0, %5, %4) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %7 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64s32"(%arg0, %3, %3, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xi32>
    %8 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %9 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%7, %arg1, %8) : (vector<64xi32>, i32, vector<256xi1>) -> vector<64xi32>
    %10 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %11 = "hivm_regbaseintrins.intr.hivm.vcvtif.s322f32.x"(%9, %10, %3) : (vector<64xi32>, vector<256xi1>, i32) -> vector<64xf32>
    %12 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg2) : (f32) -> vector<64xf32>
    %13 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %14 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%11, %12, %13) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %15 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg3) : (f32) -> vector<64xf32>
    %16 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %17 = "hivm_regbaseintrins.intr.hivm.vcmp.le.s.z"(%11, %15, %16) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %18 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %19 = "hivm_regbaseintrins.intr.hivm.pand.z"(%14, %17, %18) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %20 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %21 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%11, %6, %20) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %23 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%11, %1, %22) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = "hivm_regbaseintrins.intr.hivm.vcmp.ge.s.z"(%23, %15, %24) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %27 = "hivm_regbaseintrins.intr.hivm.por.z"(%21, %25, %26) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = "hivm_regbaseintrins.intr.hivm.pand.z"(%19, %27, %28) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %30 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %31 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %32 = "hivm_regbaseintrins.intr.hivm.pstu.b32"(%29, %arg6, %31) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %33 = llvm.extractvalue %32[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %34 = llvm.extractvalue %32[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%33, %34, %3, %3) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %35 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%arg4, %3, %3, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %36 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%3, %3) : (i32, i32) -> vector<256xi1>
    %37 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%35, %36) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %38 = llvm.extractvalue %37[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %39 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%38, %36) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %40 = llvm.extractvalue %39[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %41 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %42 = "hivm_regbaseintrins.intr.hivm.pand.z"(%40, %14, %41) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %43 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg5) : (f32) -> vector<64xf32>
    %44 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %45 = "hivm_regbaseintrins.intr.hivm.vcmp.le.s.z"(%11, %43, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %46 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %47 = "hivm_regbaseintrins.intr.hivm.pand.z"(%42, %45, %46) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %48 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %49 = "hivm_regbaseintrins.intr.hivm.vcmp.ge.s.z"(%23, %43, %48) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %50 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %51 = "hivm_regbaseintrins.intr.hivm.por.z"(%21, %49, %50) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %52 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %53 = "hivm_regbaseintrins.intr.hivm.pand.z"(%47, %51, %52) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %54 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %55 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %56 = "hivm_regbaseintrins.intr.hivm.pstu.b32"(%53, %arg7, %55) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %57 = llvm.extractvalue %56[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %58 = llvm.extractvalue %56[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%57, %58, %3, %3) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_4(%arg0: !llvm.ptr<6>, %arg1: i64, %arg2: !llvm.ptr<6>, %arg3: f32, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(8 : i32) : i32
    %1 = llvm.mlir.constant(-1.000000e+06 : f32) : f32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(6 : i32) : i32
    %4 = llvm.mlir.constant(1 : i32) : i32
    %5 = llvm.mlir.constant(8 : index) : i64
    %6 = llvm.mlir.constant(2 : i32) : i32
    %7 = llvm.mlir.constant(256 : index) : i64
    %8 = llvm.mlir.constant(1536 : index) : i64
    %9 = llvm.mlir.constant(384 : index) : i64
    %10 = llvm.mlir.constant(64 : index) : i64
    %11 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %12 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%1, %11, %4) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    llvm.br ^bb1(%2 : i32)
  ^bb1(%13: i32):  // 2 preds: ^bb0, ^bb2
    %14 = llvm.icmp "slt" %13, %3 : i32
    llvm.cond_br %14, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %15 = llvm.sext %13 : i32 to i64
    %16 = llvm.mul %arg1, %8 : i64
    %17 = llvm.mul %15, %7 : i64
    %18 = llvm.add %16, %17 : i64
    %19 = llvm.udiv %18, %5  : i64
    %20 = llvm.getelementptr %arg0[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %21 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%20, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %23 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%21, %22) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %24 = llvm.extractvalue %23[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %25 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%24, %22) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %26 = llvm.extractvalue %25[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %27 = llvm.mul %arg1, %9 : i64
    %28 = llvm.mul %15, %10 : i64
    %29 = llvm.add %27, %28 : i64
    %30 = llvm.getelementptr %arg2[%29] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %31 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%30, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %32 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %33 = "hivm_regbaseintrins.intr.hivm.vmuls.s.x"(%31, %arg3, %32) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %34 = "hivm_regbaseintrins.intr.hivm.vsel"(%33, %12, %26) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %35 = llvm.mul %15, %10 : i64
    %36 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %37 = llvm.getelementptr %arg4[%35] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%34, %37, %2, %6, %2, %36) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %38 = llvm.add %13, %4 overflow<nsw> : i32
    llvm.br ^bb1(%38 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_5(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(8 : i32) : i32
    %4 = llvm.mlir.constant(4 : i32) : i32
    %5 = llvm.mlir.undef : !llvm.ptr<6>
    %6 = llvm.mlir.constant(64 : index) : i64
    %7 = llvm.mlir.constant(6 : index) : i64
    %8 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %8, %5 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%9: i32, %10: vector<32xi8>, %11: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %12 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %12, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %13 = llvm.sext %9 : i32 to i64
    %14 = llvm.mul %13, %6 : i64
    %15 = llvm.getelementptr %arg0[%14] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %16 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%15, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %17 = llvm.mul %arg2, %7 : i64
    %18 = llvm.add %17, %13 : i64
    %19 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %20 = "hivm_regbaseintrins.intr.hivm.vcmax.s.x"(%16, %19) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%20, %22, %4, %10) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %24 = llvm.extractvalue %23[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %25 = llvm.extractvalue %23[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %26 = llvm.add %9, %0 overflow<nsw> : i32
    llvm.br ^bb1(%26, %24, %25 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%10, %11, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_6(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = llvm.mlir.constant(6 : index) : i64
    %4 = llvm.mul %arg2, %3 : i64
    %5 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %6 = llvm.extractvalue %5[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %7 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %8 = llvm.getelementptr %arg1[%4] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %9 = "hivm_regbaseintrins.intr.hivm.vldas"(%8) : (!llvm.ptr<6>) -> vector<32xi8>
    %10 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%8, %9, %1) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %11 = llvm.extractvalue %10[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    %12 = "hivm_regbaseintrins.intr.hivm.vmax.s.x"(%7, %11, %6) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%12, %arg3, %1, %2, %1, %6) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_7(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = llvm.mlir.constant(24 : i32) : i32
    %4 = llvm.mlir.constant(6 : index) : i64
    %5 = llvm.mul %arg3, %4 : i64
    %6 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %7 = llvm.extractvalue %6[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %8 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %10 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%8, %9, %7, %1) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %11 = llvm.getelementptr %arg2[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %12 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %13 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%10, %11, %3, %12) : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %14 = llvm.extractvalue %13[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %15 = llvm.extractvalue %13[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%14, %15, %1, %1) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %16 = llvm.getelementptr %arg2[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %17 = "hivm_regbaseintrins.intr.hivm.vldas"(%16) : (!llvm.ptr<6>) -> vector<32xi8>
    %18 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%16, %17, %1) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %19 = llvm.extractvalue %18[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%19, %arg4, %1, %2, %1, %7) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_8(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %4 = llvm.mlir.constant(3 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(7 : i32) : i32
    %7 = llvm.mlir.constant(4 : i32) : i32
    %8 = llvm.mlir.constant(2 : i32) : i32
    %9 = llvm.mlir.undef : !llvm.ptr<6>
    %10 = llvm.mlir.constant(64 : index) : i64
    %11 = llvm.mlir.constant(6 : index) : i64
    %12 = llvm.mul %arg3, %11 : i64
    %13 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %13, %9 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%14: i32, %15: vector<32xi8>, %16: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %17 = llvm.icmp "slt" %14, %1 : i32
    llvm.cond_br %17, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %14 : i32 to i64
    %19 = llvm.mul %18, %10 : i64
    %20 = llvm.getelementptr %arg0[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %21 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%20, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %22 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%22, %2, %4, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%21, %23, %24, %2) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %27 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%25, %3, %26) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%25, %28, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %30 = llvm.mul %18, %10 : i64
    %31 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %32 = llvm.getelementptr %arg4[%30] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%29, %32, %2, %6, %2, %31) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %33 = llvm.mul %arg3, %11 : i64
    %34 = llvm.add %33, %18 : i64
    %35 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %36 = "hivm_regbaseintrins.intr.hivm.vcadd.s.x"(%27, %35) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %37 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %38 = llvm.getelementptr %arg2[%34] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %39 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%36, %38, %7, %15) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %40 = llvm.extractvalue %39[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %41 = llvm.extractvalue %39[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %42 = llvm.add %14, %0 overflow<nsw> : i32
    llvm.br ^bb1(%42, %40, %41 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%15, %16, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %43 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%1) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %44 = llvm.extractvalue %43[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %45 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg5, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %46 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg6, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %47 = llvm.getelementptr %arg2[%12] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %48 = "hivm_regbaseintrins.intr.hivm.vldas"(%47) : (!llvm.ptr<6>) -> vector<32xi8>
    %49 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%47, %48, %2) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %50 = llvm.extractvalue %49[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    %51 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%45, %46, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %52 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%51, %50, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%52, %arg7, %2, %8, %2, %44) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_11(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(8 : i32) : i32
    %4 = llvm.mlir.constant(4 : i32) : i32
    %5 = llvm.mlir.undef : !llvm.ptr<6>
    %6 = llvm.mlir.constant(64 : index) : i64
    %7 = llvm.mlir.constant(6 : index) : i64
    %8 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %8, %5 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%9: i32, %10: vector<32xi8>, %11: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %12 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %12, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %13 = llvm.sext %9 : i32 to i64
    %14 = llvm.mul %13, %6 : i64
    %15 = llvm.getelementptr %arg0[%14] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %16 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%15, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %17 = llvm.mul %arg2, %7 : i64
    %18 = llvm.add %17, %13 : i64
    %19 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %20 = "hivm_regbaseintrins.intr.hivm.vcmax.s.x"(%16, %19) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%20, %22, %4, %10) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %24 = llvm.extractvalue %23[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %25 = llvm.extractvalue %23[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %26 = llvm.add %9, %0 overflow<nsw> : i32
    llvm.br ^bb1(%26, %24, %25 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%10, %11, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_12(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = llvm.mlir.constant(6 : index) : i64
    %4 = llvm.mul %arg2, %3 : i64
    %5 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %6 = llvm.extractvalue %5[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %7 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %8 = llvm.getelementptr %arg1[%4] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %9 = "hivm_regbaseintrins.intr.hivm.vldas"(%8) : (!llvm.ptr<6>) -> vector<32xi8>
    %10 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%8, %9, %1) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %11 = llvm.extractvalue %10[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    %12 = "hivm_regbaseintrins.intr.hivm.vmax.s.x"(%7, %11, %6) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%12, %arg3, %1, %2, %1, %6) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_13(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = llvm.mlir.constant(24 : i32) : i32
    %4 = llvm.mlir.constant(6 : index) : i64
    %5 = llvm.mul %arg3, %4 : i64
    %6 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %7 = llvm.extractvalue %6[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %8 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %10 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%8, %9, %7, %1) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %11 = llvm.getelementptr %arg2[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %12 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %13 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%10, %11, %3, %12) : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %14 = llvm.extractvalue %13[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %15 = llvm.extractvalue %13[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%14, %15, %1, %1) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %16 = llvm.getelementptr %arg2[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %17 = "hivm_regbaseintrins.intr.hivm.vldas"(%16) : (!llvm.ptr<6>) -> vector<32xi8>
    %18 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%16, %17, %1) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %19 = llvm.extractvalue %18[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%19, %arg4, %1, %2, %1, %7) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_14(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %4 = llvm.mlir.constant(3 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(7 : i32) : i32
    %7 = llvm.mlir.constant(4 : i32) : i32
    %8 = llvm.mlir.constant(2 : i32) : i32
    %9 = llvm.mlir.undef : !llvm.ptr<6>
    %10 = llvm.mlir.constant(64 : index) : i64
    %11 = llvm.mlir.constant(6 : index) : i64
    %12 = llvm.mul %arg3, %11 : i64
    %13 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %13, %9 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%14: i32, %15: vector<32xi8>, %16: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %17 = llvm.icmp "slt" %14, %1 : i32
    llvm.cond_br %17, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %14 : i32 to i64
    %19 = llvm.mul %18, %10 : i64
    %20 = llvm.getelementptr %arg0[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %21 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%20, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %22 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%22, %2, %4, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%21, %23, %24, %2) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %27 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%25, %3, %26) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%25, %28, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %30 = llvm.mul %18, %10 : i64
    %31 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %32 = llvm.getelementptr %arg4[%30] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%29, %32, %2, %6, %2, %31) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %33 = llvm.mul %arg3, %11 : i64
    %34 = llvm.add %33, %18 : i64
    %35 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %36 = "hivm_regbaseintrins.intr.hivm.vcadd.s.x"(%27, %35) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %37 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %38 = llvm.getelementptr %arg2[%34] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %39 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%36, %38, %7, %15) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %40 = llvm.extractvalue %39[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %41 = llvm.extractvalue %39[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %42 = llvm.add %14, %0 overflow<nsw> : i32
    llvm.br ^bb1(%42, %40, %41 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%15, %16, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %43 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%1) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %44 = llvm.extractvalue %43[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %45 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg5, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %46 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg6, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %47 = llvm.getelementptr %arg2[%12] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %48 = "hivm_regbaseintrins.intr.hivm.vldas"(%47) : (!llvm.ptr<6>) -> vector<32xi8>
    %49 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%47, %48, %2) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %50 = llvm.extractvalue %49[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    %51 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%45, %46, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %52 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%51, %50, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%52, %arg7, %2, %8, %2, %44) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_15(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(16 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(8 : i32) : i32
    %4 = llvm.mlir.constant(1114112 : i32) : i32
    %5 = llvm.mlir.constant(64 : index) : i64
    %6 = llvm.mlir.constant(16 : index) : i64
    %7 = llvm.mlir.constant(272 : index) : i64
    %8 = llvm.mlir.constant(0 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%9: i32):  // 2 preds: ^bb0, ^bb2
    %10 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %10, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %11 = llvm.sext %9 : i32 to i64
    %12 = llvm.mul %11, %5 : i64
    %13 = llvm.getelementptr %arg0[%12] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %14 = llvm.mul %8, %5 : i64
    %15 = llvm.add %14, %8 : i64
    %16 = llvm.getelementptr %13[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %17 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%16, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %18 = llvm.mul %11, %6 : i64
    %19 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%3, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %20 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %21 = llvm.mul %8, %7 : i64
    %22 = llvm.add %21, %8 : i64
    %23 = llvm.getelementptr %20[%22] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vsstb.v128bf16"(%17, %23, %4, %2, %19) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, vector<256xi1>) -> ()
    %24 = llvm.add %9, %0 overflow<nsw> : i32
    llvm.br ^bb1(%24 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_16(%arg0: !llvm.ptr<6>, %arg1: i64, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>, %arg8: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(256 : i32) : i32
    %4 = llvm.mlir.constant(64 : i32) : i32
    %5 = llvm.mlir.constant(3 : i32) : i32
    %6 = llvm.mlir.constant(8 : i32) : i32
    %7 = llvm.mlir.constant(2 : i32) : i32
    %8 = llvm.mlir.constant(1536 : index) : i64
    %9 = llvm.mlir.constant(256 : index) : i64
    %10 = llvm.mlir.constant(6 : index) : i64
    %11 = llvm.mlir.constant(0 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%12: i32):  // 2 preds: ^bb0, ^bb5
    %13 = llvm.icmp "slt" %12, %1 : i32
    llvm.cond_br %13, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %14 = llvm.sext %12 : i32 to i64
    %15 = llvm.mul %arg1, %10 : i64
    %16 = llvm.add %15, %14 : i64
    %17 = llvm.mul %arg1, %10 : i64
    %18 = llvm.add %17, %14 : i64
    llvm.br ^bb3(%2 : i32)
  ^bb3(%19: i32):  // 2 preds: ^bb2, ^bb4
    %20 = llvm.icmp "slt" %19, %3 : i32
    llvm.cond_br %20, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %21 = llvm.sext %19 : i32 to i64
    %22 = llvm.mul %arg1, %8 : i64
    %23 = llvm.mul %14, %9 : i64
    %24 = llvm.add %22, %23 : i64
    %25 = llvm.add %24, %21 : i64
    %26 = llvm.getelementptr %arg3[%25] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %27 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%26, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %28 = llvm.mul %14, %9 : i64
    %29 = llvm.add %28, %21 : i64
    %30 = llvm.getelementptr %arg4[%29] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %31 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%30, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %32 = llvm.getelementptr %arg0[%16] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %33 = llvm.mul %11, %10 : i64
    %34 = llvm.getelementptr %32[%33] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %35 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%34, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %36 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %37 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%31, %35, %36) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %38 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %39 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%27, %37, %38) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %40 = llvm.mul %14, %9 : i64
    %41 = llvm.add %40, %21 : i64
    %42 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %43 = llvm.getelementptr %arg7[%41] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%39, %43, %2, %7, %2, %42) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %44 = llvm.mul %arg1, %8 : i64
    %45 = llvm.mul %14, %9 : i64
    %46 = llvm.add %44, %45 : i64
    %47 = llvm.add %46, %21 : i64
    %48 = llvm.getelementptr %arg5[%47] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %49 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%48, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %50 = llvm.mul %14, %9 : i64
    %51 = llvm.add %50, %21 : i64
    %52 = llvm.getelementptr %arg6[%51] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %53 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%52, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %54 = llvm.getelementptr %arg2[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %55 = llvm.mul %11, %10 : i64
    %56 = llvm.getelementptr %54[%55] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %57 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%56, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %58 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %59 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%53, %57, %58) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %60 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %61 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%49, %59, %60) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %62 = llvm.mul %14, %9 : i64
    %63 = llvm.add %62, %21 : i64
    %64 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %65 = llvm.getelementptr %arg8[%63] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%61, %65, %2, %7, %2, %64) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %66 = llvm.add %19, %4 overflow<nsw> : i32
    llvm.br ^bb3(%66 : i32)
  ^bb5:  // pred: ^bb3
    %67 = llvm.add %12, %0 overflow<nsw> : i32
    llvm.br ^bb1(%67 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_17(%arg0: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(0 : i32) : i32
    %1 = llvm.mlir.constant(8 : i32) : i32
    %2 = llvm.mlir.constant(1 : i32) : i32
    %3 = llvm.mlir.constant(2 : i32) : i32
    %4 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %5 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%0, %4, %2) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %6 = "hivm_regbaseintrins.intr.hivm.vci"(%0, %0) : (i32, i32) -> vector<64xi32>
    %7 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %8 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%5, %6, %7) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    %9 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64s32"(%8, %arg0, %0, %3, %0, %9) : (vector<64xi32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_18(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i8) : i8
    %1 = llvm.mlir.constant(0 : i8) : i8
    %2 = llvm.mlir.constant(15 : i32) : i32
    %3 = llvm.mlir.constant(0 : i32) : i32
    %4 = llvm.mlir.constant(1 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %3) {mask_bit_width = 8 : i32} : (i32, i32) -> vector<256xi1>
    %7 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%arg0, %3, %3, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %8 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%3, %3) {mask_bit_width = 8 : i32} : (i32, i32) -> vector<256xi1>
    %9 = "hivm_regbaseintrins.intr.hivm.vbr"(%1) : (i8) -> vector<256xi8>
    %10 = "hivm_regbaseintrins.intr.hivm.vbr"(%0) : (i8) -> vector<256xi8>
    %11 = "hivm_regbaseintrins.intr.hivm.vsel"(%10, %9, %7) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %12 = "hivm_regbaseintrins.intr.hivm.vdup.z"(%11, %8, %4) : (vector<256xi8>, vector<256xi1>, i32) -> vector<256xi8>
    %13 = "hivm_regbaseintrins.intr.hivm.vcmp.ne.s.z"(%12, %9, %8) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi1>
    %14 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%5, %3) {mask_bit_width = 8 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %15 = "hivm_regbaseintrins.intr.hivm.pxor.z"(%13, %6, %14) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.psts.b8"(%15, %arg1, %3, %3, %3) : (vector<256xi1>, !llvm.ptr<6>, i32, i32, i32) -> ()
    llvm.return
  }
  llvm.func private @nd2nz_bfloat16_t(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<2>, %arg8: !llvm.ptr<2>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %15 = llvm.insertvalue %arg14, %14[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg15, %16[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg12, %17[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg13, %19[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %21, %22 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_nd2nz_bfloat16_t(%10, %22) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_nd2nz_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @set_l1_2d_bfloat16_t(%arg0: bf16, %arg1: !llvm.ptr<2>, %arg2: !llvm.ptr<2>, %arg3: i64, %arg4: i64, %arg5: i64) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg1, %1[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg4, %4[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg5, %5[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_set_l1_2d_bfloat16_t(%arg0, %7) : (bf16, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_set_l1_2d_bfloat16_t(bf16, !llvm.ptr) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @mma_tile_bfloat16_t_to_float_tb(%arg0: !llvm.ptr<2>, %arg1: !llvm.ptr<2>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<2>, %arg12: !llvm.ptr<2>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64, %arg21: i64, %arg22: i1, %arg23: i64, %arg24: i64, %arg25: i64, %arg26: !llvm.ptr<5>, %arg27: !llvm.ptr<5>, %arg28: i64, %arg29: i64, %arg30: i64, %arg31: i64, %arg32: i64, %arg33: i64, %arg34: i64, %arg35: i64, %arg36: i64, %arg37: i64, %arg38: i64, %arg39: i64, %arg40: i64, %arg41: i64, %arg42: i64, %arg43: i64, %arg44: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg18, %18[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.insertvalue %arg16, %21[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %24 = llvm.insertvalue %arg17, %23[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %25 = llvm.insertvalue %arg21, %24[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %26 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %25, %26 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %27 = llvm.insertvalue %arg26, %0[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %28 = llvm.insertvalue %arg27, %27[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %29 = llvm.insertvalue %arg28, %28[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %30 = llvm.insertvalue %arg29, %29[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %31 = llvm.insertvalue %arg33, %30[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %32 = llvm.insertvalue %arg30, %31[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %33 = llvm.insertvalue %arg34, %32[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %34 = llvm.insertvalue %arg31, %33[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %35 = llvm.insertvalue %arg35, %34[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %36 = llvm.insertvalue %arg32, %35[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %37 = llvm.insertvalue %arg36, %36[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %38 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %37, %38 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_mma_tile_bfloat16_t_to_float_tb(%14, %26, %arg22, %arg23, %arg24, %arg25, %38, %arg37, %arg38, %arg39, %arg40, %arg41, %arg42, %arg43, %arg44) : (!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_mma_tile_bfloat16_t_to_float_tb(!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%arg0: !llvm.ptr<5>, %arg1: !llvm.ptr<5>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<6>, %arg12: !llvm.ptr<6>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: f32, %arg20: i64, %arg21: i1, %arg22: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %21, %22 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%14, %22, %arg18, %arg19, %arg20, %arg21, %arg22) : (!llvm.ptr, !llvm.ptr, i64, f32, i64, i1, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(!llvm.ptr, !llvm.ptr, i64, f32, i64, i1, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @mma_tile_bfloat16_t_to_float(%arg0: !llvm.ptr<2>, %arg1: !llvm.ptr<2>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<2>, %arg12: !llvm.ptr<2>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64, %arg21: i64, %arg22: i1, %arg23: i64, %arg24: i64, %arg25: i64, %arg26: !llvm.ptr<5>, %arg27: !llvm.ptr<5>, %arg28: i64, %arg29: i64, %arg30: i64, %arg31: i64, %arg32: i64, %arg33: i64, %arg34: i64, %arg35: i64, %arg36: i64, %arg37: i64, %arg38: i64, %arg39: i64, %arg40: i64, %arg41: i64, %arg42: i64, %arg43: i64, %arg44: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg18, %18[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.insertvalue %arg16, %21[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %24 = llvm.insertvalue %arg17, %23[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %25 = llvm.insertvalue %arg21, %24[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %26 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %25, %26 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %27 = llvm.insertvalue %arg26, %0[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %28 = llvm.insertvalue %arg27, %27[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %29 = llvm.insertvalue %arg28, %28[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %30 = llvm.insertvalue %arg29, %29[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %31 = llvm.insertvalue %arg33, %30[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %32 = llvm.insertvalue %arg30, %31[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %33 = llvm.insertvalue %arg34, %32[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %34 = llvm.insertvalue %arg31, %33[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %35 = llvm.insertvalue %arg35, %34[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %36 = llvm.insertvalue %arg32, %35[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %37 = llvm.insertvalue %arg36, %36[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %38 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %37, %38 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_mma_tile_bfloat16_t_to_float(%14, %26, %arg22, %arg23, %arg24, %arg25, %38, %arg37, %arg38, %arg39, %arg40, %arg41, %arg42, %arg43, %arg44) : (!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_mma_tile_bfloat16_t_to_float(!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @load_gm_to_ubuf_1d_float(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i32, %arg11: f32, %arg12: i64, %arg13: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.insertvalue %arg4, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %8 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %7, %8 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %9 = llvm.insertvalue %arg5, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg6, %9[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg7, %10[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_load_gm_to_ubuf_1d_float(%8, %14, %arg10, %arg11, %arg12, %arg13) : (!llvm.ptr, !llvm.ptr, i32, f32, i64, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_load_gm_to_ubuf_1d_float(!llvm.ptr, !llvm.ptr, i32, f32, i64, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_ubuf_1d_float(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg0, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg1, %2[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg2, %3[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg3, %4[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %8 = llvm.insertvalue %arg5, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg7, %9[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg8, %10[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg9, %11[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %12, %13 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_ubuf_1d_float(%7, %13) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_ubuf_1d_float(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_ubuf_1d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg0, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg1, %2[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg2, %3[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg3, %4[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %8 = llvm.insertvalue %arg5, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg7, %9[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg8, %10[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg9, %11[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %12, %13 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_ubuf_1d_bfloat16_t(%7, %13) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_ubuf_1d_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_cbuf_2d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<2>, %arg8: !llvm.ptr<2>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg12, %14[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %17, %18 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_cbuf_2d_bfloat16_t(%10, %18) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_cbuf_2d_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @store_ubuf_to_gm_2d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<1>, %arg8: !llvm.ptr<1>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg12, %14[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %17, %18 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_store_ubuf_to_gm_2d_bfloat16_t(%10, %18, %arg14) : (!llvm.ptr, !llvm.ptr, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_store_ubuf_to_gm_2d_bfloat16_t(!llvm.ptr, !llvm.ptr, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv(%arg0: i64, %arg1: !llvm.ptr<1>, %arg2: !llvm.ptr<1>, %arg3: !llvm.ptr<1>, %arg4: !llvm.ptr<1>, %arg5: !llvm.ptr<1>, %arg6: !llvm.ptr<1>, %arg7: !llvm.ptr<1>, %arg8: i32, %arg9: !llvm.ptr<1>, %arg10: !llvm.ptr<1>, %arg11: !llvm.ptr<1>, %arg12: f32, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32, %arg17: i32, %arg18: i32, %arg19: i32, %arg20: i32, %arg21: i32, %arg22: i32, %arg23: i32, %arg24: i32, %arg25: i32, %arg26: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix, hivm.vf_mode = #hivm.vf_mode<SIMD>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, mix_mode = "mix", parallel_mode = "simd"} {
    %0 = llvm.mlir.constant(272 : index) : i64
    %1 = llvm.mlir.constant(5 : index) : i64
    %2 = llvm.mlir.constant(3 : index) : i64
    %3 = llvm.mlir.constant(9 : index) : i64
    %4 = llvm.mlir.constant(7 : index) : i64
    %5 = llvm.mlir.constant(12 : index) : i64
    %6 = llvm.mlir.constant(-1 : index) : i64
    %7 = llvm.mlir.constant(384 : index) : i64
    %8 = llvm.mlir.constant(1024 : index) : i64
    %9 = llvm.mlir.constant(4 : index) : i64
    %10 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %11 = llvm.mlir.constant(1536 : index) : i64
    %12 = llvm.mlir.constant(256 : index) : i64
    %13 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %14 = llvm.mlir.constant(6 : index) : i64
    %15 = llvm.mlir.constant(48 : i64) : i64
    %16 = llvm.mlir.constant(60 : i64) : i64
    %17 = llvm.mlir.constant(0 : index) : i64
    %18 = llvm.mlir.constant(511 : i32) : i32
    %19 = llvm.mlir.constant(63 : i32) : i32
    %20 = llvm.mlir.constant(64 : i32) : i32
    %21 = llvm.mlir.constant(0 : i32) : i32
    %22 = llvm.mlir.constant(0 : i64) : i64
    %23 = llvm.mlir.constant(32 : i64) : i64
    %24 = llvm.mlir.constant(6176 : i64) : i64
    %25 = llvm.mlir.constant(6208 : i64) : i64
    %26 = llvm.mlir.constant(6464 : i64) : i64
    %27 = llvm.mlir.constant(6496 : i64) : i64
    %28 = llvm.mlir.constant(56128 : i64) : i64
    %29 = llvm.mlir.constant(44992 : i64) : i64
    %30 = llvm.mlir.constant(56064 : i64) : i64
    %31 = llvm.mlir.constant(62272 : i64) : i64
    %32 = llvm.mlir.constant(51808 : i64) : i64
    %33 = llvm.mlir.constant(56096 : i64) : i64
    %34 = llvm.mlir.constant(6528 : i64) : i64
    %35 = llvm.mlir.constant(18816 : i64) : i64
    %36 = llvm.mlir.constant(16384 : i64) : i64
    %37 = llvm.mlir.constant(20480 : i64) : i64
    %38 = llvm.mlir.constant(31104 : i64) : i64
    %39 = llvm.mlir.constant(34176 : i64) : i64
    %40 = llvm.mlir.constant(41472 : i64) : i64
    %41 = llvm.mlir.constant(41344 : i64) : i64
    %42 = llvm.mlir.constant(41408 : i64) : i64
    %43 = llvm.mlir.constant(37248 : i64) : i64
    %44 = llvm.mlir.constant(41856 : i64) : i64
    %45 = llvm.mlir.constant(42240 : i64) : i64
    %46 = llvm.mlir.constant(42272 : i64) : i64
    %47 = llvm.mlir.constant(42304 : i64) : i64
    %48 = llvm.mlir.constant(42368 : i64) : i64
    %49 = llvm.mlir.constant(42432 : i64) : i64
    %50 = llvm.mlir.constant(43968 : i64) : i64
    %51 = llvm.mlir.constant(44032 : i64) : i64
    %52 = llvm.mlir.constant(44064 : i64) : i64
    %53 = llvm.mlir.constant(44128 : i64) : i64
    %54 = llvm.mlir.constant(44224 : i64) : i64
    %55 = llvm.mlir.constant(44160 : i64) : i64
    %56 = llvm.mlir.constant(45024 : i64) : i64
    %57 = llvm.mlir.constant(47072 : i64) : i64
    %58 = llvm.mlir.constant(49248 : i64) : i64
    %59 = llvm.mlir.constant(50784 : i64) : i64
    %60 = llvm.mlir.constant(50848 : i64) : i64
    %61 = llvm.mlir.constant(50880 : i64) : i64
    %62 = llvm.mlir.constant(50944 : i64) : i64
    %63 = llvm.mlir.constant(51040 : i64) : i64
    %64 = llvm.mlir.constant(50976 : i64) : i64
    %65 = llvm.mlir.constant(51840 : i64) : i64
    %66 = llvm.mlir.constant(53888 : i64) : i64
    %67 = llvm.mlir.constant(68416 : i64) : i64
    %68 = llvm.mlir.constant(71488 : i64) : i64
    %69 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %70 = llvm.mlir.constant(1 : index) : i64
    %71 = llvm.mlir.constant(1 : i32) : i32
    %72 = llvm.mlir.constant(2 : index) : i64
    %73 = llvm.mlir.constant(2 : i32) : i32
    %74 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %75 = "hivm.intr.hivm.SBITSET0"(%74, %16) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%75) : (i64) -> ()
    %76 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %77 = "hivm.intr.hivm.SBITSET1"(%76, %15) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%77) : (i64) -> ()
    %78 = "hivm.intr.hivm.GET.BLOCK.IDX"() : () -> i64
    %79 = llvm.trunc %78 : i64 to i32
    %80 = llvm.srem %79, %arg24  : i32
    %81 = llvm.inttoptr %22 : i64 to !llvm.ptr<6>
    %82 = llvm.inttoptr %23 : i64 to !llvm.ptr<6>
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_merged_vf_0(%81, %82) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %83 = llvm.mul %80, %arg8 : i32
    %84 = llvm.sdiv %83, %arg24  : i32
    %85 = llvm.add %80, %71 : i32
    %86 = llvm.mul %85, %arg8 : i32
    %87 = llvm.sdiv %86, %arg24  : i32
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 7 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 8 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 9 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 10 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 0 : i64}> : () -> ()
    llvm.br ^bb1(%84 : i32)
  ^bb1(%88: i32):  // 2 preds: ^bb0, ^bb24
    %89 = llvm.icmp "slt" %88, %87 : i32
    llvm.cond_br %89, ^bb2, ^bb25
  ^bb2:  // pred: ^bb1
    %90 = llvm.sext %88 : i32 to i64
    %91 = llvm.getelementptr %arg9[%90] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %92 = llvm.load %91 : !llvm.ptr<1> -> i32
    %93 = llvm.add %90, %70 : i64
    %94 = llvm.getelementptr %arg9[%93] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %95 = llvm.load %94 : !llvm.ptr<1> -> i32
    %96 = llvm.sub %95, %92 : i32
    %97 = llvm.icmp "sgt" %96, %21 : i32
    llvm.cond_br %97, ^bb3, ^bb24
  ^bb3:  // pred: ^bb2
    %98 = llvm.getelementptr %arg10[%90] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %99 = llvm.load %98 : !llvm.ptr<1> -> i32
    %100 = llvm.sub %99, %96 : i32
    %101 = llvm.icmp "sgt" %96, %71 : i32
    %102 = llvm.zext %101 : i1 to i64
    %103 = llvm.mul %102, %14 : i64
    %104 = llvm.mul %102, %12 : i64
    %105 = llvm.inttoptr %24 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @load_gm_to_ubuf_1d_float(%arg7, %arg7, %17, %14, %70, %105, %105, %17, %14, %70, %21, %69, %17, %21) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i32, f32, i64, i32) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    %106 = llvm.add %99, %19 : i32
    %107 = llvm.sdiv %106, %20  : i32
    %108 = llvm.intr.smin(%107, %21)  : (i32, i32) -> i32
    %109 = llvm.sub %100, %18 : i32
    %110 = llvm.intr.smax(%109, %21)  : (i32, i32) -> i32
    %111 = llvm.sdiv %110, %20  : i32
    %112 = llvm.intr.smax(%108, %111)  : (i32, i32) -> i32
    %113 = llvm.intr.smax(%108, %112)  : (i32, i32) -> i32
    %114 = llvm.sub %107, %113 : i32
    %115 = llvm.intr.smax(%114, %21)  : (i32, i32) -> i32
    %116 = llvm.add %108, %115 : i32
    %117 = llvm.intr.smin(%116, %107)  : (i32, i32) -> i32
    %118 = llvm.add %100, %71 : i32
    %119 = llvm.sitofp %108 : i32 to f32
    %120 = llvm.inttoptr %25 : i64 to !llvm.ptr<6>
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_17(%120) {hivm.vector_function, no_inline} : (!llvm.ptr<6>) -> ()
    %121 = llvm.sitofp %99 : i32 to f32
    %122 = llvm.sitofp %100 : i32 to f32
    %123 = llvm.sitofp %118 : i32 to f32
    %124 = llvm.sext %117 : i32 to i64
    %125 = llvm.inttoptr %26 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 0 : i64}> : () -> ()
    llvm.store %101, %125 : i1, !llvm.ptr<6>
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 0 : i64, wait_pipe = 1 : i64}> : () -> ()
    %126 = llvm.inttoptr %27 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 0 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_18(%125, %126) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 0 : i64}> : () -> ()
    %127 = "hivm.intr.hivm.GET.SUBBLOCKID"() : () -> i64
    %128 = llvm.icmp "eq" %127, %17 : i64
    %129 = llvm.inttoptr %28 : i64 to !llvm.ptr<6>
    %130 = llvm.insertvalue %129, %10[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %131 = llvm.insertvalue %129, %130[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %132 = llvm.insertvalue %17, %131[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %133 = llvm.insertvalue %14, %132[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %134 = llvm.insertvalue %12, %133[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %135 = llvm.insertvalue %12, %134[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %136 = llvm.insertvalue %70, %135[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%82, %82, %17, %11, %70, %129, %129, %17, %11, %70) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %137 = llvm.inttoptr %29 : i64 to !llvm.ptr<6>
    %138 = llvm.insertvalue %137, %13[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %139 = llvm.insertvalue %137, %138[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %140 = llvm.insertvalue %17, %139[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %141 = llvm.insertvalue %14, %140[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %142 = llvm.insertvalue %70, %141[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%81, %81, %17, %14, %70, %137, %137, %17, %14, %70) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %143 = llvm.inttoptr %30 : i64 to !llvm.ptr<6>
    %144 = llvm.insertvalue %143, %13[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %145 = llvm.insertvalue %143, %144[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %146 = llvm.insertvalue %17, %145[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %147 = llvm.insertvalue %14, %146[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %148 = llvm.insertvalue %70, %147[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_float(%105, %105, %17, %14, %70, %143, %143, %17, %14, %70) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %149 = llvm.inttoptr %31 : i64 to !llvm.ptr<6>
    %150 = llvm.insertvalue %149, %10[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %151 = llvm.insertvalue %149, %150[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %152 = llvm.insertvalue %17, %151[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %153 = llvm.insertvalue %14, %152[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %154 = llvm.insertvalue %12, %153[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %155 = llvm.insertvalue %12, %154[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %156 = llvm.insertvalue %70, %155[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%82, %82, %17, %11, %70, %149, %149, %17, %11, %70) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %157 = llvm.inttoptr %32 : i64 to !llvm.ptr<6>
    %158 = llvm.insertvalue %157, %13[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %159 = llvm.insertvalue %157, %158[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %160 = llvm.insertvalue %17, %159[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %161 = llvm.insertvalue %14, %160[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %162 = llvm.insertvalue %70, %161[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%81, %81, %17, %14, %70, %157, %157, %17, %14, %70) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %163 = llvm.inttoptr %33 : i64 to !llvm.ptr<6>
    %164 = llvm.insertvalue %163, %13[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %165 = llvm.insertvalue %163, %164[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %166 = llvm.insertvalue %17, %165[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %167 = llvm.insertvalue %14, %166[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %168 = llvm.insertvalue %70, %167[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%105, %105, %17, %14, %70, %163, %163, %17, %14, %70) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.br ^bb4(%21, %136, %142, %148, %156, %162, %168 : i32, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>)
  ^bb4(%169: i32, %170: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %171: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %172: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %173: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %174: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %175: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>):  // 2 preds: ^bb3, ^bb18
    %176 = llvm.icmp "slt" %169, %117 : i32
    llvm.cond_br %176, ^bb5, ^bb19
  ^bb5:  // pred: ^bb4
    %177 = llvm.inttoptr %34 : i64 to !llvm.ptr<6>
    %178 = llvm.inttoptr %35 : i64 to !llvm.ptr<6>
    %179 = llvm.inttoptr %36 : i64 to !llvm.ptr<2>
    %180 = llvm.inttoptr %37 : i64 to !llvm.ptr<2>
    %181 = llvm.inttoptr %38 : i64 to !llvm.ptr<6>
    %182 = llvm.inttoptr %39 : i64 to !llvm.ptr<6>
    %183 = llvm.sext %169 : i32 to i64
    %184 = llvm.mul %183, %6 : i64
    %185 = llvm.add %124, %184 : i64
    %186 = llvm.intr.umin(%185, %72)  : (i64, i64) -> i64
    %187 = llvm.inttoptr %40 : i64 to !llvm.ptr<6>
    %188 = llvm.inttoptr %41 : i64 to !llvm.ptr<6>
    %189 = llvm.inttoptr %42 : i64 to !llvm.ptr<6>
    %190 = llvm.inttoptr %43 : i64 to !llvm.ptr<6>
    %191 = llvm.inttoptr %44 : i64 to !llvm.ptr<6>
    llvm.br ^bb6(%17 : i64)
  ^bb6(%192: i64):  // 2 preds: ^bb5, ^bb7
    %193 = llvm.icmp "slt" %192, %186 : i64
    llvm.cond_br %193, ^bb7, ^bb8
  ^bb7:  // pred: ^bb6
    %194 = llvm.add %192, %183 : i64
    %195 = llvm.trunc %194 : i64 to i32
    %196 = llvm.sitofp %195 : i32 to f32
    %197 = llvm.fcmp "olt" %196, %119 : f32
    %198 = llvm.zext %197 : i1 to i32
    %199 = llvm.mul %198, %195 : i32
    %200 = llvm.sub %71, %198 : i32
    %201 = llvm.add %113, %195 : i32
    %202 = llvm.sub %201, %108 : i32
    %203 = llvm.mul %200, %202 : i32
    %204 = llvm.add %199, %203 : i32
    %205 = llvm.mul %204, %20 : i32
    %206 = llvm.inttoptr %45 : i64 to !llvm.ptr<6>
    %207 = llvm.inttoptr %46 : i64 to !llvm.ptr<6>
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_0(%120, %205, %121, %122, %126, %123, %206, %207) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, i32, f32, f32, !llvm.ptr<6>, f32, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_merged_merged_vf_0(%188, %192, %189, %192, %190, %192, %206, %207, %187, %192, %191, %192) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, i64, !llvm.ptr<6>, i64, !llvm.ptr<6>, i64, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>, i64) -> ()
    %208 = llvm.add %192, %70 overflow<nsw> : i64
    llvm.br ^bb6(%208 : i64)
  ^bb8:  // pred: ^bb6
    %209 = llvm.inttoptr %47 : i64 to !llvm.ptr<6>
    %210 = llvm.inttoptr %48 : i64 to !llvm.ptr<6>
    llvm.br ^bb9(%17, %172, %171, %175, %174 : i64, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>)
  ^bb9(%211: i64, %212: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %213: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %214: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %215: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>):  // 2 preds: ^bb8, ^bb14
    %216 = llvm.icmp "slt" %211, %186 : i64
    llvm.cond_br %216, ^bb10, ^bb15
  ^bb10:  // pred: ^bb9
    %217 = llvm.add %211, %4 : i64
    %218 = llvm.add %211, %3 : i64
    %219 = llvm.add %211, %2 : i64
    %220 = llvm.add %211, %1 : i64
    %221 = llvm.inttoptr %49 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 0 : i64}> : () -> ()
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_4(%187, %211, %181, %arg12, %221) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, i64, !llvm.ptr<6>, f32, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCK.mode"(%218) <{pipe = 1 : i64}> : (i64) -> ()
    %222 = llvm.inttoptr %50 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%188, %188, %17, %5, %70, %222, %222, %17, %5, %70) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_5(%221, %222, %211) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i64) -> ()
    %223 = llvm.inttoptr %51 : i64 to !llvm.ptr<6>
    %224 = llvm.extractvalue %212[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_6(%224, %222, %211, %223) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>) -> ()
    %225 = llvm.inttoptr %52 : i64 to !llvm.ptr<6>
    %226 = llvm.inttoptr %53 : i64 to !llvm.ptr<6>
    %227 = llvm.extractvalue %212[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_7(%227, %223, %225, %211, %226) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>) -> ()
    %228 = llvm.mul %211, %14 : i64
    llvm.call @copy_ubuf_to_ubuf_1d_float(%226, %226, %17, %14, %70, %209, %209, %228, %14, %70) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %229 = llvm.inttoptr %54 : i64 to !llvm.ptr<6>
    %230 = llvm.inttoptr %29 : i64 to !llvm.ptr<6>
    %231 = llvm.insertvalue %230, %13[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %232 = llvm.insertvalue %230, %231[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %233 = llvm.insertvalue %17, %232[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %234 = llvm.insertvalue %14, %233[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %235 = llvm.insertvalue %70, %234[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %236 = llvm.inttoptr %55 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%189, %189, %17, %5, %70, %236, %236, %17, %5, %70) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %237 = llvm.extractvalue %213[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_8(%221, %223, %236, %211, %229, %237, %226, %230) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %238 = llvm.inttoptr %56 : i64 to !llvm.ptr<6>
    %239 = llvm.mul %211, %8 : i64
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%190, %190, %239, %8, %70, %238, %238, %17, %8, %70) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%229, %229, %17, %7, %70, %238, %238, %17, %7, %70) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %240 = llvm.inttoptr %57 : i64 to !llvm.ptr<6>
    %241 = llvm.inttoptr %58 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 13 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_merged_vf_2(%238, %240, %191, %211, %182, %arg12, %241) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>, f32, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCK.mode"(%217) <{pipe = 1 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCK.mode"(%220) <{pipe = 5 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %128, ^bb11, ^bb12
  ^bb11:  // pred: ^bb10
    %242 = llvm.mul %211, %8 : i64
    llvm.call @copy_ubuf_to_cbuf_2d_bfloat16_t(%240, %240, %17, %9, %12, %0, %70, %179, %179, %242, %9, %12, %12, %70) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64) -> ()
    llvm.br ^bb12
  ^bb12:  // 2 preds: ^bb10, ^bb11
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 12 : i64}> : () -> ()
    %243 = llvm.inttoptr %59 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%188, %188, %17, %5, %70, %243, %243, %17, %5, %70) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_11(%241, %243, %211) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i64) -> ()
    %244 = llvm.inttoptr %60 : i64 to !llvm.ptr<6>
    %245 = llvm.extractvalue %214[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_12(%245, %243, %211, %244) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>) -> ()
    %246 = llvm.inttoptr %61 : i64 to !llvm.ptr<6>
    %247 = llvm.inttoptr %62 : i64 to !llvm.ptr<6>
    %248 = llvm.extractvalue %214[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_13(%248, %244, %246, %211, %247) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>) -> ()
    %249 = llvm.mul %211, %14 : i64
    llvm.call @copy_ubuf_to_ubuf_1d_float(%247, %247, %17, %14, %70, %210, %210, %249, %14, %70) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %250 = llvm.inttoptr %63 : i64 to !llvm.ptr<6>
    %251 = llvm.inttoptr %32 : i64 to !llvm.ptr<6>
    %252 = llvm.insertvalue %251, %13[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %253 = llvm.insertvalue %251, %252[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %254 = llvm.insertvalue %17, %253[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %255 = llvm.insertvalue %14, %254[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %256 = llvm.insertvalue %70, %255[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %257 = llvm.inttoptr %64 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%189, %189, %17, %5, %70, %257, %257, %17, %5, %70) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %258 = llvm.extractvalue %215[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_14(%241, %244, %257, %211, %250, %258, %247, %251) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %259 = llvm.inttoptr %65 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%190, %190, %239, %8, %70, %259, %259, %17, %8, %70) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%250, %250, %17, %7, %70, %259, %259, %17, %7, %70) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %260 = llvm.inttoptr %66 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_15(%259, %260) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCK.mode"(%219) <{pipe = 5 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %128, ^bb13, ^bb14
  ^bb13:  // pred: ^bb12
    %261 = llvm.mul %211, %8 : i64
    llvm.call @copy_ubuf_to_cbuf_2d_bfloat16_t(%260, %260, %17, %9, %12, %0, %70, %180, %180, %261, %9, %12, %12, %70) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64) -> ()
    llvm.br ^bb14
  ^bb14:  // 2 preds: ^bb12, ^bb13
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 11 : i64}> : () -> ()
    %262 = llvm.inttoptr %30 : i64 to !llvm.ptr<6>
    %263 = llvm.insertvalue %262, %13[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %264 = llvm.insertvalue %262, %263[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %265 = llvm.insertvalue %17, %264[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %266 = llvm.insertvalue %14, %265[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %267 = llvm.insertvalue %70, %266[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%223, %223, %17, %14, %70, %262, %262, %17, %14, %70) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %268 = llvm.inttoptr %33 : i64 to !llvm.ptr<6>
    %269 = llvm.insertvalue %268, %13[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %270 = llvm.insertvalue %268, %269[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %271 = llvm.insertvalue %17, %270[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %272 = llvm.insertvalue %14, %271[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %273 = llvm.insertvalue %70, %272[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%244, %244, %17, %14, %70, %268, %268, %17, %14, %70) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %274 = llvm.add %211, %70 overflow<nsw> : i64
    llvm.br ^bb9(%274, %267, %235, %273, %256 : i64, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>)
  ^bb15:  // pred: ^bb9
    llvm.br ^bb16(%17, %170, %173 : i64, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>)
  ^bb16(%275: i64, %276: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %277: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>):  // 2 preds: ^bb15, ^bb17
    %278 = llvm.icmp "slt" %275, %186 : i64
    llvm.cond_br %278, ^bb17, ^bb18
  ^bb17:  // pred: ^bb16
    %279 = llvm.add %275, %70 : i64
    %280 = llvm.inttoptr %28 : i64 to !llvm.ptr<6>
    %281 = llvm.insertvalue %280, %10[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %282 = llvm.insertvalue %280, %281[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %283 = llvm.insertvalue %17, %282[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %284 = llvm.insertvalue %14, %283[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %285 = llvm.insertvalue %12, %284[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %286 = llvm.insertvalue %12, %285[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %287 = llvm.insertvalue %70, %286[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %288 = llvm.inttoptr %31 : i64 to !llvm.ptr<6>
    %289 = llvm.insertvalue %288, %10[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %290 = llvm.insertvalue %288, %289[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %291 = llvm.insertvalue %17, %290[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %292 = llvm.insertvalue %14, %291[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %293 = llvm.insertvalue %12, %292[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %294 = llvm.insertvalue %12, %293[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %295 = llvm.insertvalue %70, %294[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 0 : i64}> : () -> ()
    %296 = llvm.extractvalue %276[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %297 = llvm.extractvalue %277[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_16(%209, %275, %210, %177, %296, %178, %297, %280, %288) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, i64, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCK.mode"(%279) <{pipe = 1 : i64}> : (i64) -> ()
    %298 = llvm.add %275, %70 overflow<nsw> : i64
    llvm.br ^bb16(%298, %287, %295 : i64, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>)
  ^bb18:  // pred: ^bb16
    %299 = llvm.add %169, %73 overflow<nsw> : i32
    llvm.br ^bb4(%299, %276, %213, %212, %277, %215, %214 : i32, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>)
  ^bb19:  // pred: ^bb4
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %300 = llvm.mul %92, %arg13 : i32
    %301 = llvm.sext %300 : i32 to i64
    %302 = llvm.sext %arg14 : i32 to i64
    %303 = llvm.inttoptr %67 : i64 to !llvm.ptr<6>
    %304 = llvm.sext %arg13 : i32 to i64
    %305 = llvm.add %301, %304 : i64
    %306 = llvm.inttoptr %68 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %307 = llvm.extractvalue %171[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %308 = llvm.extractvalue %170[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %309 = llvm.extractvalue %174[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %310 = llvm.extractvalue %173[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_merged_vf_3(%307, %308, %303, %309, %310, %306) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %128, ^bb20, ^bb21
  ^bb20:  // pred: ^bb19
    llvm.call @store_ubuf_to_gm_2d_bfloat16_t(%303, %303, %17, %14, %12, %12, %70, %arg3, %arg3, %301, %14, %12, %302, %70, %21) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i32) -> ()
    llvm.br ^bb21
  ^bb21:  // 2 preds: ^bb19, ^bb20
    llvm.cond_br %128, ^bb22, ^bb23
  ^bb22:  // pred: ^bb21
    "hivm.intr.hivm.BARRIER"() <{pipe = 5 : i64}> : () -> ()
    llvm.call @store_ubuf_to_gm_2d_bfloat16_t(%306, %306, %17, %103, %104, %12, %70, %arg3, %arg3, %305, %103, %104, %302, %70, %21) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i32) -> ()
    llvm.br ^bb23
  ^bb23:  // 2 preds: ^bb21, ^bb22
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.br ^bb24
  ^bb24:  // 2 preds: ^bb2, ^bb23
    %311 = llvm.add %88, %71 overflow<nsw> : i32
    llvm.br ^bb1(%311 : i32)
  ^bb25:  // pred: ^bb1
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 0 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 6 : i64}> : () -> ()
    %312 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %313 = "hivm.intr.hivm.SBITSET1"(%312, %16) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%313) : (i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 6 : i64}> : () -> ()
    llvm.return
  }
}


bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
ld.lld: warning: -z separate-code and -z separate-loadable-segments will be ignored
