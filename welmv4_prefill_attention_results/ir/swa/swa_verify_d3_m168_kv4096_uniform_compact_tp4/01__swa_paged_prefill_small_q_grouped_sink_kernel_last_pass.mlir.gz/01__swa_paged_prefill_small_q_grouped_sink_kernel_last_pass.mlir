// -----// IR Dump After AppendUsePrintDebugData (append-use-print-debug-data) //----- //
module attributes {dlti.target_system_spec = #dlti.target_system_spec<"NPU" : #hacc.target_device_spec<#dlti.dl_entry<"AI_CORE_COUNT", 28 : i32>, #dlti.dl_entry<"CUBE_CORE_COUNT", 28 : i32>, #dlti.dl_entry<"VECTOR_CORE_COUNT", 56 : i32>, #dlti.dl_entry<"UB_SIZE", 2031616 : i32>, #dlti.dl_entry<"L1_SIZE", 4194304 : i32>, #dlti.dl_entry<"L0A_SIZE", 524288 : i32>, #dlti.dl_entry<"L0B_SIZE", 524288 : i32>, #dlti.dl_entry<"L0C_SIZE", 2097152 : i32>, #dlti.dl_entry<"UB_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L1_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L0C_ALIGN_SIZE", 4096 : i32>, #dlti.dl_entry<"MINIMAL_D_CACHE_SIZE", 262144 : i32>, #dlti.dl_entry<"MAXIMUM_D_CACHE_SIZE", 983040 : i32>, #dlti.dl_entry<"ARCH", "dav-c310">>>, hacc.target = #hacc.target<"Ascend950PR_957b">, hivm.aic_bitcode = #hivm.aic_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.aic.c310.bc">, hivm.aiv_bitcode = #hivm.aiv_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.aiv.c310.bc">, hivm.host_bitcode = #hivm.host_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/host-a5.bc">, hivm.mix_aic_bitcode = #hivm.mix_aic_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.mix.aic.c310.bc">, hivm.mix_aiv_bitcode = #hivm.mix_aiv_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.mix.aiv.c310.bc">, hivm.module_core_type = #hivm.module_core_type<MIX>} {
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_merged_merged_vf_1(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>, %arg8: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(256 : i32) : i32
    %4 = llvm.mlir.constant(64 : i32) : i32
    %5 = llvm.mlir.constant(3 : i32) : i32
    %6 = llvm.mlir.constant(8 : i32) : i32
    %7 = llvm.mlir.constant(7 : i32) : i32
    %8 = llvm.mlir.constant(256 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%9: i32):  // 2 preds: ^bb0, ^bb5
    %10 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %10, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %11 = llvm.sext %9 : i32 to i64
    llvm.br ^bb3(%2 : i32)
  ^bb3(%12: i32):  // 2 preds: ^bb2, ^bb4
    %13 = llvm.icmp "slt" %12, %3 : i32
    llvm.cond_br %13, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %14 = llvm.sext %12 : i32 to i64
    %15 = llvm.mul %11, %8 : i64
    %16 = llvm.add %15, %14 : i64
    %17 = llvm.getelementptr %arg1[%16] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %18 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%17, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %19 = llvm.getelementptr %arg0[%11] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %20 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%19, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.vdiv.s.x"(%18, %20, %21) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %23 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %24 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%22, %23, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %25 = llvm.mul %11, %8 : i64
    %26 = llvm.add %25, %14 : i64
    %27 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %28 = llvm.getelementptr %arg2[%26] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%24, %28, %2, %7, %2, %27) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %29 = llvm.add %12, %4 overflow<nsw> : i32
    llvm.br ^bb3(%29 : i32)
  ^bb5:  // pred: ^bb3
    %30 = llvm.add %9, %0 overflow<nsw> : i32
    llvm.br ^bb1(%30 : i32)
  ^bb6:  // pred: ^bb1
    llvm.br ^bb7(%2 : i32)
  ^bb7(%31: i32):  // 2 preds: ^bb6, ^bb11
    %32 = llvm.icmp "slt" %31, %1 : i32
    llvm.cond_br %32, ^bb8, ^bb12
  ^bb8:  // pred: ^bb7
    %33 = llvm.sext %31 : i32 to i64
    llvm.br ^bb9(%2 : i32)
  ^bb9(%34: i32):  // 2 preds: ^bb8, ^bb10
    %35 = llvm.icmp "slt" %34, %3 : i32
    llvm.cond_br %35, ^bb10, ^bb11
  ^bb10:  // pred: ^bb9
    %36 = llvm.sext %34 : i32 to i64
    %37 = llvm.mul %33, %8 : i64
    %38 = llvm.add %37, %36 : i64
    %39 = llvm.getelementptr %arg4[%38] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %40 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%39, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %41 = llvm.getelementptr %arg3[%33] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %42 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%41, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %43 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %44 = "hivm_regbaseintrins.intr.hivm.vdiv.s.x"(%40, %42, %43) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %45 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %46 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%44, %45, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %47 = llvm.mul %33, %8 : i64
    %48 = llvm.add %47, %36 : i64
    %49 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %50 = llvm.getelementptr %arg5[%48] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%46, %50, %2, %7, %2, %49) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %51 = llvm.add %34, %4 overflow<nsw> : i32
    llvm.br ^bb9(%51 : i32)
  ^bb11:  // pred: ^bb9
    %52 = llvm.add %31, %0 overflow<nsw> : i32
    llvm.br ^bb7(%52 : i32)
  ^bb12:  // pred: ^bb7
    llvm.br ^bb13(%2 : i32)
  ^bb13(%53: i32):  // 2 preds: ^bb12, ^bb17
    %54 = llvm.icmp "slt" %53, %1 : i32
    llvm.cond_br %54, ^bb14, ^bb18
  ^bb14:  // pred: ^bb13
    %55 = llvm.sext %53 : i32 to i64
    llvm.br ^bb15(%2 : i32)
  ^bb15(%56: i32):  // 2 preds: ^bb14, ^bb16
    %57 = llvm.icmp "slt" %56, %3 : i32
    llvm.cond_br %57, ^bb16, ^bb17
  ^bb16:  // pred: ^bb15
    %58 = llvm.sext %56 : i32 to i64
    %59 = llvm.mul %55, %8 : i64
    %60 = llvm.add %59, %58 : i64
    %61 = llvm.getelementptr %arg7[%60] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %62 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%61, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %63 = llvm.getelementptr %arg6[%55] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %64 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%63, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %65 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %66 = "hivm_regbaseintrins.intr.hivm.vdiv.s.x"(%62, %64, %65) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %67 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %68 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%66, %67, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %69 = llvm.mul %55, %8 : i64
    %70 = llvm.add %69, %58 : i64
    %71 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %72 = llvm.getelementptr %arg8[%70] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%68, %72, %2, %7, %2, %71) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %73 = llvm.add %56, %4 overflow<nsw> : i32
    llvm.br ^bb15(%73 : i32)
  ^bb17:  // pred: ^bb15
    %74 = llvm.add %53, %0 overflow<nsw> : i32
    llvm.br ^bb13(%74 : i32)
  ^bb18:  // pred: ^bb13
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_merged_merged_vf_0(%arg0: !llvm.ptr<6>, %arg1: i64, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>, %arg5: i64, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>, %arg8: !llvm.ptr<6>, %arg9: !llvm.ptr<6>, %arg10: i64, %arg11: !llvm.ptr<6>, %arg12: i64, %arg13: !llvm.ptr<6>, %arg14: i64) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(1 : i32) : i32
    %2 = llvm.mlir.constant(16 : i32) : i32
    %3 = llvm.mlir.constant(0 : i32) : i32
    %4 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %5 = llvm.mlir.constant(0xFF800000 : f32) : f32
    %6 = llvm.mlir.constant(0.000000e+00 : bf16) : bf16
    %7 = llvm.mlir.constant(-1.000000e+00 : f16) : f16
    %8 = llvm.mlir.constant(0.000000e+00 : f16) : f16
    %9 = llvm.mlir.constant(9 : i32) : i32
    %10 = llvm.mlir.constant(8 : i32) : i32
    %11 = llvm.mlir.constant(24 : i32) : i32
    %12 = llvm.mlir.constant(8 : index) : i64
    %13 = llvm.mlir.constant(1024 : index) : i64
    %14 = llvm.mlir.constant(64 : index) : i64
    %15 = llvm.mlir.constant(256 : index) : i64
    %16 = llvm.mlir.constant(6 : index) : i64
    %17 = llvm.mlir.constant(1536 : index) : i64
    %18 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%9, %3) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %19 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%8, %18, %1) : (f16, vector<256xi1>, i32) -> vector<128xf16>
    %20 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%9, %3) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %21 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%7, %20, %1) : (f16, vector<256xi1>, i32) -> vector<128xf16>
    %22 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%9, %3) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %23 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%6, %22, %1) : (bf16, vector<256xi1>, i32) -> vector<128xbf16>
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%10, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%5, %24, %1) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%10, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %27 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%4, %26, %1) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %28 = llvm.mul %arg3, %16 : i64
    %29 = llvm.mul %arg1, %16 : i64
    %30 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %31 = llvm.getelementptr %arg0[%29] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %32 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %33 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%25, %31, %11, %32) : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %34 = llvm.extractvalue %33[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %35 = llvm.extractvalue %33[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%34, %35, %3, %3) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %36 = llvm.getelementptr %arg2[%28] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %37 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %38 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%27, %36, %11, %37) : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %39 = llvm.extractvalue %38[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %40 = llvm.extractvalue %38[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%39, %40, %3, %3) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.br ^bb1(%3 : i32)
  ^bb1(%41: i32):  // 2 preds: ^bb0, ^bb2
    %42 = llvm.icmp "slt" %41, %2 : i32
    llvm.cond_br %42, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %43 = llvm.sext %41 : i32 to i64
    %44 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%10, %3) {mask_bit_width = 16 : i32, mask_op_idx = 1 : i32} : (i32, i32) -> vector<256xi1>
    %45 = llvm.mul %arg5, %13 : i64
    %46 = llvm.mul %43, %14 : i64
    %47 = llvm.add %45, %46 : i64
    %48 = llvm.getelementptr %arg4[%47] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%23, %48, %3, %1, %3, %44) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %49 = llvm.add %41, %1 overflow<nsw> : i32
    llvm.br ^bb1(%49 : i32)
  ^bb3:  // pred: ^bb1
    llvm.br ^bb4(%3 : i32)
  ^bb4(%50: i32):  // 2 preds: ^bb3, ^bb5
    %51 = llvm.icmp "slt" %50, %0 : i32
    llvm.cond_br %51, ^bb5, ^bb6
  ^bb5:  // pred: ^bb4
    %52 = llvm.sext %50 : i32 to i64
    %53 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%10, %3) {mask_bit_width = 16 : i32, mask_op_idx = 2 : i32} : (i32, i32) -> vector<256xi1>
    %54 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%arg6, %3, %3, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %55 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%3, %3) : (i32, i32) -> vector<256xi1>
    %56 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%54, %55) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %57 = llvm.extractvalue %56[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %58 = "hivm_regbaseintrins.intr.hivm.vsel"(%21, %19, %57) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    %59 = "hivm_regbaseintrins.intr.hivm.vcmp.ne.s.z"(%58, %19, %53) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<256xi1>
    %60 = llvm.mul %arg10, %17 : i64
    %61 = llvm.mul %52, %15 : i64
    %62 = llvm.add %60, %61 : i64
    %63 = llvm.udiv %62, %12  : i64
    %64 = llvm.getelementptr %arg9[%63] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %65 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %66 = "hivm_regbaseintrins.intr.hivm.pstu.b16"(%59, %64, %65) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %67 = llvm.extractvalue %66[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %68 = llvm.extractvalue %66[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%67, %68, %3, %3) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %69 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%arg7, %3, %3, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %70 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%3, %3) : (i32, i32) -> vector<256xi1>
    %71 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%69, %70) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %72 = llvm.extractvalue %71[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %73 = "hivm_regbaseintrins.intr.hivm.vsel"(%21, %19, %72) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    %74 = "hivm_regbaseintrins.intr.hivm.vcmp.ne.s.z"(%73, %19, %53) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<256xi1>
    %75 = llvm.mul %arg12, %17 : i64
    %76 = llvm.mul %52, %15 : i64
    %77 = llvm.add %75, %76 : i64
    %78 = llvm.udiv %77, %12  : i64
    %79 = llvm.getelementptr %arg11[%78] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %80 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %81 = "hivm_regbaseintrins.intr.hivm.pstu.b16"(%74, %79, %80) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %82 = llvm.extractvalue %81[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %83 = llvm.extractvalue %81[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%82, %83, %3, %3) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %84 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%arg8, %3, %3, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %85 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%3, %3) : (i32, i32) -> vector<256xi1>
    %86 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%84, %85) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %87 = llvm.extractvalue %86[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %88 = "hivm_regbaseintrins.intr.hivm.vsel"(%21, %19, %87) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    %89 = "hivm_regbaseintrins.intr.hivm.vcmp.ne.s.z"(%88, %19, %53) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<256xi1>
    %90 = llvm.mul %arg14, %17 : i64
    %91 = llvm.mul %52, %15 : i64
    %92 = llvm.add %90, %91 : i64
    %93 = llvm.udiv %92, %12  : i64
    %94 = llvm.getelementptr %arg13[%93] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %95 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %96 = "hivm_regbaseintrins.intr.hivm.pstu.b16"(%89, %94, %95) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %97 = llvm.extractvalue %96[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %98 = llvm.extractvalue %96[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%97, %98, %3, %3) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %99 = llvm.add %50, %1 overflow<nsw> : i32
    llvm.br ^bb4(%99 : i32)
  ^bb6:  // pred: ^bb4
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_merged_vf_3(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>, %arg5: f32, %arg6: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(8 : i32) : i32
    %1 = llvm.mlir.constant(-1.000000e+06 : f32) : f32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(16 : i32) : i32
    %4 = llvm.mlir.constant(1 : i32) : i32
    %5 = llvm.mlir.constant(6 : i32) : i32
    %6 = llvm.mlir.constant(1114112 : i32) : i32
    %7 = llvm.mlir.constant(8 : index) : i64
    %8 = llvm.mlir.constant(2 : i32) : i32
    %9 = llvm.mlir.constant(16 : index) : i64
    %10 = llvm.mlir.constant(272 : index) : i64
    %11 = llvm.mlir.constant(256 : index) : i64
    %12 = llvm.mlir.constant(1536 : index) : i64
    %13 = llvm.mlir.constant(384 : index) : i64
    %14 = llvm.mlir.constant(64 : index) : i64
    %15 = llvm.mlir.constant(0 : index) : i64
    %16 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %17 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%1, %16, %4) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    llvm.br ^bb1(%2 : i32)
  ^bb1(%18: i32):  // 2 preds: ^bb0, ^bb2
    %19 = llvm.icmp "slt" %18, %3 : i32
    llvm.cond_br %19, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %20 = llvm.sext %18 : i32 to i64
    %21 = llvm.mul %20, %14 : i64
    %22 = llvm.getelementptr %arg0[%21] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %23 = llvm.mul %15, %14 : i64
    %24 = llvm.add %23, %15 : i64
    %25 = llvm.getelementptr %22[%24] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %26 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%25, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %27 = llvm.mul %20, %9 : i64
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%0, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %29 = llvm.getelementptr %arg1[%27] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %30 = llvm.mul %15, %10 : i64
    %31 = llvm.add %30, %15 : i64
    %32 = llvm.getelementptr %29[%31] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vsstb.v128bf16"(%26, %32, %6, %2, %28) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, vector<256xi1>) -> ()
    %33 = llvm.add %18, %4 overflow<nsw> : i32
    llvm.br ^bb1(%33 : i32)
  ^bb3:  // pred: ^bb1
    llvm.br ^bb4(%2 : i32)
  ^bb4(%34: i32):  // 2 preds: ^bb3, ^bb5
    %35 = llvm.icmp "slt" %34, %5 : i32
    llvm.cond_br %35, ^bb5, ^bb6
  ^bb5:  // pred: ^bb4
    %36 = llvm.sext %34 : i32 to i64
    %37 = llvm.mul %arg3, %12 : i64
    %38 = llvm.mul %36, %11 : i64
    %39 = llvm.add %37, %38 : i64
    %40 = llvm.udiv %39, %7  : i64
    %41 = llvm.getelementptr %arg2[%40] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %42 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%41, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %43 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %44 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%42, %43) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %45 = llvm.extractvalue %44[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %46 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%45, %43) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %47 = llvm.extractvalue %46[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %48 = llvm.mul %arg3, %13 : i64
    %49 = llvm.mul %36, %14 : i64
    %50 = llvm.add %48, %49 : i64
    %51 = llvm.getelementptr %arg4[%50] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %52 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%51, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %53 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %54 = "hivm_regbaseintrins.intr.hivm.vmuls.s.x"(%52, %arg5, %53) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %55 = "hivm_regbaseintrins.intr.hivm.vsel"(%54, %17, %47) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %56 = llvm.mul %36, %14 : i64
    %57 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %58 = llvm.getelementptr %arg6[%56] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%55, %58, %2, %8, %2, %57) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %59 = llvm.add %34, %4 overflow<nsw> : i32
    llvm.br ^bb4(%59 : i32)
  ^bb6:  // pred: ^bb4
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_merged_vf_2(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>, %arg5: f32, %arg6: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(8 : i32) : i32
    %1 = llvm.mlir.constant(-1.000000e+06 : f32) : f32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(16 : i32) : i32
    %4 = llvm.mlir.constant(1 : i32) : i32
    %5 = llvm.mlir.constant(6 : i32) : i32
    %6 = llvm.mlir.constant(1114112 : i32) : i32
    %7 = llvm.mlir.constant(8 : index) : i64
    %8 = llvm.mlir.constant(2 : i32) : i32
    %9 = llvm.mlir.constant(16 : index) : i64
    %10 = llvm.mlir.constant(272 : index) : i64
    %11 = llvm.mlir.constant(256 : index) : i64
    %12 = llvm.mlir.constant(1536 : index) : i64
    %13 = llvm.mlir.constant(384 : index) : i64
    %14 = llvm.mlir.constant(64 : index) : i64
    %15 = llvm.mlir.constant(0 : index) : i64
    %16 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %17 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%1, %16, %4) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    llvm.br ^bb1(%2 : i32)
  ^bb1(%18: i32):  // 2 preds: ^bb0, ^bb2
    %19 = llvm.icmp "slt" %18, %3 : i32
    llvm.cond_br %19, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %20 = llvm.sext %18 : i32 to i64
    %21 = llvm.mul %20, %14 : i64
    %22 = llvm.getelementptr %arg0[%21] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %23 = llvm.mul %15, %14 : i64
    %24 = llvm.add %23, %15 : i64
    %25 = llvm.getelementptr %22[%24] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %26 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%25, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %27 = llvm.mul %20, %9 : i64
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%0, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %29 = llvm.getelementptr %arg1[%27] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %30 = llvm.mul %15, %10 : i64
    %31 = llvm.add %30, %15 : i64
    %32 = llvm.getelementptr %29[%31] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vsstb.v128bf16"(%26, %32, %6, %2, %28) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, vector<256xi1>) -> ()
    %33 = llvm.add %18, %4 overflow<nsw> : i32
    llvm.br ^bb1(%33 : i32)
  ^bb3:  // pred: ^bb1
    llvm.br ^bb4(%2 : i32)
  ^bb4(%34: i32):  // 2 preds: ^bb3, ^bb5
    %35 = llvm.icmp "slt" %34, %5 : i32
    llvm.cond_br %35, ^bb5, ^bb6
  ^bb5:  // pred: ^bb4
    %36 = llvm.sext %34 : i32 to i64
    %37 = llvm.mul %arg3, %12 : i64
    %38 = llvm.mul %36, %11 : i64
    %39 = llvm.add %37, %38 : i64
    %40 = llvm.udiv %39, %7  : i64
    %41 = llvm.getelementptr %arg2[%40] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %42 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%41, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %43 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %44 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%42, %43) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %45 = llvm.extractvalue %44[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %46 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%45, %43) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %47 = llvm.extractvalue %46[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %48 = llvm.mul %arg3, %13 : i64
    %49 = llvm.mul %36, %14 : i64
    %50 = llvm.add %48, %49 : i64
    %51 = llvm.getelementptr %arg4[%50] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %52 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%51, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %53 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %54 = "hivm_regbaseintrins.intr.hivm.vmuls.s.x"(%52, %arg5, %53) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %55 = "hivm_regbaseintrins.intr.hivm.vsel"(%54, %17, %47) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %56 = llvm.mul %36, %14 : i64
    %57 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %58 = llvm.getelementptr %arg6[%56] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%55, %58, %2, %8, %2, %57) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %59 = llvm.add %34, %4 overflow<nsw> : i32
    llvm.br ^bb4(%59 : i32)
  ^bb6:  // pred: ^bb4
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_merged_vf_0(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(64 : i32) : i32
    %1 = llvm.mlir.constant(256 : i32) : i32
    %2 = llvm.mlir.constant(1 : i32) : i32
    %3 = llvm.mlir.constant(6 : i32) : i32
    %4 = llvm.mlir.constant(0 : i32) : i32
    %5 = llvm.mlir.constant(1.000000e+00 : f32) : f32
    %6 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %7 = llvm.mlir.constant(8 : i32) : i32
    %8 = llvm.mlir.constant(2 : i32) : i32
    %9 = llvm.mlir.constant(256 : index) : i64
    %10 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %11 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%6, %10, %2) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %12 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %13 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%5, %12, %2) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %14 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%3) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %15 = llvm.extractvalue %14[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%13, %arg0, %4, %8, %4, %15) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.br ^bb1(%4 : i32)
  ^bb1(%16: i32):  // 2 preds: ^bb0, ^bb5
    %17 = llvm.icmp "slt" %16, %3 : i32
    llvm.cond_br %17, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %16 : i32 to i64
    llvm.br ^bb3(%4 : i32)
  ^bb3(%19: i32):  // 2 preds: ^bb2, ^bb4
    %20 = llvm.icmp "slt" %19, %1 : i32
    llvm.cond_br %20, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %21 = llvm.sext %19 : i32 to i64
    %22 = llvm.mul %18, %9 : i64
    %23 = llvm.add %22, %21 : i64
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = llvm.getelementptr %arg1[%23] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%11, %25, %4, %8, %4, %24) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %26 = llvm.add %19, %0 overflow<nsw> : i32
    llvm.br ^bb3(%26 : i32)
  ^bb5:  // pred: ^bb3
    %27 = llvm.add %16, %2 overflow<nsw> : i32
    llvm.br ^bb1(%27 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aic(%arg0: i64, %arg1: !llvm.ptr<1>, %arg2: !llvm.ptr<1>, %arg3: !llvm.ptr<1>, %arg4: !llvm.ptr<1>, %arg5: !llvm.ptr<1>, %arg6: !llvm.ptr<1>, %arg7: !llvm.ptr<1>, %arg8: i32, %arg9: !llvm.ptr<1>, %arg10: !llvm.ptr<1>, %arg11: !llvm.ptr<1>, %arg12: f32, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32, %arg17: i32, %arg18: i32, %arg19: i32, %arg20: i32, %arg21: i32, %arg22: i32, %arg23: i32, %arg24: i32, %arg25: i32, %arg26: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, hivm.vf_mode = #hivm.vf_mode<SIMD>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, mix_mode = "mix", parallel_mode = "simd"} {
    %0 = llvm.mlir.constant(-1 : index) : i64
    %1 = llvm.mlir.constant(384 : index) : i64
    %2 = llvm.mlir.constant(1536 : index) : i64
    %3 = llvm.mlir.constant(8 : index) : i64
    %4 = llvm.mlir.constant(3 : index) : i64
    %5 = llvm.mlir.constant(48 : i64) : i64
    %6 = llvm.mlir.constant(60 : i64) : i64
    %7 = llvm.mlir.constant(16384 : index) : i64
    %8 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %9 = llvm.mlir.constant(4096 : index) : i64
    %10 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %11 = llvm.mlir.constant(1024 : index) : i64
    %12 = llvm.mlir.constant(16 : index) : i64
    %13 = llvm.mlir.constant(4 : index) : i64
    %14 = llvm.mlir.constant(0 : index) : i64
    %15 = llvm.mlir.constant(0 : i8) : i8
    %16 = llvm.mlir.constant(false) : i1
    %17 = llvm.mlir.constant(1.000000e+00 : f32) : f32
    %18 = llvm.mlir.constant(49600 : i64) : i64
    %19 = llvm.mlir.constant(46528 : i64) : i64
    %20 = llvm.mlir.constant(43456 : i64) : i64
    %21 = llvm.mlir.constant(32768 : i64) : i64
    %22 = llvm.mlir.constant(24576 : i64) : i64
    %23 = llvm.mlir.constant(31168 : i64) : i64
    %24 = llvm.mlir.constant(18880 : i64) : i64
    %25 = llvm.mlir.constant(6592 : i64) : i64
    %26 = llvm.mlir.constant(2 : i32) : i32
    %27 = llvm.mlir.constant(0 : i32) : i32
    %28 = llvm.mlir.constant(64 : i32) : i32
    %29 = llvm.mlir.constant(63 : i32) : i32
    %30 = llvm.mlir.constant(511 : i32) : i32
    %31 = llvm.mlir.constant(1 : index) : i64
    %32 = llvm.mlir.constant(6 : index) : i64
    %33 = llvm.mlir.constant(256 : index) : i64
    %34 = llvm.mlir.constant(0.000000e+00 : bf16) : bf16
    %35 = llvm.mlir.constant(64 : index) : i64
    %36 = llvm.mlir.constant(1 : i32) : i32
    %37 = llvm.mlir.constant(true) : i1
    %38 = llvm.mlir.constant(2 : index) : i64
    %39 = llvm.mlir.constant(2 : i64) : i64
    %40 = llvm.mlir.constant(1 : i64) : i64
    %41 = llvm.mlir.constant(4 : i64) : i64
    %42 = llvm.mlir.constant(5 : i64) : i64
    %43 = llvm.mlir.constant(3 : i64) : i64
    %44 = llvm.mlir.constant(-1 : i64) : i64
    %45 = llvm.mlir.constant(159744 : i64) : i64
    %46 = llvm.mlir.constant(73728 : i64) : i64
    %47 = llvm.mlir.constant(12288 : i64) : i64
    %48 = llvm.mlir.constant(90112 : i64) : i64
    %49 = llvm.mlir.constant(28672 : i64) : i64
    %50 = llvm.mlir.constant(106496 : i64) : i64
    %51 = llvm.mlir.constant(45056 : i64) : i64
    %52 = llvm.mlir.constant(126976 : i64) : i64
    %53 = llvm.mlir.constant(36864 : i64) : i64
    %54 = llvm.mlir.constant(65536 : i64) : i64
    %55 = llvm.mlir.constant(4096 : i64) : i64
    %56 = llvm.mlir.constant(69632 : i64) : i64
    %57 = llvm.mlir.constant(110592 : i64) : i64
    %58 = llvm.mlir.constant(8192 : i64) : i64
    %59 = llvm.mlir.constant(118784 : i64) : i64
    %60 = llvm.mlir.constant(16384 : i64) : i64
    %61 = llvm.mlir.constant(102400 : i64) : i64
    %62 = llvm.mlir.constant(0 : i64) : i64
    %63 = llvm.mlir.constant(61440 : i64) : i64
    %64 = llvm.inttoptr %62 : i64 to !llvm.ptr<5>
    %65 = llvm.insertvalue %64, %10[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %66 = llvm.insertvalue %64, %65[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %67 = llvm.insertvalue %14, %66[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %68 = llvm.insertvalue %13, %67[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %69 = llvm.insertvalue %31, %68[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %70 = llvm.insertvalue %12, %69[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %71 = llvm.insertvalue %12, %70[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %72 = llvm.insertvalue %33, %71[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %73 = llvm.insertvalue %33, %72[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %74 = llvm.insertvalue %12, %73[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %75 = llvm.insertvalue %31, %74[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %76 = llvm.inttoptr %63 : i64 to !llvm.ptr<5>
    %77 = llvm.insertvalue %76, %10[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %78 = llvm.insertvalue %76, %77[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %79 = llvm.insertvalue %14, %78[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %80 = llvm.insertvalue %13, %79[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %81 = llvm.insertvalue %31, %80[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %82 = llvm.insertvalue %12, %81[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %83 = llvm.insertvalue %12, %82[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %84 = llvm.insertvalue %33, %83[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %85 = llvm.insertvalue %33, %84[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %86 = llvm.insertvalue %12, %85[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %87 = llvm.insertvalue %31, %86[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %88 = llvm.inttoptr %62 : i64 to !llvm.ptr<2>
    %89 = llvm.insertvalue %88, %8[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %90 = llvm.insertvalue %88, %89[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %91 = llvm.insertvalue %14, %90[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %92 = llvm.insertvalue %12, %91[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %93 = llvm.insertvalue %31, %92[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %94 = llvm.insertvalue %12, %93[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %95 = llvm.insertvalue %12, %94[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %96 = llvm.insertvalue %33, %95[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %97 = llvm.insertvalue %33, %96[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %98 = llvm.insertvalue %12, %97[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %99 = llvm.insertvalue %31, %98[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %100 = llvm.inttoptr %61 : i64 to !llvm.ptr<2>
    %101 = llvm.insertvalue %100, %8[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %102 = llvm.insertvalue %100, %101[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %103 = llvm.insertvalue %14, %102[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %104 = llvm.insertvalue %12, %103[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %105 = llvm.insertvalue %31, %104[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %106 = llvm.insertvalue %12, %105[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %107 = llvm.insertvalue %12, %106[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %108 = llvm.insertvalue %33, %107[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %109 = llvm.insertvalue %33, %108[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %110 = llvm.insertvalue %12, %109[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %111 = llvm.insertvalue %31, %110[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %112 = llvm.inttoptr %60 : i64 to !llvm.ptr<2>
    %113 = llvm.insertvalue %112, %8[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %114 = llvm.insertvalue %112, %113[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %115 = llvm.insertvalue %14, %114[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %116 = llvm.insertvalue %12, %115[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %117 = llvm.insertvalue %31, %116[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %118 = llvm.insertvalue %12, %117[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %119 = llvm.insertvalue %12, %118[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %120 = llvm.insertvalue %33, %119[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %121 = llvm.insertvalue %33, %120[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %122 = llvm.insertvalue %12, %121[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %123 = llvm.insertvalue %31, %122[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %124 = llvm.inttoptr %59 : i64 to !llvm.ptr<2>
    %125 = llvm.insertvalue %124, %8[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %126 = llvm.insertvalue %124, %125[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %127 = llvm.insertvalue %14, %126[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %128 = llvm.insertvalue %12, %127[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %129 = llvm.insertvalue %31, %128[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %130 = llvm.insertvalue %12, %129[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %131 = llvm.insertvalue %12, %130[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %132 = llvm.insertvalue %33, %131[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %133 = llvm.insertvalue %33, %132[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %134 = llvm.insertvalue %12, %133[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %135 = llvm.insertvalue %31, %134[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %136 = llvm.inttoptr %58 : i64 to !llvm.ptr<2>
    %137 = llvm.insertvalue %136, %8[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %138 = llvm.insertvalue %136, %137[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %139 = llvm.insertvalue %14, %138[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %140 = llvm.insertvalue %12, %139[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %141 = llvm.insertvalue %31, %140[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %142 = llvm.insertvalue %12, %141[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %143 = llvm.insertvalue %12, %142[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %144 = llvm.insertvalue %33, %143[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %145 = llvm.insertvalue %33, %144[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %146 = llvm.insertvalue %12, %145[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %147 = llvm.insertvalue %31, %146[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %148 = llvm.inttoptr %57 : i64 to !llvm.ptr<2>
    %149 = llvm.insertvalue %148, %8[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %150 = llvm.insertvalue %148, %149[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %151 = llvm.insertvalue %14, %150[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %152 = llvm.insertvalue %12, %151[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %153 = llvm.insertvalue %31, %152[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %154 = llvm.insertvalue %12, %153[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %155 = llvm.insertvalue %12, %154[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %156 = llvm.insertvalue %33, %155[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %157 = llvm.insertvalue %33, %156[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %158 = llvm.insertvalue %12, %157[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %159 = llvm.insertvalue %31, %158[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %160 = llvm.inttoptr %58 : i64 to !llvm.ptr<5>
    %161 = llvm.insertvalue %160, %10[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %162 = llvm.insertvalue %160, %161[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %163 = llvm.insertvalue %14, %162[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %164 = llvm.insertvalue %13, %163[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %165 = llvm.insertvalue %31, %164[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %166 = llvm.insertvalue %12, %165[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %167 = llvm.insertvalue %12, %166[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %168 = llvm.insertvalue %33, %167[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %169 = llvm.insertvalue %33, %168[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %170 = llvm.insertvalue %12, %169[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %171 = llvm.insertvalue %31, %170[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %172 = llvm.inttoptr %56 : i64 to !llvm.ptr<5>
    %173 = llvm.insertvalue %172, %10[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %174 = llvm.insertvalue %172, %173[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %175 = llvm.insertvalue %14, %174[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %176 = llvm.insertvalue %13, %175[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %177 = llvm.insertvalue %31, %176[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %178 = llvm.insertvalue %12, %177[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %179 = llvm.insertvalue %12, %178[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %180 = llvm.insertvalue %33, %179[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %181 = llvm.insertvalue %33, %180[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %182 = llvm.insertvalue %12, %181[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %183 = llvm.insertvalue %31, %182[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %184 = llvm.inttoptr %55 : i64 to !llvm.ptr<5>
    %185 = llvm.insertvalue %184, %10[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %186 = llvm.insertvalue %184, %185[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %187 = llvm.insertvalue %14, %186[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %188 = llvm.insertvalue %13, %187[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %189 = llvm.insertvalue %31, %188[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %190 = llvm.insertvalue %12, %189[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %191 = llvm.insertvalue %12, %190[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %192 = llvm.insertvalue %33, %191[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %193 = llvm.insertvalue %33, %192[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %194 = llvm.insertvalue %12, %193[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %195 = llvm.insertvalue %31, %194[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %196 = llvm.inttoptr %54 : i64 to !llvm.ptr<5>
    %197 = llvm.insertvalue %196, %10[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %198 = llvm.insertvalue %196, %197[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %199 = llvm.insertvalue %14, %198[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %200 = llvm.insertvalue %13, %199[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %201 = llvm.insertvalue %31, %200[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %202 = llvm.insertvalue %12, %201[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %203 = llvm.insertvalue %12, %202[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %204 = llvm.insertvalue %33, %203[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %205 = llvm.insertvalue %33, %204[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %206 = llvm.insertvalue %12, %205[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %207 = llvm.insertvalue %31, %206[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %208 = llvm.inttoptr %53 : i64 to !llvm.ptr<2>
    %209 = llvm.insertvalue %208, %8[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %210 = llvm.insertvalue %208, %209[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %211 = llvm.insertvalue %14, %210[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %212 = llvm.insertvalue %12, %211[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %213 = llvm.insertvalue %13, %212[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %214 = llvm.insertvalue %12, %213[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %215 = llvm.insertvalue %12, %214[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %216 = llvm.insertvalue %11, %215[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %217 = llvm.insertvalue %33, %216[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %218 = llvm.insertvalue %12, %217[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %219 = llvm.insertvalue %31, %218[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %220 = llvm.inttoptr %52 : i64 to !llvm.ptr<2>
    %221 = llvm.insertvalue %220, %8[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %222 = llvm.insertvalue %220, %221[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %223 = llvm.insertvalue %14, %222[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %224 = llvm.insertvalue %12, %223[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %225 = llvm.insertvalue %13, %224[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %226 = llvm.insertvalue %12, %225[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %227 = llvm.insertvalue %12, %226[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %228 = llvm.insertvalue %11, %227[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %229 = llvm.insertvalue %33, %228[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %230 = llvm.insertvalue %12, %229[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %231 = llvm.insertvalue %31, %230[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %232 = llvm.inttoptr %51 : i64 to !llvm.ptr<5>
    %233 = llvm.insertvalue %232, %10[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %234 = llvm.insertvalue %232, %233[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %235 = llvm.insertvalue %14, %234[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %236 = llvm.insertvalue %12, %235[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %237 = llvm.insertvalue %31, %236[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %238 = llvm.insertvalue %12, %237[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %239 = llvm.insertvalue %12, %238[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %240 = llvm.insertvalue %33, %239[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %241 = llvm.insertvalue %33, %240[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %242 = llvm.insertvalue %12, %241[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %243 = llvm.insertvalue %31, %242[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %244 = llvm.inttoptr %50 : i64 to !llvm.ptr<5>
    %245 = llvm.insertvalue %244, %10[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %246 = llvm.insertvalue %244, %245[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %247 = llvm.insertvalue %14, %246[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %248 = llvm.insertvalue %12, %247[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %249 = llvm.insertvalue %31, %248[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %250 = llvm.insertvalue %12, %249[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %251 = llvm.insertvalue %12, %250[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %252 = llvm.insertvalue %33, %251[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %253 = llvm.insertvalue %33, %252[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %254 = llvm.insertvalue %12, %253[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %255 = llvm.insertvalue %31, %254[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %256 = llvm.inttoptr %49 : i64 to !llvm.ptr<5>
    %257 = llvm.insertvalue %256, %10[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %258 = llvm.insertvalue %256, %257[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %259 = llvm.insertvalue %14, %258[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %260 = llvm.insertvalue %12, %259[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %261 = llvm.insertvalue %31, %260[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %262 = llvm.insertvalue %12, %261[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %263 = llvm.insertvalue %12, %262[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %264 = llvm.insertvalue %33, %263[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %265 = llvm.insertvalue %33, %264[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %266 = llvm.insertvalue %12, %265[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %267 = llvm.insertvalue %31, %266[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %268 = llvm.inttoptr %48 : i64 to !llvm.ptr<5>
    %269 = llvm.insertvalue %268, %10[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %270 = llvm.insertvalue %268, %269[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %271 = llvm.insertvalue %14, %270[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %272 = llvm.insertvalue %12, %271[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %273 = llvm.insertvalue %31, %272[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %274 = llvm.insertvalue %12, %273[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %275 = llvm.insertvalue %12, %274[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %276 = llvm.insertvalue %33, %275[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %277 = llvm.insertvalue %33, %276[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %278 = llvm.insertvalue %12, %277[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %279 = llvm.insertvalue %31, %278[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %280 = llvm.inttoptr %47 : i64 to !llvm.ptr<5>
    %281 = llvm.insertvalue %280, %10[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %282 = llvm.insertvalue %280, %281[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %283 = llvm.insertvalue %14, %282[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %284 = llvm.insertvalue %12, %283[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %285 = llvm.insertvalue %31, %284[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %286 = llvm.insertvalue %12, %285[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %287 = llvm.insertvalue %12, %286[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %288 = llvm.insertvalue %33, %287[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %289 = llvm.insertvalue %33, %288[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %290 = llvm.insertvalue %12, %289[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %291 = llvm.insertvalue %31, %290[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %292 = llvm.inttoptr %46 : i64 to !llvm.ptr<5>
    %293 = llvm.insertvalue %292, %10[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %294 = llvm.insertvalue %292, %293[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %295 = llvm.insertvalue %14, %294[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %296 = llvm.insertvalue %12, %295[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %297 = llvm.insertvalue %31, %296[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %298 = llvm.insertvalue %12, %297[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %299 = llvm.insertvalue %12, %298[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %300 = llvm.insertvalue %33, %299[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %301 = llvm.insertvalue %33, %300[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %302 = llvm.insertvalue %12, %301[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %303 = llvm.insertvalue %31, %302[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %304 = llvm.inttoptr %56 : i64 to !llvm.ptr<2>
    %305 = llvm.insertvalue %304, %8[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %306 = llvm.insertvalue %304, %305[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %307 = llvm.insertvalue %14, %306[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %308 = llvm.insertvalue %12, %307[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %309 = llvm.insertvalue %13, %308[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %310 = llvm.insertvalue %12, %309[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %311 = llvm.insertvalue %12, %310[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %312 = llvm.insertvalue %11, %311[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %313 = llvm.insertvalue %33, %312[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %314 = llvm.insertvalue %12, %313[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %315 = llvm.insertvalue %31, %314[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %316 = llvm.inttoptr %45 : i64 to !llvm.ptr<2>
    %317 = llvm.insertvalue %316, %8[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %318 = llvm.insertvalue %316, %317[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %319 = llvm.insertvalue %14, %318[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %320 = llvm.insertvalue %12, %319[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %321 = llvm.insertvalue %13, %320[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %322 = llvm.insertvalue %12, %321[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %323 = llvm.insertvalue %12, %322[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %324 = llvm.insertvalue %11, %323[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %325 = llvm.insertvalue %33, %324[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %326 = llvm.insertvalue %12, %325[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %327 = llvm.insertvalue %31, %326[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %328 = llvm.alloca %31 x i64 : (i64) -> !llvm.ptr
    llvm.store %62, %328 : i64, !llvm.ptr
    %329 = llvm.alloca %31 x i64 : (i64) -> !llvm.ptr
    llvm.store %62, %329 : i64, !llvm.ptr
    %330 = llvm.alloca %31 x i64 : (i64) -> !llvm.ptr
    llvm.store %62, %330 : i64, !llvm.ptr
    %331 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %332 = "hivm.intr.hivm.SBITSET0"(%331, %6) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%332) : (i64) -> ()
    %333 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %334 = "hivm.intr.hivm.SBITSET1"(%333, %5) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%334) : (i64) -> ()
    %335 = "hivm.intr.hivm.GET.BLOCK.IDX"() : () -> i64
    %336 = llvm.trunc %335 : i64 to i32
    %337 = llvm.srem %336, %arg24  : i32
    %338 = llvm.mul %337, %arg8 : i32
    %339 = llvm.sdiv %338, %arg24  : i32
    %340 = llvm.add %337, %36 : i32
    %341 = llvm.mul %340, %arg8 : i32
    %342 = llvm.sdiv %341, %arg24  : i32
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    llvm.br ^bb1(%339 : i32)
  ^bb1(%343: i32):  // 2 preds: ^bb0, ^bb21
    %344 = llvm.icmp "slt" %343, %342 : i32
    llvm.cond_br %344, ^bb2, ^bb22
  ^bb2:  // pred: ^bb1
    %345 = llvm.load %328 : !llvm.ptr -> i64
    %346 = llvm.urem %345, %39  : i64
    %347 = llvm.icmp "eq" %346, %40 : i64
    %348 = llvm.select %347, %111, %99 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %349 = llvm.select %347, %135, %123 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %350 = llvm.select %347, %159, %147 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %351 = llvm.trunc %346 : i64 to i1
    %352 = llvm.xor %351, %37  : i1
    %353 = llvm.zext %352 : i1 to i64
    %354 = llvm.sext %343 : i32 to i64
    %355 = llvm.getelementptr %arg9[%354] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %356 = llvm.load %355 : !llvm.ptr<1> -> i32
    %357 = llvm.add %354, %31 : i64
    %358 = llvm.getelementptr %arg9[%357] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %359 = llvm.load %358 : !llvm.ptr<1> -> i32
    %360 = llvm.sub %359, %356 : i32
    %361 = llvm.icmp "sgt" %360, %27 : i32
    llvm.cond_br %361, ^bb3, ^bb21
  ^bb3:  // pred: ^bb2
    %362 = llvm.getelementptr %arg10[%354] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %363 = llvm.load %362 : !llvm.ptr<1> -> i32
    %364 = llvm.sub %363, %360 : i32
    %365 = llvm.mul %356, %arg15 : i32
    %366 = llvm.sext %365 : i32 to i64
    %367 = llvm.sext %arg16 : i32 to i64
    "hivm.intr.hivm.WAIT.FLAG.REG"(%353) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    %368 = llvm.extractvalue %348[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %369 = llvm.extractvalue %348[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %370 = llvm.extractvalue %348[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %371 = llvm.extractvalue %348[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %372 = llvm.extractvalue %348[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %373 = llvm.extractvalue %348[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %374 = llvm.extractvalue %348[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %375 = llvm.extractvalue %348[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %376 = llvm.extractvalue %348[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %377 = llvm.extractvalue %348[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %378 = llvm.extractvalue %348[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @nd2nz_bfloat16_t(%arg4, %arg4, %366, %32, %33, %367, %31, %368, %369, %370, %371, %372, %373, %374, %375, %376, %377, %378) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    %379 = llvm.icmp "sgt" %360, %36 : i32
    %380 = llvm.sext %arg15 : i32 to i64
    %381 = llvm.add %366, %380 : i64
    %382 = llvm.zext %379 : i1 to i64
    %383 = llvm.mul %382, %32 : i64
    %384 = llvm.mul %382, %33 : i64
    %385 = llvm.icmp "slt" %383, %32 : i64
    %386 = llvm.icmp "slt" %384, %33 : i64
    %387 = llvm.or %385, %386  : i1
    %388 = llvm.mul %382, %4 : i64
    %389 = llvm.icmp "sle" %388, %14 : i64
    %390 = llvm.sub %14, %388 : i64
    %391 = llvm.sub %388, %31 : i64
    %392 = llvm.select %389, %390, %391 : i1, i64
    %393 = llvm.sdiv %392, %3  : i64
    %394 = llvm.sub %14, %393 : i64
    %395 = llvm.add %393, %31 : i64
    %396 = llvm.select %389, %394, %395 : i1, i64
    %397 = llvm.mul %382, %12 : i64
    %398 = llvm.extractvalue %350[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %399 = llvm.extractvalue %350[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.cond_br %387, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %400 = llvm.extractvalue %350[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %401 = llvm.extractvalue %350[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%34, %400, %401, %14, %9, %31) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb5
  ^bb5:  // 2 preds: ^bb3, ^bb4
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.call @nd2nz_bfloat16_t(%arg4, %arg4, %381, %383, %384, %367, %31, %398, %399, %14, %397, %396, %12, %12, %33, %33, %12, %31) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    %402 = llvm.icmp "sgt" %360, %26 : i32
    %403 = llvm.mul %arg15, %26 : i32
    %404 = llvm.sext %403 : i32 to i64
    %405 = llvm.add %366, %404 : i64
    %406 = llvm.zext %402 : i1 to i64
    %407 = llvm.mul %406, %32 : i64
    %408 = llvm.mul %406, %33 : i64
    %409 = llvm.icmp "slt" %407, %32 : i64
    %410 = llvm.icmp "slt" %408, %33 : i64
    %411 = llvm.or %409, %410  : i1
    %412 = llvm.mul %406, %4 : i64
    %413 = llvm.icmp "sle" %412, %14 : i64
    %414 = llvm.sub %14, %412 : i64
    %415 = llvm.sub %412, %31 : i64
    %416 = llvm.select %413, %414, %415 : i1, i64
    %417 = llvm.sdiv %416, %3  : i64
    %418 = llvm.sub %14, %417 : i64
    %419 = llvm.add %417, %31 : i64
    %420 = llvm.select %413, %418, %419 : i1, i64
    %421 = llvm.mul %406, %12 : i64
    %422 = llvm.extractvalue %349[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %423 = llvm.extractvalue %349[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.cond_br %411, ^bb6, ^bb7
  ^bb6:  // pred: ^bb5
    %424 = llvm.extractvalue %349[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %425 = llvm.extractvalue %349[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @set_l1_2d_bfloat16_t(%34, %424, %425, %14, %9, %31) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb7
  ^bb7:  // 2 preds: ^bb5, ^bb6
    llvm.call @nd2nz_bfloat16_t(%arg4, %arg4, %405, %407, %408, %367, %31, %422, %423, %14, %421, %420, %12, %12, %33, %33, %12, %31) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    %426 = llvm.add %363, %29 : i32
    %427 = llvm.sdiv %426, %28  : i32
    %428 = llvm.intr.smin(%427, %27)  : (i32, i32) -> i32
    %429 = llvm.sub %364, %30 : i32
    %430 = llvm.intr.smax(%429, %27)  : (i32, i32) -> i32
    %431 = llvm.sdiv %430, %28  : i32
    %432 = llvm.intr.smax(%428, %431)  : (i32, i32) -> i32
    %433 = llvm.intr.smax(%428, %432)  : (i32, i32) -> i32
    %434 = llvm.sub %427, %433 : i32
    %435 = llvm.intr.smax(%434, %27)  : (i32, i32) -> i32
    %436 = llvm.add %428, %435 : i32
    %437 = llvm.intr.smin(%436, %427)  : (i32, i32) -> i32
    %438 = llvm.sitofp %428 : i32 to f32
    %439 = llvm.sub %arg23, %36 : i32
    %440 = llvm.mul %343, %arg23 : i32
    %441 = llvm.sext %437 : i32 to i64
    %442 = llvm.sext %440 : i32 to i64
    %443 = llvm.sext %arg19 : i32 to i64
    %444 = llvm.sext %arg22 : i32 to i64
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 18 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 18 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 19 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 3 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 19 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 3 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 20 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 20 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 4 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 4 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 5 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    llvm.br ^bb8(%27 : i32)
  ^bb8(%445: i32):  // 2 preds: ^bb7, ^bb19
    %446 = llvm.icmp "slt" %445, %437 : i32
    llvm.cond_br %446, ^bb9, ^bb20
  ^bb9:  // pred: ^bb8
    %447 = llvm.inttoptr %25 : i64 to !llvm.ptr<6>
    %448 = llvm.inttoptr %24 : i64 to !llvm.ptr<6>
    %449 = llvm.inttoptr %23 : i64 to !llvm.ptr<6>
    %450 = llvm.inttoptr %22 : i64 to !llvm.ptr<2>
    %451 = llvm.inttoptr %49 : i64 to !llvm.ptr<2>
    %452 = llvm.inttoptr %21 : i64 to !llvm.ptr<2>
    %453 = llvm.inttoptr %20 : i64 to !llvm.ptr<6>
    %454 = llvm.inttoptr %19 : i64 to !llvm.ptr<6>
    %455 = llvm.inttoptr %18 : i64 to !llvm.ptr<6>
    %456 = llvm.sext %445 : i32 to i64
    %457 = llvm.mul %456, %0 : i64
    %458 = llvm.add %441, %457 : i64
    %459 = llvm.intr.umin(%458, %38)  : (i64, i64) -> i64
    llvm.br ^bb10(%14 : i64)
  ^bb10(%460: i64):  // 2 preds: ^bb9, ^bb13
    %461 = llvm.icmp "slt" %460, %459 : i64
    llvm.cond_br %461, ^bb11, ^bb14
  ^bb11:  // pred: ^bb10
    %462 = llvm.load %330 : !llvm.ptr -> i64
    %463 = llvm.urem %462, %39  : i64
    %464 = llvm.icmp "eq" %463, %40 : i64
    %465 = llvm.select %464, %87, %75 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %466 = llvm.select %464, %183, %171 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %467 = llvm.select %464, %207, %195 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %468 = llvm.select %464, %231, %219 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %469 = llvm.trunc %463 : i64 to i1
    %470 = llvm.select %469, %41, %42 : i1, i64
    %471 = llvm.select %469, %39, %43 : i1, i64
    %472 = llvm.xor %469, %37  : i1
    %473 = llvm.zext %472 : i1 to i64
    %474 = llvm.select %469, %43, %41 : i1, i64
    %475 = llvm.mul %460, %1 : i64
    %476 = llvm.mul %460, %1 : i64
    %477 = llvm.mul %460, %1 : i64
    %478 = llvm.add %460, %456 : i64
    %479 = llvm.trunc %478 : i64 to i32
    %480 = llvm.sitofp %479 : i32 to f32
    %481 = llvm.fcmp "olt" %480, %438 : f32
    %482 = llvm.zext %481 : i1 to i32
    %483 = llvm.mul %482, %479 : i32
    %484 = llvm.sub %36, %482 : i32
    %485 = llvm.add %433, %479 : i32
    %486 = llvm.sub %485, %428 : i32
    %487 = llvm.mul %484, %486 : i32
    %488 = llvm.add %483, %487 : i32
    %489 = llvm.mul %488, %28 : i32
    %490 = llvm.add %489, %28 : i32
    %491 = llvm.intr.smin(%490, %363)  : (i32, i32) -> i32
    %492 = llvm.sub %491, %489 : i32
    %493 = llvm.intr.smax(%492, %27)  : (i32, i32) -> i32
    %494 = llvm.sdiv %489, %28  : i32
    %495 = llvm.intr.smin(%494, %439)  : (i32, i32) -> i32
    %496 = llvm.sext %495 : i32 to i64
    %497 = llvm.add %442, %496 : i64
    %498 = llvm.getelementptr %arg11[%497] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %499 = llvm.load %498 : !llvm.ptr<1> -> i32
    %500 = llvm.mul %499, %arg17 : i32
    %501 = llvm.sext %500 : i32 to i64
    %502 = llvm.sext %493 : i32 to i64
    %503 = llvm.intr.smax(%502, %14)  : (i64, i64) -> i64
    %504 = llvm.intr.smin(%503, %35)  : (i64, i64) -> i64
    %505 = llvm.intr.smin(%504, %14)  : (i64, i64) -> i64
    %506 = llvm.mul %505, %0 : i64
    %507 = llvm.add %504, %506 : i64
    %508 = llvm.icmp "slt" %507, %35 : i64
    %509 = llvm.mul %505, %0 : i64
    %510 = llvm.add %504, %509 : i64
    %511 = llvm.icmp "sle" %510, %14 : i64
    %512 = llvm.sub %14, %510 : i64
    %513 = llvm.sub %510, %31 : i64
    %514 = llvm.select %511, %512, %513 : i1, i64
    %515 = llvm.sdiv %514, %12  : i64
    %516 = llvm.sub %14, %515 : i64
    %517 = llvm.add %515, %31 : i64
    %518 = llvm.select %511, %516, %517 : i1, i64
    %519 = llvm.extractvalue %468[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %520 = llvm.extractvalue %468[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %521 = llvm.mul %505, %12 : i64
    llvm.cond_br %508, ^bb12, ^bb13
  ^bb12:  // pred: ^bb11
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %522 = llvm.extractvalue %468[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %523 = llvm.extractvalue %468[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%34, %522, %523, %14, %7, %31) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb13
  ^bb13:  // 2 preds: ^bb11, ^bb12
    "hivm.intr.hivm.WAIT.FLAG.REG"(%474) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.call @nd2nz_bfloat16_t(%arg5, %arg5, %501, %507, %33, %443, %31, %519, %520, %521, %12, %518, %12, %12, %11, %33, %12, %31) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%473) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %524 = llvm.extractvalue %348[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %525 = llvm.extractvalue %348[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %526 = llvm.extractvalue %348[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %527 = llvm.extractvalue %348[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %528 = llvm.extractvalue %348[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %529 = llvm.extractvalue %348[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %530 = llvm.extractvalue %348[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %531 = llvm.extractvalue %348[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %532 = llvm.extractvalue %348[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %533 = llvm.extractvalue %348[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %534 = llvm.extractvalue %348[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %535 = llvm.extractvalue %468[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %536 = llvm.extractvalue %468[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %537 = llvm.extractvalue %468[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %538 = llvm.extractvalue %468[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %539 = llvm.extractvalue %468[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %540 = llvm.extractvalue %468[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %541 = llvm.extractvalue %468[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %542 = llvm.extractvalue %468[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %543 = llvm.extractvalue %468[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %544 = llvm.extractvalue %468[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %545 = llvm.extractvalue %468[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %546 = llvm.extractvalue %465[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %547 = llvm.extractvalue %465[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %548 = llvm.extractvalue %465[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %549 = llvm.extractvalue %465[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %550 = llvm.extractvalue %465[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %551 = llvm.extractvalue %465[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %552 = llvm.extractvalue %465[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %553 = llvm.extractvalue %465[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %554 = llvm.extractvalue %465[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %555 = llvm.extractvalue %465[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %556 = llvm.extractvalue %465[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float_tb(%524, %525, %526, %527, %528, %529, %530, %531, %532, %533, %534, %535, %536, %537, %538, %539, %540, %541, %542, %543, %544, %545, %37, %32, %33, %35, %546, %547, %548, %549, %550, %551, %552, %553, %554, %555, %556, %44, %62, %44, %44, %44, %44, %44, %15) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 23 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 7 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 10 : i64}> : () -> ()
    %557 = llvm.extractvalue %465[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %558 = llvm.extractvalue %465[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %559 = llvm.extractvalue %465[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %560 = llvm.extractvalue %465[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %561 = llvm.extractvalue %465[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %562 = llvm.extractvalue %465[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %563 = llvm.extractvalue %465[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %564 = llvm.extractvalue %465[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %565 = llvm.extractvalue %465[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %566 = llvm.extractvalue %465[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %567 = llvm.extractvalue %465[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%557, %558, %559, %560, %561, %562, %563, %564, %565, %566, %567, %453, %453, %477, %32, %35, %35, %31, %62, %17, %62, %16, %15) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%473) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 29 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 13 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%471) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %568 = llvm.extractvalue %350[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %569 = llvm.extractvalue %350[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %570 = llvm.extractvalue %350[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %571 = llvm.extractvalue %350[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %572 = llvm.extractvalue %350[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %573 = llvm.extractvalue %350[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %574 = llvm.extractvalue %350[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %575 = llvm.extractvalue %350[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %576 = llvm.extractvalue %350[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %577 = llvm.extractvalue %350[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %578 = llvm.extractvalue %350[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %579 = llvm.extractvalue %468[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %580 = llvm.extractvalue %468[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %581 = llvm.extractvalue %468[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %582 = llvm.extractvalue %468[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %583 = llvm.extractvalue %468[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %584 = llvm.extractvalue %468[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %585 = llvm.extractvalue %468[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %586 = llvm.extractvalue %468[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %587 = llvm.extractvalue %468[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %588 = llvm.extractvalue %468[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %589 = llvm.extractvalue %468[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %590 = llvm.extractvalue %467[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %591 = llvm.extractvalue %467[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %592 = llvm.extractvalue %467[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %593 = llvm.extractvalue %467[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %594 = llvm.extractvalue %467[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %595 = llvm.extractvalue %467[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %596 = llvm.extractvalue %467[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %597 = llvm.extractvalue %467[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %598 = llvm.extractvalue %467[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %599 = llvm.extractvalue %467[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %600 = llvm.extractvalue %467[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float_tb(%568, %569, %570, %571, %572, %573, %574, %575, %576, %577, %578, %579, %580, %581, %582, %583, %584, %585, %586, %587, %588, %589, %37, %32, %33, %35, %590, %591, %592, %593, %594, %595, %596, %597, %598, %599, %600, %44, %44, %44, %44, %44, %44, %44, %15) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 22 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 6 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %601 = llvm.extractvalue %467[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %602 = llvm.extractvalue %467[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %603 = llvm.extractvalue %467[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %604 = llvm.extractvalue %467[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %605 = llvm.extractvalue %467[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %606 = llvm.extractvalue %467[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %607 = llvm.extractvalue %467[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %608 = llvm.extractvalue %467[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %609 = llvm.extractvalue %467[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %610 = llvm.extractvalue %467[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %611 = llvm.extractvalue %467[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%601, %602, %603, %604, %605, %606, %607, %608, %609, %610, %611, %454, %454, %476, %32, %35, %35, %31, %62, %17, %62, %16, %15) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%471) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 28 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 12 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%470) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %612 = llvm.extractvalue %349[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %613 = llvm.extractvalue %349[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %614 = llvm.extractvalue %349[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %615 = llvm.extractvalue %349[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %616 = llvm.extractvalue %349[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %617 = llvm.extractvalue %349[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %618 = llvm.extractvalue %349[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %619 = llvm.extractvalue %349[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %620 = llvm.extractvalue %349[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %621 = llvm.extractvalue %349[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %622 = llvm.extractvalue %349[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %623 = llvm.extractvalue %468[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %624 = llvm.extractvalue %468[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %625 = llvm.extractvalue %468[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %626 = llvm.extractvalue %468[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %627 = llvm.extractvalue %468[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %628 = llvm.extractvalue %468[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %629 = llvm.extractvalue %468[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %630 = llvm.extractvalue %468[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %631 = llvm.extractvalue %468[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %632 = llvm.extractvalue %468[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %633 = llvm.extractvalue %468[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %634 = llvm.extractvalue %466[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %635 = llvm.extractvalue %466[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %636 = llvm.extractvalue %466[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %637 = llvm.extractvalue %466[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %638 = llvm.extractvalue %466[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %639 = llvm.extractvalue %466[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %640 = llvm.extractvalue %466[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %641 = llvm.extractvalue %466[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %642 = llvm.extractvalue %466[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %643 = llvm.extractvalue %466[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %644 = llvm.extractvalue %466[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float_tb(%612, %613, %614, %615, %616, %617, %618, %619, %620, %621, %622, %623, %624, %625, %626, %627, %628, %629, %630, %631, %632, %633, %37, %32, %33, %35, %634, %635, %636, %637, %638, %639, %640, %641, %642, %643, %644, %44, %44, %44, %474, %44, %44, %44, %15) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 21 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %645 = llvm.extractvalue %466[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %646 = llvm.extractvalue %466[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %647 = llvm.extractvalue %466[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %648 = llvm.extractvalue %466[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %649 = llvm.extractvalue %466[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %650 = llvm.extractvalue %466[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %651 = llvm.extractvalue %466[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %652 = llvm.extractvalue %466[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %653 = llvm.extractvalue %466[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %654 = llvm.extractvalue %466[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %655 = llvm.extractvalue %466[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%645, %646, %647, %648, %649, %650, %651, %652, %653, %654, %655, %455, %455, %475, %32, %35, %35, %31, %62, %17, %62, %16, %15) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%470) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 27 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 11 : i64}> : () -> ()
    %656 = llvm.add %462, %40 : i64
    llvm.store %656, %330 : i64, !llvm.ptr
    %657 = llvm.add %460, %31 overflow<nsw> : i64
    llvm.br ^bb10(%657 : i64)
  ^bb14:  // pred: ^bb10
    llvm.br ^bb15(%14 : i64)
  ^bb15(%658: i64):  // 2 preds: ^bb14, ^bb18
    %659 = llvm.icmp "slt" %658, %459 : i64
    llvm.cond_br %659, ^bb16, ^bb19
  ^bb16:  // pred: ^bb15
    %660 = llvm.load %329 : !llvm.ptr -> i64
    %661 = llvm.urem %660, %39  : i64
    %662 = llvm.icmp "eq" %661, %40 : i64
    %663 = llvm.select %662, %255, %243 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %664 = llvm.select %662, %279, %267 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %665 = llvm.select %662, %303, %291 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %666 = llvm.select %662, %327, %315 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %667 = llvm.trunc %661 : i64 to i1
    %668 = llvm.select %667, %41, %42 : i1, i64
    %669 = llvm.select %667, %39, %43 : i1, i64
    %670 = llvm.xor %667, %37  : i1
    %671 = llvm.zext %670 : i1 to i64
    %672 = llvm.select %667, %43, %41 : i1, i64
    %673 = llvm.mul %658, %2 : i64
    %674 = llvm.mul %658, %2 : i64
    %675 = llvm.mul %658, %2 : i64
    %676 = llvm.add %658, %456 : i64
    %677 = llvm.trunc %676 : i64 to i32
    %678 = llvm.sitofp %677 : i32 to f32
    %679 = llvm.fcmp "olt" %678, %438 : f32
    %680 = llvm.zext %679 : i1 to i32
    %681 = llvm.mul %680, %677 : i32
    %682 = llvm.sub %36, %680 : i32
    %683 = llvm.add %433, %677 : i32
    %684 = llvm.sub %683, %428 : i32
    %685 = llvm.mul %682, %684 : i32
    %686 = llvm.add %681, %685 : i32
    %687 = llvm.mul %686, %28 : i32
    %688 = llvm.add %687, %28 : i32
    %689 = llvm.intr.smin(%688, %363)  : (i32, i32) -> i32
    %690 = llvm.sub %689, %687 : i32
    %691 = llvm.intr.smax(%690, %27)  : (i32, i32) -> i32
    %692 = llvm.sdiv %687, %28  : i32
    %693 = llvm.intr.smin(%692, %439)  : (i32, i32) -> i32
    %694 = llvm.sext %693 : i32 to i64
    %695 = llvm.add %442, %694 : i64
    %696 = llvm.getelementptr %arg11[%695] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %697 = llvm.load %696 : !llvm.ptr<1> -> i32
    %698 = llvm.mul %697, %arg20 : i32
    %699 = llvm.sext %698 : i32 to i64
    %700 = llvm.sext %691 : i32 to i64
    %701 = llvm.intr.smax(%700, %14)  : (i64, i64) -> i64
    %702 = llvm.intr.smin(%701, %35)  : (i64, i64) -> i64
    %703 = llvm.intr.smin(%702, %14)  : (i64, i64) -> i64
    %704 = llvm.mul %703, %0 : i64
    %705 = llvm.add %702, %704 : i64
    %706 = llvm.icmp "slt" %705, %35 : i64
    %707 = llvm.mul %703, %0 : i64
    %708 = llvm.add %702, %707 : i64
    %709 = llvm.icmp "sle" %708, %14 : i64
    %710 = llvm.sub %14, %708 : i64
    %711 = llvm.sub %708, %31 : i64
    %712 = llvm.select %709, %710, %711 : i1, i64
    %713 = llvm.sdiv %712, %12  : i64
    %714 = llvm.sub %14, %713 : i64
    %715 = llvm.add %713, %31 : i64
    %716 = llvm.select %709, %714, %715 : i1, i64
    %717 = llvm.extractvalue %666[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %718 = llvm.extractvalue %666[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %719 = llvm.mul %703, %12 : i64
    llvm.cond_br %706, ^bb17, ^bb18
  ^bb17:  // pred: ^bb16
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %720 = llvm.extractvalue %666[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %721 = llvm.extractvalue %666[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%34, %720, %721, %14, %7, %31) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb18
  ^bb18:  // 2 preds: ^bb16, ^bb17
    "hivm.intr.hivm.WAIT.FLAG.REG"(%672) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.call @nd2nz_bfloat16_t(%arg6, %arg6, %699, %705, %33, %444, %31, %717, %718, %719, %12, %716, %12, %12, %11, %33, %12, %31) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    %722 = llvm.mul %658, %11 : i64
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 26 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 10 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%671) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %723 = llvm.extractvalue %666[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %724 = llvm.extractvalue %666[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %725 = llvm.extractvalue %666[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %726 = llvm.extractvalue %666[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %727 = llvm.extractvalue %666[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %728 = llvm.extractvalue %666[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %729 = llvm.extractvalue %666[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %730 = llvm.extractvalue %666[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %731 = llvm.extractvalue %666[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %732 = llvm.extractvalue %666[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %733 = llvm.extractvalue %666[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %734 = llvm.extractvalue %665[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %735 = llvm.extractvalue %665[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %736 = llvm.extractvalue %665[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %737 = llvm.extractvalue %665[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %738 = llvm.extractvalue %665[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %739 = llvm.extractvalue %665[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %740 = llvm.extractvalue %665[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %741 = llvm.extractvalue %665[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %742 = llvm.extractvalue %665[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %743 = llvm.extractvalue %665[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %744 = llvm.extractvalue %665[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float(%450, %450, %722, %13, %31, %12, %12, %33, %33, %12, %31, %723, %724, %725, %726, %727, %728, %729, %730, %731, %732, %733, %37, %32, %35, %33, %734, %735, %736, %737, %738, %739, %740, %741, %742, %743, %744, %44, %62, %44, %44, %44, %44, %44, %15) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 20 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 17 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 10 : i64}> : () -> ()
    %745 = llvm.extractvalue %665[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %746 = llvm.extractvalue %665[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %747 = llvm.extractvalue %665[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %748 = llvm.extractvalue %665[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %749 = llvm.extractvalue %665[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %750 = llvm.extractvalue %665[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %751 = llvm.extractvalue %665[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %752 = llvm.extractvalue %665[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %753 = llvm.extractvalue %665[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %754 = llvm.extractvalue %665[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %755 = llvm.extractvalue %665[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%745, %746, %747, %748, %749, %750, %751, %752, %753, %754, %755, %447, %447, %675, %32, %33, %33, %31, %62, %17, %62, %16, %15) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%671) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %756 = llvm.mul %658, %11 : i64
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 25 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 9 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%669) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %757 = llvm.extractvalue %666[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %758 = llvm.extractvalue %666[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %759 = llvm.extractvalue %666[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %760 = llvm.extractvalue %666[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %761 = llvm.extractvalue %666[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %762 = llvm.extractvalue %666[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %763 = llvm.extractvalue %666[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %764 = llvm.extractvalue %666[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %765 = llvm.extractvalue %666[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %766 = llvm.extractvalue %666[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %767 = llvm.extractvalue %666[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %768 = llvm.extractvalue %664[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %769 = llvm.extractvalue %664[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %770 = llvm.extractvalue %664[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %771 = llvm.extractvalue %664[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %772 = llvm.extractvalue %664[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %773 = llvm.extractvalue %664[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %774 = llvm.extractvalue %664[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %775 = llvm.extractvalue %664[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %776 = llvm.extractvalue %664[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %777 = llvm.extractvalue %664[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %778 = llvm.extractvalue %664[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float(%451, %451, %756, %13, %31, %12, %12, %33, %33, %12, %31, %757, %758, %759, %760, %761, %762, %763, %764, %765, %766, %767, %37, %32, %35, %33, %768, %769, %770, %771, %772, %773, %774, %775, %776, %777, %778, %44, %44, %44, %44, %44, %44, %44, %15) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 19 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %779 = llvm.extractvalue %664[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %780 = llvm.extractvalue %664[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %781 = llvm.extractvalue %664[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %782 = llvm.extractvalue %664[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %783 = llvm.extractvalue %664[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %784 = llvm.extractvalue %664[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %785 = llvm.extractvalue %664[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %786 = llvm.extractvalue %664[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %787 = llvm.extractvalue %664[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %788 = llvm.extractvalue %664[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %789 = llvm.extractvalue %664[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%779, %780, %781, %782, %783, %784, %785, %786, %787, %788, %789, %448, %448, %674, %32, %33, %33, %31, %62, %17, %62, %16, %15) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%669) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %790 = llvm.mul %658, %11 : i64
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 24 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 8 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%668) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %791 = llvm.extractvalue %666[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %792 = llvm.extractvalue %666[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %793 = llvm.extractvalue %666[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %794 = llvm.extractvalue %666[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %795 = llvm.extractvalue %666[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %796 = llvm.extractvalue %666[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %797 = llvm.extractvalue %666[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %798 = llvm.extractvalue %666[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %799 = llvm.extractvalue %666[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %800 = llvm.extractvalue %666[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %801 = llvm.extractvalue %666[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %802 = llvm.extractvalue %663[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %803 = llvm.extractvalue %663[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %804 = llvm.extractvalue %663[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %805 = llvm.extractvalue %663[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %806 = llvm.extractvalue %663[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %807 = llvm.extractvalue %663[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %808 = llvm.extractvalue %663[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %809 = llvm.extractvalue %663[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %810 = llvm.extractvalue %663[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %811 = llvm.extractvalue %663[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %812 = llvm.extractvalue %663[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float(%452, %452, %790, %13, %31, %12, %12, %33, %33, %12, %31, %791, %792, %793, %794, %795, %796, %797, %798, %799, %800, %801, %37, %32, %35, %33, %802, %803, %804, %805, %806, %807, %808, %809, %810, %811, %812, %44, %44, %44, %672, %44, %44, %44, %15) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 18 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    %813 = llvm.extractvalue %663[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %814 = llvm.extractvalue %663[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %815 = llvm.extractvalue %663[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %816 = llvm.extractvalue %663[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %817 = llvm.extractvalue %663[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %818 = llvm.extractvalue %663[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %819 = llvm.extractvalue %663[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %820 = llvm.extractvalue %663[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %821 = llvm.extractvalue %663[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %822 = llvm.extractvalue %663[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %823 = llvm.extractvalue %663[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%813, %814, %815, %816, %817, %818, %819, %820, %821, %822, %823, %449, %449, %673, %32, %33, %33, %31, %62, %17, %62, %16, %15) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%668) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 16 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 0 : i64}> : () -> ()
    %824 = llvm.add %660, %40 : i64
    llvm.store %824, %329 : i64, !llvm.ptr
    %825 = llvm.add %658, %31 overflow<nsw> : i64
    llvm.br ^bb15(%825 : i64)
  ^bb19:  // pred: ^bb15
    %826 = llvm.add %445, %26 overflow<nsw> : i32
    llvm.br ^bb8(%826 : i32)
  ^bb20:  // pred: ^bb8
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 4 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 5 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 4 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%353) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 17 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 17 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 21 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 21 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 22 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 6 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 22 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 6 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 23 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 7 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 23 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 7 : i64}> : () -> ()
    llvm.br ^bb21
  ^bb21:  // 2 preds: ^bb2, ^bb20
    %827 = llvm.add %345, %40 : i64
    llvm.store %827, %328 : i64, !llvm.ptr
    %828 = llvm.add %343, %36 overflow<nsw> : i32
    llvm.br ^bb1(%828 : i32)
  ^bb22:  // pred: ^bb1
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %829 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %830 = "hivm.intr.hivm.SBITSET1"(%829, %6) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%830) : (i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 6 : i64}> : () -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_0(%arg0: !llvm.ptr<6>, %arg1: i32, %arg2: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(0 : i32) : i32
    %1 = llvm.mlir.constant(8 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64s32"(%arg0, %0, %0, %0) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xi32>
    %4 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %5 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%3, %arg1, %4) : (vector<64xi32>, i32, vector<256xi1>) -> vector<64xi32>
    %6 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %7 = "hivm_regbaseintrins.intr.hivm.vcvtif.s322f32.x"(%5, %6, %0) : (vector<64xi32>, vector<256xi1>, i32) -> vector<64xf32>
    %8 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%7, %arg2, %0, %2, %0, %8) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_1(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(5.110000e+02 : f32) : f32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(8 : i32) : i32
    %3 = llvm.mlir.constant(2 : i32) : i32
    %4 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %5 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %1) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %6 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%4, %0, %5) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %7 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %1) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%6, %arg1, %1, %3, %1, %7) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_2(%arg0: !llvm.ptr<6>, %arg1: f32, %arg2: f32, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(0 : i32) : i32
    %1 = llvm.mlir.constant(8 : i32) : i32
    %2 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %0, %0, %0) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %3 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg1) : (f32) -> vector<64xf32>
    %4 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %5 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%2, %3, %4) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %6 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %7 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %8 = "hivm_regbaseintrins.intr.hivm.pstu.b32"(%5, %arg4, %7) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %9 = llvm.extractvalue %8[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %10 = llvm.extractvalue %8[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%9, %10, %0, %0) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %11 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg2) : (f32) -> vector<64xf32>
    %12 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %13 = "hivm_regbaseintrins.intr.hivm.vcmp.le.s.z"(%2, %11, %12) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %14 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %15 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %16 = "hivm_regbaseintrins.intr.hivm.pstu.b32"(%13, %arg5, %15) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %17 = llvm.extractvalue %16[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %18 = llvm.extractvalue %16[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%17, %18, %0, %0) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %19 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg3, %0, %0, %0) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %20 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %21 = "hivm_regbaseintrins.intr.hivm.vcmp.ge.s.z"(%19, %11, %20) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %23 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %24 = "hivm_regbaseintrins.intr.hivm.pstu.b32"(%21, %arg6, %23) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %25 = llvm.extractvalue %24[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %26 = llvm.extractvalue %24[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%25, %26, %0, %0) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_3(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: f32, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: f32, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>, %arg8: !llvm.ptr<6>, %arg9: !llvm.ptr<6>, %arg10: !llvm.ptr<6>, %arg11: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %1 = llvm.mlir.constant(8 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(1 : i32) : i32
    %4 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %5 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%0, %4, %3) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %6 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %7 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg2) : (f32) -> vector<64xf32>
    %8 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %9 = "hivm_regbaseintrins.intr.hivm.vcmp.le.s.z"(%6, %7, %8) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %10 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%arg0, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %11 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %12 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%10, %11) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %13 = llvm.extractvalue %12[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %14 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%13, %11) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %15 = llvm.extractvalue %14[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %16 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %17 = "hivm_regbaseintrins.intr.hivm.pand.z"(%15, %9, %16) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %18 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %19 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%6, %5, %18) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %20 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg3, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.vcmp.ge.s.z"(%20, %7, %21) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %23 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %24 = "hivm_regbaseintrins.intr.hivm.por.z"(%19, %22, %23) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %25 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %26 = "hivm_regbaseintrins.intr.hivm.pand.z"(%17, %24, %25) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %27 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %28 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %29 = "hivm_regbaseintrins.intr.hivm.pstu.b32"(%26, %arg9, %28) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %30 = llvm.extractvalue %29[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %31 = llvm.extractvalue %29[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%30, %31, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %32 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%arg4, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %33 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %34 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%32, %33) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %35 = llvm.extractvalue %34[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %36 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%35, %33) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %37 = llvm.extractvalue %36[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %38 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %39 = "hivm_regbaseintrins.intr.hivm.pand.z"(%37, %15, %38) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %40 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg5) : (f32) -> vector<64xf32>
    %41 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %42 = "hivm_regbaseintrins.intr.hivm.vcmp.le.s.z"(%6, %40, %41) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %43 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %44 = "hivm_regbaseintrins.intr.hivm.pand.z"(%39, %42, %43) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %45 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %46 = "hivm_regbaseintrins.intr.hivm.vcmp.ge.s.z"(%20, %40, %45) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<256xi1>
    %47 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %48 = "hivm_regbaseintrins.intr.hivm.por.z"(%19, %46, %47) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %49 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %50 = "hivm_regbaseintrins.intr.hivm.pand.z"(%44, %48, %49) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %51 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %52 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %53 = "hivm_regbaseintrins.intr.hivm.pstu.b32"(%50, %arg10, %52) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %54 = llvm.extractvalue %53[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %55 = llvm.extractvalue %53[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%54, %55, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %56 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%arg6, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %57 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %58 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%56, %57) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %59 = llvm.extractvalue %58[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %60 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%59, %57) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %61 = llvm.extractvalue %60[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %62 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %63 = "hivm_regbaseintrins.intr.hivm.pand.z"(%61, %15, %62) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %64 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%arg7, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %65 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %66 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%64, %65) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %67 = llvm.extractvalue %66[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %68 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%67, %65) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %69 = llvm.extractvalue %68[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %70 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %71 = "hivm_regbaseintrins.intr.hivm.pand.z"(%63, %69, %70) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %72 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%arg8, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %73 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %74 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%72, %73) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %75 = llvm.extractvalue %74[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %76 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%75, %73) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %77 = llvm.extractvalue %76[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %78 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %79 = "hivm_regbaseintrins.intr.hivm.por.z"(%19, %77, %78) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %80 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %81 = "hivm_regbaseintrins.intr.hivm.pand.z"(%71, %79, %80) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %82 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %83 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %84 = "hivm_regbaseintrins.intr.hivm.pstu.b32"(%81, %arg11, %83) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %85 = llvm.extractvalue %84[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %86 = llvm.extractvalue %84[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%85, %86, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_7(%arg0: !llvm.ptr<6>, %arg1: i64, %arg2: !llvm.ptr<6>, %arg3: f32, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(8 : i32) : i32
    %1 = llvm.mlir.constant(-1.000000e+06 : f32) : f32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(6 : i32) : i32
    %4 = llvm.mlir.constant(1 : i32) : i32
    %5 = llvm.mlir.constant(8 : index) : i64
    %6 = llvm.mlir.constant(2 : i32) : i32
    %7 = llvm.mlir.constant(256 : index) : i64
    %8 = llvm.mlir.constant(1536 : index) : i64
    %9 = llvm.mlir.constant(384 : index) : i64
    %10 = llvm.mlir.constant(64 : index) : i64
    %11 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %12 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%1, %11, %4) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    llvm.br ^bb1(%2 : i32)
  ^bb1(%13: i32):  // 2 preds: ^bb0, ^bb2
    %14 = llvm.icmp "slt" %13, %3 : i32
    llvm.cond_br %14, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %15 = llvm.sext %13 : i32 to i64
    %16 = llvm.mul %arg1, %8 : i64
    %17 = llvm.mul %15, %7 : i64
    %18 = llvm.add %16, %17 : i64
    %19 = llvm.udiv %18, %5  : i64
    %20 = llvm.getelementptr %arg0[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %21 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%20, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %2) : (i32, i32) -> vector<256xi1>
    %23 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%21, %22) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %24 = llvm.extractvalue %23[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %25 = "hivm_regbaseintrins.intr.hivm.pintlv.b8"(%24, %22) : (vector<256xi1>, vector<256xi1>) -> !llvm.struct<(vector<256xi1>, vector<256xi1>)>
    %26 = llvm.extractvalue %25[0] : !llvm.struct<(vector<256xi1>, vector<256xi1>)> 
    %27 = llvm.mul %arg1, %9 : i64
    %28 = llvm.mul %15, %10 : i64
    %29 = llvm.add %27, %28 : i64
    %30 = llvm.getelementptr %arg2[%29] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %31 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%30, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %32 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %33 = "hivm_regbaseintrins.intr.hivm.vmuls.s.x"(%31, %arg3, %32) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %34 = "hivm_regbaseintrins.intr.hivm.vsel"(%33, %12, %26) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %35 = llvm.mul %15, %10 : i64
    %36 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %37 = llvm.getelementptr %arg4[%35] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%34, %37, %2, %6, %2, %36) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %38 = llvm.add %13, %4 overflow<nsw> : i32
    llvm.br ^bb1(%38 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_8(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(8 : i32) : i32
    %4 = llvm.mlir.constant(4 : i32) : i32
    %5 = llvm.mlir.undef : !llvm.ptr<6>
    %6 = llvm.mlir.constant(64 : index) : i64
    %7 = llvm.mlir.constant(6 : index) : i64
    %8 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %8, %5 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%9: i32, %10: vector<32xi8>, %11: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %12 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %12, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %13 = llvm.sext %9 : i32 to i64
    %14 = llvm.mul %13, %6 : i64
    %15 = llvm.getelementptr %arg0[%14] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %16 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%15, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %17 = llvm.mul %arg2, %7 : i64
    %18 = llvm.add %17, %13 : i64
    %19 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %20 = "hivm_regbaseintrins.intr.hivm.vcmax.s.x"(%16, %19) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%20, %22, %4, %10) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %24 = llvm.extractvalue %23[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %25 = llvm.extractvalue %23[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %26 = llvm.add %9, %0 overflow<nsw> : i32
    llvm.br ^bb1(%26, %24, %25 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%10, %11, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_9(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = llvm.mlir.constant(6 : index) : i64
    %4 = llvm.mul %arg2, %3 : i64
    %5 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %6 = llvm.extractvalue %5[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %7 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %8 = llvm.getelementptr %arg1[%4] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %9 = "hivm_regbaseintrins.intr.hivm.vldas"(%8) : (!llvm.ptr<6>) -> vector<32xi8>
    %10 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%8, %9, %1) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %11 = llvm.extractvalue %10[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    %12 = "hivm_regbaseintrins.intr.hivm.vmax.s.x"(%7, %11, %6) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%12, %arg3, %1, %2, %1, %6) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_10(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = llvm.mlir.constant(24 : i32) : i32
    %4 = llvm.mlir.constant(6 : index) : i64
    %5 = llvm.mul %arg3, %4 : i64
    %6 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %7 = llvm.extractvalue %6[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %8 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %10 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%8, %9, %7, %1) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %11 = llvm.getelementptr %arg2[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %12 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %13 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%10, %11, %3, %12) : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %14 = llvm.extractvalue %13[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %15 = llvm.extractvalue %13[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%14, %15, %1, %1) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %16 = llvm.getelementptr %arg2[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %17 = "hivm_regbaseintrins.intr.hivm.vldas"(%16) : (!llvm.ptr<6>) -> vector<32xi8>
    %18 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%16, %17, %1) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %19 = llvm.extractvalue %18[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%19, %arg4, %1, %2, %1, %7) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_11(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %4 = llvm.mlir.constant(3 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(7 : i32) : i32
    %7 = llvm.mlir.constant(4 : i32) : i32
    %8 = llvm.mlir.constant(2 : i32) : i32
    %9 = llvm.mlir.undef : !llvm.ptr<6>
    %10 = llvm.mlir.constant(64 : index) : i64
    %11 = llvm.mlir.constant(6 : index) : i64
    %12 = llvm.mul %arg3, %11 : i64
    %13 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %13, %9 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%14: i32, %15: vector<32xi8>, %16: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %17 = llvm.icmp "slt" %14, %1 : i32
    llvm.cond_br %17, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %14 : i32 to i64
    %19 = llvm.mul %18, %10 : i64
    %20 = llvm.getelementptr %arg0[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %21 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%20, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %22 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%22, %2, %4, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%21, %23, %24, %2) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %27 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%25, %3, %26) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%25, %28, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %30 = llvm.mul %18, %10 : i64
    %31 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %32 = llvm.getelementptr %arg4[%30] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%29, %32, %2, %6, %2, %31) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %33 = llvm.mul %arg3, %11 : i64
    %34 = llvm.add %33, %18 : i64
    %35 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %36 = "hivm_regbaseintrins.intr.hivm.vcadd.s.x"(%27, %35) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %37 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %38 = llvm.getelementptr %arg2[%34] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %39 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%36, %38, %7, %15) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %40 = llvm.extractvalue %39[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %41 = llvm.extractvalue %39[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %42 = llvm.add %14, %0 overflow<nsw> : i32
    llvm.br ^bb1(%42, %40, %41 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%15, %16, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %43 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%1) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %44 = llvm.extractvalue %43[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %45 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg5, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %46 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg6, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %47 = llvm.getelementptr %arg2[%12] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %48 = "hivm_regbaseintrins.intr.hivm.vldas"(%47) : (!llvm.ptr<6>) -> vector<32xi8>
    %49 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%47, %48, %2) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %50 = llvm.extractvalue %49[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    %51 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%45, %46, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %52 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%51, %50, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%52, %arg7, %2, %8, %2, %44) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_14(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(8 : i32) : i32
    %4 = llvm.mlir.constant(4 : i32) : i32
    %5 = llvm.mlir.undef : !llvm.ptr<6>
    %6 = llvm.mlir.constant(64 : index) : i64
    %7 = llvm.mlir.constant(6 : index) : i64
    %8 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %8, %5 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%9: i32, %10: vector<32xi8>, %11: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %12 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %12, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %13 = llvm.sext %9 : i32 to i64
    %14 = llvm.mul %13, %6 : i64
    %15 = llvm.getelementptr %arg0[%14] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %16 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%15, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %17 = llvm.mul %arg2, %7 : i64
    %18 = llvm.add %17, %13 : i64
    %19 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %20 = "hivm_regbaseintrins.intr.hivm.vcmax.s.x"(%16, %19) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%20, %22, %4, %10) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %24 = llvm.extractvalue %23[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %25 = llvm.extractvalue %23[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %26 = llvm.add %9, %0 overflow<nsw> : i32
    llvm.br ^bb1(%26, %24, %25 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%10, %11, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_15(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = llvm.mlir.constant(6 : index) : i64
    %4 = llvm.mul %arg2, %3 : i64
    %5 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %6 = llvm.extractvalue %5[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %7 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %8 = llvm.getelementptr %arg1[%4] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %9 = "hivm_regbaseintrins.intr.hivm.vldas"(%8) : (!llvm.ptr<6>) -> vector<32xi8>
    %10 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%8, %9, %1) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %11 = llvm.extractvalue %10[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    %12 = "hivm_regbaseintrins.intr.hivm.vmax.s.x"(%7, %11, %6) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%12, %arg3, %1, %2, %1, %6) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_16(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = llvm.mlir.constant(24 : i32) : i32
    %4 = llvm.mlir.constant(6 : index) : i64
    %5 = llvm.mul %arg3, %4 : i64
    %6 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %7 = llvm.extractvalue %6[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %8 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %10 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%8, %9, %7, %1) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %11 = llvm.getelementptr %arg2[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %12 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %13 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%10, %11, %3, %12) : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %14 = llvm.extractvalue %13[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %15 = llvm.extractvalue %13[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%14, %15, %1, %1) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %16 = llvm.getelementptr %arg2[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %17 = "hivm_regbaseintrins.intr.hivm.vldas"(%16) : (!llvm.ptr<6>) -> vector<32xi8>
    %18 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%16, %17, %1) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %19 = llvm.extractvalue %18[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%19, %arg4, %1, %2, %1, %7) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_17(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %4 = llvm.mlir.constant(3 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(7 : i32) : i32
    %7 = llvm.mlir.constant(4 : i32) : i32
    %8 = llvm.mlir.constant(2 : i32) : i32
    %9 = llvm.mlir.undef : !llvm.ptr<6>
    %10 = llvm.mlir.constant(64 : index) : i64
    %11 = llvm.mlir.constant(6 : index) : i64
    %12 = llvm.mul %arg3, %11 : i64
    %13 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %13, %9 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%14: i32, %15: vector<32xi8>, %16: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %17 = llvm.icmp "slt" %14, %1 : i32
    llvm.cond_br %17, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %14 : i32 to i64
    %19 = llvm.mul %18, %10 : i64
    %20 = llvm.getelementptr %arg0[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %21 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%20, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %22 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%22, %2, %4, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%21, %23, %24, %2) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %27 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%25, %3, %26) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%25, %28, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %30 = llvm.mul %18, %10 : i64
    %31 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %32 = llvm.getelementptr %arg4[%30] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%29, %32, %2, %6, %2, %31) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %33 = llvm.mul %arg3, %11 : i64
    %34 = llvm.add %33, %18 : i64
    %35 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %36 = "hivm_regbaseintrins.intr.hivm.vcadd.s.x"(%27, %35) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %37 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %38 = llvm.getelementptr %arg2[%34] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %39 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%36, %38, %7, %15) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %40 = llvm.extractvalue %39[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %41 = llvm.extractvalue %39[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %42 = llvm.add %14, %0 overflow<nsw> : i32
    llvm.br ^bb1(%42, %40, %41 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%15, %16, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %43 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%1) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %44 = llvm.extractvalue %43[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %45 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg5, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %46 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg6, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %47 = llvm.getelementptr %arg2[%12] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %48 = "hivm_regbaseintrins.intr.hivm.vldas"(%47) : (!llvm.ptr<6>) -> vector<32xi8>
    %49 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%47, %48, %2) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %50 = llvm.extractvalue %49[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    %51 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%45, %46, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %52 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%51, %50, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%52, %arg7, %2, %8, %2, %44) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_20(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(8 : i32) : i32
    %4 = llvm.mlir.constant(4 : i32) : i32
    %5 = llvm.mlir.undef : !llvm.ptr<6>
    %6 = llvm.mlir.constant(64 : index) : i64
    %7 = llvm.mlir.constant(6 : index) : i64
    %8 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %8, %5 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%9: i32, %10: vector<32xi8>, %11: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %12 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %12, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %13 = llvm.sext %9 : i32 to i64
    %14 = llvm.mul %13, %6 : i64
    %15 = llvm.getelementptr %arg0[%14] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %16 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%15, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %17 = llvm.mul %arg2, %7 : i64
    %18 = llvm.add %17, %13 : i64
    %19 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %20 = "hivm_regbaseintrins.intr.hivm.vcmax.s.x"(%16, %19) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%20, %22, %4, %10) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %24 = llvm.extractvalue %23[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %25 = llvm.extractvalue %23[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %26 = llvm.add %9, %0 overflow<nsw> : i32
    llvm.br ^bb1(%26, %24, %25 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%10, %11, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_21(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = llvm.mlir.constant(6 : index) : i64
    %4 = llvm.mul %arg2, %3 : i64
    %5 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %6 = llvm.extractvalue %5[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %7 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %8 = llvm.getelementptr %arg1[%4] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %9 = "hivm_regbaseintrins.intr.hivm.vldas"(%8) : (!llvm.ptr<6>) -> vector<32xi8>
    %10 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%8, %9, %1) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %11 = llvm.extractvalue %10[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    %12 = "hivm_regbaseintrins.intr.hivm.vmax.s.x"(%7, %11, %6) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%12, %arg3, %1, %2, %1, %6) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_22(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(6 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = llvm.mlir.constant(24 : i32) : i32
    %4 = llvm.mlir.constant(6 : index) : i64
    %5 = llvm.mul %arg3, %4 : i64
    %6 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %7 = llvm.extractvalue %6[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %8 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %10 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%8, %9, %7, %1) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %11 = llvm.getelementptr %arg2[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %12 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %13 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%10, %11, %3, %12) : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %14 = llvm.extractvalue %13[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %15 = llvm.extractvalue %13[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%14, %15, %1, %1) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %16 = llvm.getelementptr %arg2[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %17 = "hivm_regbaseintrins.intr.hivm.vldas"(%16) : (!llvm.ptr<6>) -> vector<32xi8>
    %18 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%16, %17, %1) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %19 = llvm.extractvalue %18[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%19, %arg4, %1, %2, %1, %7) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_23(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: i64, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %4 = llvm.mlir.constant(3 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(7 : i32) : i32
    %7 = llvm.mlir.constant(4 : i32) : i32
    %8 = llvm.mlir.constant(2 : i32) : i32
    %9 = llvm.mlir.undef : !llvm.ptr<6>
    %10 = llvm.mlir.constant(64 : index) : i64
    %11 = llvm.mlir.constant(6 : index) : i64
    %12 = llvm.mul %arg3, %11 : i64
    %13 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %13, %9 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%14: i32, %15: vector<32xi8>, %16: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %17 = llvm.icmp "slt" %14, %1 : i32
    llvm.cond_br %17, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %14 : i32 to i64
    %19 = llvm.mul %18, %10 : i64
    %20 = llvm.getelementptr %arg0[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %21 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%20, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %22 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%22, %2, %4, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%21, %23, %24, %2) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %27 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%25, %3, %26) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%25, %28, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %30 = llvm.mul %18, %10 : i64
    %31 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %32 = llvm.getelementptr %arg4[%30] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%29, %32, %2, %6, %2, %31) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %33 = llvm.mul %arg3, %11 : i64
    %34 = llvm.add %33, %18 : i64
    %35 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %36 = "hivm_regbaseintrins.intr.hivm.vcadd.s.x"(%27, %35) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %37 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %38 = llvm.getelementptr %arg2[%34] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %39 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%36, %38, %7, %15) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %40 = llvm.extractvalue %39[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %41 = llvm.extractvalue %39[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %42 = llvm.add %14, %0 overflow<nsw> : i32
    llvm.br ^bb1(%42, %40, %41 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%15, %16, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %43 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%1) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %44 = llvm.extractvalue %43[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %45 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg5, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %46 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg6, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %47 = llvm.getelementptr %arg2[%12] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %48 = "hivm_regbaseintrins.intr.hivm.vldas"(%47) : (!llvm.ptr<6>) -> vector<32xi8>
    %49 = "hivm_regbaseintrins.intr.hivm.vldus.post.f32"(%47, %48, %2) : (!llvm.ptr<6>, vector<32xi8>, i32) -> !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)>
    %50 = llvm.extractvalue %49[0] : !llvm.struct<(vector<64xf32>, vector<32xi8>, ptr<6>)> 
    %51 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%45, %46, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %52 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%51, %50, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%52, %arg7, %2, %8, %2, %44) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_24(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(16 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(8 : i32) : i32
    %4 = llvm.mlir.constant(1114112 : i32) : i32
    %5 = llvm.mlir.constant(64 : index) : i64
    %6 = llvm.mlir.constant(16 : index) : i64
    %7 = llvm.mlir.constant(272 : index) : i64
    %8 = llvm.mlir.constant(0 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%9: i32):  // 2 preds: ^bb0, ^bb2
    %10 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %10, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %11 = llvm.sext %9 : i32 to i64
    %12 = llvm.mul %11, %5 : i64
    %13 = llvm.getelementptr %arg0[%12] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %14 = llvm.mul %8, %5 : i64
    %15 = llvm.add %14, %8 : i64
    %16 = llvm.getelementptr %13[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %17 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%16, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %18 = llvm.mul %11, %6 : i64
    %19 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%3, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %20 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %21 = llvm.mul %8, %7 : i64
    %22 = llvm.add %21, %8 : i64
    %23 = llvm.getelementptr %20[%22] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vsstb.v128bf16"(%17, %23, %4, %2, %19) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, vector<256xi1>) -> ()
    %24 = llvm.add %9, %0 overflow<nsw> : i32
    llvm.br ^bb1(%24 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_25(%arg0: !llvm.ptr<6>, %arg1: i64, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>, %arg8: !llvm.ptr<6>, %arg9: !llvm.ptr<6>, %arg10: !llvm.ptr<6>, %arg11: !llvm.ptr<6>, %arg12: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(6 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(256 : i32) : i32
    %4 = llvm.mlir.constant(64 : i32) : i32
    %5 = llvm.mlir.constant(3 : i32) : i32
    %6 = llvm.mlir.constant(8 : i32) : i32
    %7 = llvm.mlir.constant(2 : i32) : i32
    %8 = llvm.mlir.constant(1536 : index) : i64
    %9 = llvm.mlir.constant(256 : index) : i64
    %10 = llvm.mlir.constant(6 : index) : i64
    %11 = llvm.mlir.constant(0 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%12: i32):  // 2 preds: ^bb0, ^bb5
    %13 = llvm.icmp "slt" %12, %1 : i32
    llvm.cond_br %13, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %14 = llvm.sext %12 : i32 to i64
    %15 = llvm.mul %arg1, %10 : i64
    %16 = llvm.add %15, %14 : i64
    %17 = llvm.mul %arg1, %10 : i64
    %18 = llvm.add %17, %14 : i64
    %19 = llvm.mul %arg1, %10 : i64
    %20 = llvm.add %19, %14 : i64
    llvm.br ^bb3(%2 : i32)
  ^bb3(%21: i32):  // 2 preds: ^bb2, ^bb4
    %22 = llvm.icmp "slt" %21, %3 : i32
    llvm.cond_br %22, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %23 = llvm.sext %21 : i32 to i64
    %24 = llvm.mul %arg1, %8 : i64
    %25 = llvm.mul %14, %9 : i64
    %26 = llvm.add %24, %25 : i64
    %27 = llvm.add %26, %23 : i64
    %28 = llvm.getelementptr %arg4[%27] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %29 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%28, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %30 = llvm.mul %14, %9 : i64
    %31 = llvm.add %30, %23 : i64
    %32 = llvm.getelementptr %arg5[%31] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %33 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%32, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %34 = llvm.getelementptr %arg0[%16] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %35 = llvm.mul %11, %10 : i64
    %36 = llvm.getelementptr %34[%35] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %37 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%36, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %38 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %39 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%33, %37, %38) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %40 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %41 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%29, %39, %40) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %42 = llvm.mul %14, %9 : i64
    %43 = llvm.add %42, %23 : i64
    %44 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %45 = llvm.getelementptr %arg10[%43] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%41, %45, %2, %7, %2, %44) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %46 = llvm.mul %arg1, %8 : i64
    %47 = llvm.mul %14, %9 : i64
    %48 = llvm.add %46, %47 : i64
    %49 = llvm.add %48, %23 : i64
    %50 = llvm.getelementptr %arg6[%49] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %51 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%50, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %52 = llvm.mul %14, %9 : i64
    %53 = llvm.add %52, %23 : i64
    %54 = llvm.getelementptr %arg7[%53] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %55 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%54, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %56 = llvm.getelementptr %arg2[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %57 = llvm.mul %11, %10 : i64
    %58 = llvm.getelementptr %56[%57] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %59 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%58, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %60 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %61 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%55, %59, %60) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %62 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %63 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%51, %61, %62) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %64 = llvm.mul %14, %9 : i64
    %65 = llvm.add %64, %23 : i64
    %66 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %67 = llvm.getelementptr %arg11[%65] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%63, %67, %2, %7, %2, %66) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %68 = llvm.mul %arg1, %8 : i64
    %69 = llvm.mul %14, %9 : i64
    %70 = llvm.add %68, %69 : i64
    %71 = llvm.add %70, %23 : i64
    %72 = llvm.getelementptr %arg8[%71] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %73 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%72, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %74 = llvm.mul %14, %9 : i64
    %75 = llvm.add %74, %23 : i64
    %76 = llvm.getelementptr %arg9[%75] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %77 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%76, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %78 = llvm.getelementptr %arg3[%20] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %79 = llvm.mul %11, %10 : i64
    %80 = llvm.getelementptr %78[%79] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %81 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%80, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %82 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %83 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%77, %81, %82) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %84 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %85 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%73, %83, %84) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %86 = llvm.mul %14, %9 : i64
    %87 = llvm.add %86, %23 : i64
    %88 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %89 = llvm.getelementptr %arg12[%87] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%85, %89, %2, %7, %2, %88) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %90 = llvm.add %21, %4 overflow<nsw> : i32
    llvm.br ^bb3(%90 : i32)
  ^bb5:  // pred: ^bb3
    %91 = llvm.add %12, %0 overflow<nsw> : i32
    llvm.br ^bb1(%91 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_26(%arg0: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(0 : i32) : i32
    %1 = llvm.mlir.constant(8 : i32) : i32
    %2 = llvm.mlir.constant(1 : i32) : i32
    %3 = llvm.mlir.constant(2 : i32) : i32
    %4 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %5 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%0, %4, %2) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %6 = "hivm_regbaseintrins.intr.hivm.vci"(%0, %0) : (i32, i32) -> vector<64xi32>
    %7 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %8 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%5, %6, %7) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    %9 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64s32"(%8, %arg0, %0, %3, %0, %9) : (vector<64xi32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_27(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i8) : i8
    %1 = llvm.mlir.constant(0 : i8) : i8
    %2 = llvm.mlir.constant(15 : i32) : i32
    %3 = llvm.mlir.constant(0 : i32) : i32
    %4 = llvm.mlir.constant(1 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %3) {mask_bit_width = 8 : i32} : (i32, i32) -> vector<256xi1>
    %7 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%arg0, %3, %3, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %8 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%3, %3) {mask_bit_width = 8 : i32} : (i32, i32) -> vector<256xi1>
    %9 = "hivm_regbaseintrins.intr.hivm.vbr"(%1) : (i8) -> vector<256xi8>
    %10 = "hivm_regbaseintrins.intr.hivm.vbr"(%0) : (i8) -> vector<256xi8>
    %11 = "hivm_regbaseintrins.intr.hivm.vsel"(%10, %9, %7) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %12 = "hivm_regbaseintrins.intr.hivm.vdup.z"(%11, %8, %4) : (vector<256xi8>, vector<256xi1>, i32) -> vector<256xi8>
    %13 = "hivm_regbaseintrins.intr.hivm.vcmp.ne.s.z"(%12, %9, %8) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi1>
    %14 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%5, %3) {mask_bit_width = 8 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %15 = "hivm_regbaseintrins.intr.hivm.pxor.z"(%13, %6, %14) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.psts.b8"(%15, %arg2, %3, %3, %3) : (vector<256xi1>, !llvm.ptr<6>, i32, i32, i32) -> ()
    %16 = "hivm_regbaseintrins.intr.hivm.plds.b8"(%arg1, %3, %3, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi1>
    %17 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%3, %3) {mask_bit_width = 8 : i32} : (i32, i32) -> vector<256xi1>
    %18 = "hivm_regbaseintrins.intr.hivm.vbr"(%1) : (i8) -> vector<256xi8>
    %19 = "hivm_regbaseintrins.intr.hivm.vbr"(%0) : (i8) -> vector<256xi8>
    %20 = "hivm_regbaseintrins.intr.hivm.vsel"(%19, %18, %16) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi8>
    %21 = "hivm_regbaseintrins.intr.hivm.vdup.z"(%20, %17, %4) : (vector<256xi8>, vector<256xi1>, i32) -> vector<256xi8>
    %22 = "hivm_regbaseintrins.intr.hivm.vcmp.ne.s.z"(%21, %18, %17) : (vector<256xi8>, vector<256xi8>, vector<256xi1>) -> vector<256xi1>
    %23 = "hivm_regbaseintrins.intr.hivm.pxor.z"(%22, %6, %14) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.psts.b8"(%23, %arg3, %3, %3, %3) : (vector<256xi1>, !llvm.ptr<6>, i32, i32, i32) -> ()
    llvm.return
  }
  llvm.func private @nd2nz_bfloat16_t(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<2>, %arg8: !llvm.ptr<2>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %15 = llvm.insertvalue %arg14, %14[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg15, %16[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg12, %17[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg13, %19[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %21, %22 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_nd2nz_bfloat16_t(%10, %22) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_nd2nz_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @set_l1_2d_bfloat16_t(%arg0: bf16, %arg1: !llvm.ptr<2>, %arg2: !llvm.ptr<2>, %arg3: i64, %arg4: i64, %arg5: i64) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg1, %1[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg4, %4[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg5, %5[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_set_l1_2d_bfloat16_t(%arg0, %7) : (bf16, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_set_l1_2d_bfloat16_t(bf16, !llvm.ptr) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @mma_tile_bfloat16_t_to_float_tb(%arg0: !llvm.ptr<2>, %arg1: !llvm.ptr<2>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<2>, %arg12: !llvm.ptr<2>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64, %arg21: i64, %arg22: i1, %arg23: i64, %arg24: i64, %arg25: i64, %arg26: !llvm.ptr<5>, %arg27: !llvm.ptr<5>, %arg28: i64, %arg29: i64, %arg30: i64, %arg31: i64, %arg32: i64, %arg33: i64, %arg34: i64, %arg35: i64, %arg36: i64, %arg37: i64, %arg38: i64, %arg39: i64, %arg40: i64, %arg41: i64, %arg42: i64, %arg43: i64, %arg44: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg18, %18[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.insertvalue %arg16, %21[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %24 = llvm.insertvalue %arg17, %23[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %25 = llvm.insertvalue %arg21, %24[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %26 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %25, %26 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %27 = llvm.insertvalue %arg26, %0[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %28 = llvm.insertvalue %arg27, %27[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %29 = llvm.insertvalue %arg28, %28[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %30 = llvm.insertvalue %arg29, %29[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %31 = llvm.insertvalue %arg33, %30[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %32 = llvm.insertvalue %arg30, %31[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %33 = llvm.insertvalue %arg34, %32[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %34 = llvm.insertvalue %arg31, %33[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %35 = llvm.insertvalue %arg35, %34[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %36 = llvm.insertvalue %arg32, %35[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %37 = llvm.insertvalue %arg36, %36[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %38 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %37, %38 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_mma_tile_bfloat16_t_to_float_tb(%14, %26, %arg22, %arg23, %arg24, %arg25, %38, %arg37, %arg38, %arg39, %arg40, %arg41, %arg42, %arg43, %arg44) : (!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_mma_tile_bfloat16_t_to_float_tb(!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%arg0: !llvm.ptr<5>, %arg1: !llvm.ptr<5>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<6>, %arg12: !llvm.ptr<6>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: f32, %arg20: i64, %arg21: i1, %arg22: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %21, %22 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%14, %22, %arg18, %arg19, %arg20, %arg21, %arg22) : (!llvm.ptr, !llvm.ptr, i64, f32, i64, i1, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(!llvm.ptr, !llvm.ptr, i64, f32, i64, i1, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @mma_tile_bfloat16_t_to_float(%arg0: !llvm.ptr<2>, %arg1: !llvm.ptr<2>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<2>, %arg12: !llvm.ptr<2>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64, %arg21: i64, %arg22: i1, %arg23: i64, %arg24: i64, %arg25: i64, %arg26: !llvm.ptr<5>, %arg27: !llvm.ptr<5>, %arg28: i64, %arg29: i64, %arg30: i64, %arg31: i64, %arg32: i64, %arg33: i64, %arg34: i64, %arg35: i64, %arg36: i64, %arg37: i64, %arg38: i64, %arg39: i64, %arg40: i64, %arg41: i64, %arg42: i64, %arg43: i64, %arg44: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg18, %18[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.insertvalue %arg16, %21[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %24 = llvm.insertvalue %arg17, %23[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %25 = llvm.insertvalue %arg21, %24[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %26 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %25, %26 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %27 = llvm.insertvalue %arg26, %0[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %28 = llvm.insertvalue %arg27, %27[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %29 = llvm.insertvalue %arg28, %28[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %30 = llvm.insertvalue %arg29, %29[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %31 = llvm.insertvalue %arg33, %30[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %32 = llvm.insertvalue %arg30, %31[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %33 = llvm.insertvalue %arg34, %32[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %34 = llvm.insertvalue %arg31, %33[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %35 = llvm.insertvalue %arg35, %34[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %36 = llvm.insertvalue %arg32, %35[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %37 = llvm.insertvalue %arg36, %36[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %38 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %37, %38 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_mma_tile_bfloat16_t_to_float(%14, %26, %arg22, %arg23, %arg24, %arg25, %38, %arg37, %arg38, %arg39, %arg40, %arg41, %arg42, %arg43, %arg44) : (!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_mma_tile_bfloat16_t_to_float(!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @load_gm_to_ubuf_1d_float(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i32, %arg11: f32, %arg12: i64, %arg13: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.insertvalue %arg4, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %8 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %7, %8 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %9 = llvm.insertvalue %arg5, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg6, %9[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg7, %10[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_load_gm_to_ubuf_1d_float(%8, %14, %arg10, %arg11, %arg12, %arg13) : (!llvm.ptr, !llvm.ptr, i32, f32, i64, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_load_gm_to_ubuf_1d_float(!llvm.ptr, !llvm.ptr, i32, f32, i64, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_ubuf_1d_float(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg0, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg1, %2[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg2, %3[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg3, %4[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %8 = llvm.insertvalue %arg5, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg7, %9[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg8, %10[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg9, %11[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %12, %13 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_ubuf_1d_float(%7, %13) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_ubuf_1d_float(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_ubuf_1d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg0, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg1, %2[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg2, %3[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg3, %4[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %8 = llvm.insertvalue %arg5, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg7, %9[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg8, %10[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg9, %11[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %12, %13 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_ubuf_1d_bfloat16_t(%7, %13) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_ubuf_1d_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_cbuf_2d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<2>, %arg8: !llvm.ptr<2>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg12, %14[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %17, %18 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_cbuf_2d_bfloat16_t(%10, %18) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_cbuf_2d_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @store_ubuf_to_gm_2d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<1>, %arg8: !llvm.ptr<1>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg12, %14[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %17, %18 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_store_ubuf_to_gm_2d_bfloat16_t(%10, %18, %arg14) : (!llvm.ptr, !llvm.ptr, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_store_ubuf_to_gm_2d_bfloat16_t(!llvm.ptr, !llvm.ptr, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv(%arg0: i64, %arg1: !llvm.ptr<1>, %arg2: !llvm.ptr<1>, %arg3: !llvm.ptr<1>, %arg4: !llvm.ptr<1>, %arg5: !llvm.ptr<1>, %arg6: !llvm.ptr<1>, %arg7: !llvm.ptr<1>, %arg8: i32, %arg9: !llvm.ptr<1>, %arg10: !llvm.ptr<1>, %arg11: !llvm.ptr<1>, %arg12: f32, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32, %arg17: i32, %arg18: i32, %arg19: i32, %arg20: i32, %arg21: i32, %arg22: i32, %arg23: i32, %arg24: i32, %arg25: i32, %arg26: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix, hivm.vf_mode = #hivm.vf_mode<SIMD>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, mix_mode = "mix", parallel_mode = "simd"} {
    %0 = llvm.mlir.constant(272 : index) : i64
    %1 = llvm.mlir.constant(12 : index) : i64
    %2 = llvm.mlir.constant(-1 : index) : i64
    %3 = llvm.mlir.constant(384 : index) : i64
    %4 = llvm.mlir.constant(1024 : index) : i64
    %5 = llvm.mlir.constant(4 : index) : i64
    %6 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %7 = llvm.mlir.constant(1536 : index) : i64
    %8 = llvm.mlir.constant(256 : index) : i64
    %9 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %10 = llvm.mlir.constant(6 : index) : i64
    %11 = llvm.mlir.constant(48 : i64) : i64
    %12 = llvm.mlir.constant(60 : i64) : i64
    %13 = llvm.mlir.constant(0 : index) : i64
    %14 = llvm.mlir.constant(511 : i32) : i32
    %15 = llvm.mlir.constant(63 : i32) : i32
    %16 = llvm.mlir.constant(64 : i32) : i32
    %17 = llvm.mlir.constant(0 : i32) : i32
    %18 = llvm.mlir.constant(2 : i32) : i32
    %19 = llvm.mlir.constant(0 : i64) : i64
    %20 = llvm.mlir.constant(32 : i64) : i64
    %21 = llvm.mlir.constant(6176 : i64) : i64
    %22 = llvm.mlir.constant(6208 : i64) : i64
    %23 = llvm.mlir.constant(6464 : i64) : i64
    %24 = llvm.mlir.constant(6496 : i64) : i64
    %25 = llvm.mlir.constant(6528 : i64) : i64
    %26 = llvm.mlir.constant(6560 : i64) : i64
    %27 = llvm.mlir.constant(79456 : i64) : i64
    %28 = llvm.mlir.constant(61472 : i64) : i64
    %29 = llvm.mlir.constant(79360 : i64) : i64
    %30 = llvm.mlir.constant(85600 : i64) : i64
    %31 = llvm.mlir.constant(68288 : i64) : i64
    %32 = llvm.mlir.constant(79392 : i64) : i64
    %33 = llvm.mlir.constant(91744 : i64) : i64
    %34 = llvm.mlir.constant(75104 : i64) : i64
    %35 = llvm.mlir.constant(79424 : i64) : i64
    %36 = llvm.mlir.constant(6592 : i64) : i64
    %37 = llvm.mlir.constant(18880 : i64) : i64
    %38 = llvm.mlir.constant(31168 : i64) : i64
    %39 = llvm.mlir.constant(24576 : i64) : i64
    %40 = llvm.mlir.constant(28672 : i64) : i64
    %41 = llvm.mlir.constant(32768 : i64) : i64
    %42 = llvm.mlir.constant(43456 : i64) : i64
    %43 = llvm.mlir.constant(46528 : i64) : i64
    %44 = llvm.mlir.constant(49600 : i64) : i64
    %45 = llvm.mlir.constant(57664 : i64) : i64
    %46 = llvm.mlir.constant(57600 : i64) : i64
    %47 = llvm.mlir.constant(52672 : i64) : i64
    %48 = llvm.mlir.constant(52736 : i64) : i64
    %49 = llvm.mlir.constant(56832 : i64) : i64
    %50 = llvm.mlir.constant(57216 : i64) : i64
    %51 = llvm.mlir.constant(58048 : i64) : i64
    %52 = llvm.mlir.constant(58304 : i64) : i64
    %53 = llvm.mlir.constant(58560 : i64) : i64
    %54 = llvm.mlir.constant(58592 : i64) : i64
    %55 = llvm.mlir.constant(58624 : i64) : i64
    %56 = llvm.mlir.constant(58656 : i64) : i64
    %57 = llvm.mlir.constant(58688 : i64) : i64
    %58 = llvm.mlir.constant(58784 : i64) : i64
    %59 = llvm.mlir.constant(58848 : i64) : i64
    %60 = llvm.mlir.constant(58720 : i64) : i64
    %61 = llvm.mlir.constant(58912 : i64) : i64
    %62 = llvm.mlir.constant(60448 : i64) : i64
    %63 = llvm.mlir.constant(60512 : i64) : i64
    %64 = llvm.mlir.constant(60544 : i64) : i64
    %65 = llvm.mlir.constant(60608 : i64) : i64
    %66 = llvm.mlir.constant(60704 : i64) : i64
    %67 = llvm.mlir.constant(60640 : i64) : i64
    %68 = llvm.mlir.constant(61504 : i64) : i64
    %69 = llvm.mlir.constant(63552 : i64) : i64
    %70 = llvm.mlir.constant(65728 : i64) : i64
    %71 = llvm.mlir.constant(67264 : i64) : i64
    %72 = llvm.mlir.constant(67328 : i64) : i64
    %73 = llvm.mlir.constant(67360 : i64) : i64
    %74 = llvm.mlir.constant(67424 : i64) : i64
    %75 = llvm.mlir.constant(67520 : i64) : i64
    %76 = llvm.mlir.constant(67456 : i64) : i64
    %77 = llvm.mlir.constant(68320 : i64) : i64
    %78 = llvm.mlir.constant(70368 : i64) : i64
    %79 = llvm.mlir.constant(72544 : i64) : i64
    %80 = llvm.mlir.constant(74080 : i64) : i64
    %81 = llvm.mlir.constant(74144 : i64) : i64
    %82 = llvm.mlir.constant(74176 : i64) : i64
    %83 = llvm.mlir.constant(74240 : i64) : i64
    %84 = llvm.mlir.constant(74336 : i64) : i64
    %85 = llvm.mlir.constant(74272 : i64) : i64
    %86 = llvm.mlir.constant(75136 : i64) : i64
    %87 = llvm.mlir.constant(77184 : i64) : i64
    %88 = llvm.mlir.constant(97888 : i64) : i64
    %89 = llvm.mlir.constant(100960 : i64) : i64
    %90 = llvm.mlir.constant(104032 : i64) : i64
    %91 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %92 = llvm.mlir.constant(1 : index) : i64
    %93 = llvm.mlir.constant(1 : i32) : i32
    %94 = llvm.mlir.constant(2 : index) : i64
    %95 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %96 = "hivm.intr.hivm.SBITSET0"(%95, %12) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%96) : (i64) -> ()
    %97 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %98 = "hivm.intr.hivm.SBITSET1"(%97, %11) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%98) : (i64) -> ()
    %99 = "hivm.intr.hivm.GET.BLOCK.IDX"() : () -> i64
    %100 = llvm.trunc %99 : i64 to i32
    %101 = llvm.srem %100, %arg24  : i32
    %102 = llvm.inttoptr %19 : i64 to !llvm.ptr<6>
    %103 = llvm.inttoptr %20 : i64 to !llvm.ptr<6>
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_merged_vf_0(%102, %103) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %104 = llvm.mul %101, %arg8 : i32
    %105 = llvm.sdiv %104, %arg24  : i32
    %106 = llvm.add %101, %93 : i32
    %107 = llvm.mul %106, %arg8 : i32
    %108 = llvm.sdiv %107, %arg24  : i32
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 0 : i64}> : () -> ()
    llvm.br ^bb1(%105 : i32)
  ^bb1(%109: i32):  // 2 preds: ^bb0, ^bb28
    %110 = llvm.icmp "slt" %109, %108 : i32
    llvm.cond_br %110, ^bb2, ^bb29
  ^bb2:  // pred: ^bb1
    %111 = llvm.sext %109 : i32 to i64
    %112 = llvm.getelementptr %arg9[%111] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %113 = llvm.load %112 : !llvm.ptr<1> -> i32
    %114 = llvm.add %111, %92 : i64
    %115 = llvm.getelementptr %arg9[%114] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %116 = llvm.load %115 : !llvm.ptr<1> -> i32
    %117 = llvm.sub %116, %113 : i32
    %118 = llvm.icmp "sgt" %117, %17 : i32
    llvm.cond_br %118, ^bb3, ^bb28
  ^bb3:  // pred: ^bb2
    %119 = llvm.getelementptr %arg10[%111] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %120 = llvm.load %119 : !llvm.ptr<1> -> i32
    %121 = llvm.sub %120, %117 : i32
    %122 = llvm.icmp "sgt" %117, %93 : i32
    %123 = llvm.zext %122 : i1 to i64
    %124 = llvm.mul %123, %10 : i64
    %125 = llvm.mul %123, %8 : i64
    %126 = llvm.icmp "sgt" %117, %18 : i32
    %127 = llvm.zext %126 : i1 to i64
    %128 = llvm.mul %127, %10 : i64
    %129 = llvm.mul %127, %8 : i64
    %130 = llvm.inttoptr %21 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @load_gm_to_ubuf_1d_float(%arg7, %arg7, %13, %10, %92, %130, %130, %13, %10, %92, %17, %91, %13, %17) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i32, f32, i64, i32) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    %131 = llvm.add %120, %15 : i32
    %132 = llvm.sdiv %131, %16  : i32
    %133 = llvm.intr.smin(%132, %17)  : (i32, i32) -> i32
    %134 = llvm.sub %121, %14 : i32
    %135 = llvm.intr.smax(%134, %17)  : (i32, i32) -> i32
    %136 = llvm.sdiv %135, %16  : i32
    %137 = llvm.intr.smax(%133, %136)  : (i32, i32) -> i32
    %138 = llvm.intr.smax(%133, %137)  : (i32, i32) -> i32
    %139 = llvm.sub %132, %138 : i32
    %140 = llvm.intr.smax(%139, %17)  : (i32, i32) -> i32
    %141 = llvm.add %133, %140 : i32
    %142 = llvm.intr.smin(%141, %132)  : (i32, i32) -> i32
    %143 = llvm.add %121, %93 : i32
    %144 = llvm.add %121, %18 : i32
    %145 = llvm.sitofp %133 : i32 to f32
    %146 = llvm.inttoptr %22 : i64 to !llvm.ptr<6>
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_26(%146) {hivm.vector_function, no_inline} : (!llvm.ptr<6>) -> ()
    %147 = llvm.sitofp %120 : i32 to f32
    %148 = llvm.sitofp %121 : i32 to f32
    %149 = llvm.sitofp %143 : i32 to f32
    %150 = llvm.sitofp %144 : i32 to f32
    %151 = llvm.sext %142 : i32 to i64
    %152 = llvm.inttoptr %23 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 0 : i64}> : () -> ()
    llvm.store %122, %152 : i1, !llvm.ptr<6>
    %153 = llvm.inttoptr %24 : i64 to !llvm.ptr<6>
    llvm.store %126, %153 : i1, !llvm.ptr<6>
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 0 : i64, wait_pipe = 1 : i64}> : () -> ()
    %154 = llvm.inttoptr %25 : i64 to !llvm.ptr<6>
    %155 = llvm.inttoptr %26 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 0 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_27(%152, %153, %154, %155) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 0 : i64}> : () -> ()
    %156 = "hivm.intr.hivm.GET.SUBBLOCKID"() : () -> i64
    %157 = llvm.icmp "eq" %156, %13 : i64
    %158 = llvm.inttoptr %27 : i64 to !llvm.ptr<6>
    %159 = llvm.insertvalue %158, %6[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %160 = llvm.insertvalue %158, %159[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %161 = llvm.insertvalue %13, %160[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %162 = llvm.insertvalue %10, %161[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %163 = llvm.insertvalue %8, %162[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %164 = llvm.insertvalue %8, %163[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %165 = llvm.insertvalue %92, %164[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%103, %103, %13, %7, %92, %158, %158, %13, %7, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %166 = llvm.inttoptr %28 : i64 to !llvm.ptr<6>
    %167 = llvm.insertvalue %166, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %168 = llvm.insertvalue %166, %167[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %169 = llvm.insertvalue %13, %168[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %170 = llvm.insertvalue %10, %169[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %171 = llvm.insertvalue %92, %170[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%102, %102, %13, %10, %92, %166, %166, %13, %10, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %172 = llvm.inttoptr %29 : i64 to !llvm.ptr<6>
    %173 = llvm.insertvalue %172, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %174 = llvm.insertvalue %172, %173[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %175 = llvm.insertvalue %13, %174[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %176 = llvm.insertvalue %10, %175[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %177 = llvm.insertvalue %92, %176[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_float(%130, %130, %13, %10, %92, %172, %172, %13, %10, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %178 = llvm.inttoptr %30 : i64 to !llvm.ptr<6>
    %179 = llvm.insertvalue %178, %6[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %180 = llvm.insertvalue %178, %179[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %181 = llvm.insertvalue %13, %180[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %182 = llvm.insertvalue %10, %181[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %183 = llvm.insertvalue %8, %182[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %184 = llvm.insertvalue %8, %183[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %185 = llvm.insertvalue %92, %184[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%103, %103, %13, %7, %92, %178, %178, %13, %7, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %186 = llvm.inttoptr %31 : i64 to !llvm.ptr<6>
    %187 = llvm.insertvalue %186, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %188 = llvm.insertvalue %186, %187[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %189 = llvm.insertvalue %13, %188[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %190 = llvm.insertvalue %10, %189[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %191 = llvm.insertvalue %92, %190[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%102, %102, %13, %10, %92, %186, %186, %13, %10, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %192 = llvm.inttoptr %32 : i64 to !llvm.ptr<6>
    %193 = llvm.insertvalue %192, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %194 = llvm.insertvalue %192, %193[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %195 = llvm.insertvalue %13, %194[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %196 = llvm.insertvalue %10, %195[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %197 = llvm.insertvalue %92, %196[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%130, %130, %13, %10, %92, %192, %192, %13, %10, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %198 = llvm.inttoptr %33 : i64 to !llvm.ptr<6>
    %199 = llvm.insertvalue %198, %6[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %200 = llvm.insertvalue %198, %199[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %201 = llvm.insertvalue %13, %200[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %202 = llvm.insertvalue %10, %201[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %203 = llvm.insertvalue %8, %202[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %204 = llvm.insertvalue %8, %203[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %205 = llvm.insertvalue %92, %204[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%103, %103, %13, %7, %92, %198, %198, %13, %7, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %206 = llvm.inttoptr %34 : i64 to !llvm.ptr<6>
    %207 = llvm.insertvalue %206, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %208 = llvm.insertvalue %206, %207[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %209 = llvm.insertvalue %13, %208[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %210 = llvm.insertvalue %10, %209[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %211 = llvm.insertvalue %92, %210[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%102, %102, %13, %10, %92, %206, %206, %13, %10, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %212 = llvm.inttoptr %35 : i64 to !llvm.ptr<6>
    %213 = llvm.insertvalue %212, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %214 = llvm.insertvalue %212, %213[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %215 = llvm.insertvalue %13, %214[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %216 = llvm.insertvalue %10, %215[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %217 = llvm.insertvalue %92, %216[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%130, %130, %13, %10, %92, %212, %212, %13, %10, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 5 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 5 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 6 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 6 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 7 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 7 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.br ^bb4(%17, %165, %171, %177, %185, %191, %197, %205, %211, %217 : i32, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>)
  ^bb4(%218: i32, %219: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %220: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %221: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %222: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %223: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %224: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %225: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %226: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %227: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>):  // 2 preds: ^bb3, ^bb20
    %228 = llvm.icmp "slt" %218, %142 : i32
    llvm.cond_br %228, ^bb5, ^bb21
  ^bb5:  // pred: ^bb4
    %229 = llvm.inttoptr %36 : i64 to !llvm.ptr<6>
    %230 = llvm.inttoptr %37 : i64 to !llvm.ptr<6>
    %231 = llvm.inttoptr %38 : i64 to !llvm.ptr<6>
    %232 = llvm.inttoptr %39 : i64 to !llvm.ptr<2>
    %233 = llvm.inttoptr %40 : i64 to !llvm.ptr<2>
    %234 = llvm.inttoptr %41 : i64 to !llvm.ptr<2>
    %235 = llvm.inttoptr %42 : i64 to !llvm.ptr<6>
    %236 = llvm.inttoptr %43 : i64 to !llvm.ptr<6>
    %237 = llvm.inttoptr %44 : i64 to !llvm.ptr<6>
    %238 = llvm.sext %218 : i32 to i64
    %239 = llvm.mul %238, %2 : i64
    %240 = llvm.add %151, %239 : i64
    %241 = llvm.intr.umin(%240, %94)  : (i64, i64) -> i64
    %242 = llvm.inttoptr %45 : i64 to !llvm.ptr<6>
    %243 = llvm.inttoptr %46 : i64 to !llvm.ptr<6>
    %244 = llvm.inttoptr %47 : i64 to !llvm.ptr<6>
    %245 = llvm.inttoptr %48 : i64 to !llvm.ptr<6>
    %246 = llvm.inttoptr %49 : i64 to !llvm.ptr<6>
    %247 = llvm.inttoptr %50 : i64 to !llvm.ptr<6>
    llvm.br ^bb6(%13 : i64)
  ^bb6(%248: i64):  // 2 preds: ^bb5, ^bb7
    %249 = llvm.icmp "slt" %248, %241 : i64
    llvm.cond_br %249, ^bb7, ^bb8
  ^bb7:  // pred: ^bb6
    %250 = llvm.add %248, %238 : i64
    %251 = llvm.trunc %250 : i64 to i32
    %252 = llvm.sitofp %251 : i32 to f32
    %253 = llvm.fcmp "olt" %252, %145 : f32
    %254 = llvm.zext %253 : i1 to i32
    %255 = llvm.mul %254, %251 : i32
    %256 = llvm.sub %93, %254 : i32
    %257 = llvm.add %138, %251 : i32
    %258 = llvm.sub %257, %133 : i32
    %259 = llvm.mul %256, %258 : i32
    %260 = llvm.add %255, %259 : i32
    %261 = llvm.mul %260, %16 : i32
    %262 = llvm.inttoptr %51 : i64 to !llvm.ptr<6>
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_0(%146, %261, %262) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, i32, !llvm.ptr<6>) -> ()
    %263 = llvm.inttoptr %52 : i64 to !llvm.ptr<6>
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_1(%262, %263) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %264 = llvm.inttoptr %53 : i64 to !llvm.ptr<6>
    %265 = llvm.inttoptr %54 : i64 to !llvm.ptr<6>
    %266 = llvm.inttoptr %55 : i64 to !llvm.ptr<6>
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_2(%262, %147, %150, %263, %264, %265, %266) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, f32, f32, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %267 = llvm.inttoptr %53 : i64 to !llvm.ptr<6>
    %268 = llvm.inttoptr %56 : i64 to !llvm.ptr<6>
    %269 = llvm.inttoptr %57 : i64 to !llvm.ptr<6>
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_3(%264, %262, %148, %263, %154, %149, %155, %265, %266, %267, %268, %269) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, f32, !llvm.ptr<6>, !llvm.ptr<6>, f32, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_merged_merged_vf_0(%243, %248, %244, %248, %245, %248, %267, %268, %269, %242, %248, %246, %248, %247, %248) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, i64, !llvm.ptr<6>, i64, !llvm.ptr<6>, i64, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>, i64, !llvm.ptr<6>, i64) -> ()
    %270 = llvm.add %248, %92 overflow<nsw> : i64
    llvm.br ^bb6(%270 : i64)
  ^bb8:  // pred: ^bb6
    %271 = llvm.inttoptr %58 : i64 to !llvm.ptr<6>
    %272 = llvm.inttoptr %59 : i64 to !llvm.ptr<6>
    %273 = llvm.inttoptr %60 : i64 to !llvm.ptr<6>
    llvm.br ^bb9(%13, %221, %220, %224, %223, %227, %226 : i64, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>)
  ^bb9(%274: i64, %275: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %276: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %277: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %278: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %279: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %280: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>):  // 2 preds: ^bb8, ^bb16
    %281 = llvm.icmp "slt" %274, %241 : i64
    llvm.cond_br %281, ^bb10, ^bb17
  ^bb10:  // pred: ^bb9
    %282 = llvm.inttoptr %61 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 13 : i64}> : () -> ()
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_7(%242, %274, %235, %arg12, %282) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, i64, !llvm.ptr<6>, f32, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 7 : i64}> : () -> ()
    %283 = llvm.inttoptr %62 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%243, %243, %13, %1, %92, %283, %283, %13, %1, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_8(%282, %283, %274) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i64) -> ()
    %284 = llvm.inttoptr %63 : i64 to !llvm.ptr<6>
    %285 = llvm.extractvalue %275[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_9(%285, %283, %274, %284) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>) -> ()
    %286 = llvm.inttoptr %64 : i64 to !llvm.ptr<6>
    %287 = llvm.inttoptr %65 : i64 to !llvm.ptr<6>
    %288 = llvm.extractvalue %275[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_10(%288, %284, %286, %274, %287) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>) -> ()
    %289 = llvm.mul %274, %10 : i64
    llvm.call @copy_ubuf_to_ubuf_1d_float(%287, %287, %13, %10, %92, %271, %271, %289, %10, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %290 = llvm.inttoptr %66 : i64 to !llvm.ptr<6>
    %291 = llvm.inttoptr %28 : i64 to !llvm.ptr<6>
    %292 = llvm.insertvalue %291, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %293 = llvm.insertvalue %291, %292[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %294 = llvm.insertvalue %13, %293[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %295 = llvm.insertvalue %10, %294[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %296 = llvm.insertvalue %92, %295[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %297 = llvm.inttoptr %67 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%244, %244, %13, %1, %92, %297, %297, %13, %1, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %298 = llvm.extractvalue %276[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_11(%282, %284, %297, %274, %290, %298, %287, %291) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %299 = llvm.inttoptr %68 : i64 to !llvm.ptr<6>
    %300 = llvm.mul %274, %4 : i64
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%245, %245, %300, %4, %92, %299, %299, %13, %4, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%290, %290, %13, %3, %92, %299, %299, %13, %3, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %301 = llvm.inttoptr %69 : i64 to !llvm.ptr<6>
    %302 = llvm.inttoptr %70 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 12 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_merged_vf_2(%299, %301, %246, %274, %236, %arg12, %302) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>, f32, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 6 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %157, ^bb11, ^bb12
  ^bb11:  // pred: ^bb10
    %303 = llvm.mul %274, %4 : i64
    llvm.call @copy_ubuf_to_cbuf_2d_bfloat16_t(%301, %301, %13, %5, %8, %0, %92, %232, %232, %303, %5, %8, %8, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64) -> ()
    llvm.br ^bb12
  ^bb12:  // 2 preds: ^bb10, ^bb11
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 10 : i64}> : () -> ()
    %304 = llvm.inttoptr %71 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%243, %243, %13, %1, %92, %304, %304, %13, %1, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_14(%302, %304, %274) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i64) -> ()
    %305 = llvm.inttoptr %72 : i64 to !llvm.ptr<6>
    %306 = llvm.extractvalue %277[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_15(%306, %304, %274, %305) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>) -> ()
    %307 = llvm.inttoptr %73 : i64 to !llvm.ptr<6>
    %308 = llvm.inttoptr %74 : i64 to !llvm.ptr<6>
    %309 = llvm.extractvalue %277[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_16(%309, %305, %307, %274, %308) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>) -> ()
    %310 = llvm.mul %274, %10 : i64
    llvm.call @copy_ubuf_to_ubuf_1d_float(%308, %308, %13, %10, %92, %272, %272, %310, %10, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %311 = llvm.inttoptr %75 : i64 to !llvm.ptr<6>
    %312 = llvm.inttoptr %31 : i64 to !llvm.ptr<6>
    %313 = llvm.insertvalue %312, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %314 = llvm.insertvalue %312, %313[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %315 = llvm.insertvalue %13, %314[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %316 = llvm.insertvalue %10, %315[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %317 = llvm.insertvalue %92, %316[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %318 = llvm.inttoptr %76 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%244, %244, %13, %1, %92, %318, %318, %13, %1, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %319 = llvm.extractvalue %278[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_17(%302, %305, %318, %274, %311, %319, %308, %312) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %320 = llvm.inttoptr %77 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%245, %245, %300, %4, %92, %320, %320, %13, %4, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%311, %311, %13, %3, %92, %320, %320, %13, %3, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %321 = llvm.inttoptr %78 : i64 to !llvm.ptr<6>
    %322 = llvm.inttoptr %79 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 11 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_merged_vf_3(%320, %321, %247, %274, %237, %arg12, %322) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>, f32, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %157, ^bb13, ^bb14
  ^bb13:  // pred: ^bb12
    %323 = llvm.mul %274, %4 : i64
    llvm.call @copy_ubuf_to_cbuf_2d_bfloat16_t(%321, %321, %13, %5, %8, %0, %92, %233, %233, %323, %5, %8, %8, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64) -> ()
    llvm.br ^bb14
  ^bb14:  // 2 preds: ^bb12, ^bb13
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 9 : i64}> : () -> ()
    %324 = llvm.inttoptr %80 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%243, %243, %13, %1, %92, %324, %324, %13, %1, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_20(%322, %324, %274) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i64) -> ()
    %325 = llvm.inttoptr %81 : i64 to !llvm.ptr<6>
    %326 = llvm.extractvalue %279[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_21(%326, %324, %274, %325) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>) -> ()
    %327 = llvm.inttoptr %82 : i64 to !llvm.ptr<6>
    %328 = llvm.inttoptr %83 : i64 to !llvm.ptr<6>
    %329 = llvm.extractvalue %279[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_22(%329, %325, %327, %274, %328) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>) -> ()
    %330 = llvm.mul %274, %10 : i64
    llvm.call @copy_ubuf_to_ubuf_1d_float(%328, %328, %13, %10, %92, %273, %273, %330, %10, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %331 = llvm.inttoptr %84 : i64 to !llvm.ptr<6>
    %332 = llvm.inttoptr %34 : i64 to !llvm.ptr<6>
    %333 = llvm.insertvalue %332, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %334 = llvm.insertvalue %332, %333[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %335 = llvm.insertvalue %13, %334[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %336 = llvm.insertvalue %10, %335[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %337 = llvm.insertvalue %92, %336[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %338 = llvm.inttoptr %85 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%244, %244, %13, %1, %92, %338, %338, %13, %1, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %339 = llvm.extractvalue %280[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_23(%322, %325, %338, %274, %331, %339, %328, %332) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, i64, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %340 = llvm.inttoptr %86 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%245, %245, %300, %4, %92, %340, %340, %13, %4, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%331, %331, %13, %3, %92, %340, %340, %13, %3, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %341 = llvm.inttoptr %87 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_24(%340, %341) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %157, ^bb15, ^bb16
  ^bb15:  // pred: ^bb14
    %342 = llvm.mul %274, %4 : i64
    llvm.call @copy_ubuf_to_cbuf_2d_bfloat16_t(%341, %341, %13, %5, %8, %0, %92, %234, %234, %342, %5, %8, %8, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64) -> ()
    llvm.br ^bb16
  ^bb16:  // 2 preds: ^bb14, ^bb15
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 8 : i64}> : () -> ()
    %343 = llvm.inttoptr %29 : i64 to !llvm.ptr<6>
    %344 = llvm.insertvalue %343, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %345 = llvm.insertvalue %343, %344[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %346 = llvm.insertvalue %13, %345[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %347 = llvm.insertvalue %10, %346[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %348 = llvm.insertvalue %92, %347[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%284, %284, %13, %10, %92, %343, %343, %13, %10, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %349 = llvm.inttoptr %32 : i64 to !llvm.ptr<6>
    %350 = llvm.insertvalue %349, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %351 = llvm.insertvalue %349, %350[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %352 = llvm.insertvalue %13, %351[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %353 = llvm.insertvalue %10, %352[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %354 = llvm.insertvalue %92, %353[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%305, %305, %13, %10, %92, %349, %349, %13, %10, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %355 = llvm.inttoptr %35 : i64 to !llvm.ptr<6>
    %356 = llvm.insertvalue %355, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %357 = llvm.insertvalue %355, %356[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %358 = llvm.insertvalue %13, %357[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %359 = llvm.insertvalue %10, %358[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %360 = llvm.insertvalue %92, %359[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%325, %325, %13, %10, %92, %355, %355, %13, %10, %92) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %361 = llvm.add %274, %92 overflow<nsw> : i64
    llvm.br ^bb9(%361, %348, %296, %354, %317, %360, %337 : i64, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>)
  ^bb17:  // pred: ^bb9
    llvm.br ^bb18(%13, %219, %222, %225 : i64, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>)
  ^bb18(%362: i64, %363: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %364: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %365: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>):  // 2 preds: ^bb17, ^bb19
    %366 = llvm.icmp "slt" %362, %241 : i64
    llvm.cond_br %366, ^bb19, ^bb20
  ^bb19:  // pred: ^bb18
    %367 = llvm.inttoptr %27 : i64 to !llvm.ptr<6>
    %368 = llvm.insertvalue %367, %6[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %369 = llvm.insertvalue %367, %368[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %370 = llvm.insertvalue %13, %369[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %371 = llvm.insertvalue %10, %370[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %372 = llvm.insertvalue %8, %371[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %373 = llvm.insertvalue %8, %372[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %374 = llvm.insertvalue %92, %373[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %375 = llvm.inttoptr %30 : i64 to !llvm.ptr<6>
    %376 = llvm.insertvalue %375, %6[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %377 = llvm.insertvalue %375, %376[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %378 = llvm.insertvalue %13, %377[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %379 = llvm.insertvalue %10, %378[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %380 = llvm.insertvalue %8, %379[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %381 = llvm.insertvalue %8, %380[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %382 = llvm.insertvalue %92, %381[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %383 = llvm.inttoptr %33 : i64 to !llvm.ptr<6>
    %384 = llvm.insertvalue %383, %6[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %385 = llvm.insertvalue %383, %384[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %386 = llvm.insertvalue %13, %385[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %387 = llvm.insertvalue %10, %386[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %388 = llvm.insertvalue %8, %387[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %389 = llvm.insertvalue %8, %388[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %390 = llvm.insertvalue %92, %389[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 0 : i64}> : () -> ()
    %391 = llvm.extractvalue %363[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %392 = llvm.extractvalue %364[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %393 = llvm.extractvalue %365[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_vf_25(%271, %362, %272, %273, %229, %391, %230, %392, %231, %393, %367, %375, %383) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, i64, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 1 : i64}> : () -> ()
    %394 = llvm.add %362, %92 overflow<nsw> : i64
    llvm.br ^bb18(%394, %374, %382, %390 : i64, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>)
  ^bb20:  // pred: ^bb18
    %395 = llvm.add %218, %18 overflow<nsw> : i32
    llvm.br ^bb4(%395, %363, %276, %275, %364, %278, %277, %365, %280, %279 : i32, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>)
  ^bb21:  // pred: ^bb4
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 4 : i64}> : () -> ()
    %396 = llvm.mul %113, %arg13 : i32
    %397 = llvm.sext %396 : i32 to i64
    %398 = llvm.sext %arg14 : i32 to i64
    %399 = llvm.inttoptr %88 : i64 to !llvm.ptr<6>
    %400 = llvm.sext %arg13 : i32 to i64
    %401 = llvm.add %397, %400 : i64
    %402 = llvm.inttoptr %89 : i64 to !llvm.ptr<6>
    %403 = llvm.mul %arg13, %18 : i32
    %404 = llvm.sext %403 : i32 to i64
    %405 = llvm.add %397, %404 : i64
    %406 = llvm.inttoptr %90 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %407 = llvm.extractvalue %220[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %408 = llvm.extractvalue %219[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %409 = llvm.extractvalue %223[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %410 = llvm.extractvalue %222[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %411 = llvm.extractvalue %226[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %412 = llvm.extractvalue %225[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @_swa_paged_prefill_small_q_grouped_sink_kernel_mix_aiv_outlined_merged_merged_vf_1(%407, %408, %399, %409, %410, %402, %411, %412, %406) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %157, ^bb22, ^bb23
  ^bb22:  // pred: ^bb21
    llvm.call @store_ubuf_to_gm_2d_bfloat16_t(%399, %399, %13, %10, %8, %8, %92, %arg3, %arg3, %397, %10, %8, %398, %92, %17) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i32) -> ()
    llvm.br ^bb23
  ^bb23:  // 2 preds: ^bb21, ^bb22
    llvm.cond_br %157, ^bb24, ^bb25
  ^bb24:  // pred: ^bb23
    "hivm.intr.hivm.BARRIER"() <{pipe = 5 : i64}> : () -> ()
    llvm.call @store_ubuf_to_gm_2d_bfloat16_t(%402, %402, %13, %124, %125, %8, %92, %arg3, %arg3, %401, %124, %125, %398, %92, %17) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i32) -> ()
    llvm.br ^bb25
  ^bb25:  // 2 preds: ^bb23, ^bb24
    llvm.cond_br %157, ^bb26, ^bb27
  ^bb26:  // pred: ^bb25
    "hivm.intr.hivm.BARRIER"() <{pipe = 5 : i64}> : () -> ()
    llvm.call @store_ubuf_to_gm_2d_bfloat16_t(%406, %406, %13, %128, %129, %8, %92, %arg3, %arg3, %405, %128, %129, %398, %92, %17) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i32) -> ()
    llvm.br ^bb27
  ^bb27:  // 2 preds: ^bb25, ^bb26
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.br ^bb28
  ^bb28:  // 2 preds: ^bb2, ^bb27
    %413 = llvm.add %109, %93 overflow<nsw> : i32
    llvm.br ^bb1(%413 : i32)
  ^bb29:  // pred: ^bb1
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 0 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %414 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %415 = "hivm.intr.hivm.SBITSET1"(%414, %12) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%415) : (i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 6 : i64}> : () -> ()
    llvm.return
  }
}


bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
ld.lld: warning: -z separate-code and -z separate-loadable-segments will be ignored
