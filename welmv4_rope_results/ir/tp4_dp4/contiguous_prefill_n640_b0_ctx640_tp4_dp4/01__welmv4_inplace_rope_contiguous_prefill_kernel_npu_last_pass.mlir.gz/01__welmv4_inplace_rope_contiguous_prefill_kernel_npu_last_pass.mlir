// -----// IR Dump After AppendUsePrintDebugData (append-use-print-debug-data) //----- //
module attributes {dlti.target_system_spec = #dlti.target_system_spec<"NPU" : #hacc.target_device_spec<#dlti.dl_entry<"AI_CORE_COUNT", 28 : i32>, #dlti.dl_entry<"CUBE_CORE_COUNT", 28 : i32>, #dlti.dl_entry<"VECTOR_CORE_COUNT", 56 : i32>, #dlti.dl_entry<"UB_SIZE", 2031616 : i32>, #dlti.dl_entry<"L1_SIZE", 4194304 : i32>, #dlti.dl_entry<"L0A_SIZE", 524288 : i32>, #dlti.dl_entry<"L0B_SIZE", 524288 : i32>, #dlti.dl_entry<"L0C_SIZE", 2097152 : i32>, #dlti.dl_entry<"UB_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L1_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L0C_ALIGN_SIZE", 4096 : i32>, #dlti.dl_entry<"MINIMAL_D_CACHE_SIZE", 262144 : i32>, #dlti.dl_entry<"MAXIMUM_D_CACHE_SIZE", 983040 : i32>, #dlti.dl_entry<"ARCH", "dav-c310">>>, hacc.target = #hacc.target<"Ascend950PR_957b">, hivm.aic_bitcode = #hivm.aic_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.aic.c310.bc">, hivm.aiv_bitcode = #hivm.aiv_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.aiv.c310.bc">, hivm.host_bitcode = #hivm.host_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/host-a5.bc">, hivm.mix_aic_bitcode = #hivm.mix_aic_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.mix.aic.c310.bc">, hivm.mix_aiv_bitcode = #hivm.mix_aiv_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.mix.aiv.c310.bc">, hivm.module_core_type = #hivm.module_core_type<AIV>} {
  llvm.func @_welmv4_inplace_rope_contiguous_prefill_kernel_npu_fused_2_outlined_merged_vf_0(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>, %arg8: !llvm.ptr<6>, %arg9: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(64 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(2 : i32) : i32
    %4 = llvm.mlir.constant(7 : i32) : i32
    %5 = llvm.mlir.constant(32 : index) : i64
    %6 = llvm.mlir.constant(64 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%7: i32):  // 2 preds: ^bb0, ^bb5
    %8 = llvm.icmp "slt" %7, %1 : i32
    llvm.cond_br %8, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %9 = llvm.sext %7 : i32 to i64
    llvm.br ^bb3(%2 : i32)
  ^bb3(%10: i32):  // 2 preds: ^bb2, ^bb4
    %11 = llvm.icmp "slt" %10, %3 : i32
    llvm.cond_br %11, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %12 = llvm.sext %10 : i32 to i64
    %13 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%4, %2) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %14 = llvm.mul %9, %6 : i64
    %15 = llvm.mul %12, %5 : i64
    %16 = llvm.add %14, %15 : i64
    %17 = llvm.getelementptr %arg0[%16] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %18 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%17, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %19 = llvm.mul %9, %6 : i64
    %20 = llvm.mul %12, %5 : i64
    %21 = llvm.add %19, %20 : i64
    %22 = llvm.getelementptr %arg1[%21] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%22, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %24 = llvm.mul %9, %6 : i64
    %25 = llvm.mul %12, %5 : i64
    %26 = llvm.add %24, %25 : i64
    %27 = llvm.getelementptr %arg2[%26] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %28 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%27, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %29 = llvm.mul %9, %6 : i64
    %30 = llvm.mul %12, %5 : i64
    %31 = llvm.add %29, %30 : i64
    %32 = llvm.getelementptr %arg3[%31] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %33 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%32, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %34 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%28, %33, %13) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %35 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%18, %23, %13) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %36 = "hivm_regbaseintrins.intr.hivm.vsub.s.x"(%35, %34, %13) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %37 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%36, %13, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %38 = llvm.mul %9, %6 : i64
    %39 = llvm.mul %12, %5 : i64
    %40 = llvm.add %38, %39 : i64
    %41 = llvm.getelementptr %arg4[%40] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%37, %41, %2, %4, %2, %13) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %42 = llvm.add %10, %0 overflow<nsw> : i32
    llvm.br ^bb3(%42 : i32)
  ^bb5:  // pred: ^bb3
    %43 = llvm.add %7, %0 overflow<nsw> : i32
    llvm.br ^bb1(%43 : i32)
  ^bb6:  // pred: ^bb1
    llvm.br ^bb7(%2 : i32)
  ^bb7(%44: i32):  // 2 preds: ^bb6, ^bb11
    %45 = llvm.icmp "slt" %44, %1 : i32
    llvm.cond_br %45, ^bb8, ^bb12
  ^bb8:  // pred: ^bb7
    %46 = llvm.sext %44 : i32 to i64
    llvm.br ^bb9(%2 : i32)
  ^bb9(%47: i32):  // 2 preds: ^bb8, ^bb10
    %48 = llvm.icmp "slt" %47, %3 : i32
    llvm.cond_br %48, ^bb10, ^bb11
  ^bb10:  // pred: ^bb9
    %49 = llvm.sext %47 : i32 to i64
    %50 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%4, %2) {mask_bit_width = 32 : i32, mask_op_idx = 1 : i32} : (i32, i32) -> vector<256xi1>
    %51 = llvm.mul %46, %6 : i64
    %52 = llvm.mul %49, %5 : i64
    %53 = llvm.add %51, %52 : i64
    %54 = llvm.getelementptr %arg5[%53] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %55 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%54, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %56 = llvm.mul %46, %6 : i64
    %57 = llvm.mul %49, %5 : i64
    %58 = llvm.add %56, %57 : i64
    %59 = llvm.getelementptr %arg6[%58] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %60 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%59, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %61 = llvm.mul %46, %6 : i64
    %62 = llvm.mul %49, %5 : i64
    %63 = llvm.add %61, %62 : i64
    %64 = llvm.getelementptr %arg7[%63] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %65 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%64, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %66 = llvm.mul %46, %6 : i64
    %67 = llvm.mul %49, %5 : i64
    %68 = llvm.add %66, %67 : i64
    %69 = llvm.getelementptr %arg8[%68] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %70 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%69, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %71 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%65, %70, %50) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %72 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%55, %60, %50) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %73 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%72, %71, %50) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %74 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%73, %50, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %75 = llvm.mul %46, %6 : i64
    %76 = llvm.mul %49, %5 : i64
    %77 = llvm.add %75, %76 : i64
    %78 = llvm.getelementptr %arg9[%77] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%74, %78, %2, %4, %2, %50) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %79 = llvm.add %47, %0 overflow<nsw> : i32
    llvm.br ^bb9(%79 : i32)
  ^bb11:  // pred: ^bb9
    %80 = llvm.add %44, %0 overflow<nsw> : i32
    llvm.br ^bb7(%80 : i32)
  ^bb12:  // pred: ^bb7
    llvm.return
  }
  llvm.func @_welmv4_inplace_rope_contiguous_prefill_kernel_npu_fused_0_outlined_merged_vf_0(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>, %arg8: !llvm.ptr<6>, %arg9: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(64 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(7 : i32) : i32
    %4 = llvm.mlir.constant(32 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%5: i32):  // 2 preds: ^bb0, ^bb2
    %6 = llvm.icmp "slt" %5, %1 : i32
    llvm.cond_br %6, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %7 = llvm.sext %5 : i32 to i64
    %8 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %2) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %9 = llvm.mul %7, %4 : i64
    %10 = llvm.getelementptr %arg0[%9] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %11 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%10, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %12 = llvm.mul %7, %4 : i64
    %13 = llvm.getelementptr %arg1[%12] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %14 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%13, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %15 = llvm.mul %7, %4 : i64
    %16 = llvm.getelementptr %arg2[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %17 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%16, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %18 = llvm.mul %7, %4 : i64
    %19 = llvm.getelementptr %arg3[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %20 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%19, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%17, %20, %8) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %22 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%11, %14, %8) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %23 = "hivm_regbaseintrins.intr.hivm.vsub.s.x"(%22, %21, %8) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %24 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%23, %8, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %25 = llvm.mul %7, %4 : i64
    %26 = llvm.getelementptr %arg4[%25] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%24, %26, %2, %3, %2, %8) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %27 = llvm.add %5, %0 overflow<nsw> : i32
    llvm.br ^bb1(%27 : i32)
  ^bb3:  // pred: ^bb1
    llvm.br ^bb4(%2 : i32)
  ^bb4(%28: i32):  // 2 preds: ^bb3, ^bb5
    %29 = llvm.icmp "slt" %28, %1 : i32
    llvm.cond_br %29, ^bb5, ^bb6
  ^bb5:  // pred: ^bb4
    %30 = llvm.sext %28 : i32 to i64
    %31 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %2) {mask_bit_width = 32 : i32, mask_op_idx = 1 : i32} : (i32, i32) -> vector<256xi1>
    %32 = llvm.mul %30, %4 : i64
    %33 = llvm.getelementptr %arg5[%32] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %34 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%33, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %35 = llvm.mul %30, %4 : i64
    %36 = llvm.getelementptr %arg6[%35] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %37 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%36, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %38 = llvm.mul %30, %4 : i64
    %39 = llvm.getelementptr %arg7[%38] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %40 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%39, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %41 = llvm.mul %30, %4 : i64
    %42 = llvm.getelementptr %arg8[%41] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %43 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%42, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %44 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%40, %43, %31) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %45 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%34, %37, %31) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %46 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%45, %44, %31) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %47 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%46, %31, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %48 = llvm.mul %30, %4 : i64
    %49 = llvm.getelementptr %arg9[%48] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%47, %49, %2, %3, %2, %31) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %50 = llvm.add %28, %0 overflow<nsw> : i32
    llvm.br ^bb4(%50 : i32)
  ^bb6:  // pred: ^bb4
    llvm.return
  }
  llvm.func @_welmv4_inplace_rope_contiguous_prefill_kernel_npu_fused_0_outlined_vf_0(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(64 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(7 : i32) : i32
    %4 = llvm.mlir.constant(14 : i32) : i32
    %5 = llvm.mlir.constant(2 : i32) : i32
    %6 = llvm.mlir.constant(32 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%7: i32):  // 2 preds: ^bb0, ^bb2
    %8 = llvm.icmp "slt" %7, %1 : i32
    llvm.cond_br %8, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %9 = llvm.sext %7 : i32 to i64
    %10 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %2) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %11 = llvm.mul %9, %6 : i64
    %12 = llvm.getelementptr %arg0[%11] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %13 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%12, %2, %4, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %14 = "hivm_regbaseintrins.intr.hivm.vcvtff.bf162f32.x"(%13, %10, %2) : (vector<128xbf16>, vector<256xi1>, i32) -> vector<64xf32>
    %15 = llvm.mul %9, %6 : i64
    %16 = llvm.getelementptr %arg2[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%14, %16, %2, %5, %2, %10) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %17 = llvm.mul %9, %6 : i64
    %18 = llvm.getelementptr %arg1[%17] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %19 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%18, %2, %4, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %20 = "hivm_regbaseintrins.intr.hivm.vcvtff.bf162f32.x"(%19, %10, %2) : (vector<128xbf16>, vector<256xi1>, i32) -> vector<64xf32>
    %21 = llvm.mul %9, %6 : i64
    %22 = llvm.getelementptr %arg3[%21] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%20, %22, %2, %5, %2, %10) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %23 = llvm.add %7, %0 overflow<nsw> : i32
    llvm.br ^bb1(%23 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_welmv4_inplace_rope_contiguous_prefill_kernel_npu_fused_2_outlined_vf_0(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(64 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(2 : i32) : i32
    %4 = llvm.mlir.constant(7 : i32) : i32
    %5 = llvm.mlir.constant(14 : i32) : i32
    %6 = llvm.mlir.constant(32 : index) : i64
    %7 = llvm.mlir.constant(64 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%8: i32):  // 2 preds: ^bb0, ^bb5
    %9 = llvm.icmp "slt" %8, %1 : i32
    llvm.cond_br %9, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %10 = llvm.sext %8 : i32 to i64
    llvm.br ^bb3(%2 : i32)
  ^bb3(%11: i32):  // 2 preds: ^bb2, ^bb4
    %12 = llvm.icmp "slt" %11, %3 : i32
    llvm.cond_br %12, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %13 = llvm.sext %11 : i32 to i64
    %14 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%4, %2) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %15 = llvm.mul %10, %7 : i64
    %16 = llvm.mul %13, %6 : i64
    %17 = llvm.add %15, %16 : i64
    %18 = llvm.getelementptr %arg0[%17] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %19 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%18, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %20 = "hivm_regbaseintrins.intr.hivm.vcvtff.bf162f32.x"(%19, %14, %2) : (vector<128xbf16>, vector<256xi1>, i32) -> vector<64xf32>
    %21 = llvm.mul %10, %7 : i64
    %22 = llvm.mul %13, %6 : i64
    %23 = llvm.add %21, %22 : i64
    %24 = llvm.getelementptr %arg2[%23] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%20, %24, %2, %3, %2, %14) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %25 = llvm.mul %10, %7 : i64
    %26 = llvm.mul %13, %6 : i64
    %27 = llvm.add %25, %26 : i64
    %28 = llvm.getelementptr %arg1[%27] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %29 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%28, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %30 = "hivm_regbaseintrins.intr.hivm.vcvtff.bf162f32.x"(%29, %14, %2) : (vector<128xbf16>, vector<256xi1>, i32) -> vector<64xf32>
    %31 = llvm.mul %10, %7 : i64
    %32 = llvm.mul %13, %6 : i64
    %33 = llvm.add %31, %32 : i64
    %34 = llvm.getelementptr %arg3[%33] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%30, %34, %2, %3, %2, %14) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %35 = llvm.add %11, %0 overflow<nsw> : i32
    llvm.br ^bb3(%35 : i32)
  ^bb5:  // pred: ^bb3
    %36 = llvm.add %8, %0 overflow<nsw> : i32
    llvm.br ^bb1(%36 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_welmv4_inplace_rope_contiguous_prefill_kernel_npu_outlined_vf_0(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(7 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(64 : i32) : i32
    %3 = llvm.mlir.constant(1 : i32) : i32
    %4 = llvm.mlir.constant(2 : i32) : i32
    %5 = llvm.mlir.constant(32 : index) : i64
    %6 = llvm.mlir.constant(64 : index) : i64
    %7 = llvm.mlir.constant(0 : index) : i64
    %8 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %1) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    llvm.br ^bb1(%1 : i32)
  ^bb1(%9: i32):  // 2 preds: ^bb0, ^bb5
    %10 = llvm.icmp "slt" %9, %2 : i32
    llvm.cond_br %10, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %11 = llvm.sext %9 : i32 to i64
    %12 = llvm.mul %11, %5 : i64
    %13 = llvm.mul %11, %5 : i64
    llvm.br ^bb3(%1 : i32)
  ^bb3(%14: i32):  // 2 preds: ^bb2, ^bb4
    %15 = llvm.icmp "slt" %14, %4 : i32
    llvm.cond_br %15, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %16 = llvm.sext %14 : i32 to i64
    %17 = llvm.getelementptr %arg0[%12] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %18 = llvm.mul %7, %5 : i64
    %19 = llvm.add %18, %7 : i64
    %20 = llvm.getelementptr %17[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %21 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%20, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %22 = llvm.mul %11, %6 : i64
    %23 = llvm.mul %16, %5 : i64
    %24 = llvm.add %22, %23 : i64
    %25 = llvm.getelementptr %arg2[%24] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%21, %25, %1, %4, %1, %8) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %26 = llvm.getelementptr %arg1[%13] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %27 = llvm.mul %7, %5 : i64
    %28 = llvm.add %27, %7 : i64
    %29 = llvm.getelementptr %26[%28] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %30 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%29, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %31 = llvm.mul %11, %6 : i64
    %32 = llvm.mul %16, %5 : i64
    %33 = llvm.add %31, %32 : i64
    %34 = llvm.getelementptr %arg3[%33] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%30, %34, %1, %4, %1, %8) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %35 = llvm.add %14, %3 overflow<nsw> : i32
    llvm.br ^bb3(%35 : i32)
  ^bb5:  // pred: ^bb3
    %36 = llvm.add %9, %3 overflow<nsw> : i32
    llvm.br ^bb1(%36 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func private @load_gm_to_ubuf_2d_float(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<6>, %arg8: !llvm.ptr<6>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i32, %arg15: f32, %arg16: i64, %arg17: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg12, %14[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %17, %18 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_load_gm_to_ubuf_2d_float(%10, %18, %arg14, %arg15, %arg16, %arg17) : (!llvm.ptr, !llvm.ptr, i32, f32, i64, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_load_gm_to_ubuf_2d_float(!llvm.ptr, !llvm.ptr, i32, f32, i64, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @load_gm_to_ubuf_2d_bfloat16_t(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<6>, %arg8: !llvm.ptr<6>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i32, %arg15: bf16, %arg16: i64, %arg17: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg12, %14[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %17, %18 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_load_gm_to_ubuf_2d_bfloat16_t(%10, %18, %arg14, %arg15, %arg16, %arg17) : (!llvm.ptr, !llvm.ptr, i32, bf16, i64, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_load_gm_to_ubuf_2d_bfloat16_t(!llvm.ptr, !llvm.ptr, i32, bf16, i64, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @store_ubuf_to_gm_2d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<1>, %arg8: !llvm.ptr<1>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg12, %14[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %17, %18 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_store_ubuf_to_gm_2d_bfloat16_t(%10, %18, %arg14) : (!llvm.ptr, !llvm.ptr, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_store_ubuf_to_gm_2d_bfloat16_t(!llvm.ptr, !llvm.ptr, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @load_gm_to_ubuf_3d_bfloat16_t(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: !llvm.ptr<6>, %arg10: !llvm.ptr<6>, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i32, %arg19: bf16, %arg20: i64, %arg21: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %9 = llvm.insertvalue %arg7, %8[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %11 = llvm.insertvalue %arg8, %10[4, 2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %12 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %11, %12 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)>, !llvm.ptr
    %13 = llvm.insertvalue %arg9, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %15 = llvm.insertvalue %arg11, %14[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %17 = llvm.insertvalue %arg15, %16[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %18 = llvm.insertvalue %arg13, %17[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %20 = llvm.insertvalue %arg14, %19[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %22 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %21, %22 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_load_gm_to_ubuf_3d_bfloat16_t(%12, %22, %arg18, %arg19, %arg20, %arg21) : (!llvm.ptr, !llvm.ptr, i32, bf16, i64, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_load_gm_to_ubuf_3d_bfloat16_t(!llvm.ptr, !llvm.ptr, i32, bf16, i64, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @store_ubuf_to_gm_3d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: !llvm.ptr<1>, %arg10: !llvm.ptr<1>, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %9 = llvm.insertvalue %arg7, %8[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %11 = llvm.insertvalue %arg8, %10[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %12 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %11, %12 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)>, !llvm.ptr
    %13 = llvm.insertvalue %arg9, %0[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %15 = llvm.insertvalue %arg11, %14[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %17 = llvm.insertvalue %arg15, %16[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %18 = llvm.insertvalue %arg13, %17[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %20 = llvm.insertvalue %arg14, %19[3, 2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %22 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %21, %22 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_store_ubuf_to_gm_3d_bfloat16_t(%12, %22, %arg18) : (!llvm.ptr, !llvm.ptr, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_store_ubuf_to_gm_3d_bfloat16_t(!llvm.ptr, !llvm.ptr, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func @_welmv4_inplace_rope_contiguous_prefill_kernel_npu(%arg0: i64, %arg1: !llvm.ptr<1>, %arg2: !llvm.ptr<1>, %arg3: !llvm.ptr<1>, %arg4: !llvm.ptr<1>, %arg5: !llvm.ptr<1>, %arg6: !llvm.ptr<1>, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vf_mode = #hivm.vf_mode<SIMD>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, mix_mode = "aiv", parallel_mode = "simd"} {
    %0 = llvm.mlir.constant(256 : index) : i64
    %1 = llvm.mlir.constant(6144 : index) : i64
    %2 = llvm.mlir.constant(224 : index) : i64
    %3 = llvm.mlir.constant(512 : index) : i64
    %4 = llvm.mlir.constant(192 : index) : i64
    %5 = llvm.mlir.constant(48 : i64) : i64
    %6 = llvm.mlir.constant(60 : i64) : i64
    %7 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)>
    %8 = llvm.mlir.constant(2 : index) : i64
    %9 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %10 = llvm.mlir.constant(1 : index) : i64
    %11 = llvm.mlir.constant(32 : index) : i64
    %12 = llvm.mlir.constant(64 : index) : i64
    %13 = llvm.mlir.constant(0 : index) : i64
    %14 = llvm.mlir.constant(16384 : i64) : i64
    %15 = llvm.mlir.constant(163840 : i64) : i64
    %16 = llvm.mlir.constant(139264 : i64) : i64
    %17 = llvm.mlir.constant(204800 : i64) : i64
    %18 = llvm.mlir.constant(131072 : i64) : i64
    %19 = llvm.mlir.constant(196608 : i64) : i64
    %20 = llvm.mlir.constant(90112 : i64) : i64
    %21 = llvm.mlir.constant(188416 : i64) : i64
    %22 = llvm.mlir.constant(81920 : i64) : i64
    %23 = llvm.mlir.constant(180224 : i64) : i64
    %24 = llvm.mlir.constant(1 : i64) : i64
    %25 = llvm.mlir.constant(2 : i64) : i64
    %26 = llvm.mlir.constant(24 : i32) : i32
    %27 = llvm.mlir.constant(393216 : i32) : i32
    %28 = llvm.mlir.constant(2 : i32) : i32
    %29 = llvm.mlir.constant(0 : i32) : i32
    %30 = llvm.mlir.constant(32768 : i32) : i32
    %31 = llvm.mlir.constant(256 : i32) : i32
    %32 = llvm.mlir.constant(64 : i32) : i32
    %33 = llvm.mlir.constant(1 : i32) : i32
    %34 = llvm.mlir.constant(24576 : i64) : i64
    %35 = llvm.mlir.constant(32768 : i64) : i64
    %36 = llvm.mlir.constant(49152 : i64) : i64
    %37 = llvm.mlir.constant(65536 : i64) : i64
    %38 = llvm.mlir.constant(98304 : i64) : i64
    %39 = llvm.mlir.constant(114688 : i64) : i64
    %40 = llvm.mlir.constant(true) : i1
    %41 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %42 = llvm.mlir.constant(0.000000e+00 : bf16) : bf16
    %43 = llvm.mlir.constant(167936 : i64) : i64
    %44 = llvm.mlir.constant(20480 : i64) : i64
    %45 = llvm.mlir.constant(172032 : i64) : i64
    %46 = llvm.mlir.constant(40960 : i64) : i64
    %47 = llvm.mlir.constant(176128 : i64) : i64
    %48 = llvm.mlir.constant(45056 : i64) : i64
    %49 = llvm.mlir.constant(155648 : i64) : i64
    %50 = llvm.mlir.constant(8192 : i64) : i64
    %51 = llvm.mlir.constant(0 : i64) : i64
    %52 = llvm.mlir.constant(147456 : i64) : i64
    %53 = llvm.inttoptr %51 : i64 to !llvm.ptr<6>
    %54 = llvm.insertvalue %53, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %55 = llvm.insertvalue %53, %54[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %56 = llvm.insertvalue %13, %55[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %57 = llvm.insertvalue %12, %56[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %58 = llvm.insertvalue %11, %57[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %59 = llvm.insertvalue %11, %58[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %60 = llvm.insertvalue %10, %59[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %61 = llvm.inttoptr %52 : i64 to !llvm.ptr<6>
    %62 = llvm.insertvalue %61, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %63 = llvm.insertvalue %61, %62[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %64 = llvm.insertvalue %13, %63[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %65 = llvm.insertvalue %12, %64[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %66 = llvm.insertvalue %11, %65[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %67 = llvm.insertvalue %11, %66[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %68 = llvm.insertvalue %10, %67[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %69 = llvm.inttoptr %50 : i64 to !llvm.ptr<6>
    %70 = llvm.insertvalue %69, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %71 = llvm.insertvalue %69, %70[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %72 = llvm.insertvalue %13, %71[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %73 = llvm.insertvalue %12, %72[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %74 = llvm.insertvalue %11, %73[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %75 = llvm.insertvalue %11, %74[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %76 = llvm.insertvalue %10, %75[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %77 = llvm.inttoptr %49 : i64 to !llvm.ptr<6>
    %78 = llvm.insertvalue %77, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %79 = llvm.insertvalue %77, %78[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %80 = llvm.insertvalue %13, %79[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %81 = llvm.insertvalue %12, %80[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %82 = llvm.insertvalue %11, %81[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %83 = llvm.insertvalue %11, %82[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %84 = llvm.insertvalue %10, %83[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %85 = llvm.inttoptr %48 : i64 to !llvm.ptr<6>
    %86 = llvm.insertvalue %85, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %87 = llvm.insertvalue %85, %86[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %88 = llvm.insertvalue %13, %87[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %89 = llvm.insertvalue %12, %88[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %90 = llvm.insertvalue %11, %89[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %91 = llvm.insertvalue %11, %90[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %92 = llvm.insertvalue %10, %91[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %93 = llvm.inttoptr %47 : i64 to !llvm.ptr<6>
    %94 = llvm.insertvalue %93, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %95 = llvm.insertvalue %93, %94[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %96 = llvm.insertvalue %13, %95[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %97 = llvm.insertvalue %12, %96[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %98 = llvm.insertvalue %11, %97[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %99 = llvm.insertvalue %11, %98[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %100 = llvm.insertvalue %10, %99[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %101 = llvm.inttoptr %46 : i64 to !llvm.ptr<6>
    %102 = llvm.insertvalue %101, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %103 = llvm.insertvalue %101, %102[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %104 = llvm.insertvalue %13, %103[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %105 = llvm.insertvalue %12, %104[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %106 = llvm.insertvalue %11, %105[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %107 = llvm.insertvalue %11, %106[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %108 = llvm.insertvalue %10, %107[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %109 = llvm.inttoptr %45 : i64 to !llvm.ptr<6>
    %110 = llvm.insertvalue %109, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %111 = llvm.insertvalue %109, %110[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %112 = llvm.insertvalue %13, %111[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %113 = llvm.insertvalue %12, %112[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %114 = llvm.insertvalue %11, %113[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %115 = llvm.insertvalue %11, %114[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %116 = llvm.insertvalue %10, %115[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %117 = llvm.inttoptr %44 : i64 to !llvm.ptr<6>
    %118 = llvm.insertvalue %117, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %119 = llvm.insertvalue %117, %118[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %120 = llvm.insertvalue %13, %119[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %121 = llvm.insertvalue %12, %120[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %122 = llvm.insertvalue %11, %121[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %123 = llvm.insertvalue %11, %122[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %124 = llvm.insertvalue %10, %123[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %125 = llvm.inttoptr %43 : i64 to !llvm.ptr<6>
    %126 = llvm.insertvalue %125, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %127 = llvm.insertvalue %125, %126[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %128 = llvm.insertvalue %13, %127[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %129 = llvm.insertvalue %12, %128[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %130 = llvm.insertvalue %11, %129[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %131 = llvm.insertvalue %11, %130[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %132 = llvm.insertvalue %10, %131[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %133 = llvm.alloca %10 x i64 : (i64) -> !llvm.ptr
    llvm.store %51, %133 : i64, !llvm.ptr
    %134 = llvm.inttoptr %14 : i64 to !llvm.ptr<6>
    %135 = llvm.insertvalue %134, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %136 = llvm.insertvalue %134, %135[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %137 = llvm.insertvalue %13, %136[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %138 = llvm.insertvalue %12, %137[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %139 = llvm.insertvalue %11, %138[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %140 = llvm.insertvalue %11, %139[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %141 = llvm.insertvalue %10, %140[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %142 = llvm.inttoptr %15 : i64 to !llvm.ptr<6>
    %143 = llvm.insertvalue %142, %9[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %144 = llvm.insertvalue %142, %143[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %145 = llvm.insertvalue %13, %144[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %146 = llvm.insertvalue %12, %145[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %147 = llvm.insertvalue %11, %146[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %148 = llvm.insertvalue %11, %147[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %149 = llvm.insertvalue %10, %148[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %150 = llvm.inttoptr %16 : i64 to !llvm.ptr<6>
    %151 = llvm.insertvalue %150, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %152 = llvm.insertvalue %150, %151[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %153 = llvm.insertvalue %13, %152[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %154 = llvm.insertvalue %12, %153[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %155 = llvm.insertvalue %8, %154[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %156 = llvm.insertvalue %11, %155[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %157 = llvm.insertvalue %12, %156[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %158 = llvm.insertvalue %11, %157[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %159 = llvm.insertvalue %10, %158[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %160 = llvm.inttoptr %17 : i64 to !llvm.ptr<6>
    %161 = llvm.insertvalue %160, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %162 = llvm.insertvalue %160, %161[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %163 = llvm.insertvalue %13, %162[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %164 = llvm.insertvalue %12, %163[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %165 = llvm.insertvalue %8, %164[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %166 = llvm.insertvalue %11, %165[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %167 = llvm.insertvalue %12, %166[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %168 = llvm.insertvalue %11, %167[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %169 = llvm.insertvalue %10, %168[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %170 = llvm.inttoptr %18 : i64 to !llvm.ptr<6>
    %171 = llvm.insertvalue %170, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %172 = llvm.insertvalue %170, %171[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %173 = llvm.insertvalue %13, %172[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %174 = llvm.insertvalue %12, %173[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %175 = llvm.insertvalue %8, %174[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %176 = llvm.insertvalue %11, %175[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %177 = llvm.insertvalue %12, %176[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %178 = llvm.insertvalue %11, %177[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %179 = llvm.insertvalue %10, %178[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %180 = llvm.inttoptr %19 : i64 to !llvm.ptr<6>
    %181 = llvm.insertvalue %180, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %182 = llvm.insertvalue %180, %181[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %183 = llvm.insertvalue %13, %182[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %184 = llvm.insertvalue %12, %183[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %185 = llvm.insertvalue %8, %184[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %186 = llvm.insertvalue %11, %185[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %187 = llvm.insertvalue %12, %186[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %188 = llvm.insertvalue %11, %187[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %189 = llvm.insertvalue %10, %188[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %190 = llvm.inttoptr %20 : i64 to !llvm.ptr<6>
    %191 = llvm.insertvalue %190, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %192 = llvm.insertvalue %190, %191[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %193 = llvm.insertvalue %13, %192[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %194 = llvm.insertvalue %12, %193[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %195 = llvm.insertvalue %8, %194[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %196 = llvm.insertvalue %11, %195[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %197 = llvm.insertvalue %12, %196[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %198 = llvm.insertvalue %11, %197[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %199 = llvm.insertvalue %10, %198[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %200 = llvm.inttoptr %21 : i64 to !llvm.ptr<6>
    %201 = llvm.insertvalue %200, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %202 = llvm.insertvalue %200, %201[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %203 = llvm.insertvalue %13, %202[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %204 = llvm.insertvalue %12, %203[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %205 = llvm.insertvalue %8, %204[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %206 = llvm.insertvalue %11, %205[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %207 = llvm.insertvalue %12, %206[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %208 = llvm.insertvalue %11, %207[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %209 = llvm.insertvalue %10, %208[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %210 = llvm.alloca %10 x i64 : (i64) -> !llvm.ptr
    llvm.store %51, %210 : i64, !llvm.ptr
    %211 = llvm.inttoptr %22 : i64 to !llvm.ptr<6>
    %212 = llvm.insertvalue %211, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %213 = llvm.insertvalue %211, %212[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %214 = llvm.insertvalue %13, %213[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %215 = llvm.insertvalue %12, %214[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %216 = llvm.insertvalue %8, %215[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %217 = llvm.insertvalue %11, %216[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %218 = llvm.insertvalue %12, %217[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %219 = llvm.insertvalue %11, %218[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %220 = llvm.insertvalue %10, %219[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %221 = llvm.inttoptr %23 : i64 to !llvm.ptr<6>
    %222 = llvm.insertvalue %221, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %223 = llvm.insertvalue %221, %222[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %224 = llvm.insertvalue %13, %223[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %225 = llvm.insertvalue %12, %224[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %226 = llvm.insertvalue %8, %225[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %227 = llvm.insertvalue %11, %226[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %228 = llvm.insertvalue %12, %227[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %229 = llvm.insertvalue %11, %228[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %230 = llvm.insertvalue %10, %229[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %231 = llvm.alloca %10 x i64 : (i64) -> !llvm.ptr
    llvm.store %51, %231 : i64, !llvm.ptr
    %232 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %233 = "hivm.intr.hivm.SBITSET0"(%232, %6) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%233) : (i64) -> ()
    %234 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %235 = "hivm.intr.hivm.SBITSET1"(%234, %5) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%235) : (i64) -> ()
    %236 = "hivm.intr.hivm.GET.BLOCK.IDX"() : () -> i64
    %237 = llvm.trunc %236 : i64 to i32
    %238 = llvm.srem %237, %arg9  : i32
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.br ^bb1(%238 : i32)
  ^bb1(%239: i32):  // 2 preds: ^bb0, ^bb8
    %240 = llvm.icmp "slt" %239, %arg7 : i32
    llvm.cond_br %240, ^bb2, ^bb9
  ^bb2:  // pred: ^bb1
    %241 = llvm.load %231 : !llvm.ptr -> i64
    %242 = llvm.urem %241, %25  : i64
    %243 = llvm.icmp "eq" %242, %24 : i64
    %244 = llvm.select %243, %68, %60 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %245 = llvm.select %243, %84, %76 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %246 = llvm.trunc %242 : i64 to i1
    %247 = llvm.xor %246, %40  : i1
    %248 = llvm.zext %247 : i1 to i64
    %249 = llvm.mul %239, %32 : i32
    %250 = llvm.sext %249 : i32 to i64
    %251 = llvm.getelementptr %arg5[%250] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %252 = llvm.load %251 : !llvm.ptr<1> -> i32
    %253 = llvm.sext %252 : i32 to i64
    %254 = llvm.mul %253, %12 : i64
    "hivm.intr.hivm.WAIT.FLAG.REG"(%248) <{set_pipe = 1 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    %255 = llvm.extractvalue %244[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %256 = llvm.extractvalue %244[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %257 = llvm.extractvalue %244[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %258 = llvm.extractvalue %244[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %259 = llvm.extractvalue %244[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %260 = llvm.extractvalue %244[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %261 = llvm.extractvalue %244[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @load_gm_to_ubuf_2d_float(%arg6, %arg6, %254, %12, %11, %12, %10, %255, %256, %257, %258, %259, %260, %261, %29, %41, %13, %29) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i32, f32, i64, i32) -> ()
    %262 = llvm.mul %253, %12 : i64
    %263 = llvm.add %262, %11 : i64
    %264 = llvm.extractvalue %245[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %265 = llvm.extractvalue %245[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %266 = llvm.extractvalue %245[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %267 = llvm.extractvalue %245[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %268 = llvm.extractvalue %245[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %269 = llvm.extractvalue %245[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %270 = llvm.extractvalue %245[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @load_gm_to_ubuf_2d_float(%arg6, %arg6, %263, %12, %11, %12, %10, %264, %265, %266, %267, %268, %269, %270, %29, %41, %13, %29) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i32, f32, i64, i32) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    %271 = llvm.mul %239, %30 : i32
    %272 = llvm.sext %271 : i32 to i64
    llvm.br ^bb3(%29 : i32)
  ^bb3(%273: i32):  // 2 preds: ^bb2, ^bb4
    %274 = llvm.icmp "slt" %273, %28 : i32
    llvm.cond_br %274, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %275 = llvm.load %133 : !llvm.ptr -> i64
    %276 = llvm.urem %275, %25  : i64
    %277 = llvm.icmp "eq" %276, %24 : i64
    %278 = llvm.select %277, %100, %92 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %279 = llvm.select %277, %116, %108 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %280 = llvm.select %277, %132, %124 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %281 = llvm.select %277, %149, %141 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %282 = llvm.mul %273, %31 : i32
    %283 = llvm.sext %282 : i32 to i64
    %284 = llvm.add %283, %272 : i64
    %285 = llvm.add %284, %4 : i64
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 4 : i64}> : () -> ()
    %286 = llvm.extractvalue %281[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %287 = llvm.extractvalue %281[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %288 = llvm.extractvalue %281[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %289 = llvm.extractvalue %281[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %290 = llvm.extractvalue %281[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %291 = llvm.extractvalue %281[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %292 = llvm.extractvalue %281[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @load_gm_to_ubuf_2d_bfloat16_t(%arg4, %arg4, %285, %12, %11, %3, %10, %286, %287, %288, %289, %290, %291, %292, %29, %42, %13, %29) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i32, bf16, i64, i32) -> ()
    %293 = llvm.add %283, %272 : i64
    %294 = llvm.add %293, %2 : i64
    %295 = llvm.extractvalue %280[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %296 = llvm.extractvalue %280[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %297 = llvm.extractvalue %280[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %298 = llvm.extractvalue %280[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %299 = llvm.extractvalue %280[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %300 = llvm.extractvalue %280[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %301 = llvm.extractvalue %280[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @load_gm_to_ubuf_2d_bfloat16_t(%arg4, %arg4, %294, %12, %11, %3, %10, %295, %296, %297, %298, %299, %300, %301, %29, %42, %13, %29) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i32, bf16, i64, i32) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    %302 = llvm.inttoptr %34 : i64 to !llvm.ptr<6>
    %303 = llvm.inttoptr %35 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    %304 = llvm.extractvalue %281[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %305 = llvm.extractvalue %280[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @_welmv4_inplace_rope_contiguous_prefill_kernel_npu_fused_0_outlined_vf_0(%304, %305, %302, %303) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %306 = llvm.extractvalue %244[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %307 = llvm.extractvalue %245[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %308 = llvm.extractvalue %279[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %309 = llvm.extractvalue %245[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %310 = llvm.extractvalue %244[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %311 = llvm.extractvalue %278[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @_welmv4_inplace_rope_contiguous_prefill_kernel_npu_fused_0_outlined_merged_vf_0(%302, %306, %303, %307, %308, %302, %309, %303, %310, %311) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    %312 = llvm.extractvalue %279[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %313 = llvm.extractvalue %279[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %314 = llvm.extractvalue %279[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %315 = llvm.extractvalue %279[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %316 = llvm.extractvalue %279[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %317 = llvm.extractvalue %279[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %318 = llvm.extractvalue %279[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @store_ubuf_to_gm_2d_bfloat16_t(%312, %313, %314, %315, %316, %317, %318, %arg4, %arg4, %285, %12, %11, %3, %10, %29) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i32) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 5 : i64}> : () -> ()
    %319 = llvm.extractvalue %278[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %320 = llvm.extractvalue %278[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %321 = llvm.extractvalue %278[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %322 = llvm.extractvalue %278[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %323 = llvm.extractvalue %278[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %324 = llvm.extractvalue %278[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %325 = llvm.extractvalue %278[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @store_ubuf_to_gm_2d_bfloat16_t(%319, %320, %321, %322, %323, %324, %325, %arg4, %arg4, %294, %12, %11, %3, %10, %29) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i32) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 4 : i64}> : () -> ()
    %326 = llvm.add %275, %24 : i64
    llvm.store %326, %133 : i64, !llvm.ptr
    %327 = llvm.add %273, %33 overflow<nsw> : i32
    llvm.br ^bb3(%327 : i32)
  ^bb5:  // pred: ^bb3
    %328 = llvm.mul %239, %27 : i32
    %329 = llvm.sext %328 : i32 to i64
    %330 = llvm.inttoptr %36 : i64 to !llvm.ptr<6>
    %331 = llvm.inttoptr %37 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    %332 = llvm.extractvalue %244[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %333 = llvm.extractvalue %245[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @_welmv4_inplace_rope_contiguous_prefill_kernel_npu_outlined_vf_0(%332, %333, %330, %331) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%248) <{set_pipe = 1 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.br ^bb6(%29 : i32)
  ^bb6(%334: i32):  // 2 preds: ^bb5, ^bb7
    %335 = llvm.icmp "slt" %334, %26 : i32
    llvm.cond_br %335, ^bb7, ^bb8
  ^bb7:  // pred: ^bb6
    %336 = llvm.load %210 : !llvm.ptr -> i64
    %337 = llvm.urem %336, %25  : i64
    %338 = llvm.icmp "eq" %337, %24 : i64
    %339 = llvm.select %338, %169, %159 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)>
    %340 = llvm.select %338, %189, %179 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)>
    %341 = llvm.select %338, %209, %199 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)>
    %342 = llvm.select %338, %230, %220 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)>
    %343 = llvm.mul %334, %31 : i32
    %344 = llvm.sext %343 : i32 to i64
    %345 = llvm.add %344, %329 : i64
    %346 = llvm.add %345, %4 : i64
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 4 : i64}> : () -> ()
    %347 = llvm.extractvalue %342[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %348 = llvm.extractvalue %342[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %349 = llvm.extractvalue %342[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %350 = llvm.extractvalue %342[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %351 = llvm.extractvalue %342[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %352 = llvm.extractvalue %342[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %353 = llvm.extractvalue %342[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %354 = llvm.extractvalue %342[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %355 = llvm.extractvalue %342[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    llvm.call @load_gm_to_ubuf_3d_bfloat16_t(%arg3, %arg3, %346, %12, %8, %11, %1, %0, %10, %347, %348, %349, %350, %351, %352, %353, %354, %355, %29, %42, %13, %29) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, i64, i32, bf16, i64, i32) -> ()
    %356 = llvm.add %344, %329 : i64
    %357 = llvm.add %356, %2 : i64
    %358 = llvm.extractvalue %341[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %359 = llvm.extractvalue %341[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %360 = llvm.extractvalue %341[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %361 = llvm.extractvalue %341[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %362 = llvm.extractvalue %341[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %363 = llvm.extractvalue %341[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %364 = llvm.extractvalue %341[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %365 = llvm.extractvalue %341[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %366 = llvm.extractvalue %341[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    llvm.call @load_gm_to_ubuf_3d_bfloat16_t(%arg3, %arg3, %357, %12, %8, %11, %1, %0, %10, %358, %359, %360, %361, %362, %363, %364, %365, %366, %29, %42, %13, %29) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, i64, i32, bf16, i64, i32) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    %367 = llvm.inttoptr %38 : i64 to !llvm.ptr<6>
    %368 = llvm.inttoptr %39 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    %369 = llvm.extractvalue %342[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %370 = llvm.extractvalue %341[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    llvm.call @_welmv4_inplace_rope_contiguous_prefill_kernel_npu_fused_2_outlined_vf_0(%369, %370, %367, %368) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %371 = llvm.extractvalue %340[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %372 = llvm.extractvalue %339[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    llvm.call @_welmv4_inplace_rope_contiguous_prefill_kernel_npu_fused_2_outlined_merged_vf_0(%367, %330, %368, %331, %371, %367, %331, %368, %330, %372) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    %373 = llvm.extractvalue %340[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %374 = llvm.extractvalue %340[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %375 = llvm.extractvalue %340[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %376 = llvm.extractvalue %340[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %377 = llvm.extractvalue %340[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %378 = llvm.extractvalue %340[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %379 = llvm.extractvalue %340[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %380 = llvm.extractvalue %340[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %381 = llvm.extractvalue %340[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    llvm.call @store_ubuf_to_gm_3d_bfloat16_t(%373, %374, %375, %376, %377, %378, %379, %380, %381, %arg3, %arg3, %346, %12, %8, %11, %1, %0, %10, %29) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i64, i64, i32) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 5 : i64}> : () -> ()
    %382 = llvm.extractvalue %339[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %383 = llvm.extractvalue %339[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %384 = llvm.extractvalue %339[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %385 = llvm.extractvalue %339[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %386 = llvm.extractvalue %339[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %387 = llvm.extractvalue %339[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %388 = llvm.extractvalue %339[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %389 = llvm.extractvalue %339[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %390 = llvm.extractvalue %339[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    llvm.call @store_ubuf_to_gm_3d_bfloat16_t(%382, %383, %384, %385, %386, %387, %388, %389, %390, %arg3, %arg3, %357, %12, %8, %11, %1, %0, %10, %29) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i64, i64, i32) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 4 : i64}> : () -> ()
    %391 = llvm.add %336, %24 : i64
    llvm.store %391, %210 : i64, !llvm.ptr
    %392 = llvm.add %334, %28 overflow<nsw> : i32
    llvm.br ^bb6(%392 : i32)
  ^bb8:  // pred: ^bb6
    %393 = llvm.add %241, %24 : i64
    llvm.store %393, %231 : i64, !llvm.ptr
    %394 = llvm.add %239, %arg9 overflow<nsw> : i32
    llvm.br ^bb1(%394 : i32)
  ^bb9:  // pred: ^bb1
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    %395 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %396 = "hivm.intr.hivm.SBITSET1"(%395, %6) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%396) : (i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 6 : i64}> : () -> ()
    llvm.return
  }
}


bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
