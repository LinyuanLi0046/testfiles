// -----// IR Dump After AppendUsePrintDebugData (append-use-print-debug-data) //----- //
module attributes {dlti.target_system_spec = #dlti.target_system_spec<"NPU" : #hacc.target_device_spec<#dlti.dl_entry<"AI_CORE_COUNT", 28 : i32>, #dlti.dl_entry<"CUBE_CORE_COUNT", 28 : i32>, #dlti.dl_entry<"VECTOR_CORE_COUNT", 56 : i32>, #dlti.dl_entry<"UB_SIZE", 2031616 : i32>, #dlti.dl_entry<"L1_SIZE", 4194304 : i32>, #dlti.dl_entry<"L0A_SIZE", 524288 : i32>, #dlti.dl_entry<"L0B_SIZE", 524288 : i32>, #dlti.dl_entry<"L0C_SIZE", 2097152 : i32>, #dlti.dl_entry<"UB_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L1_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L0C_ALIGN_SIZE", 4096 : i32>, #dlti.dl_entry<"MINIMAL_D_CACHE_SIZE", 262144 : i32>, #dlti.dl_entry<"MAXIMUM_D_CACHE_SIZE", 983040 : i32>, #dlti.dl_entry<"ARCH", "dav-c310">>>, hacc.target = #hacc.target<"Ascend950PR_957b">, hivm.aic_bitcode = #hivm.aic_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.aic.c310.bc">, hivm.aiv_bitcode = #hivm.aiv_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.aiv.c310.bc">, hivm.host_bitcode = #hivm.host_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/host-a5.bc">, hivm.mix_aic_bitcode = #hivm.mix_aic_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.mix.aic.c310.bc">, hivm.mix_aiv_bitcode = #hivm.mix_aiv_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.mix.aiv.c310.bc">, hivm.module_core_type = #hivm.module_core_type<AIV>} {
  llvm.func @_welmv4_inplace_rope_contiguous_prefill_kernel_npu_fused_2_outlined_merged_merged_vf_0(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>, %arg8: !llvm.ptr<6>, %arg9: !llvm.ptr<6>, %arg10: !llvm.ptr<6>, %arg11: !llvm.ptr<6>, %arg12: !llvm.ptr<6>, %arg13: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(7 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(64 : i32) : i32
    %3 = llvm.mlir.constant(1 : i32) : i32
    %4 = llvm.mlir.constant(2 : i32) : i32
    %5 = llvm.mlir.constant(32 : index) : i64
    %6 = llvm.mlir.constant(64 : index) : i64
    %7 = llvm.mlir.constant(0 : index) : i64
    %8 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %1) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    llvm.br ^bb1(%1 : i32)
  ^bb1(%9: i32):  // 2 preds: ^bb0, ^bb2
    %10 = llvm.icmp "slt" %9, %2 : i32
    llvm.cond_br %10, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %11 = llvm.sext %9 : i32 to i64
    %12 = llvm.mul %11, %5 : i64
    %13 = llvm.getelementptr %arg0[%12] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %14 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%13, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %15 = llvm.mul %11, %5 : i64
    %16 = llvm.getelementptr %arg1[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %17 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%16, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %18 = llvm.mul %11, %5 : i64
    %19 = llvm.getelementptr %arg2[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %20 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%19, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %21 = llvm.mul %11, %5 : i64
    %22 = llvm.getelementptr %arg3[%21] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%22, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %24 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%20, %23, %8) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %25 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%14, %17, %8) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %26 = "hivm_regbaseintrins.intr.hivm.vsub.s.x"(%25, %24, %8) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %27 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%26, %8, %1, %1, %1) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %28 = llvm.mul %11, %5 : i64
    %29 = llvm.getelementptr %arg4[%28] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%27, %29, %1, %0, %1, %8) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %30 = llvm.add %9, %3 overflow<nsw> : i32
    llvm.br ^bb1(%30 : i32)
  ^bb3:  // pred: ^bb1
    llvm.br ^bb4(%1 : i32)
  ^bb4(%31: i32):  // 2 preds: ^bb3, ^bb5
    %32 = llvm.icmp "slt" %31, %2 : i32
    llvm.cond_br %32, ^bb5, ^bb6
  ^bb5:  // pred: ^bb4
    %33 = llvm.sext %31 : i32 to i64
    %34 = llvm.mul %33, %5 : i64
    %35 = llvm.getelementptr %arg5[%34] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %36 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%35, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %37 = llvm.mul %33, %5 : i64
    %38 = llvm.getelementptr %arg6[%37] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %39 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%38, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %40 = llvm.mul %33, %5 : i64
    %41 = llvm.getelementptr %arg7[%40] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %42 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%41, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %43 = llvm.mul %33, %5 : i64
    %44 = llvm.getelementptr %arg8[%43] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %45 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%44, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %46 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%42, %45, %8) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %47 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%36, %39, %8) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %48 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%47, %46, %8) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %49 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%48, %8, %1, %1, %1) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %50 = llvm.mul %33, %5 : i64
    %51 = llvm.getelementptr %arg9[%50] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%49, %51, %1, %0, %1, %8) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %52 = llvm.add %31, %3 overflow<nsw> : i32
    llvm.br ^bb4(%52 : i32)
  ^bb6:  // pred: ^bb4
    llvm.br ^bb7(%1 : i32)
  ^bb7(%53: i32):  // 2 preds: ^bb6, ^bb11
    %54 = llvm.icmp "slt" %53, %2 : i32
    llvm.cond_br %54, ^bb8, ^bb12
  ^bb8:  // pred: ^bb7
    %55 = llvm.sext %53 : i32 to i64
    %56 = llvm.mul %55, %5 : i64
    %57 = llvm.mul %55, %5 : i64
    llvm.br ^bb9(%1 : i32)
  ^bb9(%58: i32):  // 2 preds: ^bb8, ^bb10
    %59 = llvm.icmp "slt" %58, %4 : i32
    llvm.cond_br %59, ^bb10, ^bb11
  ^bb10:  // pred: ^bb9
    %60 = llvm.sext %58 : i32 to i64
    %61 = llvm.getelementptr %arg10[%56] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %62 = llvm.mul %7, %5 : i64
    %63 = llvm.add %62, %7 : i64
    %64 = llvm.getelementptr %61[%63] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %65 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%64, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %66 = llvm.mul %55, %6 : i64
    %67 = llvm.mul %60, %5 : i64
    %68 = llvm.add %66, %67 : i64
    %69 = llvm.getelementptr %arg12[%68] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%65, %69, %1, %4, %1, %8) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %70 = llvm.getelementptr %arg11[%57] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %71 = llvm.mul %7, %5 : i64
    %72 = llvm.add %71, %7 : i64
    %73 = llvm.getelementptr %70[%72] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %74 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%73, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %75 = llvm.mul %55, %6 : i64
    %76 = llvm.mul %60, %5 : i64
    %77 = llvm.add %75, %76 : i64
    %78 = llvm.getelementptr %arg13[%77] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%74, %78, %1, %4, %1, %8) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %79 = llvm.add %58, %3 overflow<nsw> : i32
    llvm.br ^bb9(%79 : i32)
  ^bb11:  // pred: ^bb9
    %80 = llvm.add %53, %3 overflow<nsw> : i32
    llvm.br ^bb7(%80 : i32)
  ^bb12:  // pred: ^bb7
    llvm.return
  }
  llvm.func @_welmv4_inplace_rope_contiguous_prefill_kernel_npu_fused_0_outlined_merged_vf_0(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>, %arg8: !llvm.ptr<6>, %arg9: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(64 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(2 : i32) : i32
    %4 = llvm.mlir.constant(7 : i32) : i32
    %5 = llvm.mlir.constant(32 : index) : i64
    %6 = llvm.mlir.constant(64 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%7: i32):  // 2 preds: ^bb0, ^bb5
    %8 = llvm.icmp "slt" %7, %1 : i32
    llvm.cond_br %8, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %9 = llvm.sext %7 : i32 to i64
    llvm.br ^bb3(%2 : i32)
  ^bb3(%10: i32):  // 2 preds: ^bb2, ^bb4
    %11 = llvm.icmp "slt" %10, %3 : i32
    llvm.cond_br %11, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %12 = llvm.sext %10 : i32 to i64
    %13 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%4, %2) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %14 = llvm.mul %9, %6 : i64
    %15 = llvm.mul %12, %5 : i64
    %16 = llvm.add %14, %15 : i64
    %17 = llvm.getelementptr %arg0[%16] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %18 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%17, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %19 = llvm.mul %9, %6 : i64
    %20 = llvm.mul %12, %5 : i64
    %21 = llvm.add %19, %20 : i64
    %22 = llvm.getelementptr %arg1[%21] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %23 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%22, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %24 = llvm.mul %9, %6 : i64
    %25 = llvm.mul %12, %5 : i64
    %26 = llvm.add %24, %25 : i64
    %27 = llvm.getelementptr %arg2[%26] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %28 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%27, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %29 = llvm.mul %9, %6 : i64
    %30 = llvm.mul %12, %5 : i64
    %31 = llvm.add %29, %30 : i64
    %32 = llvm.getelementptr %arg3[%31] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %33 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%32, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %34 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%28, %33, %13) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %35 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%18, %23, %13) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %36 = "hivm_regbaseintrins.intr.hivm.vsub.s.x"(%35, %34, %13) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %37 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%36, %13, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %38 = llvm.mul %9, %6 : i64
    %39 = llvm.mul %12, %5 : i64
    %40 = llvm.add %38, %39 : i64
    %41 = llvm.getelementptr %arg4[%40] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%37, %41, %2, %4, %2, %13) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %42 = llvm.add %10, %0 overflow<nsw> : i32
    llvm.br ^bb3(%42 : i32)
  ^bb5:  // pred: ^bb3
    %43 = llvm.add %7, %0 overflow<nsw> : i32
    llvm.br ^bb1(%43 : i32)
  ^bb6:  // pred: ^bb1
    llvm.br ^bb7(%2 : i32)
  ^bb7(%44: i32):  // 2 preds: ^bb6, ^bb11
    %45 = llvm.icmp "slt" %44, %1 : i32
    llvm.cond_br %45, ^bb8, ^bb12
  ^bb8:  // pred: ^bb7
    %46 = llvm.sext %44 : i32 to i64
    llvm.br ^bb9(%2 : i32)
  ^bb9(%47: i32):  // 2 preds: ^bb8, ^bb10
    %48 = llvm.icmp "slt" %47, %3 : i32
    llvm.cond_br %48, ^bb10, ^bb11
  ^bb10:  // pred: ^bb9
    %49 = llvm.sext %47 : i32 to i64
    %50 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%4, %2) {mask_bit_width = 32 : i32, mask_op_idx = 1 : i32} : (i32, i32) -> vector<256xi1>
    %51 = llvm.mul %46, %6 : i64
    %52 = llvm.mul %49, %5 : i64
    %53 = llvm.add %51, %52 : i64
    %54 = llvm.getelementptr %arg5[%53] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %55 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%54, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %56 = llvm.mul %46, %6 : i64
    %57 = llvm.mul %49, %5 : i64
    %58 = llvm.add %56, %57 : i64
    %59 = llvm.getelementptr %arg6[%58] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %60 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%59, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %61 = llvm.mul %46, %6 : i64
    %62 = llvm.mul %49, %5 : i64
    %63 = llvm.add %61, %62 : i64
    %64 = llvm.getelementptr %arg7[%63] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %65 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%64, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %66 = llvm.mul %46, %6 : i64
    %67 = llvm.mul %49, %5 : i64
    %68 = llvm.add %66, %67 : i64
    %69 = llvm.getelementptr %arg8[%68] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %70 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%69, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %71 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%65, %70, %50) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %72 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%55, %60, %50) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %73 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%72, %71, %50) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %74 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%73, %50, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %75 = llvm.mul %46, %6 : i64
    %76 = llvm.mul %49, %5 : i64
    %77 = llvm.add %75, %76 : i64
    %78 = llvm.getelementptr %arg9[%77] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%74, %78, %2, %4, %2, %50) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %79 = llvm.add %47, %0 overflow<nsw> : i32
    llvm.br ^bb9(%79 : i32)
  ^bb11:  // pred: ^bb9
    %80 = llvm.add %44, %0 overflow<nsw> : i32
    llvm.br ^bb7(%80 : i32)
  ^bb12:  // pred: ^bb7
    llvm.return
  }
  llvm.func @_welmv4_inplace_rope_contiguous_prefill_kernel_npu_fused_0_outlined_vf_0(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(64 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(2 : i32) : i32
    %4 = llvm.mlir.constant(7 : i32) : i32
    %5 = llvm.mlir.constant(14 : i32) : i32
    %6 = llvm.mlir.constant(32 : index) : i64
    %7 = llvm.mlir.constant(64 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%8: i32):  // 2 preds: ^bb0, ^bb5
    %9 = llvm.icmp "slt" %8, %1 : i32
    llvm.cond_br %9, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %10 = llvm.sext %8 : i32 to i64
    llvm.br ^bb3(%2 : i32)
  ^bb3(%11: i32):  // 2 preds: ^bb2, ^bb4
    %12 = llvm.icmp "slt" %11, %3 : i32
    llvm.cond_br %12, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %13 = llvm.sext %11 : i32 to i64
    %14 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%4, %2) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %15 = llvm.mul %10, %7 : i64
    %16 = llvm.mul %13, %6 : i64
    %17 = llvm.add %15, %16 : i64
    %18 = llvm.getelementptr %arg0[%17] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %19 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%18, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %20 = "hivm_regbaseintrins.intr.hivm.vcvtff.bf162f32.x"(%19, %14, %2) : (vector<128xbf16>, vector<256xi1>, i32) -> vector<64xf32>
    %21 = llvm.mul %10, %7 : i64
    %22 = llvm.mul %13, %6 : i64
    %23 = llvm.add %21, %22 : i64
    %24 = llvm.getelementptr %arg2[%23] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%20, %24, %2, %3, %2, %14) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %25 = llvm.mul %10, %7 : i64
    %26 = llvm.mul %13, %6 : i64
    %27 = llvm.add %25, %26 : i64
    %28 = llvm.getelementptr %arg1[%27] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %29 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%28, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %30 = "hivm_regbaseintrins.intr.hivm.vcvtff.bf162f32.x"(%29, %14, %2) : (vector<128xbf16>, vector<256xi1>, i32) -> vector<64xf32>
    %31 = llvm.mul %10, %7 : i64
    %32 = llvm.mul %13, %6 : i64
    %33 = llvm.add %31, %32 : i64
    %34 = llvm.getelementptr %arg3[%33] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%30, %34, %2, %3, %2, %14) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %35 = llvm.add %11, %0 overflow<nsw> : i32
    llvm.br ^bb3(%35 : i32)
  ^bb5:  // pred: ^bb3
    %36 = llvm.add %8, %0 overflow<nsw> : i32
    llvm.br ^bb1(%36 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_welmv4_inplace_rope_contiguous_prefill_kernel_npu_fused_2_outlined_vf_0(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(64 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(7 : i32) : i32
    %4 = llvm.mlir.constant(14 : i32) : i32
    %5 = llvm.mlir.constant(2 : i32) : i32
    %6 = llvm.mlir.constant(32 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%7: i32):  // 2 preds: ^bb0, ^bb2
    %8 = llvm.icmp "slt" %7, %1 : i32
    llvm.cond_br %8, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %9 = llvm.sext %7 : i32 to i64
    %10 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %2) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %11 = llvm.mul %9, %6 : i64
    %12 = llvm.getelementptr %arg0[%11] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %13 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%12, %2, %4, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %14 = "hivm_regbaseintrins.intr.hivm.vcvtff.bf162f32.x"(%13, %10, %2) : (vector<128xbf16>, vector<256xi1>, i32) -> vector<64xf32>
    %15 = llvm.mul %9, %6 : i64
    %16 = llvm.getelementptr %arg2[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%14, %16, %2, %5, %2, %10) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %17 = llvm.mul %9, %6 : i64
    %18 = llvm.getelementptr %arg1[%17] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %19 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%18, %2, %4, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %20 = "hivm_regbaseintrins.intr.hivm.vcvtff.bf162f32.x"(%19, %10, %2) : (vector<128xbf16>, vector<256xi1>, i32) -> vector<64xf32>
    %21 = llvm.mul %9, %6 : i64
    %22 = llvm.getelementptr %arg3[%21] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%20, %22, %2, %5, %2, %10) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %23 = llvm.add %7, %0 overflow<nsw> : i32
    llvm.br ^bb1(%23 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func private @load_gm_to_ubuf_2d_float(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<6>, %arg8: !llvm.ptr<6>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i32, %arg15: f32, %arg16: i64, %arg17: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg12, %14[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %17, %18 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_load_gm_to_ubuf_2d_float(%10, %18, %arg14, %arg15, %arg16, %arg17) : (!llvm.ptr, !llvm.ptr, i32, f32, i64, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_load_gm_to_ubuf_2d_float(!llvm.ptr, !llvm.ptr, i32, f32, i64, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @load_gm_to_ubuf_2d_bfloat16_t(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<6>, %arg8: !llvm.ptr<6>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i32, %arg15: bf16, %arg16: i64, %arg17: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg12, %14[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %17, %18 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_load_gm_to_ubuf_2d_bfloat16_t(%10, %18, %arg14, %arg15, %arg16, %arg17) : (!llvm.ptr, !llvm.ptr, i32, bf16, i64, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_load_gm_to_ubuf_2d_bfloat16_t(!llvm.ptr, !llvm.ptr, i32, bf16, i64, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @store_ubuf_to_gm_2d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<1>, %arg8: !llvm.ptr<1>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg12, %14[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %17, %18 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_store_ubuf_to_gm_2d_bfloat16_t(%10, %18, %arg14) : (!llvm.ptr, !llvm.ptr, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_store_ubuf_to_gm_2d_bfloat16_t(!llvm.ptr, !llvm.ptr, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @load_gm_to_ubuf_3d_bfloat16_t(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: !llvm.ptr<6>, %arg10: !llvm.ptr<6>, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i32, %arg19: bf16, %arg20: i64, %arg21: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %9 = llvm.insertvalue %arg7, %8[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %11 = llvm.insertvalue %arg8, %10[4, 2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %12 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %11, %12 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)>, !llvm.ptr
    %13 = llvm.insertvalue %arg9, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %15 = llvm.insertvalue %arg11, %14[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %17 = llvm.insertvalue %arg15, %16[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %18 = llvm.insertvalue %arg13, %17[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %20 = llvm.insertvalue %arg14, %19[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %22 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %21, %22 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_load_gm_to_ubuf_3d_bfloat16_t(%12, %22, %arg18, %arg19, %arg20, %arg21) : (!llvm.ptr, !llvm.ptr, i32, bf16, i64, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_load_gm_to_ubuf_3d_bfloat16_t(!llvm.ptr, !llvm.ptr, i32, bf16, i64, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @store_ubuf_to_gm_3d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: !llvm.ptr<1>, %arg10: !llvm.ptr<1>, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %9 = llvm.insertvalue %arg7, %8[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %11 = llvm.insertvalue %arg8, %10[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %12 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %11, %12 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)>, !llvm.ptr
    %13 = llvm.insertvalue %arg9, %0[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %15 = llvm.insertvalue %arg11, %14[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %17 = llvm.insertvalue %arg15, %16[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %18 = llvm.insertvalue %arg13, %17[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %20 = llvm.insertvalue %arg14, %19[3, 2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> 
    %22 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %21, %22 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<3 x i64>, array<3 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_store_ubuf_to_gm_3d_bfloat16_t(%12, %22, %arg18) : (!llvm.ptr, !llvm.ptr, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_store_ubuf_to_gm_3d_bfloat16_t(!llvm.ptr, !llvm.ptr, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func @_welmv4_inplace_rope_contiguous_prefill_kernel_npu(%arg0: i64, %arg1: !llvm.ptr<1>, %arg2: !llvm.ptr<1>, %arg3: !llvm.ptr<1>, %arg4: !llvm.ptr<1>, %arg5: !llvm.ptr<1>, %arg6: !llvm.ptr<1>, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vf_mode = #hivm.vf_mode<SIMD>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, mix_mode = "aiv", parallel_mode = "simd"} {
    %0 = llvm.mlir.constant(3072 : index) : i64
    %1 = llvm.mlir.constant(224 : index) : i64
    %2 = llvm.mlir.constant(256 : index) : i64
    %3 = llvm.mlir.constant(192 : index) : i64
    %4 = llvm.mlir.constant(48 : i64) : i64
    %5 = llvm.mlir.constant(60 : i64) : i64
    %6 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)>
    %7 = llvm.mlir.constant(2 : index) : i64
    %8 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %9 = llvm.mlir.constant(1 : index) : i64
    %10 = llvm.mlir.constant(32 : index) : i64
    %11 = llvm.mlir.constant(64 : index) : i64
    %12 = llvm.mlir.constant(0 : index) : i64
    %13 = llvm.mlir.constant(81920 : i64) : i64
    %14 = llvm.mlir.constant(180224 : i64) : i64
    %15 = llvm.mlir.constant(1 : i64) : i64
    %16 = llvm.mlir.constant(2 : i64) : i64
    %17 = llvm.mlir.constant(2 : i32) : i32
    %18 = llvm.mlir.constant(12 : i32) : i32
    %19 = llvm.mlir.constant(0 : i32) : i32
    %20 = llvm.mlir.constant(196608 : i32) : i32
    %21 = llvm.mlir.constant(16384 : i32) : i32
    %22 = llvm.mlir.constant(256 : i32) : i32
    %23 = llvm.mlir.constant(64 : i32) : i32
    %24 = llvm.mlir.constant(24576 : i64) : i64
    %25 = llvm.mlir.constant(32768 : i64) : i64
    %26 = llvm.mlir.constant(49152 : i64) : i64
    %27 = llvm.mlir.constant(65536 : i64) : i64
    %28 = llvm.mlir.constant(98304 : i64) : i64
    %29 = llvm.mlir.constant(114688 : i64) : i64
    %30 = llvm.mlir.constant(true) : i1
    %31 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %32 = llvm.mlir.constant(0.000000e+00 : bf16) : bf16
    %33 = llvm.mlir.constant(188416 : i64) : i64
    %34 = llvm.mlir.constant(90112 : i64) : i64
    %35 = llvm.mlir.constant(196608 : i64) : i64
    %36 = llvm.mlir.constant(131072 : i64) : i64
    %37 = llvm.mlir.constant(204800 : i64) : i64
    %38 = llvm.mlir.constant(139264 : i64) : i64
    %39 = llvm.mlir.constant(155648 : i64) : i64
    %40 = llvm.mlir.constant(8192 : i64) : i64
    %41 = llvm.mlir.constant(163840 : i64) : i64
    %42 = llvm.mlir.constant(16384 : i64) : i64
    %43 = llvm.mlir.constant(167936 : i64) : i64
    %44 = llvm.mlir.constant(20480 : i64) : i64
    %45 = llvm.mlir.constant(172032 : i64) : i64
    %46 = llvm.mlir.constant(40960 : i64) : i64
    %47 = llvm.mlir.constant(176128 : i64) : i64
    %48 = llvm.mlir.constant(45056 : i64) : i64
    %49 = llvm.mlir.constant(0 : i64) : i64
    %50 = llvm.mlir.constant(147456 : i64) : i64
    %51 = llvm.inttoptr %49 : i64 to !llvm.ptr<6>
    %52 = llvm.insertvalue %51, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %53 = llvm.insertvalue %51, %52[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %54 = llvm.insertvalue %12, %53[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %55 = llvm.insertvalue %11, %54[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %56 = llvm.insertvalue %10, %55[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %57 = llvm.insertvalue %10, %56[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %58 = llvm.insertvalue %9, %57[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %59 = llvm.inttoptr %50 : i64 to !llvm.ptr<6>
    %60 = llvm.insertvalue %59, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %61 = llvm.insertvalue %59, %60[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %62 = llvm.insertvalue %12, %61[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %63 = llvm.insertvalue %11, %62[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %64 = llvm.insertvalue %10, %63[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %65 = llvm.insertvalue %10, %64[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %66 = llvm.insertvalue %9, %65[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %67 = llvm.inttoptr %48 : i64 to !llvm.ptr<6>
    %68 = llvm.insertvalue %67, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %69 = llvm.insertvalue %67, %68[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %70 = llvm.insertvalue %12, %69[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %71 = llvm.insertvalue %11, %70[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %72 = llvm.insertvalue %10, %71[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %73 = llvm.insertvalue %10, %72[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %74 = llvm.insertvalue %9, %73[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %75 = llvm.inttoptr %47 : i64 to !llvm.ptr<6>
    %76 = llvm.insertvalue %75, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %77 = llvm.insertvalue %75, %76[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %78 = llvm.insertvalue %12, %77[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %79 = llvm.insertvalue %11, %78[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %80 = llvm.insertvalue %10, %79[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %81 = llvm.insertvalue %10, %80[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %82 = llvm.insertvalue %9, %81[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %83 = llvm.inttoptr %46 : i64 to !llvm.ptr<6>
    %84 = llvm.insertvalue %83, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %85 = llvm.insertvalue %83, %84[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %86 = llvm.insertvalue %12, %85[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %87 = llvm.insertvalue %11, %86[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %88 = llvm.insertvalue %10, %87[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %89 = llvm.insertvalue %10, %88[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %90 = llvm.insertvalue %9, %89[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %91 = llvm.inttoptr %45 : i64 to !llvm.ptr<6>
    %92 = llvm.insertvalue %91, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %93 = llvm.insertvalue %91, %92[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %94 = llvm.insertvalue %12, %93[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %95 = llvm.insertvalue %11, %94[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %96 = llvm.insertvalue %10, %95[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %97 = llvm.insertvalue %10, %96[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %98 = llvm.insertvalue %9, %97[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %99 = llvm.inttoptr %44 : i64 to !llvm.ptr<6>
    %100 = llvm.insertvalue %99, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %101 = llvm.insertvalue %99, %100[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %102 = llvm.insertvalue %12, %101[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %103 = llvm.insertvalue %11, %102[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %104 = llvm.insertvalue %10, %103[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %105 = llvm.insertvalue %10, %104[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %106 = llvm.insertvalue %9, %105[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %107 = llvm.inttoptr %43 : i64 to !llvm.ptr<6>
    %108 = llvm.insertvalue %107, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %109 = llvm.insertvalue %107, %108[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %110 = llvm.insertvalue %12, %109[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %111 = llvm.insertvalue %11, %110[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %112 = llvm.insertvalue %10, %111[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %113 = llvm.insertvalue %10, %112[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %114 = llvm.insertvalue %9, %113[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %115 = llvm.inttoptr %42 : i64 to !llvm.ptr<6>
    %116 = llvm.insertvalue %115, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %117 = llvm.insertvalue %115, %116[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %118 = llvm.insertvalue %12, %117[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %119 = llvm.insertvalue %11, %118[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %120 = llvm.insertvalue %10, %119[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %121 = llvm.insertvalue %10, %120[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %122 = llvm.insertvalue %9, %121[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %123 = llvm.inttoptr %41 : i64 to !llvm.ptr<6>
    %124 = llvm.insertvalue %123, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %125 = llvm.insertvalue %123, %124[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %126 = llvm.insertvalue %12, %125[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %127 = llvm.insertvalue %11, %126[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %128 = llvm.insertvalue %10, %127[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %129 = llvm.insertvalue %10, %128[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %130 = llvm.insertvalue %9, %129[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %131 = llvm.inttoptr %40 : i64 to !llvm.ptr<6>
    %132 = llvm.insertvalue %131, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %133 = llvm.insertvalue %131, %132[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %134 = llvm.insertvalue %12, %133[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %135 = llvm.insertvalue %11, %134[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %136 = llvm.insertvalue %10, %135[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %137 = llvm.insertvalue %10, %136[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %138 = llvm.insertvalue %9, %137[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %139 = llvm.inttoptr %39 : i64 to !llvm.ptr<6>
    %140 = llvm.insertvalue %139, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %141 = llvm.insertvalue %139, %140[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %142 = llvm.insertvalue %12, %141[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %143 = llvm.insertvalue %11, %142[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %144 = llvm.insertvalue %10, %143[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %145 = llvm.insertvalue %10, %144[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %146 = llvm.insertvalue %9, %145[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %147 = llvm.inttoptr %38 : i64 to !llvm.ptr<6>
    %148 = llvm.insertvalue %147, %6[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %149 = llvm.insertvalue %147, %148[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %150 = llvm.insertvalue %12, %149[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %151 = llvm.insertvalue %11, %150[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %152 = llvm.insertvalue %7, %151[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %153 = llvm.insertvalue %10, %152[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %154 = llvm.insertvalue %11, %153[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %155 = llvm.insertvalue %10, %154[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %156 = llvm.insertvalue %9, %155[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %157 = llvm.inttoptr %37 : i64 to !llvm.ptr<6>
    %158 = llvm.insertvalue %157, %6[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %159 = llvm.insertvalue %157, %158[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %160 = llvm.insertvalue %12, %159[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %161 = llvm.insertvalue %11, %160[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %162 = llvm.insertvalue %7, %161[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %163 = llvm.insertvalue %10, %162[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %164 = llvm.insertvalue %11, %163[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %165 = llvm.insertvalue %10, %164[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %166 = llvm.insertvalue %9, %165[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %167 = llvm.inttoptr %36 : i64 to !llvm.ptr<6>
    %168 = llvm.insertvalue %167, %6[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %169 = llvm.insertvalue %167, %168[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %170 = llvm.insertvalue %12, %169[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %171 = llvm.insertvalue %11, %170[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %172 = llvm.insertvalue %7, %171[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %173 = llvm.insertvalue %10, %172[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %174 = llvm.insertvalue %11, %173[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %175 = llvm.insertvalue %10, %174[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %176 = llvm.insertvalue %9, %175[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %177 = llvm.inttoptr %35 : i64 to !llvm.ptr<6>
    %178 = llvm.insertvalue %177, %6[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %179 = llvm.insertvalue %177, %178[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %180 = llvm.insertvalue %12, %179[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %181 = llvm.insertvalue %11, %180[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %182 = llvm.insertvalue %7, %181[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %183 = llvm.insertvalue %10, %182[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %184 = llvm.insertvalue %11, %183[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %185 = llvm.insertvalue %10, %184[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %186 = llvm.insertvalue %9, %185[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %187 = llvm.inttoptr %34 : i64 to !llvm.ptr<6>
    %188 = llvm.insertvalue %187, %6[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %189 = llvm.insertvalue %187, %188[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %190 = llvm.insertvalue %12, %189[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %191 = llvm.insertvalue %11, %190[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %192 = llvm.insertvalue %7, %191[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %193 = llvm.insertvalue %10, %192[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %194 = llvm.insertvalue %11, %193[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %195 = llvm.insertvalue %10, %194[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %196 = llvm.insertvalue %9, %195[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %197 = llvm.inttoptr %33 : i64 to !llvm.ptr<6>
    %198 = llvm.insertvalue %197, %6[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %199 = llvm.insertvalue %197, %198[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %200 = llvm.insertvalue %12, %199[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %201 = llvm.insertvalue %11, %200[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %202 = llvm.insertvalue %7, %201[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %203 = llvm.insertvalue %10, %202[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %204 = llvm.insertvalue %11, %203[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %205 = llvm.insertvalue %10, %204[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %206 = llvm.insertvalue %9, %205[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %207 = llvm.alloca %9 x i64 : (i64) -> !llvm.ptr
    llvm.store %49, %207 : i64, !llvm.ptr
    %208 = llvm.inttoptr %13 : i64 to !llvm.ptr<6>
    %209 = llvm.insertvalue %208, %6[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %210 = llvm.insertvalue %208, %209[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %211 = llvm.insertvalue %12, %210[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %212 = llvm.insertvalue %11, %211[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %213 = llvm.insertvalue %7, %212[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %214 = llvm.insertvalue %10, %213[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %215 = llvm.insertvalue %11, %214[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %216 = llvm.insertvalue %10, %215[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %217 = llvm.insertvalue %9, %216[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %218 = llvm.inttoptr %14 : i64 to !llvm.ptr<6>
    %219 = llvm.insertvalue %218, %6[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %220 = llvm.insertvalue %218, %219[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %221 = llvm.insertvalue %12, %220[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %222 = llvm.insertvalue %11, %221[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %223 = llvm.insertvalue %7, %222[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %224 = llvm.insertvalue %10, %223[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %225 = llvm.insertvalue %11, %224[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %226 = llvm.insertvalue %10, %225[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %227 = llvm.insertvalue %9, %226[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %228 = llvm.alloca %9 x i64 : (i64) -> !llvm.ptr
    llvm.store %49, %228 : i64, !llvm.ptr
    %229 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %230 = "hivm.intr.hivm.SBITSET0"(%229, %5) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%230) : (i64) -> ()
    %231 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %232 = "hivm.intr.hivm.SBITSET1"(%231, %4) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%232) : (i64) -> ()
    %233 = "hivm.intr.hivm.GET.BLOCK.IDX"() : () -> i64
    %234 = llvm.trunc %233 : i64 to i32
    %235 = llvm.srem %234, %arg9  : i32
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.br ^bb1(%235 : i32)
  ^bb1(%236: i32):  // 2 preds: ^bb0, ^bb5
    %237 = llvm.icmp "slt" %236, %arg7 : i32
    llvm.cond_br %237, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %238 = llvm.load %228 : !llvm.ptr -> i64
    %239 = llvm.urem %238, %16  : i64
    %240 = llvm.icmp "eq" %239, %15 : i64
    %241 = llvm.select %240, %66, %58 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %242 = llvm.select %240, %82, %74 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %243 = llvm.select %240, %98, %90 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %244 = llvm.select %240, %114, %106 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %245 = llvm.select %240, %130, %122 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %246 = llvm.select %240, %146, %138 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %247 = llvm.trunc %239 : i64 to i1
    %248 = llvm.xor %247, %30  : i1
    %249 = llvm.zext %248 : i1 to i64
    %250 = llvm.mul %236, %23 : i32
    %251 = llvm.sext %250 : i32 to i64
    %252 = llvm.getelementptr %arg5[%251] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %253 = llvm.load %252 : !llvm.ptr<1> -> i32
    %254 = llvm.sext %253 : i32 to i64
    %255 = llvm.mul %254, %11 : i64
    "hivm.intr.hivm.WAIT.FLAG.REG"(%249) <{set_pipe = 1 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    %256 = llvm.extractvalue %241[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %257 = llvm.extractvalue %241[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %258 = llvm.extractvalue %241[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %259 = llvm.extractvalue %241[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %260 = llvm.extractvalue %241[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %261 = llvm.extractvalue %241[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %262 = llvm.extractvalue %241[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @load_gm_to_ubuf_2d_float(%arg6, %arg6, %255, %11, %10, %11, %9, %256, %257, %258, %259, %260, %261, %262, %19, %31, %12, %19) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i32, f32, i64, i32) -> ()
    %263 = llvm.mul %254, %11 : i64
    %264 = llvm.add %263, %10 : i64
    %265 = llvm.extractvalue %246[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %266 = llvm.extractvalue %246[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %267 = llvm.extractvalue %246[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %268 = llvm.extractvalue %246[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %269 = llvm.extractvalue %246[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %270 = llvm.extractvalue %246[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %271 = llvm.extractvalue %246[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @load_gm_to_ubuf_2d_float(%arg6, %arg6, %264, %11, %10, %11, %9, %265, %266, %267, %268, %269, %270, %271, %19, %31, %12, %19) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i32, f32, i64, i32) -> ()
    %272 = llvm.mul %236, %21 : i32
    %273 = llvm.sext %272 : i32 to i64
    %274 = llvm.add %273, %3 : i64
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 4 : i64}> : () -> ()
    %275 = llvm.extractvalue %245[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %276 = llvm.extractvalue %245[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %277 = llvm.extractvalue %245[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %278 = llvm.extractvalue %245[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %279 = llvm.extractvalue %245[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %280 = llvm.extractvalue %245[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %281 = llvm.extractvalue %245[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @load_gm_to_ubuf_2d_bfloat16_t(%arg4, %arg4, %274, %11, %10, %2, %9, %275, %276, %277, %278, %279, %280, %281, %19, %32, %12, %19) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i32, bf16, i64, i32) -> ()
    %282 = llvm.add %273, %1 : i64
    %283 = llvm.extractvalue %244[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %284 = llvm.extractvalue %244[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %285 = llvm.extractvalue %244[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %286 = llvm.extractvalue %244[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %287 = llvm.extractvalue %244[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %288 = llvm.extractvalue %244[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %289 = llvm.extractvalue %244[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @load_gm_to_ubuf_2d_bfloat16_t(%arg4, %arg4, %282, %11, %10, %2, %9, %283, %284, %285, %286, %287, %288, %289, %19, %32, %12, %19) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i32, bf16, i64, i32) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    %290 = llvm.inttoptr %24 : i64 to !llvm.ptr<6>
    %291 = llvm.inttoptr %25 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    %292 = llvm.extractvalue %245[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %293 = llvm.extractvalue %244[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @_welmv4_inplace_rope_contiguous_prefill_kernel_npu_fused_2_outlined_vf_0(%292, %293, %290, %291) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %294 = llvm.mul %236, %20 : i32
    %295 = llvm.sext %294 : i32 to i64
    %296 = llvm.inttoptr %26 : i64 to !llvm.ptr<6>
    %297 = llvm.inttoptr %27 : i64 to !llvm.ptr<6>
    %298 = llvm.extractvalue %241[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %299 = llvm.extractvalue %246[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %300 = llvm.extractvalue %243[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %301 = llvm.extractvalue %246[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %302 = llvm.extractvalue %241[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %303 = llvm.extractvalue %242[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %304 = llvm.extractvalue %241[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %305 = llvm.extractvalue %246[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @_welmv4_inplace_rope_contiguous_prefill_kernel_npu_fused_2_outlined_merged_merged_vf_0(%290, %298, %291, %299, %300, %290, %301, %291, %302, %303, %304, %305, %296, %297) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%249) <{set_pipe = 1 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    %306 = llvm.extractvalue %243[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %307 = llvm.extractvalue %243[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %308 = llvm.extractvalue %243[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %309 = llvm.extractvalue %243[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %310 = llvm.extractvalue %243[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %311 = llvm.extractvalue %243[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %312 = llvm.extractvalue %243[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @store_ubuf_to_gm_2d_bfloat16_t(%306, %307, %308, %309, %310, %311, %312, %arg4, %arg4, %274, %11, %10, %2, %9, %19) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i32) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 5 : i64}> : () -> ()
    %313 = llvm.extractvalue %242[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %314 = llvm.extractvalue %242[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %315 = llvm.extractvalue %242[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %316 = llvm.extractvalue %242[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %317 = llvm.extractvalue %242[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %318 = llvm.extractvalue %242[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %319 = llvm.extractvalue %242[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @store_ubuf_to_gm_2d_bfloat16_t(%313, %314, %315, %316, %317, %318, %319, %arg4, %arg4, %282, %11, %10, %2, %9, %19) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i32) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.br ^bb3(%19 : i32)
  ^bb3(%320: i32):  // 2 preds: ^bb2, ^bb4
    %321 = llvm.icmp "slt" %320, %18 : i32
    llvm.cond_br %321, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %322 = llvm.load %207 : !llvm.ptr -> i64
    %323 = llvm.urem %322, %16  : i64
    %324 = llvm.icmp "eq" %323, %15 : i64
    %325 = llvm.select %324, %166, %156 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)>
    %326 = llvm.select %324, %186, %176 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)>
    %327 = llvm.select %324, %206, %196 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)>
    %328 = llvm.select %324, %227, %217 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)>
    %329 = llvm.mul %320, %22 : i32
    %330 = llvm.sext %329 : i32 to i64
    %331 = llvm.add %330, %295 : i64
    %332 = llvm.add %331, %3 : i64
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 4 : i64}> : () -> ()
    %333 = llvm.extractvalue %328[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %334 = llvm.extractvalue %328[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %335 = llvm.extractvalue %328[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %336 = llvm.extractvalue %328[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %337 = llvm.extractvalue %328[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %338 = llvm.extractvalue %328[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %339 = llvm.extractvalue %328[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %340 = llvm.extractvalue %328[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %341 = llvm.extractvalue %328[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    llvm.call @load_gm_to_ubuf_3d_bfloat16_t(%arg3, %arg3, %332, %11, %7, %10, %0, %2, %9, %333, %334, %335, %336, %337, %338, %339, %340, %341, %19, %32, %12, %19) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, i64, i32, bf16, i64, i32) -> ()
    %342 = llvm.add %330, %295 : i64
    %343 = llvm.add %342, %1 : i64
    %344 = llvm.extractvalue %327[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %345 = llvm.extractvalue %327[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %346 = llvm.extractvalue %327[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %347 = llvm.extractvalue %327[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %348 = llvm.extractvalue %327[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %349 = llvm.extractvalue %327[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %350 = llvm.extractvalue %327[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %351 = llvm.extractvalue %327[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %352 = llvm.extractvalue %327[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    llvm.call @load_gm_to_ubuf_3d_bfloat16_t(%arg3, %arg3, %343, %11, %7, %10, %0, %2, %9, %344, %345, %346, %347, %348, %349, %350, %351, %352, %19, %32, %12, %19) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, i64, i32, bf16, i64, i32) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    %353 = llvm.inttoptr %28 : i64 to !llvm.ptr<6>
    %354 = llvm.inttoptr %29 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    %355 = llvm.extractvalue %328[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %356 = llvm.extractvalue %327[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    llvm.call @_welmv4_inplace_rope_contiguous_prefill_kernel_npu_fused_0_outlined_vf_0(%355, %356, %353, %354) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %357 = llvm.extractvalue %326[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %358 = llvm.extractvalue %325[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    llvm.call @_welmv4_inplace_rope_contiguous_prefill_kernel_npu_fused_0_outlined_merged_vf_0(%353, %296, %354, %297, %357, %353, %297, %354, %296, %358) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    %359 = llvm.extractvalue %326[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %360 = llvm.extractvalue %326[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %361 = llvm.extractvalue %326[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %362 = llvm.extractvalue %326[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %363 = llvm.extractvalue %326[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %364 = llvm.extractvalue %326[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %365 = llvm.extractvalue %326[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %366 = llvm.extractvalue %326[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %367 = llvm.extractvalue %326[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    llvm.call @store_ubuf_to_gm_3d_bfloat16_t(%359, %360, %361, %362, %363, %364, %365, %366, %367, %arg3, %arg3, %332, %11, %7, %10, %0, %2, %9, %19) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i64, i64, i32) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 5 : i64}> : () -> ()
    %368 = llvm.extractvalue %325[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %369 = llvm.extractvalue %325[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %370 = llvm.extractvalue %325[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %371 = llvm.extractvalue %325[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %372 = llvm.extractvalue %325[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %373 = llvm.extractvalue %325[3, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %374 = llvm.extractvalue %325[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %375 = llvm.extractvalue %325[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %376 = llvm.extractvalue %325[4, 2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    llvm.call @store_ubuf_to_gm_3d_bfloat16_t(%368, %369, %370, %371, %372, %373, %374, %375, %376, %arg3, %arg3, %343, %11, %7, %10, %0, %2, %9, %19) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i64, i64, i32) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 4 : i64}> : () -> ()
    %377 = llvm.add %322, %15 : i64
    llvm.store %377, %207 : i64, !llvm.ptr
    %378 = llvm.add %320, %17 overflow<nsw> : i32
    llvm.br ^bb3(%378 : i32)
  ^bb5:  // pred: ^bb3
    %379 = llvm.add %238, %15 : i64
    llvm.store %379, %228 : i64, !llvm.ptr
    %380 = llvm.add %236, %arg9 overflow<nsw> : i32
    llvm.br ^bb1(%380 : i32)
  ^bb6:  // pred: ^bb1
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    %381 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %382 = "hivm.intr.hivm.SBITSET1"(%381, %5) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%382) : (i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 6 : i64}> : () -> ()
    llvm.return
  }
}


bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
