// -----// IR Dump After AppendUsePrintDebugData (append-use-print-debug-data) //----- //
module attributes {dlti.target_system_spec = #dlti.target_system_spec<"NPU" : #hacc.target_device_spec<#dlti.dl_entry<"AI_CORE_COUNT", 28 : i32>, #dlti.dl_entry<"CUBE_CORE_COUNT", 28 : i32>, #dlti.dl_entry<"VECTOR_CORE_COUNT", 56 : i32>, #dlti.dl_entry<"UB_SIZE", 2031616 : i32>, #dlti.dl_entry<"L1_SIZE", 4194304 : i32>, #dlti.dl_entry<"L0A_SIZE", 524288 : i32>, #dlti.dl_entry<"L0B_SIZE", 524288 : i32>, #dlti.dl_entry<"L0C_SIZE", 2097152 : i32>, #dlti.dl_entry<"UB_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L1_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L0C_ALIGN_SIZE", 4096 : i32>, #dlti.dl_entry<"MINIMAL_D_CACHE_SIZE", 262144 : i32>, #dlti.dl_entry<"MAXIMUM_D_CACHE_SIZE", 983040 : i32>, #dlti.dl_entry<"ARCH", "dav-c310">>>, hacc.target = #hacc.target<"Ascend950PR_957b">, hivm.aic_bitcode = #hivm.aic_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.aic.c310.bc">, hivm.aiv_bitcode = #hivm.aiv_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.aiv.c310.bc">, hivm.host_bitcode = #hivm.host_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/host-a5.bc">, hivm.mix_aic_bitcode = #hivm.mix_aic_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.mix.aic.c310.bc">, hivm.mix_aiv_bitcode = #hivm.mix_aiv_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.mix.aiv.c310.bc">, hivm.module_core_type = #hivm.module_core_type<MIX>} {
  llvm.func @_swa_paged_decode_sink_kernel_outlined_merged_merged_vf_0(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(64 : i32) : i32
    %1 = llvm.mlir.constant(256 : i32) : i32
    %2 = llvm.mlir.constant(1 : i32) : i32
    %3 = llvm.mlir.constant(12 : i32) : i32
    %4 = llvm.mlir.constant(1.000000e+00 : f32) : f32
    %5 = llvm.mlir.constant(0 : i32) : i32
    %6 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %7 = llvm.mlir.constant(-1.07374182E+9 : f32) : f32
    %8 = llvm.mlir.constant(8 : i32) : i32
    %9 = llvm.mlir.constant(2 : i32) : i32
    %10 = llvm.mlir.constant(256 : index) : i64
    %11 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %12 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%7, %11, %2) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %13 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %14 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%6, %13, %2) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %15 = "hivm_regbaseintrins.intr.hivm.vci"(%5, %5) : (i32, i32) -> vector<64xi32>
    %16 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %17 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%5, %16, %2) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %18 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %19 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%4, %18, %2) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    llvm.br ^bb1(%5 : i32)
  ^bb1(%20: i32):  // 2 preds: ^bb0, ^bb5
    %21 = llvm.icmp "slt" %20, %3 : i32
    llvm.cond_br %21, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %22 = llvm.sext %20 : i32 to i64
    llvm.br ^bb3(%5 : i32)
  ^bb3(%23: i32):  // 2 preds: ^bb2, ^bb4
    %24 = llvm.icmp "slt" %23, %1 : i32
    llvm.cond_br %24, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %25 = llvm.sext %23 : i32 to i64
    %26 = llvm.mul %22, %10 : i64
    %27 = llvm.add %26, %25 : i64
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = llvm.getelementptr %arg0[%27] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%14, %29, %5, %9, %5, %28) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %30 = llvm.add %23, %0 overflow<nsw> : i32
    llvm.br ^bb3(%30 : i32)
  ^bb5:  // pred: ^bb3
    %31 = llvm.add %20, %2 overflow<nsw> : i32
    llvm.br ^bb1(%31 : i32)
  ^bb6:  // pred: ^bb1
    %32 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%3) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %33 = llvm.extractvalue %32[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%19, %arg1, %5, %9, %5, %33) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %34 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%12, %arg2, %5, %9, %5, %34) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %35 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%14, %arg3, %5, %9, %5, %35) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %36 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %37 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%17, %15, %36) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    %38 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64s32"(%37, %arg4, %5, %9, %5, %38) : (vector<64xi32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_merged_vf_3(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(16 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(12 : i32) : i32
    %4 = llvm.mlir.constant(2 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(1114112 : i32) : i32
    %7 = llvm.mlir.constant(64 : index) : i64
    %8 = llvm.mlir.constant(16 : index) : i64
    %9 = llvm.mlir.constant(272 : index) : i64
    %10 = llvm.mlir.constant(0 : index) : i64
    %11 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%3) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %12 = llvm.extractvalue %11[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %13 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %14 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %15 = "hivm_regbaseintrins.intr.hivm.vsub.s.x"(%13, %14, %12) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%15, %arg2, %2, %4, %2, %12) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.br ^bb1(%2 : i32)
  ^bb1(%16: i32):  // 2 preds: ^bb0, ^bb2
    %17 = llvm.icmp "slt" %16, %1 : i32
    llvm.cond_br %17, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %16 : i32 to i64
    %19 = llvm.mul %18, %7 : i64
    %20 = llvm.getelementptr %arg3[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %21 = llvm.mul %10, %7 : i64
    %22 = llvm.add %21, %10 : i64
    %23 = llvm.getelementptr %20[%22] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %24 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%23, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %25 = llvm.mul %18, %8 : i64
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%5, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %27 = llvm.getelementptr %arg4[%25] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %28 = llvm.mul %10, %9 : i64
    %29 = llvm.add %28, %10 : i64
    %30 = llvm.getelementptr %27[%29] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vsstb.v128bf16"(%24, %30, %6, %2, %26) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, vector<256xi1>) -> ()
    %31 = llvm.add %16, %0 overflow<nsw> : i32
    llvm.br ^bb1(%31 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_merged_vf_2(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(16 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(12 : i32) : i32
    %4 = llvm.mlir.constant(2 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(1114112 : i32) : i32
    %7 = llvm.mlir.constant(64 : index) : i64
    %8 = llvm.mlir.constant(16 : index) : i64
    %9 = llvm.mlir.constant(272 : index) : i64
    %10 = llvm.mlir.constant(0 : index) : i64
    %11 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%3) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %12 = llvm.extractvalue %11[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %13 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %14 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %15 = "hivm_regbaseintrins.intr.hivm.vsub.s.x"(%13, %14, %12) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%15, %arg2, %2, %4, %2, %12) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.br ^bb1(%2 : i32)
  ^bb1(%16: i32):  // 2 preds: ^bb0, ^bb2
    %17 = llvm.icmp "slt" %16, %1 : i32
    llvm.cond_br %17, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %16 : i32 to i64
    %19 = llvm.mul %18, %7 : i64
    %20 = llvm.getelementptr %arg3[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %21 = llvm.mul %10, %7 : i64
    %22 = llvm.add %21, %10 : i64
    %23 = llvm.getelementptr %20[%22] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %24 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%23, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %25 = llvm.mul %18, %8 : i64
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%5, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %27 = llvm.getelementptr %arg4[%25] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %28 = llvm.mul %10, %9 : i64
    %29 = llvm.add %28, %10 : i64
    %30 = llvm.getelementptr %27[%29] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vsstb.v128bf16"(%24, %30, %6, %2, %26) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, vector<256xi1>) -> ()
    %31 = llvm.add %16, %0 overflow<nsw> : i32
    llvm.br ^bb1(%31 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_0(%arg0: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(0xFF800000 : f32) : f32
    %1 = llvm.mlir.constant(8 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(1 : i32) : i32
    %4 = llvm.mlir.constant(12 : i32) : i32
    %5 = llvm.mlir.constant(2 : i32) : i32
    %6 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %7 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%0, %6, %3) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %8 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%4) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %9 = llvm.extractvalue %8[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%7, %arg0, %2, %5, %2, %9) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_1(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i32, %arg3: i32, %arg4: i32, %arg5: f32, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>, %arg8: !llvm.ptr<6>, %arg9: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(12 : i32) : i32
    %2 = llvm.mlir.constant(511 : i32) : i32
    %3 = llvm.mlir.constant(0 : i32) : i32
    %4 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %5 = llvm.mlir.constant(-1.07374182E+9 : f32) : f32
    %6 = llvm.mlir.constant(8 : i32) : i32
    %7 = llvm.mlir.constant(2 : i32) : i32
    %8 = llvm.mlir.constant(4 : i32) : i32
    %9 = llvm.mlir.undef : !llvm.ptr<6>
    %10 = llvm.mlir.constant(64 : index) : i64
    %11 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %12 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%5, %11, %0) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %13 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %14 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%4, %13, %0) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %15 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %16 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%3, %15, %0) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    llvm.br ^bb1(%3 : i32)
  ^bb1(%17: i32):  // 2 preds: ^bb0, ^bb2
    %18 = llvm.icmp "slt" %17, %1 : i32
    llvm.cond_br %18, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %19 = llvm.sext %17 : i32 to i64
    %20 = llvm.mul %19, %10 : i64
    %21 = llvm.getelementptr %arg0[%20] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %22 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%21, %3, %3, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %23 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64s32"(%arg1, %3, %3, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xi32>
    %24 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg2) : (i32) -> vector<64xi32>
    %25 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %26 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%23, %24, %25) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<256xi1>
    %27 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg3) : (i32) -> vector<64xi32>
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%27, %23, %28) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    %30 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %31 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%29, %2, %30) : (vector<64xi32>, i32, vector<256xi1>) -> vector<64xi32>
    %32 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg4) : (i32) -> vector<64xi32>
    %33 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %34 = "hivm_regbaseintrins.intr.hivm.vcmp.ge.s.z"(%31, %32, %33) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<256xi1>
    %35 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %36 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%29, %16, %35) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<256xi1>
    %37 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %38 = "hivm_regbaseintrins.intr.hivm.por.z"(%36, %34, %37) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %39 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %40 = "hivm_regbaseintrins.intr.hivm.pand.z"(%38, %26, %39) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %41 = "hivm_regbaseintrins.intr.hivm.vsel"(%14, %12, %40) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %42 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %43 = "hivm_regbaseintrins.intr.hivm.vmuls.s.x"(%22, %arg5, %42) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %44 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %45 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%43, %41, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %46 = llvm.mul %19, %10 : i64
    %47 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %48 = llvm.getelementptr %arg6[%46] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%45, %48, %3, %7, %3, %47) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %49 = llvm.add %17, %0 overflow<nsw> : i32
    llvm.br ^bb1(%49 : i32)
  ^bb3:  // pred: ^bb1
    %50 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb4(%3, %50, %9 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb4(%51: i32, %52: vector<32xi8>, %53: !llvm.ptr<6>):  // 2 preds: ^bb3, ^bb5
    %54 = llvm.icmp "slt" %51, %1 : i32
    llvm.cond_br %54, ^bb5, ^bb6
  ^bb5:  // pred: ^bb4
    %55 = llvm.sext %51 : i32 to i64
    %56 = llvm.mul %55, %10 : i64
    %57 = llvm.getelementptr %arg6[%56] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %58 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%57, %3, %3, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %59 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %60 = "hivm_regbaseintrins.intr.hivm.vcmax.s.x"(%58, %59) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %61 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %62 = llvm.getelementptr %arg7[%55] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %63 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%60, %62, %8, %52) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %64 = llvm.extractvalue %63[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %65 = llvm.extractvalue %63[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %66 = llvm.add %51, %0 overflow<nsw> : i32
    llvm.br ^bb4(%66, %64, %65 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb6:  // pred: ^bb4
    "hivm_regbaseintrins.intr.hivm.vstas"(%52, %53, %3, %3) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %67 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%1) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %68 = llvm.extractvalue %67[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %69 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg8, %3, %3, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %70 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg7, %3, %3, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %71 = "hivm_regbaseintrins.intr.hivm.vmax.s.x"(%69, %70, %68) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%71, %arg9, %3, %7, %3, %68) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_2(%arg0: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(9 : i32) : i32
    %1 = llvm.mlir.constant(0.000000e+00 : bf16) : bf16
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(16 : i32) : i32
    %4 = llvm.mlir.constant(1 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(64 : index) : i64
    %7 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%0, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %8 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%1, %7, %4) : (bf16, vector<256xi1>, i32) -> vector<128xbf16>
    llvm.br ^bb1(%2 : i32)
  ^bb1(%9: i32):  // 2 preds: ^bb0, ^bb2
    %10 = llvm.icmp "slt" %9, %3 : i32
    llvm.cond_br %10, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %11 = llvm.sext %9 : i32 to i64
    %12 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%5, %2) {mask_bit_width = 16 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %13 = llvm.mul %11, %6 : i64
    %14 = llvm.getelementptr %arg0[%13] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%8, %14, %2, %4, %2, %12) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %15 = llvm.add %9, %4 overflow<nsw> : i32
    llvm.br ^bb1(%15 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_3(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(12 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %4 = llvm.mlir.constant(3 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(7 : i32) : i32
    %7 = llvm.mlir.constant(4 : i32) : i32
    %8 = llvm.mlir.undef : !llvm.ptr<6>
    %9 = llvm.mlir.constant(64 : index) : i64
    %10 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %10, %8 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%11: i32, %12: vector<32xi8>, %13: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %14 = llvm.icmp "slt" %11, %1 : i32
    llvm.cond_br %14, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %15 = llvm.sext %11 : i32 to i64
    %16 = llvm.mul %15, %9 : i64
    %17 = llvm.getelementptr %arg0[%16] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %18 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%17, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %19 = llvm.getelementptr %arg1[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %20 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%19, %2, %4, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%18, %20, %21, %2) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %23 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %24 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%22, %23, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %25 = llvm.mul %15, %9 : i64
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %27 = llvm.getelementptr %arg2[%25] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%24, %27, %2, %6, %2, %26) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%22, %3, %28) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %30 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %31 = "hivm_regbaseintrins.intr.hivm.vcadd.s.x"(%29, %30) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %32 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %33 = llvm.getelementptr %arg3[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %34 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%31, %33, %7, %12) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %35 = llvm.extractvalue %34[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %36 = llvm.extractvalue %34[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %37 = llvm.add %11, %0 overflow<nsw> : i32
    llvm.br ^bb1(%37, %35, %36 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%12, %13, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_6(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(12 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %4 = llvm.extractvalue %3[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %5 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %6 = "hivm_regbaseintrins.intr.hivm.vexp.x"(%5, %4) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%6, %arg1, %1, %2, %1, %4) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_7(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(64 : i32) : i32
    %1 = llvm.mlir.constant(256 : i32) : i32
    %2 = llvm.mlir.constant(1 : i32) : i32
    %3 = llvm.mlir.constant(12 : i32) : i32
    %4 = llvm.mlir.constant(0 : i32) : i32
    %5 = llvm.mlir.constant(2 : i32) : i32
    %6 = llvm.mlir.constant(3 : i32) : i32
    %7 = llvm.mlir.constant(8 : i32) : i32
    %8 = llvm.mlir.constant(256 : index) : i64
    %9 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%3) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %10 = llvm.extractvalue %9[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %11 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %12 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %13 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg2, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %14 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%11, %12, %10) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %15 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%14, %13, %10) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%15, %arg3, %4, %5, %4, %10) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.br ^bb1(%4 : i32)
  ^bb1(%16: i32):  // 2 preds: ^bb0, ^bb5
    %17 = llvm.icmp "slt" %16, %3 : i32
    llvm.cond_br %17, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %16 : i32 to i64
    llvm.br ^bb3(%4 : i32)
  ^bb3(%19: i32):  // 2 preds: ^bb2, ^bb4
    %20 = llvm.icmp "slt" %19, %1 : i32
    llvm.cond_br %20, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %21 = llvm.sext %19 : i32 to i64
    %22 = llvm.mul %18, %8 : i64
    %23 = llvm.add %22, %21 : i64
    %24 = llvm.getelementptr %arg4[%23] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %25 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%24, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %26 = llvm.mul %18, %8 : i64
    %27 = llvm.add %26, %21 : i64
    %28 = llvm.getelementptr %arg5[%27] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %29 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%28, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %30 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %31 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%30, %4, %6, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %32 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %33 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%29, %31, %32) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %34 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %35 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%25, %33, %34) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %36 = llvm.mul %18, %8 : i64
    %37 = llvm.add %36, %21 : i64
    %38 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %39 = llvm.getelementptr %arg6[%37] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%35, %39, %4, %5, %4, %38) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %40 = llvm.add %19, %0 overflow<nsw> : i32
    llvm.br ^bb3(%40 : i32)
  ^bb5:  // pred: ^bb3
    %41 = llvm.add %16, %2 overflow<nsw> : i32
    llvm.br ^bb1(%41 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_8(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: f32, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(0 : i32) : i32
    %1 = llvm.mlir.constant(12 : i32) : i32
    %2 = llvm.mlir.constant(1 : i32) : i32
    %3 = llvm.mlir.constant(8 : i32) : i32
    %4 = llvm.mlir.constant(2 : i32) : i32
    %5 = llvm.mlir.constant(4 : i32) : i32
    %6 = llvm.mlir.undef : !llvm.ptr<6>
    %7 = llvm.mlir.constant(64 : index) : i64
    %8 = llvm.mlir.constant(0 : index) : i64
    llvm.br ^bb1(%0 : i32)
  ^bb1(%9: i32):  // 2 preds: ^bb0, ^bb2
    %10 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %10, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %11 = llvm.sext %9 : i32 to i64
    %12 = llvm.mul %11, %7 : i64
    %13 = llvm.getelementptr %arg0[%12] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %14 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%13, %0, %0, %0) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %15 = llvm.mul %8, %7 : i64
    %16 = llvm.add %15, %8 : i64
    %17 = llvm.getelementptr %arg1[%16] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %18 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%17, %0, %0, %0) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %19 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %20 = "hivm_regbaseintrins.intr.hivm.vmuls.s.x"(%14, %arg2, %19) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%20, %18, %21) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %23 = llvm.mul %11, %7 : i64
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = llvm.getelementptr %arg3[%23] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%22, %25, %0, %4, %0, %24) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %26 = llvm.add %9, %2 overflow<nsw> : i32
    llvm.br ^bb1(%26 : i32)
  ^bb3:  // pred: ^bb1
    %27 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb4(%0, %27, %6 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb4(%28: i32, %29: vector<32xi8>, %30: !llvm.ptr<6>):  // 2 preds: ^bb3, ^bb5
    %31 = llvm.icmp "slt" %28, %1 : i32
    llvm.cond_br %31, ^bb5, ^bb6
  ^bb5:  // pred: ^bb4
    %32 = llvm.sext %28 : i32 to i64
    %33 = llvm.mul %32, %7 : i64
    %34 = llvm.getelementptr %arg3[%33] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %35 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%34, %0, %0, %0) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %36 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %37 = "hivm_regbaseintrins.intr.hivm.vcmax.s.x"(%35, %36) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %38 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %39 = llvm.getelementptr %arg4[%32] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %40 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%37, %39, %5, %29) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %41 = llvm.extractvalue %40[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %42 = llvm.extractvalue %40[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %43 = llvm.add %28, %2 overflow<nsw> : i32
    llvm.br ^bb4(%43, %41, %42 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb6:  // pred: ^bb4
    "hivm_regbaseintrins.intr.hivm.vstas"(%29, %30, %0, %0) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %44 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%1) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %45 = llvm.extractvalue %44[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %46 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg5, %0, %0, %0) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %47 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg4, %0, %0, %0) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %48 = "hivm_regbaseintrins.intr.hivm.vmax.s.x"(%46, %47, %45) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%48, %arg6, %0, %4, %0, %45) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_9(%arg0: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(9 : i32) : i32
    %1 = llvm.mlir.constant(0.000000e+00 : bf16) : bf16
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(16 : i32) : i32
    %4 = llvm.mlir.constant(1 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(64 : index) : i64
    %7 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%0, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %8 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%1, %7, %4) : (bf16, vector<256xi1>, i32) -> vector<128xbf16>
    llvm.br ^bb1(%2 : i32)
  ^bb1(%9: i32):  // 2 preds: ^bb0, ^bb2
    %10 = llvm.icmp "slt" %9, %3 : i32
    llvm.cond_br %10, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %11 = llvm.sext %9 : i32 to i64
    %12 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%5, %2) {mask_bit_width = 16 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %13 = llvm.mul %11, %6 : i64
    %14 = llvm.getelementptr %arg0[%13] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%8, %14, %2, %4, %2, %12) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %15 = llvm.add %9, %4 overflow<nsw> : i32
    llvm.br ^bb1(%15 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_10(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(12 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %4 = llvm.mlir.constant(3 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(7 : i32) : i32
    %7 = llvm.mlir.constant(4 : i32) : i32
    %8 = llvm.mlir.undef : !llvm.ptr<6>
    %9 = llvm.mlir.constant(64 : index) : i64
    %10 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %10, %8 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%11: i32, %12: vector<32xi8>, %13: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %14 = llvm.icmp "slt" %11, %1 : i32
    llvm.cond_br %14, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %15 = llvm.sext %11 : i32 to i64
    %16 = llvm.mul %15, %9 : i64
    %17 = llvm.getelementptr %arg0[%16] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %18 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%17, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %19 = llvm.getelementptr %arg1[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %20 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%19, %2, %4, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%18, %20, %21, %2) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %23 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %24 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%22, %23, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %25 = llvm.mul %15, %9 : i64
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %27 = llvm.getelementptr %arg2[%25] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%24, %27, %2, %6, %2, %26) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%22, %3, %28) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %30 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %31 = "hivm_regbaseintrins.intr.hivm.vcadd.s.x"(%29, %30) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %32 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %33 = llvm.getelementptr %arg3[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %34 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%31, %33, %7, %12) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %35 = llvm.extractvalue %34[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %36 = llvm.extractvalue %34[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %37 = llvm.add %11, %0 overflow<nsw> : i32
    llvm.br ^bb1(%37, %35, %36 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%12, %13, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_13(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(12 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %4 = llvm.extractvalue %3[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %5 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %6 = "hivm_regbaseintrins.intr.hivm.vexp.x"(%5, %4) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%6, %arg1, %1, %2, %1, %4) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_14(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(64 : i32) : i32
    %1 = llvm.mlir.constant(256 : i32) : i32
    %2 = llvm.mlir.constant(1 : i32) : i32
    %3 = llvm.mlir.constant(12 : i32) : i32
    %4 = llvm.mlir.constant(0 : i32) : i32
    %5 = llvm.mlir.constant(2 : i32) : i32
    %6 = llvm.mlir.constant(3 : i32) : i32
    %7 = llvm.mlir.constant(8 : i32) : i32
    %8 = llvm.mlir.constant(256 : index) : i64
    %9 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%3) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %10 = llvm.extractvalue %9[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %11 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %12 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %13 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg2, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %14 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%11, %12, %10) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %15 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%14, %13, %10) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%15, %arg3, %4, %5, %4, %10) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.br ^bb1(%4 : i32)
  ^bb1(%16: i32):  // 2 preds: ^bb0, ^bb5
    %17 = llvm.icmp "slt" %16, %3 : i32
    llvm.cond_br %17, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %16 : i32 to i64
    llvm.br ^bb3(%4 : i32)
  ^bb3(%19: i32):  // 2 preds: ^bb2, ^bb4
    %20 = llvm.icmp "slt" %19, %1 : i32
    llvm.cond_br %20, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %21 = llvm.sext %19 : i32 to i64
    %22 = llvm.mul %18, %8 : i64
    %23 = llvm.add %22, %21 : i64
    %24 = llvm.getelementptr %arg4[%23] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %25 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%24, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %26 = llvm.mul %18, %8 : i64
    %27 = llvm.add %26, %21 : i64
    %28 = llvm.getelementptr %arg5[%27] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %29 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%28, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %30 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %31 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%30, %4, %6, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %32 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %33 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%29, %31, %32) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %34 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %35 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%25, %33, %34) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %36 = llvm.mul %18, %8 : i64
    %37 = llvm.add %36, %21 : i64
    %38 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %39 = llvm.getelementptr %arg6[%37] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%35, %39, %4, %5, %4, %38) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %40 = llvm.add %19, %0 overflow<nsw> : i32
    llvm.br ^bb3(%40 : i32)
  ^bb5:  // pred: ^bb3
    %41 = llvm.add %16, %2 overflow<nsw> : i32
    llvm.br ^bb1(%41 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_15(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(12 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(256 : i32) : i32
    %4 = llvm.mlir.constant(64 : i32) : i32
    %5 = llvm.mlir.constant(3 : i32) : i32
    %6 = llvm.mlir.constant(8 : i32) : i32
    %7 = llvm.mlir.constant(2 : i32) : i32
    %8 = llvm.mlir.constant(256 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%9: i32):  // 2 preds: ^bb0, ^bb5
    %10 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %10, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %11 = llvm.sext %9 : i32 to i64
    llvm.br ^bb3(%2 : i32)
  ^bb3(%12: i32):  // 2 preds: ^bb2, ^bb4
    %13 = llvm.icmp "slt" %12, %3 : i32
    llvm.cond_br %13, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %14 = llvm.sext %12 : i32 to i64
    %15 = llvm.mul %11, %8 : i64
    %16 = llvm.add %15, %14 : i64
    %17 = llvm.getelementptr %arg1[%16] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %18 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%17, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %19 = llvm.getelementptr %arg0[%11] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %20 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%19, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.vdiv.s.x"(%18, %20, %21) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %23 = llvm.mul %11, %8 : i64
    %24 = llvm.add %23, %14 : i64
    %25 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %26 = llvm.getelementptr %arg2[%24] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%22, %26, %2, %7, %2, %25) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %27 = llvm.add %12, %4 overflow<nsw> : i32
    llvm.br ^bb3(%27 : i32)
  ^bb5:  // pred: ^bb3
    %28 = llvm.add %9, %0 overflow<nsw> : i32
    llvm.br ^bb1(%28 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_16(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(12 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(256 : i32) : i32
    %4 = llvm.mlir.constant(64 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(7 : i32) : i32
    %7 = llvm.mlir.constant(256 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%8: i32):  // 2 preds: ^bb0, ^bb5
    %9 = llvm.icmp "slt" %8, %1 : i32
    llvm.cond_br %9, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %10 = llvm.sext %8 : i32 to i64
    llvm.br ^bb3(%2 : i32)
  ^bb3(%11: i32):  // 2 preds: ^bb2, ^bb4
    %12 = llvm.icmp "slt" %11, %3 : i32
    llvm.cond_br %12, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %13 = llvm.sext %11 : i32 to i64
    %14 = llvm.mul %10, %7 : i64
    %15 = llvm.add %14, %13 : i64
    %16 = llvm.getelementptr %arg0[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %17 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%16, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %18 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %19 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%17, %18, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %20 = llvm.mul %10, %7 : i64
    %21 = llvm.add %20, %13 : i64
    %22 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %23 = llvm.getelementptr %arg1[%21] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%19, %23, %2, %6, %2, %22) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %24 = llvm.add %11, %4 overflow<nsw> : i32
    llvm.br ^bb3(%24 : i32)
  ^bb5:  // pred: ^bb3
    %25 = llvm.add %8, %0 overflow<nsw> : i32
    llvm.br ^bb1(%25 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_mix_aic(%arg0: i64, %arg1: !llvm.ptr<1>, %arg2: !llvm.ptr<1>, %arg3: !llvm.ptr<1>, %arg4: !llvm.ptr<1>, %arg5: !llvm.ptr<1>, %arg6: !llvm.ptr<1>, %arg7: !llvm.ptr<1>, %arg8: !llvm.ptr<1>, %arg9: !llvm.ptr<1>, %arg10: i32, %arg11: i32, %arg12: i32, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32, %arg17: i32, %arg18: i32, %arg19: i32, %arg20: i32, %arg21: i32, %arg22: f32, %arg23: i32, %arg24: i32, %arg25: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, hivm.vf_mode = #hivm.vf_mode<SIMD>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, mix_mode = "mix", parallel_mode = "simd"} {
    %0 = llvm.mlir.constant(15 : index) : i64
    %1 = llvm.mlir.constant(-1 : index) : i64
    %2 = llvm.mlir.constant(48 : i64) : i64
    %3 = llvm.mlir.constant(60 : i64) : i64
    %4 = llvm.mlir.constant(16384 : index) : i64
    %5 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %6 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %7 = llvm.mlir.constant(1024 : index) : i64
    %8 = llvm.mlir.constant(1 : index) : i64
    %9 = llvm.mlir.constant(4 : index) : i64
    %10 = llvm.mlir.constant(0 : index) : i64
    %11 = llvm.mlir.constant(0 : i8) : i8
    %12 = llvm.mlir.constant(false) : i1
    %13 = llvm.mlir.constant(1.000000e+00 : f32) : f32
    %14 = llvm.mlir.constant(39424 : i64) : i64
    %15 = llvm.mlir.constant(36352 : i64) : i64
    %16 = llvm.mlir.constant(75776 : i64) : i64
    %17 = llvm.mlir.constant(16192 : i64) : i64
    %18 = llvm.mlir.constant(13120 : i64) : i64
    %19 = llvm.mlir.constant(8192 : i64) : i64
    %20 = llvm.mlir.constant(16 : index) : i64
    %21 = llvm.mlir.constant(1024 : i64) : i64
    %22 = llvm.mlir.constant(0 : i64) : i64
    %23 = llvm.mlir.constant(0 : i32) : i32
    %24 = llvm.mlir.constant(2 : i32) : i32
    %25 = llvm.mlir.constant(12 : index) : i64
    %26 = llvm.mlir.constant(512 : i32) : i32
    %27 = llvm.mlir.constant(63 : i32) : i32
    %28 = llvm.mlir.constant(64 : i32) : i32
    %29 = llvm.mlir.constant(12 : i32) : i32
    %30 = llvm.mlir.constant(0.000000e+00 : bf16) : bf16
    %31 = llvm.mlir.constant(64 : index) : i64
    %32 = llvm.mlir.constant(256 : index) : i64
    %33 = llvm.mlir.constant(4 : i64) : i64
    %34 = llvm.mlir.constant(1028 : i64) : i64
    %35 = llvm.mlir.constant(8 : i64) : i64
    %36 = llvm.mlir.constant(1032 : i64) : i64
    %37 = llvm.mlir.constant(12 : i64) : i64
    %38 = llvm.mlir.constant(1036 : i64) : i64
    %39 = llvm.mlir.constant(16 : i64) : i64
    %40 = llvm.mlir.constant(1040 : i64) : i64
    %41 = llvm.mlir.constant(20 : i64) : i64
    %42 = llvm.mlir.constant(1044 : i64) : i64
    %43 = llvm.mlir.constant(3 : i32) : i32
    %44 = llvm.mlir.constant(1 : i32) : i32
    %45 = llvm.mlir.constant(true) : i1
    %46 = llvm.mlir.constant(2 : i64) : i64
    %47 = llvm.mlir.constant(1 : i64) : i64
    %48 = llvm.mlir.constant(3 : i64) : i64
    %49 = llvm.mlir.constant(5 : i64) : i64
    %50 = llvm.mlir.constant(6 : i64) : i64
    %51 = llvm.mlir.constant(-1 : i64) : i64
    %52 = llvm.mlir.constant(217088 : i64) : i64
    %53 = llvm.mlir.constant(77824 : i64) : i64
    %54 = llvm.mlir.constant(61440 : i64) : i64
    %55 = llvm.mlir.constant(20480 : i64) : i64
    %56 = llvm.mlir.constant(249856 : i64) : i64
    %57 = llvm.mlir.constant(110592 : i64) : i64
    %58 = llvm.mlir.constant(65536 : i64) : i64
    %59 = llvm.mlir.constant(24576 : i64) : i64
    %60 = llvm.mlir.constant(151552 : i64) : i64
    %61 = llvm.mlir.constant(10240 : i64) : i64
    %62 = llvm.mlir.constant(184320 : i64) : i64
    %63 = llvm.mlir.constant(43008 : i64) : i64
    %64 = llvm.mlir.constant(45056 : i64) : i64
    %65 = llvm.mlir.constant(4096 : i64) : i64
    %66 = llvm.mlir.constant(143360 : i64) : i64
    %67 = llvm.mlir.constant(40960 : i64) : i64
    %68 = llvm.inttoptr %22 : i64 to !llvm.ptr<5>
    %69 = llvm.insertvalue %68, %6[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %70 = llvm.insertvalue %68, %69[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %71 = llvm.insertvalue %10, %70[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %72 = llvm.insertvalue %9, %71[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %73 = llvm.insertvalue %8, %72[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %74 = llvm.insertvalue %20, %73[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %75 = llvm.insertvalue %20, %74[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %76 = llvm.insertvalue %32, %75[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %77 = llvm.insertvalue %32, %76[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %78 = llvm.insertvalue %20, %77[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %79 = llvm.insertvalue %8, %78[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %80 = llvm.inttoptr %67 : i64 to !llvm.ptr<5>
    %81 = llvm.insertvalue %80, %6[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %82 = llvm.insertvalue %80, %81[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %83 = llvm.insertvalue %10, %82[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %84 = llvm.insertvalue %9, %83[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %85 = llvm.insertvalue %8, %84[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %86 = llvm.insertvalue %20, %85[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %87 = llvm.insertvalue %20, %86[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %88 = llvm.insertvalue %32, %87[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %89 = llvm.insertvalue %32, %88[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %90 = llvm.insertvalue %20, %89[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %91 = llvm.insertvalue %8, %90[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %92 = llvm.inttoptr %22 : i64 to !llvm.ptr<2>
    %93 = llvm.insertvalue %92, %5[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %94 = llvm.insertvalue %92, %93[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %95 = llvm.insertvalue %10, %94[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %96 = llvm.insertvalue %20, %95[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %97 = llvm.insertvalue %8, %96[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %98 = llvm.insertvalue %20, %97[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %99 = llvm.insertvalue %20, %98[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %100 = llvm.insertvalue %32, %99[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %101 = llvm.insertvalue %32, %100[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %102 = llvm.insertvalue %20, %101[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %103 = llvm.insertvalue %8, %102[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %104 = llvm.inttoptr %66 : i64 to !llvm.ptr<2>
    %105 = llvm.insertvalue %104, %5[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %106 = llvm.insertvalue %104, %105[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %107 = llvm.insertvalue %10, %106[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %108 = llvm.insertvalue %20, %107[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %109 = llvm.insertvalue %8, %108[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %110 = llvm.insertvalue %20, %109[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %111 = llvm.insertvalue %20, %110[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %112 = llvm.insertvalue %32, %111[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %113 = llvm.insertvalue %32, %112[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %114 = llvm.insertvalue %20, %113[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %115 = llvm.insertvalue %8, %114[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %116 = llvm.inttoptr %65 : i64 to !llvm.ptr<5>
    %117 = llvm.insertvalue %116, %6[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %118 = llvm.insertvalue %116, %117[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %119 = llvm.insertvalue %10, %118[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %120 = llvm.insertvalue %20, %119[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %121 = llvm.insertvalue %8, %120[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %122 = llvm.insertvalue %20, %121[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %123 = llvm.insertvalue %20, %122[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %124 = llvm.insertvalue %32, %123[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %125 = llvm.insertvalue %32, %124[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %126 = llvm.insertvalue %20, %125[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %127 = llvm.insertvalue %8, %126[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %128 = llvm.inttoptr %64 : i64 to !llvm.ptr<5>
    %129 = llvm.insertvalue %128, %6[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %130 = llvm.insertvalue %128, %129[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %131 = llvm.insertvalue %10, %130[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %132 = llvm.insertvalue %20, %131[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %133 = llvm.insertvalue %8, %132[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %134 = llvm.insertvalue %20, %133[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %135 = llvm.insertvalue %20, %134[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %136 = llvm.insertvalue %32, %135[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %137 = llvm.insertvalue %32, %136[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %138 = llvm.insertvalue %20, %137[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %139 = llvm.insertvalue %8, %138[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %140 = llvm.inttoptr %63 : i64 to !llvm.ptr<2>
    %141 = llvm.insertvalue %140, %5[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %142 = llvm.insertvalue %140, %141[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %143 = llvm.insertvalue %10, %142[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %144 = llvm.insertvalue %20, %143[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %145 = llvm.insertvalue %9, %144[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %146 = llvm.insertvalue %20, %145[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %147 = llvm.insertvalue %20, %146[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %148 = llvm.insertvalue %7, %147[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %149 = llvm.insertvalue %32, %148[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %150 = llvm.insertvalue %20, %149[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %151 = llvm.insertvalue %8, %150[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %152 = llvm.inttoptr %62 : i64 to !llvm.ptr<2>
    %153 = llvm.insertvalue %152, %5[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %154 = llvm.insertvalue %152, %153[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %155 = llvm.insertvalue %10, %154[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %156 = llvm.insertvalue %20, %155[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %157 = llvm.insertvalue %9, %156[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %158 = llvm.insertvalue %20, %157[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %159 = llvm.insertvalue %20, %158[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %160 = llvm.insertvalue %7, %159[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %161 = llvm.insertvalue %32, %160[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %162 = llvm.insertvalue %20, %161[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %163 = llvm.insertvalue %8, %162[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %164 = llvm.inttoptr %61 : i64 to !llvm.ptr<2>
    %165 = llvm.insertvalue %164, %5[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %166 = llvm.insertvalue %164, %165[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %167 = llvm.insertvalue %10, %166[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %168 = llvm.insertvalue %20, %167[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %169 = llvm.insertvalue %9, %168[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %170 = llvm.insertvalue %20, %169[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %171 = llvm.insertvalue %20, %170[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %172 = llvm.insertvalue %7, %171[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %173 = llvm.insertvalue %32, %172[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %174 = llvm.insertvalue %20, %173[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %175 = llvm.insertvalue %8, %174[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %176 = llvm.inttoptr %60 : i64 to !llvm.ptr<2>
    %177 = llvm.insertvalue %176, %5[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %178 = llvm.insertvalue %176, %177[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %179 = llvm.insertvalue %10, %178[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %180 = llvm.insertvalue %20, %179[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %181 = llvm.insertvalue %9, %180[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %182 = llvm.insertvalue %20, %181[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %183 = llvm.insertvalue %20, %182[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %184 = llvm.insertvalue %7, %183[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %185 = llvm.insertvalue %32, %184[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %186 = llvm.insertvalue %20, %185[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %187 = llvm.insertvalue %8, %186[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %188 = llvm.inttoptr %59 : i64 to !llvm.ptr<5>
    %189 = llvm.insertvalue %188, %6[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %190 = llvm.insertvalue %188, %189[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %191 = llvm.insertvalue %10, %190[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %192 = llvm.insertvalue %20, %191[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %193 = llvm.insertvalue %8, %192[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %194 = llvm.insertvalue %20, %193[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %195 = llvm.insertvalue %20, %194[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %196 = llvm.insertvalue %32, %195[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %197 = llvm.insertvalue %32, %196[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %198 = llvm.insertvalue %20, %197[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %199 = llvm.insertvalue %8, %198[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %200 = llvm.inttoptr %58 : i64 to !llvm.ptr<5>
    %201 = llvm.insertvalue %200, %6[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %202 = llvm.insertvalue %200, %201[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %203 = llvm.insertvalue %10, %202[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %204 = llvm.insertvalue %20, %203[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %205 = llvm.insertvalue %8, %204[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %206 = llvm.insertvalue %20, %205[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %207 = llvm.insertvalue %20, %206[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %208 = llvm.insertvalue %32, %207[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %209 = llvm.insertvalue %32, %208[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %210 = llvm.insertvalue %20, %209[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %211 = llvm.insertvalue %8, %210[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %212 = llvm.inttoptr %57 : i64 to !llvm.ptr<2>
    %213 = llvm.insertvalue %212, %5[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %214 = llvm.insertvalue %212, %213[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %215 = llvm.insertvalue %10, %214[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %216 = llvm.insertvalue %20, %215[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %217 = llvm.insertvalue %9, %216[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %218 = llvm.insertvalue %20, %217[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %219 = llvm.insertvalue %20, %218[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %220 = llvm.insertvalue %7, %219[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %221 = llvm.insertvalue %32, %220[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %222 = llvm.insertvalue %20, %221[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %223 = llvm.insertvalue %8, %222[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %224 = llvm.inttoptr %56 : i64 to !llvm.ptr<2>
    %225 = llvm.insertvalue %224, %5[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %226 = llvm.insertvalue %224, %225[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %227 = llvm.insertvalue %10, %226[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %228 = llvm.insertvalue %20, %227[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %229 = llvm.insertvalue %9, %228[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %230 = llvm.insertvalue %20, %229[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %231 = llvm.insertvalue %20, %230[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %232 = llvm.insertvalue %7, %231[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %233 = llvm.insertvalue %32, %232[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %234 = llvm.insertvalue %20, %233[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %235 = llvm.insertvalue %8, %234[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %236 = llvm.inttoptr %55 : i64 to !llvm.ptr<5>
    %237 = llvm.insertvalue %236, %6[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %238 = llvm.insertvalue %236, %237[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %239 = llvm.insertvalue %10, %238[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %240 = llvm.insertvalue %9, %239[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %241 = llvm.insertvalue %8, %240[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %242 = llvm.insertvalue %20, %241[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %243 = llvm.insertvalue %20, %242[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %244 = llvm.insertvalue %32, %243[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %245 = llvm.insertvalue %32, %244[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %246 = llvm.insertvalue %20, %245[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %247 = llvm.insertvalue %8, %246[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %248 = llvm.inttoptr %54 : i64 to !llvm.ptr<5>
    %249 = llvm.insertvalue %248, %6[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %250 = llvm.insertvalue %248, %249[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %251 = llvm.insertvalue %10, %250[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %252 = llvm.insertvalue %9, %251[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %253 = llvm.insertvalue %8, %252[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %254 = llvm.insertvalue %20, %253[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %255 = llvm.insertvalue %20, %254[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %256 = llvm.insertvalue %32, %255[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %257 = llvm.insertvalue %32, %256[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %258 = llvm.insertvalue %20, %257[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %259 = llvm.insertvalue %8, %258[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %260 = llvm.inttoptr %53 : i64 to !llvm.ptr<2>
    %261 = llvm.insertvalue %260, %5[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %262 = llvm.insertvalue %260, %261[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %263 = llvm.insertvalue %10, %262[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %264 = llvm.insertvalue %20, %263[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %265 = llvm.insertvalue %9, %264[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %266 = llvm.insertvalue %20, %265[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %267 = llvm.insertvalue %20, %266[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %268 = llvm.insertvalue %7, %267[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %269 = llvm.insertvalue %32, %268[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %270 = llvm.insertvalue %20, %269[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %271 = llvm.insertvalue %8, %270[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %272 = llvm.inttoptr %52 : i64 to !llvm.ptr<2>
    %273 = llvm.insertvalue %272, %5[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %274 = llvm.insertvalue %272, %273[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %275 = llvm.insertvalue %10, %274[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %276 = llvm.insertvalue %20, %275[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %277 = llvm.insertvalue %9, %276[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %278 = llvm.insertvalue %20, %277[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %279 = llvm.insertvalue %20, %278[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %280 = llvm.insertvalue %7, %279[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %281 = llvm.insertvalue %32, %280[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %282 = llvm.insertvalue %20, %281[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %283 = llvm.insertvalue %8, %282[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %284 = llvm.alloca %8 x i64 : (i64) -> !llvm.ptr
    llvm.store %22, %284 : i64, !llvm.ptr
    %285 = llvm.alloca %8 x i64 : (i64) -> !llvm.ptr
    llvm.store %22, %285 : i64, !llvm.ptr
    %286 = llvm.alloca %8 x i64 : (i64) -> !llvm.ptr
    llvm.store %22, %286 : i64, !llvm.ptr
    %287 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %288 = "hivm.intr.hivm.SBITSET0"(%287, %3) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%288) : (i64) -> ()
    %289 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %290 = "hivm.intr.hivm.SBITSET1"(%289, %2) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%290) : (i64) -> ()
    %291 = "hivm.intr.hivm.GET.BLOCK.IDX"() : () -> i64
    %292 = llvm.trunc %291 : i64 to i32
    %293 = llvm.srem %292, %arg23  : i32
    %294 = llvm.inttoptr %22 : i64 to !llvm.ptr<11>
    %295 = llvm.inttoptr %21 : i64 to !llvm.ptr<11>
    llvm.store volatile %23, %294 : i32, !llvm.ptr<11>
    llvm.store volatile %23, %295 : i32, !llvm.ptr<11>
    %296 = llvm.inttoptr %33 : i64 to !llvm.ptr<11>
    %297 = llvm.inttoptr %34 : i64 to !llvm.ptr<11>
    llvm.store volatile %23, %296 : i32, !llvm.ptr<11>
    llvm.store volatile %23, %297 : i32, !llvm.ptr<11>
    %298 = llvm.inttoptr %35 : i64 to !llvm.ptr<11>
    %299 = llvm.inttoptr %36 : i64 to !llvm.ptr<11>
    llvm.store volatile %23, %298 : i32, !llvm.ptr<11>
    llvm.store volatile %23, %299 : i32, !llvm.ptr<11>
    %300 = llvm.inttoptr %37 : i64 to !llvm.ptr<11>
    %301 = llvm.inttoptr %38 : i64 to !llvm.ptr<11>
    llvm.store volatile %23, %300 : i32, !llvm.ptr<11>
    llvm.store volatile %23, %301 : i32, !llvm.ptr<11>
    %302 = llvm.inttoptr %39 : i64 to !llvm.ptr<11>
    %303 = llvm.inttoptr %40 : i64 to !llvm.ptr<11>
    llvm.store volatile %23, %302 : i32, !llvm.ptr<11>
    llvm.store volatile %23, %303 : i32, !llvm.ptr<11>
    %304 = llvm.inttoptr %41 : i64 to !llvm.ptr<11>
    %305 = llvm.inttoptr %42 : i64 to !llvm.ptr<11>
    llvm.store volatile %23, %304 : i32, !llvm.ptr<11>
    llvm.store volatile %23, %305 : i32, !llvm.ptr<11>
    %306 = llvm.mul %arg10, %24 : i32
    %307 = llvm.sext %arg12 : i32 to i64
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 17 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 16 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 0 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 4 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 5 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 6 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    llvm.br ^bb1(%293 : i32)
  ^bb1(%308: i32):  // 2 preds: ^bb0, ^bb40
    %309 = llvm.icmp "slt" %308, %306 : i32
    llvm.cond_br %309, ^bb2, ^bb41
  ^bb2:  // pred: ^bb1
    %310 = llvm.load %284 : !llvm.ptr -> i64
    %311 = llvm.urem %310, %46  : i64
    %312 = llvm.icmp "eq" %311, %47 : i64
    %313 = llvm.select %312, %115, %103 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %314 = llvm.trunc %311 : i64 to i1
    %315 = llvm.xor %314, %45  : i1
    %316 = llvm.zext %315 : i1 to i64
    %317 = llvm.sdiv %308, %24  : i32
    %318 = llvm.sext %317 : i32 to i64
    %319 = llvm.getelementptr %arg7[%318] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %320 = llvm.load %319 : !llvm.ptr<1> -> i32
    %321 = llvm.add %320, %27 : i32
    %322 = llvm.sdiv %321, %28  : i32
    %323 = llvm.intr.smin(%322, %23)  : (i32, i32) -> i32
    %324 = llvm.sub %320, %26 : i32
    %325 = llvm.intr.smax(%324, %23)  : (i32, i32) -> i32
    %326 = llvm.sdiv %325, %28  : i32
    %327 = llvm.intr.smax(%323, %326)  : (i32, i32) -> i32
    %328 = llvm.srem %308, %24  : i32
    %329 = llvm.mul %328, %29 : i32
    %330 = llvm.mul %317, %arg11 : i32
    %331 = llvm.sext %330 : i32 to i64
    %332 = llvm.sext %329 : i32 to i64
    %333 = llvm.mul %332, %307 : i64
    %334 = llvm.add %331, %333 : i64
    "hivm.intr.hivm.WAIT.FLAG.REG"(%316) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    %335 = llvm.extractvalue %313[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %336 = llvm.extractvalue %313[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %337 = llvm.extractvalue %313[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %338 = llvm.extractvalue %313[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %339 = llvm.extractvalue %313[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %340 = llvm.extractvalue %313[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %341 = llvm.extractvalue %313[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %342 = llvm.extractvalue %313[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %343 = llvm.extractvalue %313[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %344 = llvm.extractvalue %313[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %345 = llvm.extractvalue %313[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @nd2nz_bfloat16_t(%arg3, %arg3, %334, %25, %32, %307, %8, %335, %336, %337, %338, %339, %340, %341, %342, %343, %344, %345) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    %346 = llvm.mul %317, %arg21 : i32
    %347 = llvm.sext %346 : i32 to i64
    %348 = llvm.mul %328, %arg14 : i32
    %349 = llvm.mul %328, %arg17 : i32
    %350 = llvm.inttoptr %19 : i64 to !llvm.ptr<2>
    %351 = llvm.inttoptr %18 : i64 to !llvm.ptr<6>
    %352 = llvm.inttoptr %17 : i64 to !llvm.ptr<6>
    %353 = llvm.add %323, %43 : i32
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    llvm.br ^bb3(%23, %23, %23, %23 : i32, i32, i32, i32)
  ^bb3(%354: i32, %355: i32, %356: i32, %357: i32):  // 2 preds: ^bb2, ^bb20
    %358 = llvm.icmp "slt" %354, %353 : i32
    llvm.cond_br %358, ^bb4, ^bb21
  ^bb4:  // pred: ^bb3
    %359 = llvm.load %286 : !llvm.ptr -> i64
    %360 = llvm.urem %359, %46  : i64
    %361 = llvm.icmp "eq" %360, %47 : i64
    %362 = llvm.select %361, %91, %79 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %363 = llvm.select %361, %139, %127 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %364 = llvm.select %361, %163, %151 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %365 = llvm.select %361, %187, %175 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %366 = llvm.trunc %360 : i64 to i1
    %367 = llvm.select %366, %46, %48 : i1, i64
    %368 = llvm.select %366, %49, %50 : i1, i64
    %369 = llvm.xor %366, %45  : i1
    %370 = llvm.zext %369 : i1 to i64
    %371 = llvm.select %366, %48, %33 : i1, i64
    %372 = llvm.icmp "slt" %355, %323 : i32
    llvm.cond_br %372, ^bb5, ^bb6
  ^bb5:  // pred: ^bb4
    %373 = llvm.add %355, %44 : i32
    llvm.br ^bb7(%373 : i32)
  ^bb6:  // pred: ^bb4
    llvm.br ^bb7(%355 : i32)
  ^bb7(%374: i32):  // 2 preds: ^bb5, ^bb6
    llvm.br ^bb8
  ^bb8:  // pred: ^bb7
    %375 = llvm.load volatile %294 : !llvm.ptr<11> -> i32
    %376 = llvm.load volatile %295 : !llvm.ptr<11> -> i32
    %377 = llvm.icmp "slt" %375, %44 : i32
    %378 = llvm.icmp "slt" %376, %44 : i32
    %379 = llvm.and %377, %378  : i1
    %380 = llvm.icmp "slt" %356, %323 : i32
    %381 = llvm.and %379, %380  : i1
    llvm.cond_br %381, ^bb9, ^bb12
  ^bb9:  // pred: ^bb8
    %382 = llvm.mul %356, %28 : i32
    %383 = llvm.add %382, %28 : i32
    %384 = llvm.intr.smin(%383, %320)  : (i32, i32) -> i32
    %385 = llvm.sub %384, %382 : i32
    %386 = llvm.sext %385 : i32 to i64
    %387 = llvm.sext %arg15 : i32 to i64
    %388 = llvm.intr.smax(%386, %10)  : (i64, i64) -> i64
    %389 = llvm.intr.smin(%388, %31)  : (i64, i64) -> i64
    %390 = llvm.intr.smin(%389, %10)  : (i64, i64) -> i64
    %391 = llvm.mul %390, %1 : i64
    %392 = llvm.add %389, %391 : i64
    %393 = llvm.icmp "slt" %392, %31 : i64
    %394 = llvm.sdiv %382, %28  : i32
    %395 = llvm.srem %382, %28  : i32
    %396 = llvm.sext %394 : i32 to i64
    %397 = llvm.add %347, %396 : i64
    %398 = llvm.getelementptr %arg8[%397] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %399 = llvm.load %398 : !llvm.ptr<1> -> i32
    %400 = llvm.mul %399, %arg13 : i32
    %401 = llvm.sext %400 : i32 to i64
    %402 = llvm.sext %348 : i32 to i64
    %403 = llvm.mul %395, %arg15 : i32
    %404 = llvm.sext %403 : i32 to i64
    %405 = llvm.add %404, %401 : i64
    %406 = llvm.add %405, %402 : i64
    %407 = llvm.mul %390, %1 : i64
    %408 = llvm.add %389, %407 : i64
    %409 = llvm.add %408, %0 : i64
    %410 = llvm.icmp "slt" %409, %10 : i64
    %411 = llvm.sub %1, %409 : i64
    %412 = llvm.select %410, %411, %409 : i1, i64
    %413 = llvm.sdiv %412, %20  : i64
    %414 = llvm.sub %1, %413 : i64
    %415 = llvm.select %410, %414, %413 : i1, i64
    %416 = llvm.extractvalue %365[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %417 = llvm.extractvalue %365[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %418 = llvm.mul %390, %20 : i64
    llvm.cond_br %393, ^bb10, ^bb11
  ^bb10:  // pred: ^bb9
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %419 = llvm.extractvalue %365[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %420 = llvm.extractvalue %365[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%30, %419, %420, %10, %4, %8) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb11
  ^bb11:  // 2 preds: ^bb9, ^bb10
    "hivm.intr.hivm.WAIT.FLAG.REG"(%371) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.call @nd2nz_bfloat16_t(%arg4, %arg4, %406, %392, %32, %387, %8, %416, %417, %418, %20, %415, %20, %20, %7, %32, %20, %8) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%370) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %421 = llvm.extractvalue %313[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %422 = llvm.extractvalue %313[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %423 = llvm.extractvalue %313[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %424 = llvm.extractvalue %313[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %425 = llvm.extractvalue %313[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %426 = llvm.extractvalue %313[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %427 = llvm.extractvalue %313[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %428 = llvm.extractvalue %313[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %429 = llvm.extractvalue %313[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %430 = llvm.extractvalue %313[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %431 = llvm.extractvalue %313[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %432 = llvm.extractvalue %365[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %433 = llvm.extractvalue %365[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %434 = llvm.extractvalue %365[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %435 = llvm.extractvalue %365[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %436 = llvm.extractvalue %365[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %437 = llvm.extractvalue %365[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %438 = llvm.extractvalue %365[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %439 = llvm.extractvalue %365[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %440 = llvm.extractvalue %365[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %441 = llvm.extractvalue %365[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %442 = llvm.extractvalue %365[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %443 = llvm.extractvalue %362[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %444 = llvm.extractvalue %362[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %445 = llvm.extractvalue %362[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %446 = llvm.extractvalue %362[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %447 = llvm.extractvalue %362[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %448 = llvm.extractvalue %362[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %449 = llvm.extractvalue %362[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %450 = llvm.extractvalue %362[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %451 = llvm.extractvalue %362[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %452 = llvm.extractvalue %362[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %453 = llvm.extractvalue %362[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float_tb(%421, %422, %423, %424, %425, %426, %427, %428, %429, %430, %431, %432, %433, %434, %435, %436, %437, %438, %439, %440, %441, %442, %45, %25, %32, %31, %443, %444, %445, %446, %447, %448, %449, %450, %451, %452, %453, %51, %22, %51, %371, %51, %51, %51, %11) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 10 : i64}> : () -> ()
    %454 = llvm.extractvalue %362[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %455 = llvm.extractvalue %362[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %456 = llvm.extractvalue %362[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %457 = llvm.extractvalue %362[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %458 = llvm.extractvalue %362[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %459 = llvm.extractvalue %362[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %460 = llvm.extractvalue %362[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %461 = llvm.extractvalue %362[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %462 = llvm.extractvalue %362[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %463 = llvm.extractvalue %362[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %464 = llvm.extractvalue %362[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%454, %455, %456, %457, %458, %459, %460, %461, %462, %463, %464, %351, %351, %10, %25, %31, %31, %8, %22, %13, %22, %12, %11) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%370) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %465 = llvm.load volatile %294 : !llvm.ptr<11> -> i32
    %466 = llvm.load volatile %295 : !llvm.ptr<11> -> i32
    %467 = llvm.add %465, %44 : i32
    %468 = llvm.add %466, %44 : i32
    llvm.store volatile %467, %294 : i32, !llvm.ptr<11>
    llvm.store volatile %468, %295 : i32, !llvm.ptr<11>
    %469 = llvm.add %356, %44 : i32
    llvm.br ^bb13(%469 : i32)
  ^bb12:  // pred: ^bb8
    llvm.br ^bb13(%356 : i32)
  ^bb13(%470: i32):  // 2 preds: ^bb11, ^bb12
    llvm.br ^bb14
  ^bb14:  // pred: ^bb13
    %471 = llvm.load volatile %302 : !llvm.ptr<11> -> i32
    %472 = llvm.load volatile %303 : !llvm.ptr<11> -> i32
    %473 = llvm.icmp "sgt" %471, %23 : i32
    %474 = llvm.icmp "sgt" %472, %23 : i32
    %475 = llvm.and %473, %474  : i1
    %476 = llvm.load volatile %296 : !llvm.ptr<11> -> i32
    %477 = llvm.load volatile %297 : !llvm.ptr<11> -> i32
    %478 = llvm.icmp "slt" %476, %44 : i32
    %479 = llvm.icmp "slt" %477, %44 : i32
    %480 = llvm.and %478, %479  : i1
    %481 = llvm.and %475, %480  : i1
    %482 = llvm.icmp "slt" %357, %323 : i32
    %483 = llvm.and %481, %482  : i1
    llvm.cond_br %483, ^bb15, ^bb18
  ^bb15:  // pred: ^bb14
    %484 = llvm.mul %357, %28 : i32
    %485 = llvm.add %484, %28 : i32
    %486 = llvm.intr.smin(%485, %320)  : (i32, i32) -> i32
    %487 = llvm.sub %486, %484 : i32
    %488 = llvm.sext %arg18 : i32 to i64
    %489 = llvm.sext %487 : i32 to i64
    %490 = llvm.intr.smax(%489, %10)  : (i64, i64) -> i64
    %491 = llvm.intr.smin(%490, %31)  : (i64, i64) -> i64
    %492 = llvm.intr.smin(%491, %10)  : (i64, i64) -> i64
    %493 = llvm.mul %492, %1 : i64
    %494 = llvm.add %491, %493 : i64
    %495 = llvm.icmp "slt" %494, %31 : i64
    %496 = llvm.sdiv %484, %28  : i32
    %497 = llvm.srem %484, %28  : i32
    %498 = llvm.sext %496 : i32 to i64
    %499 = llvm.add %347, %498 : i64
    %500 = llvm.getelementptr %arg8[%499] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %501 = llvm.load %500 : !llvm.ptr<1> -> i32
    %502 = llvm.mul %501, %arg16 : i32
    %503 = llvm.sext %502 : i32 to i64
    %504 = llvm.sext %349 : i32 to i64
    %505 = llvm.mul %497, %arg18 : i32
    %506 = llvm.sext %505 : i32 to i64
    %507 = llvm.add %506, %503 : i64
    %508 = llvm.add %507, %504 : i64
    %509 = llvm.mul %492, %1 : i64
    %510 = llvm.add %491, %509 : i64
    %511 = llvm.add %510, %0 : i64
    %512 = llvm.icmp "slt" %511, %10 : i64
    %513 = llvm.sub %1, %511 : i64
    %514 = llvm.select %512, %513, %511 : i1, i64
    %515 = llvm.sdiv %514, %20  : i64
    %516 = llvm.sub %1, %515 : i64
    %517 = llvm.select %512, %516, %515 : i1, i64
    %518 = llvm.extractvalue %364[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %519 = llvm.extractvalue %364[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %520 = llvm.mul %492, %20 : i64
    llvm.cond_br %495, ^bb16, ^bb17
  ^bb16:  // pred: ^bb15
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %521 = llvm.extractvalue %364[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %522 = llvm.extractvalue %364[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%30, %521, %522, %10, %4, %8) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb17
  ^bb17:  // 2 preds: ^bb15, ^bb16
    "hivm.intr.hivm.WAIT.FLAG.REG"(%368) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.call @nd2nz_bfloat16_t(%arg5, %arg5, %508, %494, %32, %488, %8, %518, %519, %520, %20, %517, %20, %20, %7, %32, %20, %8) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%367) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %523 = llvm.extractvalue %364[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %524 = llvm.extractvalue %364[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %525 = llvm.extractvalue %364[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %526 = llvm.extractvalue %364[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %527 = llvm.extractvalue %364[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %528 = llvm.extractvalue %364[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %529 = llvm.extractvalue %364[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %530 = llvm.extractvalue %364[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %531 = llvm.extractvalue %364[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %532 = llvm.extractvalue %364[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %533 = llvm.extractvalue %364[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %534 = llvm.extractvalue %363[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %535 = llvm.extractvalue %363[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %536 = llvm.extractvalue %363[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %537 = llvm.extractvalue %363[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %538 = llvm.extractvalue %363[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %539 = llvm.extractvalue %363[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %540 = llvm.extractvalue %363[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %541 = llvm.extractvalue %363[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %542 = llvm.extractvalue %363[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %543 = llvm.extractvalue %363[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %544 = llvm.extractvalue %363[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float(%350, %350, %10, %9, %8, %20, %20, %32, %32, %20, %8, %523, %524, %525, %526, %527, %528, %529, %530, %531, %532, %533, %45, %20, %31, %32, %534, %535, %536, %537, %538, %539, %540, %541, %542, %543, %544, %51, %22, %51, %368, %51, %51, %51, %11) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 10 : i64}> : () -> ()
    %545 = llvm.extractvalue %363[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %546 = llvm.extractvalue %363[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %547 = llvm.extractvalue %363[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %548 = llvm.extractvalue %363[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %549 = llvm.extractvalue %363[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %550 = llvm.extractvalue %363[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %551 = llvm.extractvalue %363[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %552 = llvm.extractvalue %363[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %553 = llvm.extractvalue %363[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %554 = llvm.extractvalue %363[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %555 = llvm.extractvalue %363[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%545, %546, %547, %548, %549, %550, %551, %552, %553, %554, %555, %352, %352, %10, %25, %32, %32, %8, %22, %13, %22, %12, %11) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%367) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %556 = llvm.load volatile %302 : !llvm.ptr<11> -> i32
    %557 = llvm.load volatile %303 : !llvm.ptr<11> -> i32
    %558 = llvm.sub %556, %44 : i32
    %559 = llvm.sub %557, %44 : i32
    llvm.store volatile %558, %302 : i32, !llvm.ptr<11>
    llvm.store volatile %559, %303 : i32, !llvm.ptr<11>
    %560 = llvm.load volatile %296 : !llvm.ptr<11> -> i32
    %561 = llvm.load volatile %297 : !llvm.ptr<11> -> i32
    %562 = llvm.add %560, %44 : i32
    %563 = llvm.add %561, %44 : i32
    llvm.store volatile %562, %296 : i32, !llvm.ptr<11>
    llvm.store volatile %563, %297 : i32, !llvm.ptr<11>
    %564 = llvm.add %357, %44 : i32
    llvm.br ^bb19(%564 : i32)
  ^bb18:  // pred: ^bb14
    llvm.br ^bb19(%357 : i32)
  ^bb19(%565: i32):  // 2 preds: ^bb17, ^bb18
    llvm.br ^bb20
  ^bb20:  // pred: ^bb19
    %566 = llvm.add %359, %47 : i64
    llvm.store %566, %286 : i64, !llvm.ptr
    %567 = llvm.add %354, %44 overflow<nsw> : i32
    llvm.br ^bb3(%567, %374, %470, %565 : i32, i32, i32, i32)
  ^bb21:  // pred: ^bb3
    %568 = llvm.inttoptr %16 : i64 to !llvm.ptr<2>
    %569 = llvm.inttoptr %15 : i64 to !llvm.ptr<6>
    %570 = llvm.inttoptr %14 : i64 to !llvm.ptr<6>
    %571 = llvm.sub %322, %327 : i32
    %572 = llvm.add %571, %43 : i32
    %573 = llvm.add %327, %572 : i32
    llvm.br ^bb22(%327, %327, %327, %327 : i32, i32, i32, i32)
  ^bb22(%574: i32, %575: i32, %576: i32, %577: i32):  // 2 preds: ^bb21, ^bb39
    %578 = llvm.icmp "slt" %574, %573 : i32
    llvm.cond_br %578, ^bb23, ^bb40
  ^bb23:  // pred: ^bb22
    %579 = llvm.load %285 : !llvm.ptr -> i64
    %580 = llvm.urem %579, %46  : i64
    %581 = llvm.icmp "eq" %580, %47 : i64
    %582 = llvm.select %581, %211, %199 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %583 = llvm.select %581, %235, %223 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %584 = llvm.select %581, %259, %247 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %585 = llvm.select %581, %283, %271 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %586 = llvm.trunc %580 : i64 to i1
    %587 = llvm.select %586, %46, %48 : i1, i64
    %588 = llvm.select %586, %49, %50 : i1, i64
    %589 = llvm.xor %586, %45  : i1
    %590 = llvm.zext %589 : i1 to i64
    %591 = llvm.select %586, %48, %33 : i1, i64
    %592 = llvm.icmp "slt" %575, %322 : i32
    llvm.cond_br %592, ^bb24, ^bb25
  ^bb24:  // pred: ^bb23
    %593 = llvm.add %575, %44 : i32
    llvm.br ^bb26(%593 : i32)
  ^bb25:  // pred: ^bb23
    llvm.br ^bb26(%575 : i32)
  ^bb26(%594: i32):  // 2 preds: ^bb24, ^bb25
    llvm.br ^bb27
  ^bb27:  // pred: ^bb26
    %595 = llvm.load volatile %298 : !llvm.ptr<11> -> i32
    %596 = llvm.load volatile %299 : !llvm.ptr<11> -> i32
    %597 = llvm.icmp "slt" %595, %44 : i32
    %598 = llvm.icmp "slt" %596, %44 : i32
    %599 = llvm.and %597, %598  : i1
    %600 = llvm.icmp "slt" %576, %322 : i32
    %601 = llvm.and %599, %600  : i1
    llvm.cond_br %601, ^bb28, ^bb31
  ^bb28:  // pred: ^bb27
    %602 = llvm.mul %576, %28 : i32
    %603 = llvm.add %602, %28 : i32
    %604 = llvm.intr.smin(%603, %320)  : (i32, i32) -> i32
    %605 = llvm.sub %604, %602 : i32
    %606 = llvm.sext %605 : i32 to i64
    %607 = llvm.sext %arg15 : i32 to i64
    %608 = llvm.intr.smax(%606, %10)  : (i64, i64) -> i64
    %609 = llvm.intr.smin(%608, %31)  : (i64, i64) -> i64
    %610 = llvm.intr.smin(%609, %10)  : (i64, i64) -> i64
    %611 = llvm.mul %610, %1 : i64
    %612 = llvm.add %609, %611 : i64
    %613 = llvm.icmp "slt" %612, %31 : i64
    %614 = llvm.sdiv %602, %28  : i32
    %615 = llvm.srem %602, %28  : i32
    %616 = llvm.sext %614 : i32 to i64
    %617 = llvm.add %347, %616 : i64
    %618 = llvm.getelementptr %arg8[%617] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %619 = llvm.load %618 : !llvm.ptr<1> -> i32
    %620 = llvm.mul %619, %arg13 : i32
    %621 = llvm.sext %620 : i32 to i64
    %622 = llvm.sext %348 : i32 to i64
    %623 = llvm.mul %615, %arg15 : i32
    %624 = llvm.sext %623 : i32 to i64
    %625 = llvm.add %624, %621 : i64
    %626 = llvm.add %625, %622 : i64
    %627 = llvm.mul %610, %1 : i64
    %628 = llvm.add %609, %627 : i64
    %629 = llvm.add %628, %0 : i64
    %630 = llvm.icmp "slt" %629, %10 : i64
    %631 = llvm.sub %1, %629 : i64
    %632 = llvm.select %630, %631, %629 : i1, i64
    %633 = llvm.sdiv %632, %20  : i64
    %634 = llvm.sub %1, %633 : i64
    %635 = llvm.select %630, %634, %633 : i1, i64
    %636 = llvm.extractvalue %585[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %637 = llvm.extractvalue %585[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %638 = llvm.mul %610, %20 : i64
    llvm.cond_br %613, ^bb29, ^bb30
  ^bb29:  // pred: ^bb28
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %639 = llvm.extractvalue %585[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %640 = llvm.extractvalue %585[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%30, %639, %640, %10, %4, %8) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb30
  ^bb30:  // 2 preds: ^bb28, ^bb29
    "hivm.intr.hivm.WAIT.FLAG.REG"(%591) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.call @nd2nz_bfloat16_t(%arg4, %arg4, %626, %612, %32, %607, %8, %636, %637, %638, %20, %635, %20, %20, %7, %32, %20, %8) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%590) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %641 = llvm.extractvalue %313[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %642 = llvm.extractvalue %313[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %643 = llvm.extractvalue %313[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %644 = llvm.extractvalue %313[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %645 = llvm.extractvalue %313[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %646 = llvm.extractvalue %313[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %647 = llvm.extractvalue %313[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %648 = llvm.extractvalue %313[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %649 = llvm.extractvalue %313[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %650 = llvm.extractvalue %313[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %651 = llvm.extractvalue %313[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %652 = llvm.extractvalue %585[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %653 = llvm.extractvalue %585[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %654 = llvm.extractvalue %585[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %655 = llvm.extractvalue %585[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %656 = llvm.extractvalue %585[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %657 = llvm.extractvalue %585[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %658 = llvm.extractvalue %585[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %659 = llvm.extractvalue %585[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %660 = llvm.extractvalue %585[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %661 = llvm.extractvalue %585[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %662 = llvm.extractvalue %585[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %663 = llvm.extractvalue %584[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %664 = llvm.extractvalue %584[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %665 = llvm.extractvalue %584[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %666 = llvm.extractvalue %584[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %667 = llvm.extractvalue %584[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %668 = llvm.extractvalue %584[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %669 = llvm.extractvalue %584[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %670 = llvm.extractvalue %584[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %671 = llvm.extractvalue %584[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %672 = llvm.extractvalue %584[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %673 = llvm.extractvalue %584[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float_tb(%641, %642, %643, %644, %645, %646, %647, %648, %649, %650, %651, %652, %653, %654, %655, %656, %657, %658, %659, %660, %661, %662, %45, %25, %32, %31, %663, %664, %665, %666, %667, %668, %669, %670, %671, %672, %673, %51, %22, %51, %591, %51, %51, %51, %11) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 10 : i64}> : () -> ()
    %674 = llvm.extractvalue %584[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %675 = llvm.extractvalue %584[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %676 = llvm.extractvalue %584[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %677 = llvm.extractvalue %584[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %678 = llvm.extractvalue %584[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %679 = llvm.extractvalue %584[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %680 = llvm.extractvalue %584[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %681 = llvm.extractvalue %584[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %682 = llvm.extractvalue %584[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %683 = llvm.extractvalue %584[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %684 = llvm.extractvalue %584[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%674, %675, %676, %677, %678, %679, %680, %681, %682, %683, %684, %569, %569, %10, %25, %31, %31, %8, %22, %13, %22, %12, %11) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%590) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %685 = llvm.load volatile %298 : !llvm.ptr<11> -> i32
    %686 = llvm.load volatile %299 : !llvm.ptr<11> -> i32
    %687 = llvm.add %685, %44 : i32
    %688 = llvm.add %686, %44 : i32
    llvm.store volatile %687, %298 : i32, !llvm.ptr<11>
    llvm.store volatile %688, %299 : i32, !llvm.ptr<11>
    %689 = llvm.add %576, %44 : i32
    llvm.br ^bb32(%689 : i32)
  ^bb31:  // pred: ^bb27
    llvm.br ^bb32(%576 : i32)
  ^bb32(%690: i32):  // 2 preds: ^bb30, ^bb31
    llvm.br ^bb33
  ^bb33:  // pred: ^bb32
    %691 = llvm.load volatile %304 : !llvm.ptr<11> -> i32
    %692 = llvm.load volatile %305 : !llvm.ptr<11> -> i32
    %693 = llvm.icmp "sgt" %691, %23 : i32
    %694 = llvm.icmp "sgt" %692, %23 : i32
    %695 = llvm.and %693, %694  : i1
    %696 = llvm.load volatile %300 : !llvm.ptr<11> -> i32
    %697 = llvm.load volatile %301 : !llvm.ptr<11> -> i32
    %698 = llvm.icmp "slt" %696, %44 : i32
    %699 = llvm.icmp "slt" %697, %44 : i32
    %700 = llvm.and %698, %699  : i1
    %701 = llvm.and %695, %700  : i1
    %702 = llvm.icmp "slt" %577, %322 : i32
    %703 = llvm.and %701, %702  : i1
    llvm.cond_br %703, ^bb34, ^bb37
  ^bb34:  // pred: ^bb33
    %704 = llvm.mul %577, %28 : i32
    %705 = llvm.add %704, %28 : i32
    %706 = llvm.intr.smin(%705, %320)  : (i32, i32) -> i32
    %707 = llvm.sub %706, %704 : i32
    %708 = llvm.sext %arg18 : i32 to i64
    %709 = llvm.sext %707 : i32 to i64
    %710 = llvm.intr.smax(%709, %10)  : (i64, i64) -> i64
    %711 = llvm.intr.smin(%710, %31)  : (i64, i64) -> i64
    %712 = llvm.intr.smin(%711, %10)  : (i64, i64) -> i64
    %713 = llvm.mul %712, %1 : i64
    %714 = llvm.add %711, %713 : i64
    %715 = llvm.icmp "slt" %714, %31 : i64
    %716 = llvm.sdiv %704, %28  : i32
    %717 = llvm.srem %704, %28  : i32
    %718 = llvm.sext %716 : i32 to i64
    %719 = llvm.add %347, %718 : i64
    %720 = llvm.getelementptr %arg8[%719] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %721 = llvm.load %720 : !llvm.ptr<1> -> i32
    %722 = llvm.mul %721, %arg16 : i32
    %723 = llvm.sext %722 : i32 to i64
    %724 = llvm.sext %349 : i32 to i64
    %725 = llvm.mul %717, %arg18 : i32
    %726 = llvm.sext %725 : i32 to i64
    %727 = llvm.add %726, %723 : i64
    %728 = llvm.add %727, %724 : i64
    %729 = llvm.mul %712, %1 : i64
    %730 = llvm.add %711, %729 : i64
    %731 = llvm.add %730, %0 : i64
    %732 = llvm.icmp "slt" %731, %10 : i64
    %733 = llvm.sub %1, %731 : i64
    %734 = llvm.select %732, %733, %731 : i1, i64
    %735 = llvm.sdiv %734, %20  : i64
    %736 = llvm.sub %1, %735 : i64
    %737 = llvm.select %732, %736, %735 : i1, i64
    %738 = llvm.extractvalue %583[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %739 = llvm.extractvalue %583[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %740 = llvm.mul %712, %20 : i64
    llvm.cond_br %715, ^bb35, ^bb36
  ^bb35:  // pred: ^bb34
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %741 = llvm.extractvalue %583[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %742 = llvm.extractvalue %583[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%30, %741, %742, %10, %4, %8) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb36
  ^bb36:  // 2 preds: ^bb34, ^bb35
    "hivm.intr.hivm.WAIT.FLAG.REG"(%588) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.call @nd2nz_bfloat16_t(%arg5, %arg5, %728, %714, %32, %708, %8, %738, %739, %740, %20, %737, %20, %20, %7, %32, %20, %8) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%587) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %743 = llvm.extractvalue %583[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %744 = llvm.extractvalue %583[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %745 = llvm.extractvalue %583[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %746 = llvm.extractvalue %583[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %747 = llvm.extractvalue %583[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %748 = llvm.extractvalue %583[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %749 = llvm.extractvalue %583[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %750 = llvm.extractvalue %583[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %751 = llvm.extractvalue %583[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %752 = llvm.extractvalue %583[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %753 = llvm.extractvalue %583[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %754 = llvm.extractvalue %582[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %755 = llvm.extractvalue %582[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %756 = llvm.extractvalue %582[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %757 = llvm.extractvalue %582[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %758 = llvm.extractvalue %582[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %759 = llvm.extractvalue %582[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %760 = llvm.extractvalue %582[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %761 = llvm.extractvalue %582[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %762 = llvm.extractvalue %582[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %763 = llvm.extractvalue %582[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %764 = llvm.extractvalue %582[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float(%568, %568, %10, %9, %8, %20, %20, %32, %32, %20, %8, %743, %744, %745, %746, %747, %748, %749, %750, %751, %752, %753, %45, %20, %31, %32, %754, %755, %756, %757, %758, %759, %760, %761, %762, %763, %764, %51, %22, %51, %588, %51, %51, %51, %11) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 10 : i64}> : () -> ()
    %765 = llvm.extractvalue %582[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %766 = llvm.extractvalue %582[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %767 = llvm.extractvalue %582[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %768 = llvm.extractvalue %582[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %769 = llvm.extractvalue %582[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %770 = llvm.extractvalue %582[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %771 = llvm.extractvalue %582[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %772 = llvm.extractvalue %582[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %773 = llvm.extractvalue %582[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %774 = llvm.extractvalue %582[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %775 = llvm.extractvalue %582[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%765, %766, %767, %768, %769, %770, %771, %772, %773, %774, %775, %570, %570, %10, %25, %32, %32, %8, %22, %13, %22, %12, %11) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%587) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %776 = llvm.load volatile %304 : !llvm.ptr<11> -> i32
    %777 = llvm.load volatile %305 : !llvm.ptr<11> -> i32
    %778 = llvm.sub %776, %44 : i32
    %779 = llvm.sub %777, %44 : i32
    llvm.store volatile %778, %304 : i32, !llvm.ptr<11>
    llvm.store volatile %779, %305 : i32, !llvm.ptr<11>
    %780 = llvm.load volatile %300 : !llvm.ptr<11> -> i32
    %781 = llvm.load volatile %301 : !llvm.ptr<11> -> i32
    %782 = llvm.add %780, %44 : i32
    %783 = llvm.add %781, %44 : i32
    llvm.store volatile %782, %300 : i32, !llvm.ptr<11>
    llvm.store volatile %783, %301 : i32, !llvm.ptr<11>
    %784 = llvm.add %577, %44 : i32
    llvm.br ^bb38(%784 : i32)
  ^bb37:  // pred: ^bb33
    llvm.br ^bb38(%577 : i32)
  ^bb38(%785: i32):  // 2 preds: ^bb36, ^bb37
    llvm.br ^bb39
  ^bb39:  // pred: ^bb38
    %786 = llvm.add %579, %47 : i64
    llvm.store %786, %285 : i64, !llvm.ptr
    %787 = llvm.add %574, %44 overflow<nsw> : i32
    llvm.br ^bb22(%787, %594, %690, %785 : i32, i32, i32, i32)
  ^bb40:  // pred: ^bb22
    "hivm.intr.hivm.SET.FLAG.REG"(%316) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    %788 = llvm.add %310, %47 : i64
    llvm.store %788, %284 : i64, !llvm.ptr
    %789 = llvm.add %308, %arg23 overflow<nsw> : i32
    llvm.br ^bb1(%789 : i32)
  ^bb41:  // pred: ^bb1
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 4 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 5 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 6 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %790 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %791 = "hivm.intr.hivm.SBITSET1"(%790, %3) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%791) : (i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 6 : i64}> : () -> ()
    llvm.return
  }
  llvm.func private @nd2nz_bfloat16_t(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<2>, %arg8: !llvm.ptr<2>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %15 = llvm.insertvalue %arg14, %14[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg15, %16[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg12, %17[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg13, %19[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %21, %22 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_nd2nz_bfloat16_t(%10, %22) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_nd2nz_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @set_l1_2d_bfloat16_t(%arg0: bf16, %arg1: !llvm.ptr<2>, %arg2: !llvm.ptr<2>, %arg3: i64, %arg4: i64, %arg5: i64) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg1, %1[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg4, %4[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg5, %5[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_set_l1_2d_bfloat16_t(%arg0, %7) : (bf16, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_set_l1_2d_bfloat16_t(bf16, !llvm.ptr) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @mma_tile_bfloat16_t_to_float_tb(%arg0: !llvm.ptr<2>, %arg1: !llvm.ptr<2>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<2>, %arg12: !llvm.ptr<2>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64, %arg21: i64, %arg22: i1, %arg23: i64, %arg24: i64, %arg25: i64, %arg26: !llvm.ptr<5>, %arg27: !llvm.ptr<5>, %arg28: i64, %arg29: i64, %arg30: i64, %arg31: i64, %arg32: i64, %arg33: i64, %arg34: i64, %arg35: i64, %arg36: i64, %arg37: i64, %arg38: i64, %arg39: i64, %arg40: i64, %arg41: i64, %arg42: i64, %arg43: i64, %arg44: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg18, %18[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.insertvalue %arg16, %21[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %24 = llvm.insertvalue %arg17, %23[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %25 = llvm.insertvalue %arg21, %24[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %26 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %25, %26 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %27 = llvm.insertvalue %arg26, %0[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %28 = llvm.insertvalue %arg27, %27[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %29 = llvm.insertvalue %arg28, %28[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %30 = llvm.insertvalue %arg29, %29[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %31 = llvm.insertvalue %arg33, %30[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %32 = llvm.insertvalue %arg30, %31[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %33 = llvm.insertvalue %arg34, %32[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %34 = llvm.insertvalue %arg31, %33[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %35 = llvm.insertvalue %arg35, %34[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %36 = llvm.insertvalue %arg32, %35[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %37 = llvm.insertvalue %arg36, %36[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %38 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %37, %38 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_mma_tile_bfloat16_t_to_float_tb(%14, %26, %arg22, %arg23, %arg24, %arg25, %38, %arg37, %arg38, %arg39, %arg40, %arg41, %arg42, %arg43, %arg44) : (!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_mma_tile_bfloat16_t_to_float_tb(!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%arg0: !llvm.ptr<5>, %arg1: !llvm.ptr<5>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<6>, %arg12: !llvm.ptr<6>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: f32, %arg20: i64, %arg21: i1, %arg22: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %21, %22 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%14, %22, %arg18, %arg19, %arg20, %arg21, %arg22) : (!llvm.ptr, !llvm.ptr, i64, f32, i64, i1, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(!llvm.ptr, !llvm.ptr, i64, f32, i64, i1, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @mma_tile_bfloat16_t_to_float(%arg0: !llvm.ptr<2>, %arg1: !llvm.ptr<2>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<2>, %arg12: !llvm.ptr<2>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64, %arg21: i64, %arg22: i1, %arg23: i64, %arg24: i64, %arg25: i64, %arg26: !llvm.ptr<5>, %arg27: !llvm.ptr<5>, %arg28: i64, %arg29: i64, %arg30: i64, %arg31: i64, %arg32: i64, %arg33: i64, %arg34: i64, %arg35: i64, %arg36: i64, %arg37: i64, %arg38: i64, %arg39: i64, %arg40: i64, %arg41: i64, %arg42: i64, %arg43: i64, %arg44: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg18, %18[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.insertvalue %arg16, %21[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %24 = llvm.insertvalue %arg17, %23[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %25 = llvm.insertvalue %arg21, %24[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %26 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %25, %26 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %27 = llvm.insertvalue %arg26, %0[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %28 = llvm.insertvalue %arg27, %27[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %29 = llvm.insertvalue %arg28, %28[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %30 = llvm.insertvalue %arg29, %29[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %31 = llvm.insertvalue %arg33, %30[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %32 = llvm.insertvalue %arg30, %31[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %33 = llvm.insertvalue %arg34, %32[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %34 = llvm.insertvalue %arg31, %33[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %35 = llvm.insertvalue %arg35, %34[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %36 = llvm.insertvalue %arg32, %35[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %37 = llvm.insertvalue %arg36, %36[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %38 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %37, %38 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_mma_tile_bfloat16_t_to_float(%14, %26, %arg22, %arg23, %arg24, %arg25, %38, %arg37, %arg38, %arg39, %arg40, %arg41, %arg42, %arg43, %arg44) : (!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_mma_tile_bfloat16_t_to_float(!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @load_gm_to_ubuf_1d_float(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i32, %arg11: f32, %arg12: i64, %arg13: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.insertvalue %arg4, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %8 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %7, %8 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %9 = llvm.insertvalue %arg5, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg6, %9[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg7, %10[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_load_gm_to_ubuf_1d_float(%8, %14, %arg10, %arg11, %arg12, %arg13) : (!llvm.ptr, !llvm.ptr, i32, f32, i64, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_load_gm_to_ubuf_1d_float(!llvm.ptr, !llvm.ptr, i32, f32, i64, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_ubuf_1d_float(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg0, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg1, %2[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg2, %3[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg3, %4[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %8 = llvm.insertvalue %arg5, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg7, %9[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg8, %10[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg9, %11[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %12, %13 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_ubuf_1d_float(%7, %13) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_ubuf_1d_float(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_ubuf_1d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg0, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg1, %2[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg2, %3[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg3, %4[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %8 = llvm.insertvalue %arg5, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg7, %9[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg8, %10[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg9, %11[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %12, %13 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_ubuf_1d_bfloat16_t(%7, %13) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_ubuf_1d_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_cbuf_2d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<2>, %arg8: !llvm.ptr<2>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg12, %14[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %17, %18 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_cbuf_2d_bfloat16_t(%10, %18) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_cbuf_2d_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @store_ubuf_to_gm_2d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<1>, %arg8: !llvm.ptr<1>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg12, %14[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %17, %18 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_store_ubuf_to_gm_2d_bfloat16_t(%10, %18, %arg14) : (!llvm.ptr, !llvm.ptr, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_store_ubuf_to_gm_2d_bfloat16_t(!llvm.ptr, !llvm.ptr, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func @_swa_paged_decode_sink_kernel_mix_aiv(%arg0: i64, %arg1: !llvm.ptr<1>, %arg2: !llvm.ptr<1>, %arg3: !llvm.ptr<1>, %arg4: !llvm.ptr<1>, %arg5: !llvm.ptr<1>, %arg6: !llvm.ptr<1>, %arg7: !llvm.ptr<1>, %arg8: !llvm.ptr<1>, %arg9: !llvm.ptr<1>, %arg10: i32, %arg11: i32, %arg12: i32, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32, %arg17: i32, %arg18: i32, %arg19: i32, %arg20: i32, %arg21: i32, %arg22: f32, %arg23: i32, %arg24: i32, %arg25: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix, hivm.vf_mode = #hivm.vf_mode<SIMD>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, mix_mode = "mix", parallel_mode = "simd"} {
    %0 = llvm.mlir.constant(-511 : index) : i64
    %1 = llvm.mlir.constant(575 : index) : i64
    %2 = llvm.mlir.constant(511 : index) : i64
    %3 = llvm.mlir.constant(272 : index) : i64
    %4 = llvm.mlir.constant(768 : index) : i64
    %5 = llvm.mlir.constant(4 : index) : i64
    %6 = llvm.mlir.constant(-1 : index) : i64
    %7 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %8 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %9 = llvm.mlir.constant(3072 : index) : i64
    %10 = llvm.mlir.constant(1 : index) : i64
    %11 = llvm.mlir.constant(256 : index) : i64
    %12 = llvm.mlir.constant(48 : i64) : i64
    %13 = llvm.mlir.constant(60 : i64) : i64
    %14 = llvm.mlir.constant(0 : index) : i64
    %15 = llvm.mlir.constant(64 : i32) : i32
    %16 = llvm.mlir.constant(63 : i32) : i32
    %17 = llvm.mlir.constant(512 : i32) : i32
    %18 = llvm.mlir.constant(12 : index) : i64
    %19 = llvm.mlir.constant(24 : index) : i64
    %20 = llvm.mlir.constant(2 : i32) : i32
    %21 = llvm.mlir.constant(0xFF800000 : f32) : f32
    %22 = llvm.mlir.constant(0 : i32) : i32
    %23 = llvm.mlir.constant(1024 : i64) : i64
    %24 = llvm.mlir.constant(0 : i64) : i64
    %25 = llvm.mlir.constant(12288 : i64) : i64
    %26 = llvm.mlir.constant(12352 : i64) : i64
    %27 = llvm.mlir.constant(12608 : i64) : i64
    %28 = llvm.mlir.constant(12864 : i64) : i64
    %29 = llvm.mlir.constant(60160 : i64) : i64
    %30 = llvm.mlir.constant(8192 : i64) : i64
    %31 = llvm.mlir.constant(13120 : i64) : i64
    %32 = llvm.mlir.constant(16192 : i64) : i64
    %33 = llvm.mlir.constant(28480 : i64) : i64
    %34 = llvm.mlir.constant(28544 : i64) : i64
    %35 = llvm.mlir.constant(28608 : i64) : i64
    %36 = llvm.mlir.constant(28672 : i64) : i64
    %37 = llvm.mlir.constant(60096 : i64) : i64
    %38 = llvm.mlir.constant(60224 : i64) : i64
    %39 = llvm.mlir.constant(28736 : i64) : i64
    %40 = llvm.mlir.constant(31808 : i64) : i64
    %41 = llvm.mlir.constant(36224 : i64) : i64
    %42 = llvm.mlir.constant(31872 : i64) : i64
    %43 = llvm.mlir.constant(33920 : i64) : i64
    %44 = llvm.mlir.constant(33984 : i64) : i64
    %45 = llvm.mlir.constant(34048 : i64) : i64
    %46 = llvm.mlir.constant(36288 : i64) : i64
    %47 = llvm.mlir.constant(75776 : i64) : i64
    %48 = llvm.mlir.constant(36352 : i64) : i64
    %49 = llvm.mlir.constant(39424 : i64) : i64
    %50 = llvm.mlir.constant(51712 : i64) : i64
    %51 = llvm.mlir.constant(51776 : i64) : i64
    %52 = llvm.mlir.constant(51840 : i64) : i64
    %53 = llvm.mlir.constant(51904 : i64) : i64
    %54 = llvm.mlir.constant(52224 : i64) : i64
    %55 = llvm.mlir.constant(51968 : i64) : i64
    %56 = llvm.mlir.constant(52480 : i64) : i64
    %57 = llvm.mlir.constant(55552 : i64) : i64
    %58 = llvm.mlir.constant(59968 : i64) : i64
    %59 = llvm.mlir.constant(55616 : i64) : i64
    %60 = llvm.mlir.constant(57664 : i64) : i64
    %61 = llvm.mlir.constant(57728 : i64) : i64
    %62 = llvm.mlir.constant(57792 : i64) : i64
    %63 = llvm.mlir.constant(60032 : i64) : i64
    %64 = llvm.mlir.constant(72512 : i64) : i64
    %65 = llvm.mlir.constant(12 : i32) : i32
    %66 = llvm.mlir.constant(64 : index) : i64
    %67 = llvm.mlir.constant(4 : i64) : i64
    %68 = llvm.mlir.constant(1028 : i64) : i64
    %69 = llvm.mlir.constant(8 : i64) : i64
    %70 = llvm.mlir.constant(1032 : i64) : i64
    %71 = llvm.mlir.constant(12 : i64) : i64
    %72 = llvm.mlir.constant(1036 : i64) : i64
    %73 = llvm.mlir.constant(16 : i64) : i64
    %74 = llvm.mlir.constant(1040 : i64) : i64
    %75 = llvm.mlir.constant(20 : i64) : i64
    %76 = llvm.mlir.constant(1044 : i64) : i64
    %77 = llvm.mlir.constant(3 : i32) : i32
    %78 = llvm.mlir.constant(1 : i32) : i32
    %79 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %80 = "hivm.intr.hivm.SBITSET0"(%79, %13) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%80) : (i64) -> ()
    %81 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %82 = "hivm.intr.hivm.SBITSET1"(%81, %12) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%82) : (i64) -> ()
    %83 = "hivm.intr.hivm.GET.BLOCK.IDX"() : () -> i64
    %84 = llvm.trunc %83 : i64 to i32
    %85 = llvm.srem %84, %arg23  : i32
    %86 = llvm.inttoptr %24 : i64 to !llvm.ptr<11>
    %87 = llvm.inttoptr %23 : i64 to !llvm.ptr<11>
    llvm.store volatile %22, %86 : i32, !llvm.ptr<11>
    llvm.store volatile %22, %87 : i32, !llvm.ptr<11>
    %88 = llvm.inttoptr %67 : i64 to !llvm.ptr<11>
    %89 = llvm.inttoptr %68 : i64 to !llvm.ptr<11>
    llvm.store volatile %22, %88 : i32, !llvm.ptr<11>
    llvm.store volatile %22, %89 : i32, !llvm.ptr<11>
    %90 = llvm.inttoptr %69 : i64 to !llvm.ptr<11>
    %91 = llvm.inttoptr %70 : i64 to !llvm.ptr<11>
    llvm.store volatile %22, %90 : i32, !llvm.ptr<11>
    llvm.store volatile %22, %91 : i32, !llvm.ptr<11>
    %92 = llvm.inttoptr %71 : i64 to !llvm.ptr<11>
    %93 = llvm.inttoptr %72 : i64 to !llvm.ptr<11>
    llvm.store volatile %22, %92 : i32, !llvm.ptr<11>
    llvm.store volatile %22, %93 : i32, !llvm.ptr<11>
    %94 = llvm.inttoptr %73 : i64 to !llvm.ptr<11>
    %95 = llvm.inttoptr %74 : i64 to !llvm.ptr<11>
    llvm.store volatile %22, %94 : i32, !llvm.ptr<11>
    llvm.store volatile %22, %95 : i32, !llvm.ptr<11>
    %96 = llvm.inttoptr %75 : i64 to !llvm.ptr<11>
    %97 = llvm.inttoptr %76 : i64 to !llvm.ptr<11>
    llvm.store volatile %22, %96 : i32, !llvm.ptr<11>
    llvm.store volatile %22, %97 : i32, !llvm.ptr<11>
    %98 = "hivm.intr.hivm.GET.SUBBLOCKID"() : () -> i64
    %99 = llvm.mul %98, %23 : i64
    %100 = llvm.add %99, %71 : i64
    %101 = llvm.inttoptr %100 : i64 to !llvm.ptr<11>
    %102 = llvm.add %99, %69 : i64
    %103 = llvm.inttoptr %102 : i64 to !llvm.ptr<11>
    %104 = llvm.add %99, %75 : i64
    %105 = llvm.inttoptr %104 : i64 to !llvm.ptr<11>
    %106 = llvm.add %99, %67 : i64
    %107 = llvm.inttoptr %106 : i64 to !llvm.ptr<11>
    %108 = llvm.inttoptr %99 : i64 to !llvm.ptr<11>
    %109 = llvm.add %99, %73 : i64
    %110 = llvm.inttoptr %109 : i64 to !llvm.ptr<11>
    %111 = llvm.inttoptr %24 : i64 to !llvm.ptr<6>
    %112 = llvm.inttoptr %25 : i64 to !llvm.ptr<6>
    %113 = llvm.mul %arg10, %20 : i32
    %114 = llvm.inttoptr %26 : i64 to !llvm.ptr<6>
    %115 = llvm.inttoptr %27 : i64 to !llvm.ptr<6>
    %116 = llvm.inttoptr %28 : i64 to !llvm.ptr<6>
    llvm.call @_swa_paged_decode_sink_kernel_outlined_merged_merged_vf_0(%111, %112, %114, %115, %116) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %117 = llvm.sext %arg20 : i32 to i64
    %118 = llvm.icmp "eq" %98, %14 : i64
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.br ^bb1(%85 : i32)
  ^bb1(%119: i32):  // 2 preds: ^bb0, ^bb48
    %120 = llvm.icmp "slt" %119, %113 : i32
    llvm.cond_br %120, ^bb2, ^bb49
  ^bb2:  // pred: ^bb1
    %121 = llvm.srem %119, %20  : i32
    %122 = llvm.sdiv %119, %20  : i32
    %123 = llvm.sext %122 : i32 to i64
    %124 = llvm.getelementptr %arg7[%123] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %125 = llvm.load %124 : !llvm.ptr<1> -> i32
    %126 = llvm.mul %121, %65 : i32
    %127 = llvm.sext %126 : i32 to i64
    %128 = llvm.add %127, %18 : i64
    %129 = llvm.intr.smax(%127, %19)  : (i64, i64) -> i64
    %130 = llvm.intr.smin(%128, %129)  : (i64, i64) -> i64
    %131 = llvm.mul %127, %6 : i64
    %132 = llvm.add %130, %131 : i64
    %133 = llvm.icmp "slt" %132, %18 : i64
    %134 = llvm.add %125, %16 : i32
    %135 = llvm.sdiv %134, %15  : i32
    %136 = llvm.intr.smin(%135, %22)  : (i32, i32) -> i32
    %137 = llvm.sub %125, %17 : i32
    %138 = llvm.intr.smax(%137, %22)  : (i32, i32) -> i32
    %139 = llvm.sdiv %138, %15  : i32
    %140 = llvm.intr.smax(%136, %139)  : (i32, i32) -> i32
    %141 = llvm.icmp "sgt" %125, %22 : i32
    %142 = llvm.inttoptr %29 : i64 to !llvm.ptr<6>
    %143 = llvm.insertvalue %142, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %144 = llvm.insertvalue %142, %143[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %145 = llvm.insertvalue %14, %144[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %146 = llvm.insertvalue %18, %145[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %147 = llvm.insertvalue %10, %146[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.cond_br %133, ^bb3, ^bb4
  ^bb3:  // pred: ^bb2
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_0(%142) {hivm.vector_function, no_inline} : (!llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.br ^bb4
  ^bb4:  // 2 preds: ^bb2, ^bb3
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @load_gm_to_ubuf_1d_float(%arg9, %arg9, %127, %132, %10, %142, %142, %14, %132, %10, %20, %21, %14, %22) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i32, f32, i64, i32) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    %148 = llvm.sub %125, %78 : i32
    %149 = llvm.inttoptr %30 : i64 to !llvm.ptr<2>
    %150 = llvm.inttoptr %31 : i64 to !llvm.ptr<6>
    %151 = llvm.inttoptr %32 : i64 to !llvm.ptr<6>
    %152 = llvm.inttoptr %33 : i64 to !llvm.ptr<6>
    %153 = llvm.insertvalue %152, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %154 = llvm.insertvalue %152, %153[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %155 = llvm.insertvalue %14, %154[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %156 = llvm.insertvalue %18, %155[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %157 = llvm.insertvalue %10, %156[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %158 = llvm.inttoptr %34 : i64 to !llvm.ptr<6>
    %159 = llvm.insertvalue %158, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %160 = llvm.insertvalue %158, %159[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %161 = llvm.insertvalue %14, %160[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %162 = llvm.insertvalue %18, %161[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %163 = llvm.insertvalue %10, %162[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %164 = llvm.inttoptr %35 : i64 to !llvm.ptr<6>
    %165 = llvm.insertvalue %164, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %166 = llvm.insertvalue %164, %165[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %167 = llvm.insertvalue %14, %166[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %168 = llvm.insertvalue %18, %167[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %169 = llvm.insertvalue %10, %168[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %170 = llvm.inttoptr %36 : i64 to !llvm.ptr<6>
    %171 = llvm.insertvalue %170, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %172 = llvm.insertvalue %170, %171[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %173 = llvm.insertvalue %14, %172[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %174 = llvm.insertvalue %18, %173[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %175 = llvm.insertvalue %10, %174[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %176 = llvm.add %136, %77 : i32
    %177 = llvm.inttoptr %37 : i64 to !llvm.ptr<6>
    %178 = llvm.insertvalue %177, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %179 = llvm.insertvalue %177, %178[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %180 = llvm.insertvalue %14, %179[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %181 = llvm.insertvalue %18, %180[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %182 = llvm.insertvalue %10, %181[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%112, %112, %14, %18, %10, %177, %177, %14, %18, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %183 = llvm.inttoptr %38 : i64 to !llvm.ptr<6>
    %184 = llvm.insertvalue %183, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %185 = llvm.insertvalue %183, %184[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %186 = llvm.insertvalue %14, %185[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %187 = llvm.insertvalue %18, %186[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %188 = llvm.insertvalue %11, %187[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %189 = llvm.insertvalue %11, %188[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %190 = llvm.insertvalue %10, %189[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%111, %111, %14, %9, %10, %183, %183, %14, %9, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.br ^bb5(%22, %182, %190, %147, %22, %22, %22, %22 : i32, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, i32, i32, i32, i32)
  ^bb5(%191: i32, %192: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %193: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %194: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %195: i32, %196: i32, %197: i32, %198: i32):  // 2 preds: ^bb4, ^bb20
    %199 = llvm.icmp "slt" %191, %176 : i32
    llvm.cond_br %199, ^bb6, ^bb21
  ^bb6:  // pred: ^bb5
    %200 = llvm.load volatile %108 : !llvm.ptr<11> -> i32
    %201 = llvm.icmp "sgt" %200, %22 : i32
    %202 = llvm.load volatile %110 : !llvm.ptr<11> -> i32
    %203 = llvm.icmp "slt" %202, %78 : i32
    %204 = llvm.and %201, %203  : i1
    %205 = llvm.icmp "slt" %197, %20 : i32
    %206 = llvm.icmp "slt" %198, %20 : i32
    %207 = llvm.and %205, %206  : i1
    %208 = llvm.icmp "slt" %195, %136 : i32
    %209 = llvm.and %204, %207  : i1
    %210 = llvm.and %209, %208  : i1
    llvm.cond_br %210, ^bb7, ^bb14
  ^bb7:  // pred: ^bb6
    %211 = llvm.mul %195, %15 : i32
    %212 = llvm.add %211, %15 : i32
    %213 = llvm.intr.smin(%212, %125)  : (i32, i32) -> i32
    %214 = llvm.sub %213, %211 : i32
    %215 = llvm.inttoptr %39 : i64 to !llvm.ptr<6>
    %216 = llvm.inttoptr %40 : i64 to !llvm.ptr<6>
    %217 = llvm.inttoptr %41 : i64 to !llvm.ptr<6>
    %218 = llvm.insertvalue %217, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %219 = llvm.insertvalue %217, %218[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %220 = llvm.insertvalue %14, %219[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %221 = llvm.insertvalue %18, %220[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %222 = llvm.insertvalue %10, %221[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %223 = llvm.extractvalue %194[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_1(%150, %116, %214, %211, %148, %arg22, %215, %216, %223, %217) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i32, i32, i32, f32, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %224 = llvm.inttoptr %42 : i64 to !llvm.ptr<6>
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_2(%224) {hivm.vector_function, no_inline} : (!llvm.ptr<6>) -> ()
    %225 = llvm.inttoptr %39 : i64 to !llvm.ptr<6>
    %226 = llvm.inttoptr %43 : i64 to !llvm.ptr<6>
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_3(%215, %217, %225, %226) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%225, %225, %14, %4, %10, %224, %224, %14, %4, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %227 = llvm.srem %195, %20  : i32
    %228 = llvm.icmp "eq" %227, %22 : i32
    llvm.cond_br %228, ^bb8(%164 : !llvm.ptr<6>), ^bb8(%170 : !llvm.ptr<6>)
  ^bb8(%229: !llvm.ptr<6>):  // 2 preds: ^bb7, ^bb7
    llvm.call @copy_ubuf_to_ubuf_1d_float(%226, %226, %14, %18, %10, %229, %229, %14, %18, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.br ^bb9
  ^bb9:  // pred: ^bb8
    %230 = llvm.inttoptr %44 : i64 to !llvm.ptr<6>
    %231 = llvm.inttoptr %45 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %232 = llvm.extractvalue %194[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_decode_sink_kernel_outlined_merged_vf_2(%232, %217, %230, %224, %231) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %228, ^bb10(%152 : !llvm.ptr<6>), ^bb10(%158 : !llvm.ptr<6>)
  ^bb10(%233: !llvm.ptr<6>):  // 2 preds: ^bb9, ^bb9
    llvm.call @copy_ubuf_to_ubuf_1d_float(%230, %230, %14, %18, %10, %233, %233, %14, %18, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.br ^bb11
  ^bb11:  // pred: ^bb10
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %118, ^bb12, ^bb13
  ^bb12:  // pred: ^bb11
    llvm.call @copy_ubuf_to_cbuf_2d_bfloat16_t(%231, %231, %14, %5, %11, %3, %10, %149, %149, %14, %5, %11, %11, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64) -> ()
    llvm.br ^bb13
  ^bb13:  // 2 preds: ^bb11, ^bb12
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %234 = llvm.load volatile %108 : !llvm.ptr<11> -> i32
    %235 = llvm.sub %234, %78 : i32
    llvm.store volatile %235, %108 : i32, !llvm.ptr<11>
    %236 = llvm.load volatile %110 : !llvm.ptr<11> -> i32
    %237 = llvm.add %236, %78 : i32
    llvm.store volatile %237, %110 : i32, !llvm.ptr<11>
    %238 = llvm.add %197, %78 : i32
    %239 = llvm.add %198, %78 : i32
    %240 = llvm.add %195, %78 : i32
    llvm.br ^bb15(%222, %238, %239, %240 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, i32, i32, i32)
  ^bb14:  // pred: ^bb6
    %241 = llvm.inttoptr %41 : i64 to !llvm.ptr<6>
    %242 = llvm.insertvalue %241, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %243 = llvm.insertvalue %241, %242[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %244 = llvm.insertvalue %14, %243[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %245 = llvm.insertvalue %18, %244[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %246 = llvm.insertvalue %10, %245[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %247 = llvm.extractvalue %194[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %248 = llvm.extractvalue %194[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %249 = llvm.extractvalue %194[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %250 = llvm.extractvalue %194[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %251 = llvm.extractvalue %194[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%247, %248, %249, %250, %251, %241, %241, %14, %18, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.br ^bb15(%246, %197, %198, %195 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, i32, i32, i32)
  ^bb15(%252: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %253: i32, %254: i32, %255: i32):  // 2 preds: ^bb13, ^bb14
    llvm.br ^bb16
  ^bb16:  // pred: ^bb15
    %256 = llvm.load volatile %107 : !llvm.ptr<11> -> i32
    %257 = llvm.icmp "sgt" %256, %22 : i32
    %258 = llvm.icmp "sgt" %253, %22 : i32
    %259 = llvm.icmp "sgt" %254, %22 : i32
    %260 = llvm.and %258, %259  : i1
    %261 = llvm.icmp "slt" %196, %136 : i32
    %262 = llvm.and %257, %260  : i1
    %263 = llvm.and %262, %261  : i1
    llvm.cond_br %263, ^bb17, ^bb18
  ^bb17:  // pred: ^bb16
    %264 = llvm.srem %196, %20  : i32
    %265 = llvm.icmp "eq" %264, %22 : i32
    %266 = llvm.select %265, %157, %163 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %267 = llvm.inttoptr %46 : i64 to !llvm.ptr<6>
    %268 = llvm.extractvalue %266[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_6(%268, %267) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %269 = llvm.select %265, %169, %175 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %270 = llvm.inttoptr %37 : i64 to !llvm.ptr<6>
    %271 = llvm.insertvalue %270, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %272 = llvm.insertvalue %270, %271[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %273 = llvm.insertvalue %14, %272[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %274 = llvm.insertvalue %18, %273[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %275 = llvm.insertvalue %10, %274[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %276 = llvm.inttoptr %38 : i64 to !llvm.ptr<6>
    %277 = llvm.insertvalue %276, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %278 = llvm.insertvalue %276, %277[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %279 = llvm.insertvalue %14, %278[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %280 = llvm.insertvalue %18, %279[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %281 = llvm.insertvalue %11, %280[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %282 = llvm.insertvalue %11, %281[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %283 = llvm.insertvalue %10, %282[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %284 = llvm.extractvalue %192[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %285 = llvm.extractvalue %269[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %286 = llvm.extractvalue %193[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_7(%284, %267, %285, %270, %151, %286, %276) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %287 = llvm.load volatile %107 : !llvm.ptr<11> -> i32
    %288 = llvm.sub %287, %78 : i32
    llvm.store volatile %288, %107 : i32, !llvm.ptr<11>
    %289 = llvm.sub %253, %78 : i32
    %290 = llvm.sub %254, %78 : i32
    %291 = llvm.add %196, %78 : i32
    llvm.br ^bb19(%275, %283, %289, %290, %291 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, i32, i32, i32)
  ^bb18:  // pred: ^bb16
    llvm.br ^bb19(%192, %193, %253, %254, %196 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, i32, i32, i32)
  ^bb19(%292: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %293: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %294: i32, %295: i32, %296: i32):  // 2 preds: ^bb17, ^bb18
    llvm.br ^bb20
  ^bb20:  // pred: ^bb19
    %297 = llvm.inttoptr %29 : i64 to !llvm.ptr<6>
    %298 = llvm.insertvalue %297, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %299 = llvm.insertvalue %297, %298[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %300 = llvm.insertvalue %14, %299[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %301 = llvm.insertvalue %18, %300[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %302 = llvm.insertvalue %10, %301[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %303 = llvm.extractvalue %252[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %304 = llvm.extractvalue %252[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %305 = llvm.extractvalue %252[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %306 = llvm.extractvalue %252[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %307 = llvm.extractvalue %252[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%303, %304, %305, %306, %307, %297, %297, %14, %18, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %308 = llvm.add %191, %78 overflow<nsw> : i32
    llvm.br ^bb5(%308, %292, %293, %302, %255, %296, %294, %295 : i32, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, i32, i32, i32, i32)
  ^bb21:  // pred: ^bb5
    %309 = llvm.inttoptr %47 : i64 to !llvm.ptr<2>
    %310 = llvm.inttoptr %48 : i64 to !llvm.ptr<6>
    %311 = llvm.inttoptr %49 : i64 to !llvm.ptr<6>
    %312 = llvm.inttoptr %50 : i64 to !llvm.ptr<6>
    %313 = llvm.insertvalue %312, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %314 = llvm.insertvalue %312, %313[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %315 = llvm.insertvalue %14, %314[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %316 = llvm.insertvalue %18, %315[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %317 = llvm.insertvalue %10, %316[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %318 = llvm.inttoptr %51 : i64 to !llvm.ptr<6>
    %319 = llvm.insertvalue %318, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %320 = llvm.insertvalue %318, %319[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %321 = llvm.insertvalue %14, %320[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %322 = llvm.insertvalue %18, %321[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %323 = llvm.insertvalue %10, %322[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %324 = llvm.inttoptr %52 : i64 to !llvm.ptr<6>
    %325 = llvm.insertvalue %324, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %326 = llvm.insertvalue %324, %325[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %327 = llvm.insertvalue %14, %326[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %328 = llvm.insertvalue %18, %327[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %329 = llvm.insertvalue %10, %328[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %330 = llvm.inttoptr %53 : i64 to !llvm.ptr<6>
    %331 = llvm.insertvalue %330, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %332 = llvm.insertvalue %330, %331[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %333 = llvm.insertvalue %14, %332[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %334 = llvm.insertvalue %18, %333[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %335 = llvm.insertvalue %10, %334[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %336 = llvm.sub %135, %140 : i32
    %337 = llvm.add %336, %77 : i32
    %338 = llvm.add %140, %337 : i32
    llvm.br ^bb22(%140, %192, %193, %194, %140, %140, %22, %22 : i32, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, i32, i32, i32, i32)
  ^bb22(%339: i32, %340: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %341: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %342: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %343: i32, %344: i32, %345: i32, %346: i32):  // 2 preds: ^bb21, ^bb41
    %347 = llvm.icmp "slt" %339, %338 : i32
    llvm.cond_br %347, ^bb23, ^bb42
  ^bb23:  // pred: ^bb22
    %348 = llvm.load volatile %103 : !llvm.ptr<11> -> i32
    %349 = llvm.icmp "sgt" %348, %22 : i32
    %350 = llvm.load volatile %105 : !llvm.ptr<11> -> i32
    %351 = llvm.icmp "slt" %350, %78 : i32
    %352 = llvm.and %349, %351  : i1
    %353 = llvm.icmp "slt" %345, %20 : i32
    %354 = llvm.icmp "slt" %346, %20 : i32
    %355 = llvm.and %353, %354  : i1
    %356 = llvm.icmp "slt" %343, %135 : i32
    %357 = llvm.and %352, %355  : i1
    %358 = llvm.and %357, %356  : i1
    llvm.cond_br %358, ^bb24, ^bb35
  ^bb24:  // pred: ^bb23
    %359 = llvm.mul %343, %15 : i32
    %360 = llvm.add %359, %15 : i32
    %361 = llvm.intr.smin(%360, %125)  : (i32, i32) -> i32
    %362 = llvm.sub %361, %359 : i32
    %363 = llvm.sext %362 : i32 to i64
    %364 = llvm.intr.smax(%363, %14)  : (i64, i64) -> i64
    %365 = llvm.intr.smin(%364, %66)  : (i64, i64) -> i64
    %366 = llvm.sext %359 : i32 to i64
    %367 = llvm.add %366, %2 : i64
    %368 = llvm.add %366, %1 : i64
    %369 = llvm.sext %148 : i32 to i64
    %370 = llvm.intr.smax(%367, %369)  : (i64, i64) -> i64
    %371 = llvm.intr.smin(%368, %370)  : (i64, i64) -> i64
    %372 = llvm.mul %366, %6 : i64
    %373 = llvm.add %371, %372 : i64
    %374 = llvm.add %373, %0 : i64
    %375 = llvm.intr.smax(%374, %14)  : (i64, i64) -> i64
    %376 = llvm.intr.smin(%365, %66)  : (i64, i64) -> i64
    %377 = llvm.mul %375, %6 : i64
    %378 = llvm.add %376, %377 : i64
    %379 = llvm.intr.smax(%378, %14)  : (i64, i64) -> i64
    %380 = llvm.add %375, %379 : i64
    %381 = llvm.icmp "slt" %375, %14 : i64
    %382 = llvm.icmp "sge" %375, %66 : i64
    %383 = llvm.or %381, %382  : i1
    llvm.cond_br %383, ^bb25, ^bb26
  ^bb25:  // pred: ^bb24
    %384 = llvm.inttoptr %54 : i64 to !llvm.ptr<6>
    %385 = llvm.insertvalue %384, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %386 = llvm.insertvalue %384, %385[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %387 = llvm.insertvalue %14, %386[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %388 = llvm.insertvalue %10, %387[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %389 = llvm.insertvalue %66, %388[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %390 = llvm.insertvalue %66, %389[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %391 = llvm.insertvalue %10, %390[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%114, %114, %14, %66, %10, %384, %384, %14, %66, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.br ^bb27(%391 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>)
  ^bb26:  // pred: ^bb24
    %392 = llvm.inttoptr %55 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%115, %115, %14, %66, %10, %392, %392, %14, %66, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_float(%114, %114, %14, %375, %10, %392, %392, %14, %375, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %393 = llvm.inttoptr %54 : i64 to !llvm.ptr<6>
    %394 = llvm.insertvalue %393, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %395 = llvm.insertvalue %393, %394[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %396 = llvm.insertvalue %14, %395[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %397 = llvm.insertvalue %10, %396[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %398 = llvm.insertvalue %66, %397[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %399 = llvm.insertvalue %66, %398[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %400 = llvm.insertvalue %10, %399[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%114, %114, %14, %66, %10, %393, %393, %14, %66, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_float(%392, %392, %14, %380, %10, %393, %393, %14, %380, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.br ^bb27(%400 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>)
  ^bb27(%401: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>):  // 2 preds: ^bb25, ^bb26
    llvm.br ^bb28
  ^bb28:  // pred: ^bb27
    %402 = llvm.inttoptr %56 : i64 to !llvm.ptr<6>
    %403 = llvm.inttoptr %57 : i64 to !llvm.ptr<6>
    %404 = llvm.inttoptr %58 : i64 to !llvm.ptr<6>
    %405 = llvm.insertvalue %404, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %406 = llvm.insertvalue %404, %405[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %407 = llvm.insertvalue %14, %406[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %408 = llvm.insertvalue %18, %407[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %409 = llvm.insertvalue %10, %408[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %410 = llvm.extractvalue %401[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %411 = llvm.extractvalue %342[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_8(%310, %410, %arg22, %402, %403, %411, %404) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, f32, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %412 = llvm.inttoptr %59 : i64 to !llvm.ptr<6>
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_9(%412) {hivm.vector_function, no_inline} : (!llvm.ptr<6>) -> ()
    %413 = llvm.inttoptr %56 : i64 to !llvm.ptr<6>
    %414 = llvm.inttoptr %60 : i64 to !llvm.ptr<6>
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_10(%402, %404, %413, %414) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%413, %413, %14, %4, %10, %412, %412, %14, %4, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %415 = llvm.sub %343, %140 : i32
    %416 = llvm.srem %415, %20  : i32
    %417 = llvm.icmp "eq" %416, %22 : i32
    llvm.cond_br %417, ^bb29(%324 : !llvm.ptr<6>), ^bb29(%330 : !llvm.ptr<6>)
  ^bb29(%418: !llvm.ptr<6>):  // 2 preds: ^bb28, ^bb28
    llvm.call @copy_ubuf_to_ubuf_1d_float(%414, %414, %14, %18, %10, %418, %418, %14, %18, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.br ^bb30
  ^bb30:  // pred: ^bb29
    %419 = llvm.inttoptr %61 : i64 to !llvm.ptr<6>
    %420 = llvm.inttoptr %62 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %421 = llvm.extractvalue %342[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_decode_sink_kernel_outlined_merged_vf_3(%421, %404, %419, %412, %420) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %417, ^bb31(%312 : !llvm.ptr<6>), ^bb31(%318 : !llvm.ptr<6>)
  ^bb31(%422: !llvm.ptr<6>):  // 2 preds: ^bb30, ^bb30
    llvm.call @copy_ubuf_to_ubuf_1d_float(%419, %419, %14, %18, %10, %422, %422, %14, %18, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.br ^bb32
  ^bb32:  // pred: ^bb31
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %118, ^bb33, ^bb34
  ^bb33:  // pred: ^bb32
    llvm.call @copy_ubuf_to_cbuf_2d_bfloat16_t(%420, %420, %14, %5, %11, %3, %10, %309, %309, %14, %5, %11, %11, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64) -> ()
    llvm.br ^bb34
  ^bb34:  // 2 preds: ^bb32, ^bb33
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %423 = llvm.load volatile %103 : !llvm.ptr<11> -> i32
    %424 = llvm.sub %423, %78 : i32
    llvm.store volatile %424, %103 : i32, !llvm.ptr<11>
    %425 = llvm.load volatile %105 : !llvm.ptr<11> -> i32
    %426 = llvm.add %425, %78 : i32
    llvm.store volatile %426, %105 : i32, !llvm.ptr<11>
    %427 = llvm.add %345, %78 : i32
    %428 = llvm.add %346, %78 : i32
    %429 = llvm.add %343, %78 : i32
    llvm.br ^bb36(%409, %427, %428, %429 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, i32, i32, i32)
  ^bb35:  // pred: ^bb23
    %430 = llvm.inttoptr %58 : i64 to !llvm.ptr<6>
    %431 = llvm.insertvalue %430, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %432 = llvm.insertvalue %430, %431[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %433 = llvm.insertvalue %14, %432[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %434 = llvm.insertvalue %18, %433[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %435 = llvm.insertvalue %10, %434[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %436 = llvm.extractvalue %342[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %437 = llvm.extractvalue %342[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %438 = llvm.extractvalue %342[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %439 = llvm.extractvalue %342[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %440 = llvm.extractvalue %342[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%436, %437, %438, %439, %440, %430, %430, %14, %18, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.br ^bb36(%435, %345, %346, %343 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, i32, i32, i32)
  ^bb36(%441: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %442: i32, %443: i32, %444: i32):  // 2 preds: ^bb34, ^bb35
    llvm.br ^bb37
  ^bb37:  // pred: ^bb36
    %445 = llvm.load volatile %101 : !llvm.ptr<11> -> i32
    %446 = llvm.icmp "sgt" %445, %22 : i32
    %447 = llvm.icmp "sgt" %442, %22 : i32
    %448 = llvm.icmp "sgt" %443, %22 : i32
    %449 = llvm.and %447, %448  : i1
    %450 = llvm.icmp "slt" %344, %135 : i32
    %451 = llvm.and %446, %449  : i1
    %452 = llvm.and %451, %450  : i1
    llvm.cond_br %452, ^bb38, ^bb39
  ^bb38:  // pred: ^bb37
    %453 = llvm.sub %344, %140 : i32
    %454 = llvm.srem %453, %20  : i32
    %455 = llvm.icmp "eq" %454, %22 : i32
    %456 = llvm.select %455, %317, %323 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %457 = llvm.inttoptr %63 : i64 to !llvm.ptr<6>
    %458 = llvm.extractvalue %456[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_13(%458, %457) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %459 = llvm.select %455, %329, %335 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %460 = llvm.inttoptr %37 : i64 to !llvm.ptr<6>
    %461 = llvm.insertvalue %460, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %462 = llvm.insertvalue %460, %461[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %463 = llvm.insertvalue %14, %462[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %464 = llvm.insertvalue %18, %463[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %465 = llvm.insertvalue %10, %464[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %466 = llvm.inttoptr %38 : i64 to !llvm.ptr<6>
    %467 = llvm.insertvalue %466, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %468 = llvm.insertvalue %466, %467[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %469 = llvm.insertvalue %14, %468[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %470 = llvm.insertvalue %18, %469[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %471 = llvm.insertvalue %11, %470[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %472 = llvm.insertvalue %11, %471[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %473 = llvm.insertvalue %10, %472[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %474 = llvm.extractvalue %340[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %475 = llvm.extractvalue %459[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %476 = llvm.extractvalue %341[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_14(%474, %457, %475, %460, %311, %476, %466) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %477 = llvm.load volatile %101 : !llvm.ptr<11> -> i32
    %478 = llvm.sub %477, %78 : i32
    llvm.store volatile %478, %101 : i32, !llvm.ptr<11>
    %479 = llvm.sub %442, %78 : i32
    %480 = llvm.sub %443, %78 : i32
    %481 = llvm.add %344, %78 : i32
    llvm.br ^bb40(%465, %473, %479, %480, %481 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, i32, i32, i32)
  ^bb39:  // pred: ^bb37
    llvm.br ^bb40(%340, %341, %442, %443, %344 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, i32, i32, i32)
  ^bb40(%482: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %483: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %484: i32, %485: i32, %486: i32):  // 2 preds: ^bb38, ^bb39
    llvm.br ^bb41
  ^bb41:  // pred: ^bb40
    %487 = llvm.inttoptr %29 : i64 to !llvm.ptr<6>
    %488 = llvm.insertvalue %487, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %489 = llvm.insertvalue %487, %488[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %490 = llvm.insertvalue %14, %489[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %491 = llvm.insertvalue %18, %490[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %492 = llvm.insertvalue %10, %491[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %493 = llvm.extractvalue %441[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %494 = llvm.extractvalue %441[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %495 = llvm.extractvalue %441[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %496 = llvm.extractvalue %441[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %497 = llvm.extractvalue %441[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%493, %494, %495, %496, %497, %487, %487, %14, %18, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %498 = llvm.add %339, %78 overflow<nsw> : i32
    llvm.br ^bb22(%498, %482, %483, %492, %444, %486, %484, %485 : i32, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, i32, i32, i32, i32)
  ^bb42:  // pred: ^bb22
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.cond_br %141, ^bb43, ^bb44
  ^bb43:  // pred: ^bb42
    %499 = llvm.inttoptr %38 : i64 to !llvm.ptr<6>
    %500 = llvm.insertvalue %499, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %501 = llvm.insertvalue %499, %500[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %502 = llvm.insertvalue %14, %501[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %503 = llvm.insertvalue %18, %502[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %504 = llvm.insertvalue %11, %503[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %505 = llvm.insertvalue %11, %504[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %506 = llvm.insertvalue %10, %505[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %507 = llvm.extractvalue %340[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %508 = llvm.extractvalue %341[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_15(%507, %508, %499) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    llvm.br ^bb45(%506 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>)
  ^bb44:  // pred: ^bb42
    llvm.br ^bb45(%341 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>)
  ^bb45(%509: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>):  // 2 preds: ^bb43, ^bb44
    llvm.br ^bb46
  ^bb46:  // pred: ^bb45
    %510 = llvm.mul %122, %arg19 : i32
    %511 = llvm.sext %510 : i32 to i64
    %512 = llvm.mul %127, %117 : i64
    %513 = llvm.add %511, %512 : i64
    %514 = llvm.inttoptr %64 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %515 = llvm.extractvalue %509[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_16(%515, %514) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %118, ^bb47, ^bb48
  ^bb47:  // pred: ^bb46
    llvm.call @store_ubuf_to_gm_2d_bfloat16_t(%514, %514, %14, %18, %11, %11, %10, %arg6, %arg6, %513, %18, %11, %117, %10, %22) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i32) -> ()
    llvm.br ^bb48
  ^bb48:  // 2 preds: ^bb46, ^bb47
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %516 = llvm.add %119, %arg23 overflow<nsw> : i32
    llvm.br ^bb1(%516 : i32)
  ^bb49:  // pred: ^bb1
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 0 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 1 : i64}> : () -> ()
    %517 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %518 = "hivm.intr.hivm.SBITSET1"(%517, %13) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%518) : (i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 6 : i64}> : () -> ()
    llvm.return
  }
}


bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
ld.lld: warning: -z separate-code and -z separate-loadable-segments will be ignored
