// -----// IR Dump After AppendUsePrintDebugData (append-use-print-debug-data) //----- //
module attributes {dlti.target_system_spec = #dlti.target_system_spec<"NPU" : #hacc.target_device_spec<#dlti.dl_entry<"AI_CORE_COUNT", 28 : i32>, #dlti.dl_entry<"CUBE_CORE_COUNT", 28 : i32>, #dlti.dl_entry<"VECTOR_CORE_COUNT", 56 : i32>, #dlti.dl_entry<"UB_SIZE", 2031616 : i32>, #dlti.dl_entry<"L1_SIZE", 4194304 : i32>, #dlti.dl_entry<"L0A_SIZE", 524288 : i32>, #dlti.dl_entry<"L0B_SIZE", 524288 : i32>, #dlti.dl_entry<"L0C_SIZE", 2097152 : i32>, #dlti.dl_entry<"UB_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L1_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L0C_ALIGN_SIZE", 4096 : i32>, #dlti.dl_entry<"MINIMAL_D_CACHE_SIZE", 262144 : i32>, #dlti.dl_entry<"MAXIMUM_D_CACHE_SIZE", 983040 : i32>, #dlti.dl_entry<"ARCH", "dav-c310">>>, hacc.target = #hacc.target<"Ascend950PR_957b">, hivm.aic_bitcode = #hivm.aic_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.aic.c310.bc">, hivm.aiv_bitcode = #hivm.aiv_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.aiv.c310.bc">, hivm.host_bitcode = #hivm.host_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/host-a5.bc">, hivm.mix_aic_bitcode = #hivm.mix_aic_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.mix.aic.c310.bc">, hivm.mix_aiv_bitcode = #hivm.mix_aiv_bitcode<"/usr/local/Ascend/cann-9.1.0/tools/bishengir/lib/meta_op.mix.aiv.c310.bc">, hivm.module_core_type = #hivm.module_core_type<MIX>} {
  llvm.func @_swa_paged_decode_sink_kernel_outlined_merged_merged_vf_0(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(64 : i32) : i32
    %1 = llvm.mlir.constant(256 : i32) : i32
    %2 = llvm.mlir.constant(1 : i32) : i32
    %3 = llvm.mlir.constant(12 : i32) : i32
    %4 = llvm.mlir.constant(1.000000e+00 : f32) : f32
    %5 = llvm.mlir.constant(0 : i32) : i32
    %6 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %7 = llvm.mlir.constant(-1.07374182E+9 : f32) : f32
    %8 = llvm.mlir.constant(8 : i32) : i32
    %9 = llvm.mlir.constant(2 : i32) : i32
    %10 = llvm.mlir.constant(256 : index) : i64
    %11 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %12 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%7, %11, %2) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %13 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %14 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%6, %13, %2) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %15 = "hivm_regbaseintrins.intr.hivm.vci"(%5, %5) : (i32, i32) -> vector<64xi32>
    %16 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %17 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%5, %16, %2) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    %18 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %19 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%4, %18, %2) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    llvm.br ^bb1(%5 : i32)
  ^bb1(%20: i32):  // 2 preds: ^bb0, ^bb5
    %21 = llvm.icmp "slt" %20, %3 : i32
    llvm.cond_br %21, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %22 = llvm.sext %20 : i32 to i64
    llvm.br ^bb3(%5 : i32)
  ^bb3(%23: i32):  // 2 preds: ^bb2, ^bb4
    %24 = llvm.icmp "slt" %23, %1 : i32
    llvm.cond_br %24, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %25 = llvm.sext %23 : i32 to i64
    %26 = llvm.mul %22, %10 : i64
    %27 = llvm.add %26, %25 : i64
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = llvm.getelementptr %arg0[%27] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%14, %29, %5, %9, %5, %28) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %30 = llvm.add %23, %0 overflow<nsw> : i32
    llvm.br ^bb3(%30 : i32)
  ^bb5:  // pred: ^bb3
    %31 = llvm.add %20, %2 overflow<nsw> : i32
    llvm.br ^bb1(%31 : i32)
  ^bb6:  // pred: ^bb1
    %32 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%3) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %33 = llvm.extractvalue %32[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%19, %arg1, %5, %9, %5, %33) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %34 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%12, %arg2, %5, %9, %5, %34) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %35 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%14, %arg3, %5, %9, %5, %35) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %36 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %37 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%17, %15, %36) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    %38 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%8, %5) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64s32"(%37, %arg4, %5, %9, %5, %38) : (vector<64xi32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_merged_vf_3(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(16 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(12 : i32) : i32
    %4 = llvm.mlir.constant(2 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(1114112 : i32) : i32
    %7 = llvm.mlir.constant(64 : index) : i64
    %8 = llvm.mlir.constant(16 : index) : i64
    %9 = llvm.mlir.constant(272 : index) : i64
    %10 = llvm.mlir.constant(0 : index) : i64
    %11 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%3) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %12 = llvm.extractvalue %11[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %13 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %14 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %15 = "hivm_regbaseintrins.intr.hivm.vsub.s.x"(%13, %14, %12) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%15, %arg2, %2, %4, %2, %12) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.br ^bb1(%2 : i32)
  ^bb1(%16: i32):  // 2 preds: ^bb0, ^bb2
    %17 = llvm.icmp "slt" %16, %1 : i32
    llvm.cond_br %17, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %16 : i32 to i64
    %19 = llvm.mul %18, %7 : i64
    %20 = llvm.getelementptr %arg3[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %21 = llvm.mul %10, %7 : i64
    %22 = llvm.add %21, %10 : i64
    %23 = llvm.getelementptr %20[%22] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %24 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%23, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %25 = llvm.mul %18, %8 : i64
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%5, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %27 = llvm.getelementptr %arg4[%25] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %28 = llvm.mul %10, %9 : i64
    %29 = llvm.add %28, %10 : i64
    %30 = llvm.getelementptr %27[%29] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vsstb.v128bf16"(%24, %30, %6, %2, %26) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, vector<256xi1>) -> ()
    %31 = llvm.add %16, %0 overflow<nsw> : i32
    llvm.br ^bb1(%31 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_merged_vf_2(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(16 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(12 : i32) : i32
    %4 = llvm.mlir.constant(2 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(1114112 : i32) : i32
    %7 = llvm.mlir.constant(64 : index) : i64
    %8 = llvm.mlir.constant(16 : index) : i64
    %9 = llvm.mlir.constant(272 : index) : i64
    %10 = llvm.mlir.constant(0 : index) : i64
    %11 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%3) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %12 = llvm.extractvalue %11[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %13 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %14 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %15 = "hivm_regbaseintrins.intr.hivm.vsub.s.x"(%13, %14, %12) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%15, %arg2, %2, %4, %2, %12) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.br ^bb1(%2 : i32)
  ^bb1(%16: i32):  // 2 preds: ^bb0, ^bb2
    %17 = llvm.icmp "slt" %16, %1 : i32
    llvm.cond_br %17, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %16 : i32 to i64
    %19 = llvm.mul %18, %7 : i64
    %20 = llvm.getelementptr %arg3[%19] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %21 = llvm.mul %10, %7 : i64
    %22 = llvm.add %21, %10 : i64
    %23 = llvm.getelementptr %20[%22] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %24 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%23, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    %25 = llvm.mul %18, %8 : i64
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%5, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %27 = llvm.getelementptr %arg4[%25] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %28 = llvm.mul %10, %9 : i64
    %29 = llvm.add %28, %10 : i64
    %30 = llvm.getelementptr %27[%29] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vsstb.v128bf16"(%24, %30, %6, %2, %26) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, vector<256xi1>) -> ()
    %31 = llvm.add %16, %0 overflow<nsw> : i32
    llvm.br ^bb1(%31 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_0(%arg0: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(0xFF800000 : f32) : f32
    %1 = llvm.mlir.constant(8 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(1 : i32) : i32
    %4 = llvm.mlir.constant(12 : i32) : i32
    %5 = llvm.mlir.constant(2 : i32) : i32
    %6 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%1, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %7 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%0, %6, %3) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %8 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%4) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %9 = llvm.extractvalue %8[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%7, %arg0, %2, %5, %2, %9) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_1(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i32, %arg3: i32, %arg4: i32, %arg5: f32, %arg6: !llvm.ptr<6>, %arg7: !llvm.ptr<6>, %arg8: !llvm.ptr<6>, %arg9: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(12 : i32) : i32
    %2 = llvm.mlir.constant(511 : i32) : i32
    %3 = llvm.mlir.constant(0 : i32) : i32
    %4 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %5 = llvm.mlir.constant(-1.07374182E+9 : f32) : f32
    %6 = llvm.mlir.constant(8 : i32) : i32
    %7 = llvm.mlir.constant(2 : i32) : i32
    %8 = llvm.mlir.constant(4 : i32) : i32
    %9 = llvm.mlir.undef : !llvm.ptr<6>
    %10 = llvm.mlir.constant(64 : index) : i64
    %11 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %12 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%5, %11, %0) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %13 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %14 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%4, %13, %0) : (f32, vector<256xi1>, i32) -> vector<64xf32>
    %15 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %16 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%3, %15, %0) : (i32, vector<256xi1>, i32) -> vector<64xi32>
    llvm.br ^bb1(%3 : i32)
  ^bb1(%17: i32):  // 2 preds: ^bb0, ^bb2
    %18 = llvm.icmp "slt" %17, %1 : i32
    llvm.cond_br %18, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %19 = llvm.sext %17 : i32 to i64
    %20 = llvm.mul %19, %10 : i64
    %21 = llvm.getelementptr %arg0[%20] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %22 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%21, %3, %3, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %23 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64s32"(%arg1, %3, %3, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xi32>
    %24 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg2) : (i32) -> vector<64xi32>
    %25 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %26 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%23, %24, %25) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<256xi1>
    %27 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg3) : (i32) -> vector<64xi32>
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%27, %23, %28) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    %30 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %31 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%29, %2, %30) : (vector<64xi32>, i32, vector<256xi1>) -> vector<64xi32>
    %32 = "hivm_regbaseintrins.intr.hivm.vbr"(%arg4) : (i32) -> vector<64xi32>
    %33 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %34 = "hivm_regbaseintrins.intr.hivm.vcmp.ge.s.z"(%31, %32, %33) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<256xi1>
    %35 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %36 = "hivm_regbaseintrins.intr.hivm.vcmp.lt.s.z"(%29, %16, %35) : (vector<64xi32>, vector<64xi32>, vector<256xi1>) -> vector<256xi1>
    %37 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %38 = "hivm_regbaseintrins.intr.hivm.por.z"(%36, %34, %37) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %39 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %40 = "hivm_regbaseintrins.intr.hivm.pand.z"(%38, %26, %39) : (vector<256xi1>, vector<256xi1>, vector<256xi1>) -> vector<256xi1>
    %41 = "hivm_regbaseintrins.intr.hivm.vsel"(%14, %12, %40) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %42 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %43 = "hivm_regbaseintrins.intr.hivm.vmuls.s.x"(%22, %arg5, %42) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %44 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %45 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%43, %41, %44) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %46 = llvm.mul %19, %10 : i64
    %47 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %48 = llvm.getelementptr %arg6[%46] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%45, %48, %3, %7, %3, %47) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %49 = llvm.add %17, %0 overflow<nsw> : i32
    llvm.br ^bb1(%49 : i32)
  ^bb3:  // pred: ^bb1
    %50 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb4(%3, %50, %9 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb4(%51: i32, %52: vector<32xi8>, %53: !llvm.ptr<6>):  // 2 preds: ^bb3, ^bb5
    %54 = llvm.icmp "slt" %51, %1 : i32
    llvm.cond_br %54, ^bb5, ^bb6
  ^bb5:  // pred: ^bb4
    %55 = llvm.sext %51 : i32 to i64
    %56 = llvm.mul %55, %10 : i64
    %57 = llvm.getelementptr %arg6[%56] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %58 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%57, %3, %3, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %59 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %60 = "hivm_regbaseintrins.intr.hivm.vcmax.s.x"(%58, %59) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %61 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %3) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %62 = llvm.getelementptr %arg7[%55] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %63 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%60, %62, %8, %52) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %64 = llvm.extractvalue %63[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %65 = llvm.extractvalue %63[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %66 = llvm.add %51, %0 overflow<nsw> : i32
    llvm.br ^bb4(%66, %64, %65 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb6:  // pred: ^bb4
    "hivm_regbaseintrins.intr.hivm.vstas"(%52, %53, %3, %3) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %67 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%1) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %68 = llvm.extractvalue %67[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %69 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg8, %3, %3, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %70 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg7, %3, %3, %3) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %71 = "hivm_regbaseintrins.intr.hivm.vmax.s.x"(%69, %70, %68) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%71, %arg9, %3, %7, %3, %68) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_2(%arg0: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(9 : i32) : i32
    %1 = llvm.mlir.constant(0.000000e+00 : bf16) : bf16
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(16 : i32) : i32
    %4 = llvm.mlir.constant(1 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(64 : index) : i64
    %7 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%0, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %8 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%1, %7, %4) : (bf16, vector<256xi1>, i32) -> vector<128xbf16>
    llvm.br ^bb1(%2 : i32)
  ^bb1(%9: i32):  // 2 preds: ^bb0, ^bb2
    %10 = llvm.icmp "slt" %9, %3 : i32
    llvm.cond_br %10, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %11 = llvm.sext %9 : i32 to i64
    %12 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%5, %2) {mask_bit_width = 16 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %13 = llvm.mul %11, %6 : i64
    %14 = llvm.getelementptr %arg0[%13] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%8, %14, %2, %4, %2, %12) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %15 = llvm.add %9, %4 overflow<nsw> : i32
    llvm.br ^bb1(%15 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_3(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(12 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %4 = llvm.mlir.constant(3 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(7 : i32) : i32
    %7 = llvm.mlir.constant(4 : i32) : i32
    %8 = llvm.mlir.undef : !llvm.ptr<6>
    %9 = llvm.mlir.constant(64 : index) : i64
    %10 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %10, %8 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%11: i32, %12: vector<32xi8>, %13: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %14 = llvm.icmp "slt" %11, %1 : i32
    llvm.cond_br %14, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %15 = llvm.sext %11 : i32 to i64
    %16 = llvm.mul %15, %9 : i64
    %17 = llvm.getelementptr %arg0[%16] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %18 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%17, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %19 = llvm.getelementptr %arg1[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %20 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%19, %2, %4, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%18, %20, %21, %2) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %23 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %24 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%22, %23, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %25 = llvm.mul %15, %9 : i64
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %27 = llvm.getelementptr %arg2[%25] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%24, %27, %2, %6, %2, %26) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%22, %3, %28) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %30 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %31 = "hivm_regbaseintrins.intr.hivm.vcadd.s.x"(%29, %30) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %32 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %33 = llvm.getelementptr %arg3[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %34 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%31, %33, %7, %12) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %35 = llvm.extractvalue %34[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %36 = llvm.extractvalue %34[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %37 = llvm.add %11, %0 overflow<nsw> : i32
    llvm.br ^bb1(%37, %35, %36 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%12, %13, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_6(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(12 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %4 = llvm.extractvalue %3[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %5 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %6 = "hivm_regbaseintrins.intr.hivm.vexp.x"(%5, %4) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%6, %arg1, %1, %2, %1, %4) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_7(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(64 : i32) : i32
    %1 = llvm.mlir.constant(256 : i32) : i32
    %2 = llvm.mlir.constant(1 : i32) : i32
    %3 = llvm.mlir.constant(12 : i32) : i32
    %4 = llvm.mlir.constant(0 : i32) : i32
    %5 = llvm.mlir.constant(2 : i32) : i32
    %6 = llvm.mlir.constant(3 : i32) : i32
    %7 = llvm.mlir.constant(8 : i32) : i32
    %8 = llvm.mlir.constant(256 : index) : i64
    %9 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%3) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %10 = llvm.extractvalue %9[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %11 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %12 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %13 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg2, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %14 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%11, %12, %10) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %15 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%14, %13, %10) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%15, %arg3, %4, %5, %4, %10) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.br ^bb1(%4 : i32)
  ^bb1(%16: i32):  // 2 preds: ^bb0, ^bb5
    %17 = llvm.icmp "slt" %16, %3 : i32
    llvm.cond_br %17, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %16 : i32 to i64
    llvm.br ^bb3(%4 : i32)
  ^bb3(%19: i32):  // 2 preds: ^bb2, ^bb4
    %20 = llvm.icmp "slt" %19, %1 : i32
    llvm.cond_br %20, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %21 = llvm.sext %19 : i32 to i64
    %22 = llvm.mul %18, %8 : i64
    %23 = llvm.add %22, %21 : i64
    %24 = llvm.getelementptr %arg4[%23] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %25 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%24, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %26 = llvm.mul %18, %8 : i64
    %27 = llvm.add %26, %21 : i64
    %28 = llvm.getelementptr %arg5[%27] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %29 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%28, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %30 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %31 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%30, %4, %6, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %32 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %33 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%29, %31, %32) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %34 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %35 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%25, %33, %34) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %36 = llvm.mul %18, %8 : i64
    %37 = llvm.add %36, %21 : i64
    %38 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %39 = llvm.getelementptr %arg6[%37] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%35, %39, %4, %5, %4, %38) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %40 = llvm.add %19, %0 overflow<nsw> : i32
    llvm.br ^bb3(%40 : i32)
  ^bb5:  // pred: ^bb3
    %41 = llvm.add %16, %2 overflow<nsw> : i32
    llvm.br ^bb1(%41 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_8(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: f32, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(0 : i32) : i32
    %1 = llvm.mlir.constant(12 : i32) : i32
    %2 = llvm.mlir.constant(1 : i32) : i32
    %3 = llvm.mlir.constant(8 : i32) : i32
    %4 = llvm.mlir.constant(2 : i32) : i32
    %5 = llvm.mlir.constant(4 : i32) : i32
    %6 = llvm.mlir.undef : !llvm.ptr<6>
    %7 = llvm.mlir.constant(64 : index) : i64
    %8 = llvm.mlir.constant(0 : index) : i64
    llvm.br ^bb1(%0 : i32)
  ^bb1(%9: i32):  // 2 preds: ^bb0, ^bb2
    %10 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %10, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %11 = llvm.sext %9 : i32 to i64
    %12 = llvm.mul %11, %7 : i64
    %13 = llvm.getelementptr %arg0[%12] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %14 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%13, %0, %0, %0) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %15 = llvm.mul %8, %7 : i64
    %16 = llvm.add %15, %8 : i64
    %17 = llvm.getelementptr %arg1[%16] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %18 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%17, %0, %0, %0) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %19 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %20 = "hivm_regbaseintrins.intr.hivm.vmuls.s.x"(%14, %arg2, %19) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%20, %18, %21) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %23 = llvm.mul %11, %7 : i64
    %24 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %25 = llvm.getelementptr %arg3[%23] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%22, %25, %0, %4, %0, %24) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %26 = llvm.add %9, %2 overflow<nsw> : i32
    llvm.br ^bb1(%26 : i32)
  ^bb3:  // pred: ^bb1
    %27 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb4(%0, %27, %6 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb4(%28: i32, %29: vector<32xi8>, %30: !llvm.ptr<6>):  // 2 preds: ^bb3, ^bb5
    %31 = llvm.icmp "slt" %28, %1 : i32
    llvm.cond_br %31, ^bb5, ^bb6
  ^bb5:  // pred: ^bb4
    %32 = llvm.sext %28 : i32 to i64
    %33 = llvm.mul %32, %7 : i64
    %34 = llvm.getelementptr %arg3[%33] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %35 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%34, %0, %0, %0) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %36 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %37 = "hivm_regbaseintrins.intr.hivm.vcmax.s.x"(%35, %36) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %38 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %0) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %39 = llvm.getelementptr %arg4[%32] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %40 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%37, %39, %5, %29) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %41 = llvm.extractvalue %40[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %42 = llvm.extractvalue %40[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %43 = llvm.add %28, %2 overflow<nsw> : i32
    llvm.br ^bb4(%43, %41, %42 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb6:  // pred: ^bb4
    "hivm_regbaseintrins.intr.hivm.vstas"(%29, %30, %0, %0) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %44 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%1) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %45 = llvm.extractvalue %44[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %46 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg5, %0, %0, %0) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %47 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg4, %0, %0, %0) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %48 = "hivm_regbaseintrins.intr.hivm.vmax.s.x"(%46, %47, %45) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%48, %arg6, %0, %4, %0, %45) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_9(%arg0: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(9 : i32) : i32
    %1 = llvm.mlir.constant(0.000000e+00 : bf16) : bf16
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(16 : i32) : i32
    %4 = llvm.mlir.constant(1 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(64 : index) : i64
    %7 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%0, %2) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %8 = "hivm_regbaseintrins.intr.hivm.vdups.z"(%1, %7, %4) : (bf16, vector<256xi1>, i32) -> vector<128xbf16>
    llvm.br ^bb1(%2 : i32)
  ^bb1(%9: i32):  // 2 preds: ^bb0, ^bb2
    %10 = llvm.icmp "slt" %9, %3 : i32
    llvm.cond_br %10, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %11 = llvm.sext %9 : i32 to i64
    %12 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%5, %2) {mask_bit_width = 16 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %13 = llvm.mul %11, %6 : i64
    %14 = llvm.getelementptr %arg0[%13] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%8, %14, %2, %4, %2, %12) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %15 = llvm.add %9, %4 overflow<nsw> : i32
    llvm.br ^bb1(%15 : i32)
  ^bb3:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_10(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(12 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %4 = llvm.mlir.constant(3 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(7 : i32) : i32
    %7 = llvm.mlir.constant(4 : i32) : i32
    %8 = llvm.mlir.undef : !llvm.ptr<6>
    %9 = llvm.mlir.constant(64 : index) : i64
    %10 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    llvm.br ^bb1(%2, %10, %8 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb1(%11: i32, %12: vector<32xi8>, %13: !llvm.ptr<6>):  // 2 preds: ^bb0, ^bb2
    %14 = llvm.icmp "slt" %11, %1 : i32
    llvm.cond_br %14, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %15 = llvm.sext %11 : i32 to i64
    %16 = llvm.mul %15, %9 : i64
    %17 = llvm.getelementptr %arg0[%16] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %18 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%17, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %19 = llvm.getelementptr %arg1[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %20 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%19, %2, %4, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.vexpdif"(%18, %20, %21, %2) : (vector<64xf32>, vector<64xf32>, vector<256xi1>, i32) -> vector<64xf32>
    %23 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %24 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%22, %23, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %25 = llvm.mul %15, %9 : i64
    %26 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %27 = llvm.getelementptr %arg2[%25] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%24, %27, %2, %6, %2, %26) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %28 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %29 = "hivm_regbaseintrins.intr.hivm.vadds.s.x"(%22, %3, %28) : (vector<64xf32>, f32, vector<256xi1>) -> vector<64xf32>
    %30 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %31 = "hivm_regbaseintrins.intr.hivm.vcadd.s.x"(%29, %30) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %32 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%0, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %33 = llvm.getelementptr %arg3[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %34 = "hivm_regbaseintrins.intr.hivm.vstus.post.f32"(%31, %33, %7, %12) {hivm.is_continuous} : (vector<64xf32>, !llvm.ptr<6>, i32, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %35 = llvm.extractvalue %34[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %36 = llvm.extractvalue %34[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %37 = llvm.add %11, %0 overflow<nsw> : i32
    llvm.br ^bb1(%37, %35, %36 : i32, vector<32xi8>, !llvm.ptr<6>)
  ^bb3:  // pred: ^bb1
    "hivm_regbaseintrins.intr.hivm.vstas"(%12, %13, %2, %2) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_13(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(12 : i32) : i32
    %1 = llvm.mlir.constant(0 : i32) : i32
    %2 = llvm.mlir.constant(2 : i32) : i32
    %3 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%0) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %4 = llvm.extractvalue %3[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %5 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %1, %1, %1) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %6 = "hivm_regbaseintrins.intr.hivm.vexp.x"(%5, %4) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%6, %arg1, %1, %2, %1, %4) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_14(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>, %arg3: !llvm.ptr<6>, %arg4: !llvm.ptr<6>, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(64 : i32) : i32
    %1 = llvm.mlir.constant(256 : i32) : i32
    %2 = llvm.mlir.constant(1 : i32) : i32
    %3 = llvm.mlir.constant(12 : i32) : i32
    %4 = llvm.mlir.constant(0 : i32) : i32
    %5 = llvm.mlir.constant(2 : i32) : i32
    %6 = llvm.mlir.constant(3 : i32) : i32
    %7 = llvm.mlir.constant(8 : i32) : i32
    %8 = llvm.mlir.constant(256 : index) : i64
    %9 = "hivm_regbaseintrins.intr.hivm.plt.b32.v300"(%3) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %10 = llvm.extractvalue %9[0] {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %11 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg0, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %12 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg1, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %13 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%arg2, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %14 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%11, %12, %10) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %15 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%14, %13, %10) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%15, %arg3, %4, %5, %4, %10) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    llvm.br ^bb1(%4 : i32)
  ^bb1(%16: i32):  // 2 preds: ^bb0, ^bb5
    %17 = llvm.icmp "slt" %16, %3 : i32
    llvm.cond_br %17, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %18 = llvm.sext %16 : i32 to i64
    llvm.br ^bb3(%4 : i32)
  ^bb3(%19: i32):  // 2 preds: ^bb2, ^bb4
    %20 = llvm.icmp "slt" %19, %1 : i32
    llvm.cond_br %20, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %21 = llvm.sext %19 : i32 to i64
    %22 = llvm.mul %18, %8 : i64
    %23 = llvm.add %22, %21 : i64
    %24 = llvm.getelementptr %arg4[%23] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %25 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%24, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %26 = llvm.mul %18, %8 : i64
    %27 = llvm.add %26, %21 : i64
    %28 = llvm.getelementptr %arg5[%27] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %29 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%28, %4, %4, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %30 = llvm.getelementptr %arg1[%18] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %31 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%30, %4, %6, %4) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %32 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %33 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%29, %31, %32) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %34 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %35 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%25, %33, %34) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %36 = llvm.mul %18, %8 : i64
    %37 = llvm.add %36, %21 : i64
    %38 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%7, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %39 = llvm.getelementptr %arg6[%37] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%35, %39, %4, %5, %4, %38) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %40 = llvm.add %19, %0 overflow<nsw> : i32
    llvm.br ^bb3(%40 : i32)
  ^bb5:  // pred: ^bb3
    %41 = llvm.add %16, %2 overflow<nsw> : i32
    llvm.br ^bb1(%41 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_15(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(12 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(256 : i32) : i32
    %4 = llvm.mlir.constant(64 : i32) : i32
    %5 = llvm.mlir.constant(3 : i32) : i32
    %6 = llvm.mlir.constant(8 : i32) : i32
    %7 = llvm.mlir.constant(2 : i32) : i32
    %8 = llvm.mlir.constant(256 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%9: i32):  // 2 preds: ^bb0, ^bb5
    %10 = llvm.icmp "slt" %9, %1 : i32
    llvm.cond_br %10, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %11 = llvm.sext %9 : i32 to i64
    llvm.br ^bb3(%2 : i32)
  ^bb3(%12: i32):  // 2 preds: ^bb2, ^bb4
    %13 = llvm.icmp "slt" %12, %3 : i32
    llvm.cond_br %13, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %14 = llvm.sext %12 : i32 to i64
    %15 = llvm.mul %11, %8 : i64
    %16 = llvm.add %15, %14 : i64
    %17 = llvm.getelementptr %arg1[%16] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %18 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%17, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %19 = llvm.getelementptr %arg0[%11] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %20 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%19, %2, %5, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %21 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %22 = "hivm_regbaseintrins.intr.hivm.vdiv.s.x"(%18, %20, %21) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    %23 = llvm.mul %11, %8 : i64
    %24 = llvm.add %23, %14 : i64
    %25 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%6, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %26 = llvm.getelementptr %arg2[%24] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%22, %26, %2, %7, %2, %25) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %27 = llvm.add %12, %4 overflow<nsw> : i32
    llvm.br ^bb3(%27 : i32)
  ^bb5:  // pred: ^bb3
    %28 = llvm.add %9, %0 overflow<nsw> : i32
    llvm.br ^bb1(%28 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_outlined_vf_16(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function} {
    %0 = llvm.mlir.constant(1 : i32) : i32
    %1 = llvm.mlir.constant(12 : i32) : i32
    %2 = llvm.mlir.constant(0 : i32) : i32
    %3 = llvm.mlir.constant(256 : i32) : i32
    %4 = llvm.mlir.constant(64 : i32) : i32
    %5 = llvm.mlir.constant(8 : i32) : i32
    %6 = llvm.mlir.constant(7 : i32) : i32
    %7 = llvm.mlir.constant(256 : index) : i64
    llvm.br ^bb1(%2 : i32)
  ^bb1(%8: i32):  // 2 preds: ^bb0, ^bb5
    %9 = llvm.icmp "slt" %8, %1 : i32
    llvm.cond_br %9, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    %10 = llvm.sext %8 : i32 to i64
    llvm.br ^bb3(%2 : i32)
  ^bb3(%11: i32):  // 2 preds: ^bb2, ^bb4
    %12 = llvm.icmp "slt" %11, %3 : i32
    llvm.cond_br %12, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %13 = llvm.sext %11 : i32 to i64
    %14 = llvm.mul %10, %7 : i64
    %15 = llvm.add %14, %13 : i64
    %16 = llvm.getelementptr %arg0[%15] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %17 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%16, %2, %2, %2) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    %18 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %19 = "hivm_regbaseintrins.intr.hivm.vcvtff.f322bf16.x"(%17, %18, %2, %2, %2) : (vector<64xf32>, vector<256xi1>, i32, i32, i32) -> vector<128xbf16>
    %20 = llvm.mul %10, %7 : i64
    %21 = llvm.add %20, %13 : i64
    %22 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%5, %2) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %23 = llvm.getelementptr %arg1[%21] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    "hivm_regbaseintrins.intr.hivm.vstsx1.v128bf16"(%19, %23, %2, %6, %2, %22) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    %24 = llvm.add %11, %4 overflow<nsw> : i32
    llvm.br ^bb3(%24 : i32)
  ^bb5:  // pred: ^bb3
    %25 = llvm.add %8, %0 overflow<nsw> : i32
    llvm.br ^bb1(%25 : i32)
  ^bb6:  // pred: ^bb1
    llvm.return
  }
  llvm.func @_swa_paged_decode_sink_kernel_mix_aic(%arg0: i64, %arg1: !llvm.ptr<1>, %arg2: !llvm.ptr<1>, %arg3: !llvm.ptr<1>, %arg4: !llvm.ptr<1>, %arg5: !llvm.ptr<1>, %arg6: !llvm.ptr<1>, %arg7: !llvm.ptr<1>, %arg8: !llvm.ptr<1>, %arg9: !llvm.ptr<1>, %arg10: i32, %arg11: i32, %arg12: i32, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32, %arg17: i32, %arg18: i32, %arg19: i32, %arg20: i32, %arg21: i32, %arg22: f32, %arg23: i32, %arg24: i32, %arg25: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, hivm.vf_mode = #hivm.vf_mode<SIMD>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, mix_mode = "mix", parallel_mode = "simd"} {
    %0 = llvm.mlir.constant(15 : index) : i64
    %1 = llvm.mlir.constant(-1 : index) : i64
    %2 = llvm.mlir.constant(48 : i64) : i64
    %3 = llvm.mlir.constant(60 : i64) : i64
    %4 = llvm.mlir.constant(16384 : index) : i64
    %5 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %6 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %7 = llvm.mlir.constant(1024 : index) : i64
    %8 = llvm.mlir.constant(1 : index) : i64
    %9 = llvm.mlir.constant(4 : index) : i64
    %10 = llvm.mlir.constant(0 : index) : i64
    %11 = llvm.mlir.constant(0 : i8) : i8
    %12 = llvm.mlir.constant(false) : i1
    %13 = llvm.mlir.constant(1.000000e+00 : f32) : f32
    %14 = llvm.mlir.constant(39424 : i64) : i64
    %15 = llvm.mlir.constant(36352 : i64) : i64
    %16 = llvm.mlir.constant(75776 : i64) : i64
    %17 = llvm.mlir.constant(16192 : i64) : i64
    %18 = llvm.mlir.constant(13120 : i64) : i64
    %19 = llvm.mlir.constant(8192 : i64) : i64
    %20 = llvm.mlir.constant(16 : index) : i64
    %21 = llvm.mlir.constant(1024 : i64) : i64
    %22 = llvm.mlir.constant(0 : i64) : i64
    %23 = llvm.mlir.constant(0 : i32) : i32
    %24 = llvm.mlir.constant(2 : i32) : i32
    %25 = llvm.mlir.constant(12 : index) : i64
    %26 = llvm.mlir.constant(512 : i32) : i32
    %27 = llvm.mlir.constant(63 : i32) : i32
    %28 = llvm.mlir.constant(64 : i32) : i32
    %29 = llvm.mlir.constant(12 : i32) : i32
    %30 = llvm.mlir.constant(0.000000e+00 : bf16) : bf16
    %31 = llvm.mlir.constant(64 : index) : i64
    %32 = llvm.mlir.constant(256 : index) : i64
    %33 = llvm.mlir.constant(4 : i64) : i64
    %34 = llvm.mlir.constant(1028 : i64) : i64
    %35 = llvm.mlir.constant(8 : i64) : i64
    %36 = llvm.mlir.constant(1032 : i64) : i64
    %37 = llvm.mlir.constant(12 : i64) : i64
    %38 = llvm.mlir.constant(1036 : i64) : i64
    %39 = llvm.mlir.constant(16 : i64) : i64
    %40 = llvm.mlir.constant(1040 : i64) : i64
    %41 = llvm.mlir.constant(20 : i64) : i64
    %42 = llvm.mlir.constant(1044 : i64) : i64
    %43 = llvm.mlir.constant(3 : i32) : i32
    %44 = llvm.mlir.constant(1 : i32) : i32
    %45 = llvm.mlir.constant(true) : i1
    %46 = llvm.mlir.constant(2 : i64) : i64
    %47 = llvm.mlir.constant(1 : i64) : i64
    %48 = llvm.mlir.constant(3 : i64) : i64
    %49 = llvm.mlir.constant(5 : i64) : i64
    %50 = llvm.mlir.constant(6 : i64) : i64
    %51 = llvm.mlir.constant(-1 : i64) : i64
    %52 = llvm.mlir.constant(217088 : i64) : i64
    %53 = llvm.mlir.constant(77824 : i64) : i64
    %54 = llvm.mlir.constant(61440 : i64) : i64
    %55 = llvm.mlir.constant(20480 : i64) : i64
    %56 = llvm.mlir.constant(249856 : i64) : i64
    %57 = llvm.mlir.constant(110592 : i64) : i64
    %58 = llvm.mlir.constant(65536 : i64) : i64
    %59 = llvm.mlir.constant(24576 : i64) : i64
    %60 = llvm.mlir.constant(151552 : i64) : i64
    %61 = llvm.mlir.constant(10240 : i64) : i64
    %62 = llvm.mlir.constant(184320 : i64) : i64
    %63 = llvm.mlir.constant(43008 : i64) : i64
    %64 = llvm.mlir.constant(45056 : i64) : i64
    %65 = llvm.mlir.constant(4096 : i64) : i64
    %66 = llvm.mlir.constant(143360 : i64) : i64
    %67 = llvm.mlir.constant(40960 : i64) : i64
    %68 = llvm.inttoptr %22 : i64 to !llvm.ptr<5>
    %69 = llvm.insertvalue %68, %6[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %70 = llvm.insertvalue %68, %69[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %71 = llvm.insertvalue %10, %70[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %72 = llvm.insertvalue %9, %71[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %73 = llvm.insertvalue %8, %72[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %74 = llvm.insertvalue %20, %73[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %75 = llvm.insertvalue %20, %74[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %76 = llvm.insertvalue %32, %75[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %77 = llvm.insertvalue %32, %76[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %78 = llvm.insertvalue %20, %77[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %79 = llvm.insertvalue %8, %78[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %80 = llvm.inttoptr %67 : i64 to !llvm.ptr<5>
    %81 = llvm.insertvalue %80, %6[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %82 = llvm.insertvalue %80, %81[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %83 = llvm.insertvalue %10, %82[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %84 = llvm.insertvalue %9, %83[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %85 = llvm.insertvalue %8, %84[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %86 = llvm.insertvalue %20, %85[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %87 = llvm.insertvalue %20, %86[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %88 = llvm.insertvalue %32, %87[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %89 = llvm.insertvalue %32, %88[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %90 = llvm.insertvalue %20, %89[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %91 = llvm.insertvalue %8, %90[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %92 = llvm.inttoptr %22 : i64 to !llvm.ptr<2>
    %93 = llvm.insertvalue %92, %5[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %94 = llvm.insertvalue %92, %93[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %95 = llvm.insertvalue %10, %94[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %96 = llvm.insertvalue %20, %95[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %97 = llvm.insertvalue %8, %96[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %98 = llvm.insertvalue %20, %97[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %99 = llvm.insertvalue %20, %98[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %100 = llvm.insertvalue %32, %99[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %101 = llvm.insertvalue %32, %100[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %102 = llvm.insertvalue %20, %101[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %103 = llvm.insertvalue %8, %102[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %104 = llvm.inttoptr %66 : i64 to !llvm.ptr<2>
    %105 = llvm.insertvalue %104, %5[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %106 = llvm.insertvalue %104, %105[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %107 = llvm.insertvalue %10, %106[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %108 = llvm.insertvalue %20, %107[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %109 = llvm.insertvalue %8, %108[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %110 = llvm.insertvalue %20, %109[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %111 = llvm.insertvalue %20, %110[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %112 = llvm.insertvalue %32, %111[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %113 = llvm.insertvalue %32, %112[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %114 = llvm.insertvalue %20, %113[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %115 = llvm.insertvalue %8, %114[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %116 = llvm.inttoptr %65 : i64 to !llvm.ptr<5>
    %117 = llvm.insertvalue %116, %6[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %118 = llvm.insertvalue %116, %117[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %119 = llvm.insertvalue %10, %118[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %120 = llvm.insertvalue %20, %119[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %121 = llvm.insertvalue %8, %120[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %122 = llvm.insertvalue %20, %121[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %123 = llvm.insertvalue %20, %122[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %124 = llvm.insertvalue %32, %123[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %125 = llvm.insertvalue %32, %124[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %126 = llvm.insertvalue %20, %125[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %127 = llvm.insertvalue %8, %126[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %128 = llvm.inttoptr %64 : i64 to !llvm.ptr<5>
    %129 = llvm.insertvalue %128, %6[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %130 = llvm.insertvalue %128, %129[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %131 = llvm.insertvalue %10, %130[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %132 = llvm.insertvalue %20, %131[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %133 = llvm.insertvalue %8, %132[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %134 = llvm.insertvalue %20, %133[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %135 = llvm.insertvalue %20, %134[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %136 = llvm.insertvalue %32, %135[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %137 = llvm.insertvalue %32, %136[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %138 = llvm.insertvalue %20, %137[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %139 = llvm.insertvalue %8, %138[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %140 = llvm.inttoptr %63 : i64 to !llvm.ptr<2>
    %141 = llvm.insertvalue %140, %5[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %142 = llvm.insertvalue %140, %141[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %143 = llvm.insertvalue %10, %142[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %144 = llvm.insertvalue %20, %143[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %145 = llvm.insertvalue %9, %144[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %146 = llvm.insertvalue %20, %145[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %147 = llvm.insertvalue %20, %146[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %148 = llvm.insertvalue %7, %147[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %149 = llvm.insertvalue %32, %148[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %150 = llvm.insertvalue %20, %149[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %151 = llvm.insertvalue %8, %150[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %152 = llvm.inttoptr %62 : i64 to !llvm.ptr<2>
    %153 = llvm.insertvalue %152, %5[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %154 = llvm.insertvalue %152, %153[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %155 = llvm.insertvalue %10, %154[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %156 = llvm.insertvalue %20, %155[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %157 = llvm.insertvalue %9, %156[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %158 = llvm.insertvalue %20, %157[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %159 = llvm.insertvalue %20, %158[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %160 = llvm.insertvalue %7, %159[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %161 = llvm.insertvalue %32, %160[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %162 = llvm.insertvalue %20, %161[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %163 = llvm.insertvalue %8, %162[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %164 = llvm.inttoptr %61 : i64 to !llvm.ptr<2>
    %165 = llvm.insertvalue %164, %5[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %166 = llvm.insertvalue %164, %165[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %167 = llvm.insertvalue %10, %166[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %168 = llvm.insertvalue %20, %167[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %169 = llvm.insertvalue %9, %168[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %170 = llvm.insertvalue %20, %169[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %171 = llvm.insertvalue %20, %170[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %172 = llvm.insertvalue %7, %171[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %173 = llvm.insertvalue %32, %172[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %174 = llvm.insertvalue %20, %173[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %175 = llvm.insertvalue %8, %174[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %176 = llvm.inttoptr %60 : i64 to !llvm.ptr<2>
    %177 = llvm.insertvalue %176, %5[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %178 = llvm.insertvalue %176, %177[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %179 = llvm.insertvalue %10, %178[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %180 = llvm.insertvalue %20, %179[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %181 = llvm.insertvalue %9, %180[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %182 = llvm.insertvalue %20, %181[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %183 = llvm.insertvalue %20, %182[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %184 = llvm.insertvalue %7, %183[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %185 = llvm.insertvalue %32, %184[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %186 = llvm.insertvalue %20, %185[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %187 = llvm.insertvalue %8, %186[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %188 = llvm.inttoptr %59 : i64 to !llvm.ptr<5>
    %189 = llvm.insertvalue %188, %6[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %190 = llvm.insertvalue %188, %189[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %191 = llvm.insertvalue %10, %190[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %192 = llvm.insertvalue %20, %191[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %193 = llvm.insertvalue %8, %192[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %194 = llvm.insertvalue %20, %193[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %195 = llvm.insertvalue %20, %194[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %196 = llvm.insertvalue %32, %195[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %197 = llvm.insertvalue %32, %196[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %198 = llvm.insertvalue %20, %197[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %199 = llvm.insertvalue %8, %198[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %200 = llvm.inttoptr %58 : i64 to !llvm.ptr<5>
    %201 = llvm.insertvalue %200, %6[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %202 = llvm.insertvalue %200, %201[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %203 = llvm.insertvalue %10, %202[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %204 = llvm.insertvalue %20, %203[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %205 = llvm.insertvalue %8, %204[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %206 = llvm.insertvalue %20, %205[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %207 = llvm.insertvalue %20, %206[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %208 = llvm.insertvalue %32, %207[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %209 = llvm.insertvalue %32, %208[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %210 = llvm.insertvalue %20, %209[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %211 = llvm.insertvalue %8, %210[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %212 = llvm.inttoptr %57 : i64 to !llvm.ptr<2>
    %213 = llvm.insertvalue %212, %5[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %214 = llvm.insertvalue %212, %213[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %215 = llvm.insertvalue %10, %214[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %216 = llvm.insertvalue %20, %215[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %217 = llvm.insertvalue %9, %216[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %218 = llvm.insertvalue %20, %217[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %219 = llvm.insertvalue %20, %218[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %220 = llvm.insertvalue %7, %219[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %221 = llvm.insertvalue %32, %220[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %222 = llvm.insertvalue %20, %221[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %223 = llvm.insertvalue %8, %222[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %224 = llvm.inttoptr %56 : i64 to !llvm.ptr<2>
    %225 = llvm.insertvalue %224, %5[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %226 = llvm.insertvalue %224, %225[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %227 = llvm.insertvalue %10, %226[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %228 = llvm.insertvalue %20, %227[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %229 = llvm.insertvalue %9, %228[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %230 = llvm.insertvalue %20, %229[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %231 = llvm.insertvalue %20, %230[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %232 = llvm.insertvalue %7, %231[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %233 = llvm.insertvalue %32, %232[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %234 = llvm.insertvalue %20, %233[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %235 = llvm.insertvalue %8, %234[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %236 = llvm.inttoptr %55 : i64 to !llvm.ptr<5>
    %237 = llvm.insertvalue %236, %6[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %238 = llvm.insertvalue %236, %237[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %239 = llvm.insertvalue %10, %238[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %240 = llvm.insertvalue %9, %239[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %241 = llvm.insertvalue %8, %240[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %242 = llvm.insertvalue %20, %241[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %243 = llvm.insertvalue %20, %242[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %244 = llvm.insertvalue %32, %243[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %245 = llvm.insertvalue %32, %244[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %246 = llvm.insertvalue %20, %245[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %247 = llvm.insertvalue %8, %246[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %248 = llvm.inttoptr %54 : i64 to !llvm.ptr<5>
    %249 = llvm.insertvalue %248, %6[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %250 = llvm.insertvalue %248, %249[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %251 = llvm.insertvalue %10, %250[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %252 = llvm.insertvalue %9, %251[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %253 = llvm.insertvalue %8, %252[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %254 = llvm.insertvalue %20, %253[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %255 = llvm.insertvalue %20, %254[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %256 = llvm.insertvalue %32, %255[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %257 = llvm.insertvalue %32, %256[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %258 = llvm.insertvalue %20, %257[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %259 = llvm.insertvalue %8, %258[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %260 = llvm.inttoptr %53 : i64 to !llvm.ptr<2>
    %261 = llvm.insertvalue %260, %5[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %262 = llvm.insertvalue %260, %261[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %263 = llvm.insertvalue %10, %262[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %264 = llvm.insertvalue %20, %263[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %265 = llvm.insertvalue %9, %264[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %266 = llvm.insertvalue %20, %265[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %267 = llvm.insertvalue %20, %266[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %268 = llvm.insertvalue %7, %267[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %269 = llvm.insertvalue %32, %268[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %270 = llvm.insertvalue %20, %269[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %271 = llvm.insertvalue %8, %270[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %272 = llvm.inttoptr %52 : i64 to !llvm.ptr<2>
    %273 = llvm.insertvalue %272, %5[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %274 = llvm.insertvalue %272, %273[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %275 = llvm.insertvalue %10, %274[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %276 = llvm.insertvalue %20, %275[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %277 = llvm.insertvalue %9, %276[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %278 = llvm.insertvalue %20, %277[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %279 = llvm.insertvalue %20, %278[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %280 = llvm.insertvalue %7, %279[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %281 = llvm.insertvalue %32, %280[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %282 = llvm.insertvalue %20, %281[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %283 = llvm.insertvalue %8, %282[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %284 = llvm.alloca %8 x i64 : (i64) -> !llvm.ptr
    llvm.store %22, %284 : i64, !llvm.ptr
    %285 = llvm.alloca %8 x i64 : (i64) -> !llvm.ptr
    llvm.store %22, %285 : i64, !llvm.ptr
    %286 = llvm.alloca %8 x i64 : (i64) -> !llvm.ptr
    llvm.store %22, %286 : i64, !llvm.ptr
    %287 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %288 = "hivm.intr.hivm.SBITSET0"(%287, %3) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%288) : (i64) -> ()
    %289 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %290 = "hivm.intr.hivm.SBITSET1"(%289, %2) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%290) : (i64) -> ()
    %291 = "hivm.intr.hivm.GET.BLOCK.IDX"() : () -> i64
    %292 = llvm.trunc %291 : i64 to i32
    %293 = llvm.srem %292, %arg23  : i32
    %294 = llvm.inttoptr %22 : i64 to !llvm.ptr<11>
    %295 = llvm.inttoptr %21 : i64 to !llvm.ptr<11>
    llvm.store volatile %23, %294 : i32, !llvm.ptr<11>
    llvm.store volatile %23, %295 : i32, !llvm.ptr<11>
    %296 = llvm.inttoptr %33 : i64 to !llvm.ptr<11>
    %297 = llvm.inttoptr %34 : i64 to !llvm.ptr<11>
    llvm.store volatile %23, %296 : i32, !llvm.ptr<11>
    llvm.store volatile %23, %297 : i32, !llvm.ptr<11>
    %298 = llvm.inttoptr %35 : i64 to !llvm.ptr<11>
    %299 = llvm.inttoptr %36 : i64 to !llvm.ptr<11>
    llvm.store volatile %23, %298 : i32, !llvm.ptr<11>
    llvm.store volatile %23, %299 : i32, !llvm.ptr<11>
    %300 = llvm.inttoptr %37 : i64 to !llvm.ptr<11>
    %301 = llvm.inttoptr %38 : i64 to !llvm.ptr<11>
    llvm.store volatile %23, %300 : i32, !llvm.ptr<11>
    llvm.store volatile %23, %301 : i32, !llvm.ptr<11>
    %302 = llvm.inttoptr %39 : i64 to !llvm.ptr<11>
    %303 = llvm.inttoptr %40 : i64 to !llvm.ptr<11>
    llvm.store volatile %23, %302 : i32, !llvm.ptr<11>
    llvm.store volatile %23, %303 : i32, !llvm.ptr<11>
    %304 = llvm.inttoptr %41 : i64 to !llvm.ptr<11>
    %305 = llvm.inttoptr %42 : i64 to !llvm.ptr<11>
    llvm.store volatile %23, %304 : i32, !llvm.ptr<11>
    llvm.store volatile %23, %305 : i32, !llvm.ptr<11>
    %306 = llvm.mul %arg10, %24 : i32
    %307 = llvm.sdiv %306, %arg23  : i32
    %308 = llvm.mul %307, %arg23 : i32
    %309 = llvm.sub %306, %308 : i32
    %310 = llvm.mul %293, %307 : i32
    %311 = llvm.intr.smin(%293, %309)  : (i32, i32) -> i32
    %312 = llvm.add %310, %311 : i32
    %313 = llvm.sitofp %293 : i32 to f32
    %314 = llvm.sitofp %309 : i32 to f32
    %315 = llvm.fcmp "olt" %313, %314 : f32
    %316 = llvm.zext %315 : i1 to i32
    %317 = llvm.add %307, %316 : i32
    %318 = llvm.add %312, %317 : i32
    %319 = llvm.sext %arg12 : i32 to i64
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 17 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 3 : i64, sync_id = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 16 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.INTRA.BLOCKI.mode"() <{pipe = 10 : i64, sync_id = 0 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 4 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 5 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 6 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    llvm.br ^bb1(%312 : i32)
  ^bb1(%320: i32):  // 2 preds: ^bb0, ^bb40
    %321 = llvm.icmp "slt" %320, %318 : i32
    llvm.cond_br %321, ^bb2, ^bb41
  ^bb2:  // pred: ^bb1
    %322 = llvm.load %284 : !llvm.ptr -> i64
    %323 = llvm.urem %322, %46  : i64
    %324 = llvm.icmp "eq" %323, %47 : i64
    %325 = llvm.select %324, %115, %103 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %326 = llvm.trunc %323 : i64 to i1
    %327 = llvm.xor %326, %45  : i1
    %328 = llvm.zext %327 : i1 to i64
    %329 = llvm.sdiv %320, %24  : i32
    %330 = llvm.sext %329 : i32 to i64
    %331 = llvm.getelementptr %arg7[%330] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %332 = llvm.load %331 : !llvm.ptr<1> -> i32
    %333 = llvm.add %332, %27 : i32
    %334 = llvm.sdiv %333, %28  : i32
    %335 = llvm.intr.smin(%334, %23)  : (i32, i32) -> i32
    %336 = llvm.sub %332, %26 : i32
    %337 = llvm.intr.smax(%336, %23)  : (i32, i32) -> i32
    %338 = llvm.sdiv %337, %28  : i32
    %339 = llvm.intr.smax(%335, %338)  : (i32, i32) -> i32
    %340 = llvm.mul %329, %24 : i32
    %341 = llvm.sub %320, %340 : i32
    %342 = llvm.mul %341, %29 : i32
    %343 = llvm.mul %329, %arg11 : i32
    %344 = llvm.sext %343 : i32 to i64
    %345 = llvm.sext %342 : i32 to i64
    %346 = llvm.mul %345, %319 : i64
    %347 = llvm.add %344, %346 : i64
    "hivm.intr.hivm.WAIT.FLAG.REG"(%328) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    %348 = llvm.extractvalue %325[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %349 = llvm.extractvalue %325[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %350 = llvm.extractvalue %325[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %351 = llvm.extractvalue %325[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %352 = llvm.extractvalue %325[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %353 = llvm.extractvalue %325[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %354 = llvm.extractvalue %325[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %355 = llvm.extractvalue %325[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %356 = llvm.extractvalue %325[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %357 = llvm.extractvalue %325[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %358 = llvm.extractvalue %325[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @nd2nz_bfloat16_t(%arg3, %arg3, %347, %25, %32, %319, %8, %348, %349, %350, %351, %352, %353, %354, %355, %356, %357, %358) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    %359 = llvm.mul %329, %arg21 : i32
    %360 = llvm.sext %359 : i32 to i64
    %361 = llvm.mul %341, %arg14 : i32
    %362 = llvm.mul %341, %arg17 : i32
    %363 = llvm.inttoptr %19 : i64 to !llvm.ptr<2>
    %364 = llvm.inttoptr %18 : i64 to !llvm.ptr<6>
    %365 = llvm.inttoptr %17 : i64 to !llvm.ptr<6>
    %366 = llvm.add %335, %43 : i32
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    llvm.br ^bb3(%23, %23, %23, %23 : i32, i32, i32, i32)
  ^bb3(%367: i32, %368: i32, %369: i32, %370: i32):  // 2 preds: ^bb2, ^bb20
    %371 = llvm.icmp "slt" %367, %366 : i32
    llvm.cond_br %371, ^bb4, ^bb21
  ^bb4:  // pred: ^bb3
    %372 = llvm.load %286 : !llvm.ptr -> i64
    %373 = llvm.urem %372, %46  : i64
    %374 = llvm.icmp "eq" %373, %47 : i64
    %375 = llvm.select %374, %91, %79 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %376 = llvm.select %374, %139, %127 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %377 = llvm.select %374, %163, %151 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %378 = llvm.select %374, %187, %175 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %379 = llvm.trunc %373 : i64 to i1
    %380 = llvm.select %379, %46, %48 : i1, i64
    %381 = llvm.select %379, %49, %50 : i1, i64
    %382 = llvm.xor %379, %45  : i1
    %383 = llvm.zext %382 : i1 to i64
    %384 = llvm.select %379, %48, %33 : i1, i64
    %385 = llvm.icmp "slt" %368, %335 : i32
    llvm.cond_br %385, ^bb5, ^bb6
  ^bb5:  // pred: ^bb4
    %386 = llvm.add %368, %44 : i32
    llvm.br ^bb7(%386 : i32)
  ^bb6:  // pred: ^bb4
    llvm.br ^bb7(%368 : i32)
  ^bb7(%387: i32):  // 2 preds: ^bb5, ^bb6
    llvm.br ^bb8
  ^bb8:  // pred: ^bb7
    %388 = llvm.load volatile %294 : !llvm.ptr<11> -> i32
    %389 = llvm.load volatile %295 : !llvm.ptr<11> -> i32
    %390 = llvm.icmp "slt" %388, %44 : i32
    %391 = llvm.icmp "slt" %389, %44 : i32
    %392 = llvm.and %390, %391  : i1
    %393 = llvm.icmp "slt" %369, %335 : i32
    %394 = llvm.and %392, %393  : i1
    llvm.cond_br %394, ^bb9, ^bb12
  ^bb9:  // pred: ^bb8
    %395 = llvm.mul %369, %28 : i32
    %396 = llvm.add %395, %28 : i32
    %397 = llvm.intr.smin(%396, %332)  : (i32, i32) -> i32
    %398 = llvm.sub %397, %395 : i32
    %399 = llvm.sext %398 : i32 to i64
    %400 = llvm.sext %arg15 : i32 to i64
    %401 = llvm.intr.smax(%399, %10)  : (i64, i64) -> i64
    %402 = llvm.intr.smin(%401, %31)  : (i64, i64) -> i64
    %403 = llvm.intr.smin(%402, %10)  : (i64, i64) -> i64
    %404 = llvm.mul %403, %1 : i64
    %405 = llvm.add %402, %404 : i64
    %406 = llvm.icmp "slt" %405, %31 : i64
    %407 = llvm.sdiv %395, %28  : i32
    %408 = llvm.srem %395, %28  : i32
    %409 = llvm.sext %407 : i32 to i64
    %410 = llvm.add %360, %409 : i64
    %411 = llvm.getelementptr %arg8[%410] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %412 = llvm.load %411 : !llvm.ptr<1> -> i32
    %413 = llvm.mul %412, %arg13 : i32
    %414 = llvm.sext %413 : i32 to i64
    %415 = llvm.sext %361 : i32 to i64
    %416 = llvm.mul %408, %arg15 : i32
    %417 = llvm.sext %416 : i32 to i64
    %418 = llvm.add %417, %414 : i64
    %419 = llvm.add %418, %415 : i64
    %420 = llvm.mul %403, %1 : i64
    %421 = llvm.add %402, %420 : i64
    %422 = llvm.add %421, %0 : i64
    %423 = llvm.icmp "slt" %422, %10 : i64
    %424 = llvm.sub %1, %422 : i64
    %425 = llvm.select %423, %424, %422 : i1, i64
    %426 = llvm.sdiv %425, %20  : i64
    %427 = llvm.sub %1, %426 : i64
    %428 = llvm.select %423, %427, %426 : i1, i64
    %429 = llvm.extractvalue %378[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %430 = llvm.extractvalue %378[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %431 = llvm.mul %403, %20 : i64
    llvm.cond_br %406, ^bb10, ^bb11
  ^bb10:  // pred: ^bb9
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %432 = llvm.extractvalue %378[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %433 = llvm.extractvalue %378[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%30, %432, %433, %10, %4, %8) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb11
  ^bb11:  // 2 preds: ^bb9, ^bb10
    "hivm.intr.hivm.WAIT.FLAG.REG"(%384) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.call @nd2nz_bfloat16_t(%arg4, %arg4, %419, %405, %32, %400, %8, %429, %430, %431, %20, %428, %20, %20, %7, %32, %20, %8) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%383) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %434 = llvm.extractvalue %325[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %435 = llvm.extractvalue %325[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %436 = llvm.extractvalue %325[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %437 = llvm.extractvalue %325[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %438 = llvm.extractvalue %325[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %439 = llvm.extractvalue %325[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %440 = llvm.extractvalue %325[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %441 = llvm.extractvalue %325[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %442 = llvm.extractvalue %325[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %443 = llvm.extractvalue %325[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %444 = llvm.extractvalue %325[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %445 = llvm.extractvalue %378[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %446 = llvm.extractvalue %378[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %447 = llvm.extractvalue %378[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %448 = llvm.extractvalue %378[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %449 = llvm.extractvalue %378[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %450 = llvm.extractvalue %378[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %451 = llvm.extractvalue %378[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %452 = llvm.extractvalue %378[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %453 = llvm.extractvalue %378[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %454 = llvm.extractvalue %378[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %455 = llvm.extractvalue %378[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %456 = llvm.extractvalue %375[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %457 = llvm.extractvalue %375[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %458 = llvm.extractvalue %375[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %459 = llvm.extractvalue %375[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %460 = llvm.extractvalue %375[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %461 = llvm.extractvalue %375[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %462 = llvm.extractvalue %375[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %463 = llvm.extractvalue %375[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %464 = llvm.extractvalue %375[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %465 = llvm.extractvalue %375[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %466 = llvm.extractvalue %375[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float_tb(%434, %435, %436, %437, %438, %439, %440, %441, %442, %443, %444, %445, %446, %447, %448, %449, %450, %451, %452, %453, %454, %455, %45, %25, %32, %31, %456, %457, %458, %459, %460, %461, %462, %463, %464, %465, %466, %51, %22, %51, %384, %51, %51, %51, %11) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 10 : i64}> : () -> ()
    %467 = llvm.extractvalue %375[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %468 = llvm.extractvalue %375[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %469 = llvm.extractvalue %375[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %470 = llvm.extractvalue %375[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %471 = llvm.extractvalue %375[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %472 = llvm.extractvalue %375[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %473 = llvm.extractvalue %375[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %474 = llvm.extractvalue %375[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %475 = llvm.extractvalue %375[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %476 = llvm.extractvalue %375[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %477 = llvm.extractvalue %375[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%467, %468, %469, %470, %471, %472, %473, %474, %475, %476, %477, %364, %364, %10, %25, %31, %31, %8, %22, %13, %22, %12, %11) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%383) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %478 = llvm.load volatile %294 : !llvm.ptr<11> -> i32
    %479 = llvm.load volatile %295 : !llvm.ptr<11> -> i32
    %480 = llvm.add %478, %44 : i32
    %481 = llvm.add %479, %44 : i32
    llvm.store volatile %480, %294 : i32, !llvm.ptr<11>
    llvm.store volatile %481, %295 : i32, !llvm.ptr<11>
    %482 = llvm.add %369, %44 : i32
    llvm.br ^bb13(%482 : i32)
  ^bb12:  // pred: ^bb8
    llvm.br ^bb13(%369 : i32)
  ^bb13(%483: i32):  // 2 preds: ^bb11, ^bb12
    llvm.br ^bb14
  ^bb14:  // pred: ^bb13
    %484 = llvm.load volatile %302 : !llvm.ptr<11> -> i32
    %485 = llvm.load volatile %303 : !llvm.ptr<11> -> i32
    %486 = llvm.icmp "sgt" %484, %23 : i32
    %487 = llvm.icmp "sgt" %485, %23 : i32
    %488 = llvm.and %486, %487  : i1
    %489 = llvm.load volatile %296 : !llvm.ptr<11> -> i32
    %490 = llvm.load volatile %297 : !llvm.ptr<11> -> i32
    %491 = llvm.icmp "slt" %489, %44 : i32
    %492 = llvm.icmp "slt" %490, %44 : i32
    %493 = llvm.and %491, %492  : i1
    %494 = llvm.and %488, %493  : i1
    %495 = llvm.icmp "slt" %370, %335 : i32
    %496 = llvm.and %494, %495  : i1
    llvm.cond_br %496, ^bb15, ^bb18
  ^bb15:  // pred: ^bb14
    %497 = llvm.mul %370, %28 : i32
    %498 = llvm.add %497, %28 : i32
    %499 = llvm.intr.smin(%498, %332)  : (i32, i32) -> i32
    %500 = llvm.sub %499, %497 : i32
    %501 = llvm.sext %arg18 : i32 to i64
    %502 = llvm.sext %500 : i32 to i64
    %503 = llvm.intr.smax(%502, %10)  : (i64, i64) -> i64
    %504 = llvm.intr.smin(%503, %31)  : (i64, i64) -> i64
    %505 = llvm.intr.smin(%504, %10)  : (i64, i64) -> i64
    %506 = llvm.mul %505, %1 : i64
    %507 = llvm.add %504, %506 : i64
    %508 = llvm.icmp "slt" %507, %31 : i64
    %509 = llvm.sdiv %497, %28  : i32
    %510 = llvm.srem %497, %28  : i32
    %511 = llvm.sext %509 : i32 to i64
    %512 = llvm.add %360, %511 : i64
    %513 = llvm.getelementptr %arg8[%512] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %514 = llvm.load %513 : !llvm.ptr<1> -> i32
    %515 = llvm.mul %514, %arg16 : i32
    %516 = llvm.sext %515 : i32 to i64
    %517 = llvm.sext %362 : i32 to i64
    %518 = llvm.mul %510, %arg18 : i32
    %519 = llvm.sext %518 : i32 to i64
    %520 = llvm.add %519, %516 : i64
    %521 = llvm.add %520, %517 : i64
    %522 = llvm.mul %505, %1 : i64
    %523 = llvm.add %504, %522 : i64
    %524 = llvm.add %523, %0 : i64
    %525 = llvm.icmp "slt" %524, %10 : i64
    %526 = llvm.sub %1, %524 : i64
    %527 = llvm.select %525, %526, %524 : i1, i64
    %528 = llvm.sdiv %527, %20  : i64
    %529 = llvm.sub %1, %528 : i64
    %530 = llvm.select %525, %529, %528 : i1, i64
    %531 = llvm.extractvalue %377[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %532 = llvm.extractvalue %377[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %533 = llvm.mul %505, %20 : i64
    llvm.cond_br %508, ^bb16, ^bb17
  ^bb16:  // pred: ^bb15
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %534 = llvm.extractvalue %377[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %535 = llvm.extractvalue %377[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%30, %534, %535, %10, %4, %8) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb17
  ^bb17:  // 2 preds: ^bb15, ^bb16
    "hivm.intr.hivm.WAIT.FLAG.REG"(%381) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.call @nd2nz_bfloat16_t(%arg5, %arg5, %521, %507, %32, %501, %8, %531, %532, %533, %20, %530, %20, %20, %7, %32, %20, %8) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%380) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %536 = llvm.extractvalue %377[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %537 = llvm.extractvalue %377[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %538 = llvm.extractvalue %377[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %539 = llvm.extractvalue %377[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %540 = llvm.extractvalue %377[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %541 = llvm.extractvalue %377[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %542 = llvm.extractvalue %377[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %543 = llvm.extractvalue %377[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %544 = llvm.extractvalue %377[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %545 = llvm.extractvalue %377[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %546 = llvm.extractvalue %377[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %547 = llvm.extractvalue %376[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %548 = llvm.extractvalue %376[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %549 = llvm.extractvalue %376[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %550 = llvm.extractvalue %376[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %551 = llvm.extractvalue %376[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %552 = llvm.extractvalue %376[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %553 = llvm.extractvalue %376[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %554 = llvm.extractvalue %376[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %555 = llvm.extractvalue %376[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %556 = llvm.extractvalue %376[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %557 = llvm.extractvalue %376[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float(%363, %363, %10, %9, %8, %20, %20, %32, %32, %20, %8, %536, %537, %538, %539, %540, %541, %542, %543, %544, %545, %546, %45, %20, %31, %32, %547, %548, %549, %550, %551, %552, %553, %554, %555, %556, %557, %51, %22, %51, %381, %51, %51, %51, %11) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 10 : i64}> : () -> ()
    %558 = llvm.extractvalue %376[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %559 = llvm.extractvalue %376[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %560 = llvm.extractvalue %376[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %561 = llvm.extractvalue %376[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %562 = llvm.extractvalue %376[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %563 = llvm.extractvalue %376[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %564 = llvm.extractvalue %376[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %565 = llvm.extractvalue %376[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %566 = llvm.extractvalue %376[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %567 = llvm.extractvalue %376[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %568 = llvm.extractvalue %376[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%558, %559, %560, %561, %562, %563, %564, %565, %566, %567, %568, %365, %365, %10, %25, %32, %32, %8, %22, %13, %22, %12, %11) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%380) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %569 = llvm.load volatile %302 : !llvm.ptr<11> -> i32
    %570 = llvm.load volatile %303 : !llvm.ptr<11> -> i32
    %571 = llvm.sub %569, %44 : i32
    %572 = llvm.sub %570, %44 : i32
    llvm.store volatile %571, %302 : i32, !llvm.ptr<11>
    llvm.store volatile %572, %303 : i32, !llvm.ptr<11>
    %573 = llvm.load volatile %296 : !llvm.ptr<11> -> i32
    %574 = llvm.load volatile %297 : !llvm.ptr<11> -> i32
    %575 = llvm.add %573, %44 : i32
    %576 = llvm.add %574, %44 : i32
    llvm.store volatile %575, %296 : i32, !llvm.ptr<11>
    llvm.store volatile %576, %297 : i32, !llvm.ptr<11>
    %577 = llvm.add %370, %44 : i32
    llvm.br ^bb19(%577 : i32)
  ^bb18:  // pred: ^bb14
    llvm.br ^bb19(%370 : i32)
  ^bb19(%578: i32):  // 2 preds: ^bb17, ^bb18
    llvm.br ^bb20
  ^bb20:  // pred: ^bb19
    %579 = llvm.add %372, %47 : i64
    llvm.store %579, %286 : i64, !llvm.ptr
    %580 = llvm.add %367, %44 overflow<nsw> : i32
    llvm.br ^bb3(%580, %387, %483, %578 : i32, i32, i32, i32)
  ^bb21:  // pred: ^bb3
    %581 = llvm.inttoptr %16 : i64 to !llvm.ptr<2>
    %582 = llvm.inttoptr %15 : i64 to !llvm.ptr<6>
    %583 = llvm.inttoptr %14 : i64 to !llvm.ptr<6>
    %584 = llvm.sub %334, %339 : i32
    %585 = llvm.add %584, %43 : i32
    %586 = llvm.add %339, %585 : i32
    llvm.br ^bb22(%339, %339, %339, %339 : i32, i32, i32, i32)
  ^bb22(%587: i32, %588: i32, %589: i32, %590: i32):  // 2 preds: ^bb21, ^bb39
    %591 = llvm.icmp "slt" %587, %586 : i32
    llvm.cond_br %591, ^bb23, ^bb40
  ^bb23:  // pred: ^bb22
    %592 = llvm.load %285 : !llvm.ptr -> i64
    %593 = llvm.urem %592, %46  : i64
    %594 = llvm.icmp "eq" %593, %47 : i64
    %595 = llvm.select %594, %211, %199 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %596 = llvm.select %594, %235, %223 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %597 = llvm.select %594, %259, %247 : i1, !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %598 = llvm.select %594, %283, %271 : i1, !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %599 = llvm.trunc %593 : i64 to i1
    %600 = llvm.select %599, %46, %48 : i1, i64
    %601 = llvm.select %599, %49, %50 : i1, i64
    %602 = llvm.xor %599, %45  : i1
    %603 = llvm.zext %602 : i1 to i64
    %604 = llvm.select %599, %48, %33 : i1, i64
    %605 = llvm.icmp "slt" %588, %334 : i32
    llvm.cond_br %605, ^bb24, ^bb25
  ^bb24:  // pred: ^bb23
    %606 = llvm.add %588, %44 : i32
    llvm.br ^bb26(%606 : i32)
  ^bb25:  // pred: ^bb23
    llvm.br ^bb26(%588 : i32)
  ^bb26(%607: i32):  // 2 preds: ^bb24, ^bb25
    llvm.br ^bb27
  ^bb27:  // pred: ^bb26
    %608 = llvm.load volatile %298 : !llvm.ptr<11> -> i32
    %609 = llvm.load volatile %299 : !llvm.ptr<11> -> i32
    %610 = llvm.icmp "slt" %608, %44 : i32
    %611 = llvm.icmp "slt" %609, %44 : i32
    %612 = llvm.and %610, %611  : i1
    %613 = llvm.icmp "slt" %589, %334 : i32
    %614 = llvm.and %612, %613  : i1
    llvm.cond_br %614, ^bb28, ^bb31
  ^bb28:  // pred: ^bb27
    %615 = llvm.mul %589, %28 : i32
    %616 = llvm.add %615, %28 : i32
    %617 = llvm.intr.smin(%616, %332)  : (i32, i32) -> i32
    %618 = llvm.sub %617, %615 : i32
    %619 = llvm.sext %618 : i32 to i64
    %620 = llvm.sext %arg15 : i32 to i64
    %621 = llvm.intr.smax(%619, %10)  : (i64, i64) -> i64
    %622 = llvm.intr.smin(%621, %31)  : (i64, i64) -> i64
    %623 = llvm.intr.smin(%622, %10)  : (i64, i64) -> i64
    %624 = llvm.mul %623, %1 : i64
    %625 = llvm.add %622, %624 : i64
    %626 = llvm.icmp "slt" %625, %31 : i64
    %627 = llvm.sdiv %615, %28  : i32
    %628 = llvm.srem %615, %28  : i32
    %629 = llvm.sext %627 : i32 to i64
    %630 = llvm.add %360, %629 : i64
    %631 = llvm.getelementptr %arg8[%630] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %632 = llvm.load %631 : !llvm.ptr<1> -> i32
    %633 = llvm.mul %632, %arg13 : i32
    %634 = llvm.sext %633 : i32 to i64
    %635 = llvm.sext %361 : i32 to i64
    %636 = llvm.mul %628, %arg15 : i32
    %637 = llvm.sext %636 : i32 to i64
    %638 = llvm.add %637, %634 : i64
    %639 = llvm.add %638, %635 : i64
    %640 = llvm.mul %623, %1 : i64
    %641 = llvm.add %622, %640 : i64
    %642 = llvm.add %641, %0 : i64
    %643 = llvm.icmp "slt" %642, %10 : i64
    %644 = llvm.sub %1, %642 : i64
    %645 = llvm.select %643, %644, %642 : i1, i64
    %646 = llvm.sdiv %645, %20  : i64
    %647 = llvm.sub %1, %646 : i64
    %648 = llvm.select %643, %647, %646 : i1, i64
    %649 = llvm.extractvalue %598[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %650 = llvm.extractvalue %598[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %651 = llvm.mul %623, %20 : i64
    llvm.cond_br %626, ^bb29, ^bb30
  ^bb29:  // pred: ^bb28
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %652 = llvm.extractvalue %598[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %653 = llvm.extractvalue %598[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%30, %652, %653, %10, %4, %8) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb30
  ^bb30:  // 2 preds: ^bb28, ^bb29
    "hivm.intr.hivm.WAIT.FLAG.REG"(%604) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.call @nd2nz_bfloat16_t(%arg4, %arg4, %639, %625, %32, %620, %8, %649, %650, %651, %20, %648, %20, %20, %7, %32, %20, %8) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%603) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %654 = llvm.extractvalue %325[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %655 = llvm.extractvalue %325[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %656 = llvm.extractvalue %325[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %657 = llvm.extractvalue %325[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %658 = llvm.extractvalue %325[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %659 = llvm.extractvalue %325[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %660 = llvm.extractvalue %325[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %661 = llvm.extractvalue %325[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %662 = llvm.extractvalue %325[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %663 = llvm.extractvalue %325[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %664 = llvm.extractvalue %325[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %665 = llvm.extractvalue %598[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %666 = llvm.extractvalue %598[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %667 = llvm.extractvalue %598[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %668 = llvm.extractvalue %598[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %669 = llvm.extractvalue %598[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %670 = llvm.extractvalue %598[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %671 = llvm.extractvalue %598[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %672 = llvm.extractvalue %598[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %673 = llvm.extractvalue %598[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %674 = llvm.extractvalue %598[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %675 = llvm.extractvalue %598[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %676 = llvm.extractvalue %597[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %677 = llvm.extractvalue %597[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %678 = llvm.extractvalue %597[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %679 = llvm.extractvalue %597[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %680 = llvm.extractvalue %597[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %681 = llvm.extractvalue %597[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %682 = llvm.extractvalue %597[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %683 = llvm.extractvalue %597[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %684 = llvm.extractvalue %597[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %685 = llvm.extractvalue %597[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %686 = llvm.extractvalue %597[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float_tb(%654, %655, %656, %657, %658, %659, %660, %661, %662, %663, %664, %665, %666, %667, %668, %669, %670, %671, %672, %673, %674, %675, %45, %25, %32, %31, %676, %677, %678, %679, %680, %681, %682, %683, %684, %685, %686, %51, %22, %51, %604, %51, %51, %51, %11) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 10 : i64}> : () -> ()
    %687 = llvm.extractvalue %597[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %688 = llvm.extractvalue %597[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %689 = llvm.extractvalue %597[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %690 = llvm.extractvalue %597[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %691 = llvm.extractvalue %597[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %692 = llvm.extractvalue %597[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %693 = llvm.extractvalue %597[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %694 = llvm.extractvalue %597[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %695 = llvm.extractvalue %597[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %696 = llvm.extractvalue %597[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %697 = llvm.extractvalue %597[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%687, %688, %689, %690, %691, %692, %693, %694, %695, %696, %697, %582, %582, %10, %25, %31, %31, %8, %22, %13, %22, %12, %11) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%603) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %698 = llvm.load volatile %298 : !llvm.ptr<11> -> i32
    %699 = llvm.load volatile %299 : !llvm.ptr<11> -> i32
    %700 = llvm.add %698, %44 : i32
    %701 = llvm.add %699, %44 : i32
    llvm.store volatile %700, %298 : i32, !llvm.ptr<11>
    llvm.store volatile %701, %299 : i32, !llvm.ptr<11>
    %702 = llvm.add %589, %44 : i32
    llvm.br ^bb32(%702 : i32)
  ^bb31:  // pred: ^bb27
    llvm.br ^bb32(%589 : i32)
  ^bb32(%703: i32):  // 2 preds: ^bb30, ^bb31
    llvm.br ^bb33
  ^bb33:  // pred: ^bb32
    %704 = llvm.load volatile %304 : !llvm.ptr<11> -> i32
    %705 = llvm.load volatile %305 : !llvm.ptr<11> -> i32
    %706 = llvm.icmp "sgt" %704, %23 : i32
    %707 = llvm.icmp "sgt" %705, %23 : i32
    %708 = llvm.and %706, %707  : i1
    %709 = llvm.load volatile %300 : !llvm.ptr<11> -> i32
    %710 = llvm.load volatile %301 : !llvm.ptr<11> -> i32
    %711 = llvm.icmp "slt" %709, %44 : i32
    %712 = llvm.icmp "slt" %710, %44 : i32
    %713 = llvm.and %711, %712  : i1
    %714 = llvm.and %708, %713  : i1
    %715 = llvm.icmp "slt" %590, %334 : i32
    %716 = llvm.and %714, %715  : i1
    llvm.cond_br %716, ^bb34, ^bb37
  ^bb34:  // pred: ^bb33
    %717 = llvm.mul %590, %28 : i32
    %718 = llvm.add %717, %28 : i32
    %719 = llvm.intr.smin(%718, %332)  : (i32, i32) -> i32
    %720 = llvm.sub %719, %717 : i32
    %721 = llvm.sext %arg18 : i32 to i64
    %722 = llvm.sext %720 : i32 to i64
    %723 = llvm.intr.smax(%722, %10)  : (i64, i64) -> i64
    %724 = llvm.intr.smin(%723, %31)  : (i64, i64) -> i64
    %725 = llvm.intr.smin(%724, %10)  : (i64, i64) -> i64
    %726 = llvm.mul %725, %1 : i64
    %727 = llvm.add %724, %726 : i64
    %728 = llvm.icmp "slt" %727, %31 : i64
    %729 = llvm.sdiv %717, %28  : i32
    %730 = llvm.srem %717, %28  : i32
    %731 = llvm.sext %729 : i32 to i64
    %732 = llvm.add %360, %731 : i64
    %733 = llvm.getelementptr %arg8[%732] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %734 = llvm.load %733 : !llvm.ptr<1> -> i32
    %735 = llvm.mul %734, %arg16 : i32
    %736 = llvm.sext %735 : i32 to i64
    %737 = llvm.sext %362 : i32 to i64
    %738 = llvm.mul %730, %arg18 : i32
    %739 = llvm.sext %738 : i32 to i64
    %740 = llvm.add %739, %736 : i64
    %741 = llvm.add %740, %737 : i64
    %742 = llvm.mul %725, %1 : i64
    %743 = llvm.add %724, %742 : i64
    %744 = llvm.add %743, %0 : i64
    %745 = llvm.icmp "slt" %744, %10 : i64
    %746 = llvm.sub %1, %744 : i64
    %747 = llvm.select %745, %746, %744 : i1, i64
    %748 = llvm.sdiv %747, %20  : i64
    %749 = llvm.sub %1, %748 : i64
    %750 = llvm.select %745, %749, %748 : i1, i64
    %751 = llvm.extractvalue %596[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %752 = llvm.extractvalue %596[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %753 = llvm.mul %725, %20 : i64
    llvm.cond_br %728, ^bb35, ^bb36
  ^bb35:  // pred: ^bb34
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %754 = llvm.extractvalue %596[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %755 = llvm.extractvalue %596[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @set_l1_2d_bfloat16_t(%30, %754, %755, %10, %4, %8) : (bf16, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 4 : i64}> : () -> ()
    llvm.br ^bb36
  ^bb36:  // 2 preds: ^bb34, ^bb35
    "hivm.intr.hivm.WAIT.FLAG.REG"(%601) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    llvm.call @nd2nz_bfloat16_t(%arg5, %arg5, %741, %727, %32, %721, %8, %751, %752, %753, %20, %750, %20, %20, %7, %32, %20, %8) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.REG"(%600) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %756 = llvm.extractvalue %596[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %757 = llvm.extractvalue %596[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %758 = llvm.extractvalue %596[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %759 = llvm.extractvalue %596[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %760 = llvm.extractvalue %596[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %761 = llvm.extractvalue %596[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %762 = llvm.extractvalue %596[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %763 = llvm.extractvalue %596[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %764 = llvm.extractvalue %596[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %765 = llvm.extractvalue %596[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %766 = llvm.extractvalue %596[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %767 = llvm.extractvalue %595[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %768 = llvm.extractvalue %595[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %769 = llvm.extractvalue %595[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %770 = llvm.extractvalue %595[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %771 = llvm.extractvalue %595[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %772 = llvm.extractvalue %595[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %773 = llvm.extractvalue %595[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %774 = llvm.extractvalue %595[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %775 = llvm.extractvalue %595[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %776 = llvm.extractvalue %595[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %777 = llvm.extractvalue %595[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @mma_tile_bfloat16_t_to_float(%581, %581, %10, %9, %8, %20, %20, %32, %32, %20, %8, %756, %757, %758, %759, %760, %761, %762, %763, %764, %765, %766, %45, %20, %31, %32, %767, %768, %769, %770, %771, %772, %773, %774, %775, %776, %777, %51, %22, %51, %601, %51, %51, %51, %11) : (!llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i64, !llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 10 : i64}> : () -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 10 : i64}> : () -> ()
    %778 = llvm.extractvalue %595[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %779 = llvm.extractvalue %595[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %780 = llvm.extractvalue %595[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %781 = llvm.extractvalue %595[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %782 = llvm.extractvalue %595[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %783 = llvm.extractvalue %595[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %784 = llvm.extractvalue %595[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %785 = llvm.extractvalue %595[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %786 = llvm.extractvalue %595[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %787 = llvm.extractvalue %595[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %788 = llvm.extractvalue %595[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    llvm.call @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%778, %779, %780, %781, %782, %783, %784, %785, %786, %787, %788, %583, %583, %10, %25, %32, %32, %8, %22, %13, %22, %12, %11) : (!llvm.ptr<5>, !llvm.ptr<5>, i64, i64, i64, i64, i64, i64, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, i64, f32, i64, i1, i8) -> ()
    "hivm.intr.hivm.SET.FLAG.REG"(%600) <{set_pipe = 10 : i64, wait_pipe = 2 : i64}> : (i64) -> ()
    %789 = llvm.load volatile %304 : !llvm.ptr<11> -> i32
    %790 = llvm.load volatile %305 : !llvm.ptr<11> -> i32
    %791 = llvm.sub %789, %44 : i32
    %792 = llvm.sub %790, %44 : i32
    llvm.store volatile %791, %304 : i32, !llvm.ptr<11>
    llvm.store volatile %792, %305 : i32, !llvm.ptr<11>
    %793 = llvm.load volatile %300 : !llvm.ptr<11> -> i32
    %794 = llvm.load volatile %301 : !llvm.ptr<11> -> i32
    %795 = llvm.add %793, %44 : i32
    %796 = llvm.add %794, %44 : i32
    llvm.store volatile %795, %300 : i32, !llvm.ptr<11>
    llvm.store volatile %796, %301 : i32, !llvm.ptr<11>
    %797 = llvm.add %590, %44 : i32
    llvm.br ^bb38(%797 : i32)
  ^bb37:  // pred: ^bb33
    llvm.br ^bb38(%590 : i32)
  ^bb38(%798: i32):  // 2 preds: ^bb36, ^bb37
    llvm.br ^bb39
  ^bb39:  // pred: ^bb38
    %799 = llvm.add %592, %47 : i64
    llvm.store %799, %285 : i64, !llvm.ptr
    %800 = llvm.add %587, %44 overflow<nsw> : i32
    llvm.br ^bb22(%800, %607, %703, %798 : i32, i32, i32, i32)
  ^bb40:  // pred: ^bb22
    "hivm.intr.hivm.SET.FLAG.REG"(%328) <{set_pipe = 3 : i64, wait_pipe = 4 : i64}> : (i64) -> ()
    %801 = llvm.add %322, %47 : i64
    llvm.store %801, %284 : i64, !llvm.ptr
    %802 = llvm.add %320, %44 overflow<nsw> : i32
    llvm.br ^bb1(%802 : i32)
  ^bb41:  // pred: ^bb1
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 2 : i64, wait_pipe = 3 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 2 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 10 : i64, wait_pipe = 2 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 3 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 4 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 5 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 6 : i64, set_pipe = 3 : i64, wait_pipe = 4 : i64}> : () -> ()
    %803 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %804 = "hivm.intr.hivm.SBITSET1"(%803, %3) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%804) : (i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 6 : i64}> : () -> ()
    llvm.return
  }
  llvm.func private @nd2nz_bfloat16_t(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<2>, %arg8: !llvm.ptr<2>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %15 = llvm.insertvalue %arg14, %14[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg15, %16[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg12, %17[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg13, %19[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %21, %22 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_nd2nz_bfloat16_t(%10, %22) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_nd2nz_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @set_l1_2d_bfloat16_t(%arg0: bf16, %arg1: !llvm.ptr<2>, %arg2: !llvm.ptr<2>, %arg3: i64, %arg4: i64, %arg5: i64) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg1, %1[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg4, %4[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg5, %5[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_set_l1_2d_bfloat16_t(%arg0, %7) : (bf16, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_set_l1_2d_bfloat16_t(bf16, !llvm.ptr) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @mma_tile_bfloat16_t_to_float_tb(%arg0: !llvm.ptr<2>, %arg1: !llvm.ptr<2>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<2>, %arg12: !llvm.ptr<2>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64, %arg21: i64, %arg22: i1, %arg23: i64, %arg24: i64, %arg25: i64, %arg26: !llvm.ptr<5>, %arg27: !llvm.ptr<5>, %arg28: i64, %arg29: i64, %arg30: i64, %arg31: i64, %arg32: i64, %arg33: i64, %arg34: i64, %arg35: i64, %arg36: i64, %arg37: i64, %arg38: i64, %arg39: i64, %arg40: i64, %arg41: i64, %arg42: i64, %arg43: i64, %arg44: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg18, %18[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.insertvalue %arg16, %21[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %24 = llvm.insertvalue %arg17, %23[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %25 = llvm.insertvalue %arg21, %24[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %26 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %25, %26 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %27 = llvm.insertvalue %arg26, %0[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %28 = llvm.insertvalue %arg27, %27[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %29 = llvm.insertvalue %arg28, %28[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %30 = llvm.insertvalue %arg29, %29[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %31 = llvm.insertvalue %arg33, %30[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %32 = llvm.insertvalue %arg30, %31[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %33 = llvm.insertvalue %arg34, %32[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %34 = llvm.insertvalue %arg31, %33[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %35 = llvm.insertvalue %arg35, %34[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %36 = llvm.insertvalue %arg32, %35[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %37 = llvm.insertvalue %arg36, %36[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %38 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %37, %38 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_mma_tile_bfloat16_t_to_float_tb(%14, %26, %arg22, %arg23, %arg24, %arg25, %38, %arg37, %arg38, %arg39, %arg40, %arg41, %arg42, %arg43, %arg44) : (!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_mma_tile_bfloat16_t_to_float_tb(!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%arg0: !llvm.ptr<5>, %arg1: !llvm.ptr<5>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<6>, %arg12: !llvm.ptr<6>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: f32, %arg20: i64, %arg21: i1, %arg22: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.insertvalue %arg17, %20[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %21, %22 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(%14, %22, %arg18, %arg19, %arg20, %arg21, %arg22) : (!llvm.ptr, !llvm.ptr, i64, f32, i64, i1, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_fixpipe_nz2nd_float_to_float_4d_to_2d_ubuf(!llvm.ptr, !llvm.ptr, i64, f32, i64, i1, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @mma_tile_bfloat16_t_to_float(%arg0: !llvm.ptr<2>, %arg1: !llvm.ptr<2>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: !llvm.ptr<2>, %arg12: !llvm.ptr<2>, %arg13: i64, %arg14: i64, %arg15: i64, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64, %arg21: i64, %arg22: i1, %arg23: i64, %arg24: i64, %arg25: i64, %arg26: !llvm.ptr<5>, %arg27: !llvm.ptr<5>, %arg28: i64, %arg29: i64, %arg30: i64, %arg31: i64, %arg32: i64, %arg33: i64, %arg34: i64, %arg35: i64, %arg36: i64, %arg37: i64, %arg38: i64, %arg39: i64, %arg40: i64, %arg41: i64, %arg42: i64, %arg43: i64, %arg44: i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %7 = llvm.insertvalue %arg7, %6[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %9 = llvm.insertvalue %arg8, %8[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %10 = llvm.insertvalue %arg5, %9[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %12 = llvm.insertvalue %arg6, %11[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %13 = llvm.insertvalue %arg10, %12[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %15 = llvm.insertvalue %arg11, %2[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %16 = llvm.insertvalue %arg12, %15[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %18 = llvm.insertvalue %arg14, %17[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %19 = llvm.insertvalue %arg18, %18[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %20 = llvm.insertvalue %arg15, %19[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %22 = llvm.insertvalue %arg16, %21[3, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %24 = llvm.insertvalue %arg17, %23[3, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %25 = llvm.insertvalue %arg21, %24[4, 3] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> 
    %26 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %25, %26 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    %27 = llvm.insertvalue %arg26, %0[0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %28 = llvm.insertvalue %arg27, %27[1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %29 = llvm.insertvalue %arg28, %28[2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %30 = llvm.insertvalue %arg29, %29[3, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %31 = llvm.insertvalue %arg33, %30[4, 0] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %32 = llvm.insertvalue %arg30, %31[3, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %33 = llvm.insertvalue %arg34, %32[4, 1] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %34 = llvm.insertvalue %arg31, %33[3, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %35 = llvm.insertvalue %arg35, %34[4, 2] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %36 = llvm.insertvalue %arg32, %35[3, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %37 = llvm.insertvalue %arg36, %36[4, 3] : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> 
    %38 = llvm.alloca %1 x !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %37, %38 : !llvm.struct<(ptr<5>, ptr<5>, i64, array<4 x i64>, array<4 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_mma_tile_bfloat16_t_to_float(%14, %26, %arg22, %arg23, %arg24, %arg25, %38, %arg37, %arg38, %arg39, %arg40, %arg41, %arg42, %arg43, %arg44) : (!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_mma_tile_bfloat16_t_to_float(!llvm.ptr, !llvm.ptr, i1, i64, i64, i64, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i8) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIC>, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @load_gm_to_ubuf_1d_float(%arg0: !llvm.ptr<1>, %arg1: !llvm.ptr<1>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i32, %arg11: f32, %arg12: i64, %arg13: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.insertvalue %arg4, %6[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> 
    %8 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %7, %8 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %9 = llvm.insertvalue %arg5, %0[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg6, %9[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg7, %10[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %13, %14 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_load_gm_to_ubuf_1d_float(%8, %14, %arg10, %arg11, %arg12, %arg13) : (!llvm.ptr, !llvm.ptr, i32, f32, i64, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_load_gm_to_ubuf_1d_float(!llvm.ptr, !llvm.ptr, i32, f32, i64, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_ubuf_1d_float(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg0, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg1, %2[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg2, %3[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg3, %4[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %8 = llvm.insertvalue %arg5, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg7, %9[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg8, %10[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg9, %11[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %12, %13 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_ubuf_1d_float(%7, %13) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_ubuf_1d_float(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_ubuf_1d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: !llvm.ptr<6>, %arg6: !llvm.ptr<6>, %arg7: i64, %arg8: i64, %arg9: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.constant(1 : index) : i64
    %1 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.insertvalue %arg0, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.insertvalue %arg1, %2[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.insertvalue %arg2, %3[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %5 = llvm.insertvalue %arg3, %4[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %7 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %6, %7 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    %8 = llvm.insertvalue %arg5, %1[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg7, %9[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg8, %10[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg9, %11[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.alloca %0 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %12, %13 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_ubuf_1d_bfloat16_t(%7, %13) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_ubuf_1d_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @copy_ubuf_to_cbuf_2d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<2>, %arg8: !llvm.ptr<2>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg12, %14[4, 0] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[4, 1] : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.alloca %1 x !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %17, %18 : !llvm.struct<(ptr<2>, ptr<2>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_copy_ubuf_to_cbuf_2d_bfloat16_t(%10, %18) : (!llvm.ptr, !llvm.ptr) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_copy_ubuf_to_cbuf_2d_bfloat16_t(!llvm.ptr, !llvm.ptr) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func private @store_ubuf_to_gm_2d_bfloat16_t(%arg0: !llvm.ptr<6>, %arg1: !llvm.ptr<6>, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr<1>, %arg8: !llvm.ptr<1>, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1 : index) : i64
    %2 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %3 = llvm.insertvalue %arg0, %2[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg1, %3[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg2, %4[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg3, %5[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg5, %6[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.insertvalue %arg4, %7[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %9 = llvm.insertvalue %arg6, %8[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.alloca %1 x !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %9, %10 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    %11 = llvm.insertvalue %arg7, %0[0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg8, %11[1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg9, %12[2] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg10, %13[3, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg12, %14[4, 0] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.insertvalue %arg11, %15[3, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %17 = llvm.insertvalue %arg13, %16[4, 1] : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.alloca %1 x !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)> : (i64) -> !llvm.ptr
    llvm.store %17, %18 : !llvm.struct<(ptr<1>, ptr<1>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.ptr
    llvm.call @_mlir_ciface_store_ubuf_to_gm_2d_bfloat16_t(%10, %18, %arg14) : (!llvm.ptr, !llvm.ptr, i32) -> ()
    llvm.return
  }
  llvm.func @_mlir_ciface_store_ubuf_to_gm_2d_bfloat16_t(!llvm.ptr, !llvm.ptr, i32) attributes {hacc.function_kind = #hacc.function_kind<DEVICE>, hacc.noinline, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, llvm.emit_c_interface, sym_visibility = "private"}
  llvm.func @_swa_paged_decode_sink_kernel_mix_aiv(%arg0: i64, %arg1: !llvm.ptr<1>, %arg2: !llvm.ptr<1>, %arg3: !llvm.ptr<1>, %arg4: !llvm.ptr<1>, %arg5: !llvm.ptr<1>, %arg6: !llvm.ptr<1>, %arg7: !llvm.ptr<1>, %arg8: !llvm.ptr<1>, %arg9: !llvm.ptr<1>, %arg10: i32, %arg11: i32, %arg12: i32, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32, %arg17: i32, %arg18: i32, %arg19: i32, %arg20: i32, %arg21: i32, %arg22: f32, %arg23: i32, %arg24: i32, %arg25: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix, hivm.vf_mode = #hivm.vf_mode<SIMD>, hivm_regbaseintrins.target = #hivm_regbaseintrins.target<"dav-c310">, mix_mode = "mix", parallel_mode = "simd"} {
    %0 = llvm.mlir.constant(-511 : index) : i64
    %1 = llvm.mlir.constant(575 : index) : i64
    %2 = llvm.mlir.constant(511 : index) : i64
    %3 = llvm.mlir.constant(272 : index) : i64
    %4 = llvm.mlir.constant(768 : index) : i64
    %5 = llvm.mlir.constant(4 : index) : i64
    %6 = llvm.mlir.constant(-1 : index) : i64
    %7 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %8 = llvm.mlir.undef : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %9 = llvm.mlir.constant(3072 : index) : i64
    %10 = llvm.mlir.constant(1 : index) : i64
    %11 = llvm.mlir.constant(256 : index) : i64
    %12 = llvm.mlir.constant(48 : i64) : i64
    %13 = llvm.mlir.constant(60 : i64) : i64
    %14 = llvm.mlir.constant(0 : index) : i64
    %15 = llvm.mlir.constant(64 : i32) : i32
    %16 = llvm.mlir.constant(63 : i32) : i32
    %17 = llvm.mlir.constant(512 : i32) : i32
    %18 = llvm.mlir.constant(12 : index) : i64
    %19 = llvm.mlir.constant(24 : index) : i64
    %20 = llvm.mlir.constant(2 : i32) : i32
    %21 = llvm.mlir.constant(0xFF800000 : f32) : f32
    %22 = llvm.mlir.constant(0 : i32) : i32
    %23 = llvm.mlir.constant(1024 : i64) : i64
    %24 = llvm.mlir.constant(0 : i64) : i64
    %25 = llvm.mlir.constant(12288 : i64) : i64
    %26 = llvm.mlir.constant(12352 : i64) : i64
    %27 = llvm.mlir.constant(12608 : i64) : i64
    %28 = llvm.mlir.constant(12864 : i64) : i64
    %29 = llvm.mlir.constant(60160 : i64) : i64
    %30 = llvm.mlir.constant(8192 : i64) : i64
    %31 = llvm.mlir.constant(13120 : i64) : i64
    %32 = llvm.mlir.constant(16192 : i64) : i64
    %33 = llvm.mlir.constant(28480 : i64) : i64
    %34 = llvm.mlir.constant(28544 : i64) : i64
    %35 = llvm.mlir.constant(28608 : i64) : i64
    %36 = llvm.mlir.constant(28672 : i64) : i64
    %37 = llvm.mlir.constant(60096 : i64) : i64
    %38 = llvm.mlir.constant(60224 : i64) : i64
    %39 = llvm.mlir.constant(28736 : i64) : i64
    %40 = llvm.mlir.constant(31808 : i64) : i64
    %41 = llvm.mlir.constant(36224 : i64) : i64
    %42 = llvm.mlir.constant(31872 : i64) : i64
    %43 = llvm.mlir.constant(33920 : i64) : i64
    %44 = llvm.mlir.constant(33984 : i64) : i64
    %45 = llvm.mlir.constant(34048 : i64) : i64
    %46 = llvm.mlir.constant(36288 : i64) : i64
    %47 = llvm.mlir.constant(75776 : i64) : i64
    %48 = llvm.mlir.constant(36352 : i64) : i64
    %49 = llvm.mlir.constant(39424 : i64) : i64
    %50 = llvm.mlir.constant(51712 : i64) : i64
    %51 = llvm.mlir.constant(51776 : i64) : i64
    %52 = llvm.mlir.constant(51840 : i64) : i64
    %53 = llvm.mlir.constant(51904 : i64) : i64
    %54 = llvm.mlir.constant(52224 : i64) : i64
    %55 = llvm.mlir.constant(51968 : i64) : i64
    %56 = llvm.mlir.constant(52480 : i64) : i64
    %57 = llvm.mlir.constant(55552 : i64) : i64
    %58 = llvm.mlir.constant(59968 : i64) : i64
    %59 = llvm.mlir.constant(55616 : i64) : i64
    %60 = llvm.mlir.constant(57664 : i64) : i64
    %61 = llvm.mlir.constant(57728 : i64) : i64
    %62 = llvm.mlir.constant(57792 : i64) : i64
    %63 = llvm.mlir.constant(60032 : i64) : i64
    %64 = llvm.mlir.constant(72512 : i64) : i64
    %65 = llvm.mlir.constant(12 : i32) : i32
    %66 = llvm.mlir.constant(64 : index) : i64
    %67 = llvm.mlir.constant(4 : i64) : i64
    %68 = llvm.mlir.constant(1028 : i64) : i64
    %69 = llvm.mlir.constant(8 : i64) : i64
    %70 = llvm.mlir.constant(1032 : i64) : i64
    %71 = llvm.mlir.constant(12 : i64) : i64
    %72 = llvm.mlir.constant(1036 : i64) : i64
    %73 = llvm.mlir.constant(16 : i64) : i64
    %74 = llvm.mlir.constant(1040 : i64) : i64
    %75 = llvm.mlir.constant(20 : i64) : i64
    %76 = llvm.mlir.constant(1044 : i64) : i64
    %77 = llvm.mlir.constant(3 : i32) : i32
    %78 = llvm.mlir.constant(1 : i32) : i32
    %79 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %80 = "hivm.intr.hivm.SBITSET0"(%79, %13) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%80) : (i64) -> ()
    %81 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %82 = "hivm.intr.hivm.SBITSET1"(%81, %12) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%82) : (i64) -> ()
    %83 = "hivm.intr.hivm.GET.BLOCK.IDX"() : () -> i64
    %84 = llvm.trunc %83 : i64 to i32
    %85 = llvm.srem %84, %arg23  : i32
    %86 = llvm.inttoptr %24 : i64 to !llvm.ptr<11>
    %87 = llvm.inttoptr %23 : i64 to !llvm.ptr<11>
    llvm.store volatile %22, %86 : i32, !llvm.ptr<11>
    llvm.store volatile %22, %87 : i32, !llvm.ptr<11>
    %88 = llvm.inttoptr %67 : i64 to !llvm.ptr<11>
    %89 = llvm.inttoptr %68 : i64 to !llvm.ptr<11>
    llvm.store volatile %22, %88 : i32, !llvm.ptr<11>
    llvm.store volatile %22, %89 : i32, !llvm.ptr<11>
    %90 = llvm.inttoptr %69 : i64 to !llvm.ptr<11>
    %91 = llvm.inttoptr %70 : i64 to !llvm.ptr<11>
    llvm.store volatile %22, %90 : i32, !llvm.ptr<11>
    llvm.store volatile %22, %91 : i32, !llvm.ptr<11>
    %92 = llvm.inttoptr %71 : i64 to !llvm.ptr<11>
    %93 = llvm.inttoptr %72 : i64 to !llvm.ptr<11>
    llvm.store volatile %22, %92 : i32, !llvm.ptr<11>
    llvm.store volatile %22, %93 : i32, !llvm.ptr<11>
    %94 = llvm.inttoptr %73 : i64 to !llvm.ptr<11>
    %95 = llvm.inttoptr %74 : i64 to !llvm.ptr<11>
    llvm.store volatile %22, %94 : i32, !llvm.ptr<11>
    llvm.store volatile %22, %95 : i32, !llvm.ptr<11>
    %96 = llvm.inttoptr %75 : i64 to !llvm.ptr<11>
    %97 = llvm.inttoptr %76 : i64 to !llvm.ptr<11>
    llvm.store volatile %22, %96 : i32, !llvm.ptr<11>
    llvm.store volatile %22, %97 : i32, !llvm.ptr<11>
    %98 = "hivm.intr.hivm.GET.SUBBLOCKID"() : () -> i64
    %99 = llvm.mul %98, %23 : i64
    %100 = llvm.add %99, %71 : i64
    %101 = llvm.inttoptr %100 : i64 to !llvm.ptr<11>
    %102 = llvm.add %99, %69 : i64
    %103 = llvm.inttoptr %102 : i64 to !llvm.ptr<11>
    %104 = llvm.add %99, %75 : i64
    %105 = llvm.inttoptr %104 : i64 to !llvm.ptr<11>
    %106 = llvm.add %99, %67 : i64
    %107 = llvm.inttoptr %106 : i64 to !llvm.ptr<11>
    %108 = llvm.inttoptr %99 : i64 to !llvm.ptr<11>
    %109 = llvm.add %99, %73 : i64
    %110 = llvm.inttoptr %109 : i64 to !llvm.ptr<11>
    %111 = llvm.inttoptr %24 : i64 to !llvm.ptr<6>
    %112 = llvm.inttoptr %25 : i64 to !llvm.ptr<6>
    %113 = llvm.mul %arg10, %20 : i32
    %114 = llvm.sdiv %113, %arg23  : i32
    %115 = llvm.mul %114, %arg23 : i32
    %116 = llvm.sub %113, %115 : i32
    %117 = llvm.mul %85, %114 : i32
    %118 = llvm.intr.smin(%85, %116)  : (i32, i32) -> i32
    %119 = llvm.add %117, %118 : i32
    %120 = llvm.sitofp %85 : i32 to f32
    %121 = llvm.sitofp %116 : i32 to f32
    %122 = llvm.fcmp "olt" %120, %121 : f32
    %123 = llvm.zext %122 : i1 to i32
    %124 = llvm.add %114, %123 : i32
    %125 = llvm.add %119, %124 : i32
    %126 = llvm.inttoptr %26 : i64 to !llvm.ptr<6>
    %127 = llvm.inttoptr %27 : i64 to !llvm.ptr<6>
    %128 = llvm.inttoptr %28 : i64 to !llvm.ptr<6>
    llvm.call @_swa_paged_decode_sink_kernel_outlined_merged_merged_vf_0(%111, %112, %126, %127, %128) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %129 = llvm.sext %arg20 : i32 to i64
    %130 = llvm.icmp "eq" %98, %14 : i64
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.br ^bb1(%119 : i32)
  ^bb1(%131: i32):  // 2 preds: ^bb0, ^bb48
    %132 = llvm.icmp "slt" %131, %125 : i32
    llvm.cond_br %132, ^bb2, ^bb49
  ^bb2:  // pred: ^bb1
    %133 = llvm.sdiv %131, %20  : i32
    %134 = llvm.mul %133, %20 : i32
    %135 = llvm.sub %131, %134 : i32
    %136 = llvm.sext %133 : i32 to i64
    %137 = llvm.getelementptr %arg7[%136] : (!llvm.ptr<1>, i64) -> !llvm.ptr<1>, i32
    %138 = llvm.load %137 : !llvm.ptr<1> -> i32
    %139 = llvm.mul %135, %65 : i32
    %140 = llvm.sext %139 : i32 to i64
    %141 = llvm.add %140, %18 : i64
    %142 = llvm.intr.smax(%140, %19)  : (i64, i64) -> i64
    %143 = llvm.intr.smin(%141, %142)  : (i64, i64) -> i64
    %144 = llvm.mul %140, %6 : i64
    %145 = llvm.add %143, %144 : i64
    %146 = llvm.icmp "slt" %145, %18 : i64
    %147 = llvm.add %138, %16 : i32
    %148 = llvm.sdiv %147, %15  : i32
    %149 = llvm.intr.smin(%148, %22)  : (i32, i32) -> i32
    %150 = llvm.sub %138, %17 : i32
    %151 = llvm.intr.smax(%150, %22)  : (i32, i32) -> i32
    %152 = llvm.sdiv %151, %15  : i32
    %153 = llvm.intr.smax(%149, %152)  : (i32, i32) -> i32
    %154 = llvm.icmp "sgt" %138, %22 : i32
    %155 = llvm.inttoptr %29 : i64 to !llvm.ptr<6>
    %156 = llvm.insertvalue %155, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %157 = llvm.insertvalue %155, %156[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %158 = llvm.insertvalue %14, %157[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %159 = llvm.insertvalue %18, %158[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %160 = llvm.insertvalue %10, %159[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.cond_br %146, ^bb3, ^bb4
  ^bb3:  // pred: ^bb2
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_0(%155) {hivm.vector_function, no_inline} : (!llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.br ^bb4
  ^bb4:  // 2 preds: ^bb2, ^bb3
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.call @load_gm_to_ubuf_1d_float(%arg9, %arg9, %140, %145, %10, %155, %155, %14, %145, %10, %20, %21, %14, %22) : (!llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i32, f32, i64, i32) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    %161 = llvm.sub %138, %78 : i32
    %162 = llvm.inttoptr %30 : i64 to !llvm.ptr<2>
    %163 = llvm.inttoptr %31 : i64 to !llvm.ptr<6>
    %164 = llvm.inttoptr %32 : i64 to !llvm.ptr<6>
    %165 = llvm.inttoptr %33 : i64 to !llvm.ptr<6>
    %166 = llvm.insertvalue %165, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %167 = llvm.insertvalue %165, %166[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %168 = llvm.insertvalue %14, %167[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %169 = llvm.insertvalue %18, %168[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %170 = llvm.insertvalue %10, %169[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %171 = llvm.inttoptr %34 : i64 to !llvm.ptr<6>
    %172 = llvm.insertvalue %171, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %173 = llvm.insertvalue %171, %172[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %174 = llvm.insertvalue %14, %173[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %175 = llvm.insertvalue %18, %174[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %176 = llvm.insertvalue %10, %175[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %177 = llvm.inttoptr %35 : i64 to !llvm.ptr<6>
    %178 = llvm.insertvalue %177, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %179 = llvm.insertvalue %177, %178[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %180 = llvm.insertvalue %14, %179[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %181 = llvm.insertvalue %18, %180[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %182 = llvm.insertvalue %10, %181[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %183 = llvm.inttoptr %36 : i64 to !llvm.ptr<6>
    %184 = llvm.insertvalue %183, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %185 = llvm.insertvalue %183, %184[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %186 = llvm.insertvalue %14, %185[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %187 = llvm.insertvalue %18, %186[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %188 = llvm.insertvalue %10, %187[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %189 = llvm.add %149, %77 : i32
    %190 = llvm.inttoptr %37 : i64 to !llvm.ptr<6>
    %191 = llvm.insertvalue %190, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %192 = llvm.insertvalue %190, %191[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %193 = llvm.insertvalue %14, %192[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %194 = llvm.insertvalue %18, %193[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %195 = llvm.insertvalue %10, %194[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%112, %112, %14, %18, %10, %190, %190, %14, %18, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %196 = llvm.inttoptr %38 : i64 to !llvm.ptr<6>
    %197 = llvm.insertvalue %196, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %198 = llvm.insertvalue %196, %197[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %199 = llvm.insertvalue %14, %198[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %200 = llvm.insertvalue %18, %199[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %201 = llvm.insertvalue %11, %200[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %202 = llvm.insertvalue %11, %201[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %203 = llvm.insertvalue %10, %202[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%111, %111, %14, %9, %10, %196, %196, %14, %9, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 4 : i64, wait_pipe = 1 : i64}> : () -> ()
    llvm.br ^bb5(%22, %195, %203, %160, %22, %22, %22, %22 : i32, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, i32, i32, i32, i32)
  ^bb5(%204: i32, %205: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %206: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %207: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %208: i32, %209: i32, %210: i32, %211: i32):  // 2 preds: ^bb4, ^bb20
    %212 = llvm.icmp "slt" %204, %189 : i32
    llvm.cond_br %212, ^bb6, ^bb21
  ^bb6:  // pred: ^bb5
    %213 = llvm.load volatile %108 : !llvm.ptr<11> -> i32
    %214 = llvm.icmp "sgt" %213, %22 : i32
    %215 = llvm.load volatile %110 : !llvm.ptr<11> -> i32
    %216 = llvm.icmp "slt" %215, %78 : i32
    %217 = llvm.and %214, %216  : i1
    %218 = llvm.icmp "slt" %210, %20 : i32
    %219 = llvm.icmp "slt" %211, %20 : i32
    %220 = llvm.and %218, %219  : i1
    %221 = llvm.icmp "slt" %208, %149 : i32
    %222 = llvm.and %217, %220  : i1
    %223 = llvm.and %222, %221  : i1
    llvm.cond_br %223, ^bb7, ^bb14
  ^bb7:  // pred: ^bb6
    %224 = llvm.mul %208, %15 : i32
    %225 = llvm.add %224, %15 : i32
    %226 = llvm.intr.smin(%225, %138)  : (i32, i32) -> i32
    %227 = llvm.sub %226, %224 : i32
    %228 = llvm.inttoptr %39 : i64 to !llvm.ptr<6>
    %229 = llvm.inttoptr %40 : i64 to !llvm.ptr<6>
    %230 = llvm.inttoptr %41 : i64 to !llvm.ptr<6>
    %231 = llvm.insertvalue %230, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %232 = llvm.insertvalue %230, %231[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %233 = llvm.insertvalue %14, %232[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %234 = llvm.insertvalue %18, %233[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %235 = llvm.insertvalue %10, %234[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %236 = llvm.extractvalue %207[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_1(%163, %128, %227, %224, %161, %arg22, %228, %229, %236, %230) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, i32, i32, i32, f32, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %237 = llvm.inttoptr %42 : i64 to !llvm.ptr<6>
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_2(%237) {hivm.vector_function, no_inline} : (!llvm.ptr<6>) -> ()
    %238 = llvm.inttoptr %39 : i64 to !llvm.ptr<6>
    %239 = llvm.inttoptr %43 : i64 to !llvm.ptr<6>
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_3(%228, %230, %238, %239) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%238, %238, %14, %4, %10, %237, %237, %14, %4, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %240 = llvm.srem %208, %20  : i32
    %241 = llvm.icmp "eq" %240, %22 : i32
    llvm.cond_br %241, ^bb8(%177 : !llvm.ptr<6>), ^bb8(%183 : !llvm.ptr<6>)
  ^bb8(%242: !llvm.ptr<6>):  // 2 preds: ^bb7, ^bb7
    llvm.call @copy_ubuf_to_ubuf_1d_float(%239, %239, %14, %18, %10, %242, %242, %14, %18, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.br ^bb9
  ^bb9:  // pred: ^bb8
    %243 = llvm.inttoptr %44 : i64 to !llvm.ptr<6>
    %244 = llvm.inttoptr %45 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %245 = llvm.extractvalue %207[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_decode_sink_kernel_outlined_merged_vf_2(%245, %230, %243, %237, %244) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %241, ^bb10(%165 : !llvm.ptr<6>), ^bb10(%171 : !llvm.ptr<6>)
  ^bb10(%246: !llvm.ptr<6>):  // 2 preds: ^bb9, ^bb9
    llvm.call @copy_ubuf_to_ubuf_1d_float(%243, %243, %14, %18, %10, %246, %246, %14, %18, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.br ^bb11
  ^bb11:  // pred: ^bb10
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %130, ^bb12, ^bb13
  ^bb12:  // pred: ^bb11
    llvm.call @copy_ubuf_to_cbuf_2d_bfloat16_t(%244, %244, %14, %5, %11, %3, %10, %162, %162, %14, %5, %11, %11, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64) -> ()
    llvm.br ^bb13
  ^bb13:  // 2 preds: ^bb11, ^bb12
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %247 = llvm.load volatile %108 : !llvm.ptr<11> -> i32
    %248 = llvm.sub %247, %78 : i32
    llvm.store volatile %248, %108 : i32, !llvm.ptr<11>
    %249 = llvm.load volatile %110 : !llvm.ptr<11> -> i32
    %250 = llvm.add %249, %78 : i32
    llvm.store volatile %250, %110 : i32, !llvm.ptr<11>
    %251 = llvm.add %210, %78 : i32
    %252 = llvm.add %211, %78 : i32
    %253 = llvm.add %208, %78 : i32
    llvm.br ^bb15(%235, %251, %252, %253 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, i32, i32, i32)
  ^bb14:  // pred: ^bb6
    %254 = llvm.inttoptr %41 : i64 to !llvm.ptr<6>
    %255 = llvm.insertvalue %254, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %256 = llvm.insertvalue %254, %255[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %257 = llvm.insertvalue %14, %256[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %258 = llvm.insertvalue %18, %257[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %259 = llvm.insertvalue %10, %258[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %260 = llvm.extractvalue %207[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %261 = llvm.extractvalue %207[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %262 = llvm.extractvalue %207[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %263 = llvm.extractvalue %207[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %264 = llvm.extractvalue %207[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%260, %261, %262, %263, %264, %254, %254, %14, %18, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.br ^bb15(%259, %210, %211, %208 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, i32, i32, i32)
  ^bb15(%265: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %266: i32, %267: i32, %268: i32):  // 2 preds: ^bb13, ^bb14
    llvm.br ^bb16
  ^bb16:  // pred: ^bb15
    %269 = llvm.load volatile %107 : !llvm.ptr<11> -> i32
    %270 = llvm.icmp "sgt" %269, %22 : i32
    %271 = llvm.icmp "sgt" %266, %22 : i32
    %272 = llvm.icmp "sgt" %267, %22 : i32
    %273 = llvm.and %271, %272  : i1
    %274 = llvm.icmp "slt" %209, %149 : i32
    %275 = llvm.and %270, %273  : i1
    %276 = llvm.and %275, %274  : i1
    llvm.cond_br %276, ^bb17, ^bb18
  ^bb17:  // pred: ^bb16
    %277 = llvm.srem %209, %20  : i32
    %278 = llvm.icmp "eq" %277, %22 : i32
    %279 = llvm.select %278, %170, %176 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %280 = llvm.inttoptr %46 : i64 to !llvm.ptr<6>
    %281 = llvm.extractvalue %279[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_6(%281, %280) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %282 = llvm.select %278, %182, %188 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %283 = llvm.inttoptr %37 : i64 to !llvm.ptr<6>
    %284 = llvm.insertvalue %283, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %285 = llvm.insertvalue %283, %284[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %286 = llvm.insertvalue %14, %285[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %287 = llvm.insertvalue %18, %286[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %288 = llvm.insertvalue %10, %287[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %289 = llvm.inttoptr %38 : i64 to !llvm.ptr<6>
    %290 = llvm.insertvalue %289, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %291 = llvm.insertvalue %289, %290[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %292 = llvm.insertvalue %14, %291[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %293 = llvm.insertvalue %18, %292[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %294 = llvm.insertvalue %11, %293[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %295 = llvm.insertvalue %11, %294[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %296 = llvm.insertvalue %10, %295[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %297 = llvm.extractvalue %205[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %298 = llvm.extractvalue %282[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %299 = llvm.extractvalue %206[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_7(%297, %280, %298, %283, %164, %299, %289) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %300 = llvm.load volatile %107 : !llvm.ptr<11> -> i32
    %301 = llvm.sub %300, %78 : i32
    llvm.store volatile %301, %107 : i32, !llvm.ptr<11>
    %302 = llvm.sub %266, %78 : i32
    %303 = llvm.sub %267, %78 : i32
    %304 = llvm.add %209, %78 : i32
    llvm.br ^bb19(%288, %296, %302, %303, %304 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, i32, i32, i32)
  ^bb18:  // pred: ^bb16
    llvm.br ^bb19(%205, %206, %266, %267, %209 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, i32, i32, i32)
  ^bb19(%305: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %306: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %307: i32, %308: i32, %309: i32):  // 2 preds: ^bb17, ^bb18
    llvm.br ^bb20
  ^bb20:  // pred: ^bb19
    %310 = llvm.inttoptr %29 : i64 to !llvm.ptr<6>
    %311 = llvm.insertvalue %310, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %312 = llvm.insertvalue %310, %311[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %313 = llvm.insertvalue %14, %312[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %314 = llvm.insertvalue %18, %313[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %315 = llvm.insertvalue %10, %314[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %316 = llvm.extractvalue %265[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %317 = llvm.extractvalue %265[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %318 = llvm.extractvalue %265[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %319 = llvm.extractvalue %265[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %320 = llvm.extractvalue %265[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%316, %317, %318, %319, %320, %310, %310, %14, %18, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %321 = llvm.add %204, %78 overflow<nsw> : i32
    llvm.br ^bb5(%321, %305, %306, %315, %268, %309, %307, %308 : i32, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, i32, i32, i32, i32)
  ^bb21:  // pred: ^bb5
    %322 = llvm.inttoptr %47 : i64 to !llvm.ptr<2>
    %323 = llvm.inttoptr %48 : i64 to !llvm.ptr<6>
    %324 = llvm.inttoptr %49 : i64 to !llvm.ptr<6>
    %325 = llvm.inttoptr %50 : i64 to !llvm.ptr<6>
    %326 = llvm.insertvalue %325, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %327 = llvm.insertvalue %325, %326[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %328 = llvm.insertvalue %14, %327[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %329 = llvm.insertvalue %18, %328[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %330 = llvm.insertvalue %10, %329[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %331 = llvm.inttoptr %51 : i64 to !llvm.ptr<6>
    %332 = llvm.insertvalue %331, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %333 = llvm.insertvalue %331, %332[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %334 = llvm.insertvalue %14, %333[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %335 = llvm.insertvalue %18, %334[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %336 = llvm.insertvalue %10, %335[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %337 = llvm.inttoptr %52 : i64 to !llvm.ptr<6>
    %338 = llvm.insertvalue %337, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %339 = llvm.insertvalue %337, %338[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %340 = llvm.insertvalue %14, %339[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %341 = llvm.insertvalue %18, %340[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %342 = llvm.insertvalue %10, %341[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %343 = llvm.inttoptr %53 : i64 to !llvm.ptr<6>
    %344 = llvm.insertvalue %343, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %345 = llvm.insertvalue %343, %344[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %346 = llvm.insertvalue %14, %345[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %347 = llvm.insertvalue %18, %346[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %348 = llvm.insertvalue %10, %347[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %349 = llvm.sub %148, %153 : i32
    %350 = llvm.add %349, %77 : i32
    %351 = llvm.add %153, %350 : i32
    llvm.br ^bb22(%153, %205, %206, %207, %153, %153, %22, %22 : i32, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, i32, i32, i32, i32)
  ^bb22(%352: i32, %353: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %354: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %355: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %356: i32, %357: i32, %358: i32, %359: i32):  // 2 preds: ^bb21, ^bb41
    %360 = llvm.icmp "slt" %352, %351 : i32
    llvm.cond_br %360, ^bb23, ^bb42
  ^bb23:  // pred: ^bb22
    %361 = llvm.load volatile %103 : !llvm.ptr<11> -> i32
    %362 = llvm.icmp "sgt" %361, %22 : i32
    %363 = llvm.load volatile %105 : !llvm.ptr<11> -> i32
    %364 = llvm.icmp "slt" %363, %78 : i32
    %365 = llvm.and %362, %364  : i1
    %366 = llvm.icmp "slt" %358, %20 : i32
    %367 = llvm.icmp "slt" %359, %20 : i32
    %368 = llvm.and %366, %367  : i1
    %369 = llvm.icmp "slt" %356, %148 : i32
    %370 = llvm.and %365, %368  : i1
    %371 = llvm.and %370, %369  : i1
    llvm.cond_br %371, ^bb24, ^bb35
  ^bb24:  // pred: ^bb23
    %372 = llvm.mul %356, %15 : i32
    %373 = llvm.add %372, %15 : i32
    %374 = llvm.intr.smin(%373, %138)  : (i32, i32) -> i32
    %375 = llvm.sub %374, %372 : i32
    %376 = llvm.sext %375 : i32 to i64
    %377 = llvm.intr.smax(%376, %14)  : (i64, i64) -> i64
    %378 = llvm.intr.smin(%377, %66)  : (i64, i64) -> i64
    %379 = llvm.sext %372 : i32 to i64
    %380 = llvm.add %379, %2 : i64
    %381 = llvm.add %379, %1 : i64
    %382 = llvm.sext %161 : i32 to i64
    %383 = llvm.intr.smax(%380, %382)  : (i64, i64) -> i64
    %384 = llvm.intr.smin(%381, %383)  : (i64, i64) -> i64
    %385 = llvm.mul %379, %6 : i64
    %386 = llvm.add %384, %385 : i64
    %387 = llvm.add %386, %0 : i64
    %388 = llvm.intr.smax(%387, %14)  : (i64, i64) -> i64
    %389 = llvm.intr.smin(%378, %66)  : (i64, i64) -> i64
    %390 = llvm.mul %388, %6 : i64
    %391 = llvm.add %389, %390 : i64
    %392 = llvm.intr.smax(%391, %14)  : (i64, i64) -> i64
    %393 = llvm.add %388, %392 : i64
    %394 = llvm.icmp "slt" %388, %14 : i64
    %395 = llvm.icmp "sge" %388, %66 : i64
    %396 = llvm.or %394, %395  : i1
    llvm.cond_br %396, ^bb25, ^bb26
  ^bb25:  // pred: ^bb24
    %397 = llvm.inttoptr %54 : i64 to !llvm.ptr<6>
    %398 = llvm.insertvalue %397, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %399 = llvm.insertvalue %397, %398[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %400 = llvm.insertvalue %14, %399[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %401 = llvm.insertvalue %10, %400[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %402 = llvm.insertvalue %66, %401[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %403 = llvm.insertvalue %66, %402[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %404 = llvm.insertvalue %10, %403[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%126, %126, %14, %66, %10, %397, %397, %14, %66, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.br ^bb27(%404 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>)
  ^bb26:  // pred: ^bb24
    %405 = llvm.inttoptr %55 : i64 to !llvm.ptr<6>
    llvm.call @copy_ubuf_to_ubuf_1d_float(%127, %127, %14, %66, %10, %405, %405, %14, %66, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_float(%126, %126, %14, %388, %10, %405, %405, %14, %388, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %406 = llvm.inttoptr %54 : i64 to !llvm.ptr<6>
    %407 = llvm.insertvalue %406, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %408 = llvm.insertvalue %406, %407[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %409 = llvm.insertvalue %14, %408[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %410 = llvm.insertvalue %10, %409[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %411 = llvm.insertvalue %66, %410[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %412 = llvm.insertvalue %66, %411[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %413 = llvm.insertvalue %10, %412[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%126, %126, %14, %66, %10, %406, %406, %14, %66, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_float(%405, %405, %14, %393, %10, %406, %406, %14, %393, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.br ^bb27(%413 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>)
  ^bb27(%414: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>):  // 2 preds: ^bb25, ^bb26
    llvm.br ^bb28
  ^bb28:  // pred: ^bb27
    %415 = llvm.inttoptr %56 : i64 to !llvm.ptr<6>
    %416 = llvm.inttoptr %57 : i64 to !llvm.ptr<6>
    %417 = llvm.inttoptr %58 : i64 to !llvm.ptr<6>
    %418 = llvm.insertvalue %417, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %419 = llvm.insertvalue %417, %418[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %420 = llvm.insertvalue %14, %419[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %421 = llvm.insertvalue %18, %420[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %422 = llvm.insertvalue %10, %421[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %423 = llvm.extractvalue %414[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %424 = llvm.extractvalue %355[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_8(%323, %423, %arg22, %415, %416, %424, %417) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, f32, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %425 = llvm.inttoptr %59 : i64 to !llvm.ptr<6>
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_9(%425) {hivm.vector_function, no_inline} : (!llvm.ptr<6>) -> ()
    %426 = llvm.inttoptr %56 : i64 to !llvm.ptr<6>
    %427 = llvm.inttoptr %60 : i64 to !llvm.ptr<6>
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_10(%415, %417, %426, %427) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    llvm.call @copy_ubuf_to_ubuf_1d_bfloat16_t(%426, %426, %14, %4, %10, %425, %425, %14, %4, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %428 = llvm.sub %356, %153 : i32
    %429 = llvm.srem %428, %20  : i32
    %430 = llvm.icmp "eq" %429, %22 : i32
    llvm.cond_br %430, ^bb29(%337 : !llvm.ptr<6>), ^bb29(%343 : !llvm.ptr<6>)
  ^bb29(%431: !llvm.ptr<6>):  // 2 preds: ^bb28, ^bb28
    llvm.call @copy_ubuf_to_ubuf_1d_float(%427, %427, %14, %18, %10, %431, %431, %14, %18, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.br ^bb30
  ^bb30:  // pred: ^bb29
    %432 = llvm.inttoptr %61 : i64 to !llvm.ptr<6>
    %433 = llvm.inttoptr %62 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %434 = llvm.extractvalue %355[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_decode_sink_kernel_outlined_merged_vf_3(%434, %417, %432, %425, %433) {hivm.vector_function, no_inline, ptc_simdvf} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %430, ^bb31(%325 : !llvm.ptr<6>), ^bb31(%331 : !llvm.ptr<6>)
  ^bb31(%435: !llvm.ptr<6>):  // 2 preds: ^bb30, ^bb30
    llvm.call @copy_ubuf_to_ubuf_1d_float(%432, %432, %14, %18, %10, %435, %435, %14, %18, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.br ^bb32
  ^bb32:  // pred: ^bb31
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %130, ^bb33, ^bb34
  ^bb33:  // pred: ^bb32
    llvm.call @copy_ubuf_to_cbuf_2d_bfloat16_t(%433, %433, %14, %5, %11, %3, %10, %322, %322, %14, %5, %11, %11, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<2>, !llvm.ptr<2>, i64, i64, i64, i64, i64) -> ()
    llvm.br ^bb34
  ^bb34:  // 2 preds: ^bb32, ^bb33
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %436 = llvm.load volatile %103 : !llvm.ptr<11> -> i32
    %437 = llvm.sub %436, %78 : i32
    llvm.store volatile %437, %103 : i32, !llvm.ptr<11>
    %438 = llvm.load volatile %105 : !llvm.ptr<11> -> i32
    %439 = llvm.add %438, %78 : i32
    llvm.store volatile %439, %105 : i32, !llvm.ptr<11>
    %440 = llvm.add %358, %78 : i32
    %441 = llvm.add %359, %78 : i32
    %442 = llvm.add %356, %78 : i32
    llvm.br ^bb36(%422, %440, %441, %442 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, i32, i32, i32)
  ^bb35:  // pred: ^bb23
    %443 = llvm.inttoptr %58 : i64 to !llvm.ptr<6>
    %444 = llvm.insertvalue %443, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %445 = llvm.insertvalue %443, %444[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %446 = llvm.insertvalue %14, %445[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %447 = llvm.insertvalue %18, %446[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %448 = llvm.insertvalue %10, %447[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %449 = llvm.extractvalue %355[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %450 = llvm.extractvalue %355[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %451 = llvm.extractvalue %355[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %452 = llvm.extractvalue %355[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %453 = llvm.extractvalue %355[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%449, %450, %451, %452, %453, %443, %443, %14, %18, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    llvm.br ^bb36(%448, %358, %359, %356 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, i32, i32, i32)
  ^bb36(%454: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %455: i32, %456: i32, %457: i32):  // 2 preds: ^bb34, ^bb35
    llvm.br ^bb37
  ^bb37:  // pred: ^bb36
    %458 = llvm.load volatile %101 : !llvm.ptr<11> -> i32
    %459 = llvm.icmp "sgt" %458, %22 : i32
    %460 = llvm.icmp "sgt" %455, %22 : i32
    %461 = llvm.icmp "sgt" %456, %22 : i32
    %462 = llvm.and %460, %461  : i1
    %463 = llvm.icmp "slt" %357, %148 : i32
    %464 = llvm.and %459, %462  : i1
    %465 = llvm.and %464, %463  : i1
    llvm.cond_br %465, ^bb38, ^bb39
  ^bb38:  // pred: ^bb37
    %466 = llvm.sub %357, %153 : i32
    %467 = llvm.srem %466, %20  : i32
    %468 = llvm.icmp "eq" %467, %22 : i32
    %469 = llvm.select %468, %330, %336 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %470 = llvm.inttoptr %63 : i64 to !llvm.ptr<6>
    %471 = llvm.extractvalue %469[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_13(%471, %470) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %472 = llvm.select %468, %342, %348 : i1, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %473 = llvm.inttoptr %37 : i64 to !llvm.ptr<6>
    %474 = llvm.insertvalue %473, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %475 = llvm.insertvalue %473, %474[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %476 = llvm.insertvalue %14, %475[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %477 = llvm.insertvalue %18, %476[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %478 = llvm.insertvalue %10, %477[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %479 = llvm.inttoptr %38 : i64 to !llvm.ptr<6>
    %480 = llvm.insertvalue %479, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %481 = llvm.insertvalue %479, %480[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %482 = llvm.insertvalue %14, %481[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %483 = llvm.insertvalue %18, %482[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %484 = llvm.insertvalue %11, %483[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %485 = llvm.insertvalue %11, %484[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %486 = llvm.insertvalue %10, %485[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %487 = llvm.extractvalue %353[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %488 = llvm.extractvalue %472[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %489 = llvm.extractvalue %354[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_14(%487, %470, %488, %473, %324, %489, %479) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    %490 = llvm.load volatile %101 : !llvm.ptr<11> -> i32
    %491 = llvm.sub %490, %78 : i32
    llvm.store volatile %491, %101 : i32, !llvm.ptr<11>
    %492 = llvm.sub %455, %78 : i32
    %493 = llvm.sub %456, %78 : i32
    %494 = llvm.add %357, %78 : i32
    llvm.br ^bb40(%478, %486, %492, %493, %494 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, i32, i32, i32)
  ^bb39:  // pred: ^bb37
    llvm.br ^bb40(%353, %354, %455, %456, %357 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, i32, i32, i32)
  ^bb40(%495: !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, %496: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, %497: i32, %498: i32, %499: i32):  // 2 preds: ^bb38, ^bb39
    llvm.br ^bb41
  ^bb41:  // pred: ^bb40
    %500 = llvm.inttoptr %29 : i64 to !llvm.ptr<6>
    %501 = llvm.insertvalue %500, %7[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %502 = llvm.insertvalue %500, %501[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %503 = llvm.insertvalue %14, %502[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %504 = llvm.insertvalue %18, %503[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %505 = llvm.insertvalue %10, %504[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %506 = llvm.extractvalue %454[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %507 = llvm.extractvalue %454[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %508 = llvm.extractvalue %454[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %509 = llvm.extractvalue %454[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %510 = llvm.extractvalue %454[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @copy_ubuf_to_ubuf_1d_float(%506, %507, %508, %509, %510, %500, %500, %14, %18, %10) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, !llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64) -> ()
    %511 = llvm.add %352, %78 overflow<nsw> : i32
    llvm.br ^bb22(%511, %495, %496, %505, %457, %499, %497, %498 : i32, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>, !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>, i32, i32, i32, i32)
  ^bb42:  // pred: ^bb22
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    llvm.cond_br %154, ^bb43, ^bb44
  ^bb43:  // pred: ^bb42
    %512 = llvm.inttoptr %38 : i64 to !llvm.ptr<6>
    %513 = llvm.insertvalue %512, %8[0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %514 = llvm.insertvalue %512, %513[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %515 = llvm.insertvalue %14, %514[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %516 = llvm.insertvalue %18, %515[3, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %517 = llvm.insertvalue %11, %516[3, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %518 = llvm.insertvalue %11, %517[4, 0] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %519 = llvm.insertvalue %10, %518[4, 1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %520 = llvm.extractvalue %353[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %521 = llvm.extractvalue %354[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_15(%520, %521, %512) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>, !llvm.ptr<6>) -> ()
    llvm.br ^bb45(%519 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>)
  ^bb44:  // pred: ^bb42
    llvm.br ^bb45(%354 : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>)
  ^bb45(%522: !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>):  // 2 preds: ^bb43, ^bb44
    llvm.br ^bb46
  ^bb46:  // pred: ^bb45
    %523 = llvm.mul %133, %arg19 : i32
    %524 = llvm.sext %523 : i32 to i64
    %525 = llvm.mul %140, %129 : i64
    %526 = llvm.add %524, %525 : i64
    %527 = llvm.inttoptr %64 : i64 to !llvm.ptr<6>
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %528 = llvm.extractvalue %522[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @_swa_paged_decode_sink_kernel_outlined_vf_16(%528, %527) {hivm.vector_function, no_inline} : (!llvm.ptr<6>, !llvm.ptr<6>) -> ()
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 5 : i64}> : () -> ()
    llvm.cond_br %130, ^bb47, ^bb48
  ^bb47:  // pred: ^bb46
    llvm.call @store_ubuf_to_gm_2d_bfloat16_t(%527, %527, %14, %18, %11, %11, %10, %arg6, %arg6, %526, %18, %11, %129, %10, %22) : (!llvm.ptr<6>, !llvm.ptr<6>, i64, i64, i64, i64, i64, !llvm.ptr<1>, !llvm.ptr<1>, i64, i64, i64, i64, i64, i32) -> ()
    llvm.br ^bb48
  ^bb48:  // 2 preds: ^bb46, ^bb47
    "hivm.intr.hivm.SET.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    %529 = llvm.add %131, %78 overflow<nsw> : i32
    llvm.br ^bb1(%529 : i32)
  ^bb49:  // pred: ^bb1
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 1 : i64, wait_pipe = 4 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 0 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.WAIT.FLAG.IMM"() <{event_id = 1 : i64, set_pipe = 5 : i64, wait_pipe = 1 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 1 : i64, sync_id = 0 : i64}> : () -> ()
    "hivm.intr.hivm.SET.INTRA.BLOCKI.mode"() <{pipe = 5 : i64, sync_id = 1 : i64}> : () -> ()
    %530 = "hivm.intr.hivm.GET.CTRL"() : () -> i64
    %531 = "hivm.intr.hivm.SBITSET1"(%530, %13) : (i64, i64) -> i64
    "hivm.intr.hivm.SET.CTRL"(%531) : (i64) -> ()
    "hivm.intr.hivm.BARRIER"() <{pipe = 6 : i64}> : () -> ()
    llvm.return
  }
}


bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
ld.lld: warning: -z separate-code and -z separate-loadable-segments will be ignored
